/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.LogWorkServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.LogWorkServiceSoap
 * @generated
 */
public class LogWorkSoap implements Serializable {
	public static LogWorkSoap toSoapModel(LogWork model) {
		LogWorkSoap soapModel = new LogWorkSoap();

		soapModel.setLogworkId(model.getLogworkId());
		soapModel.setUser(model.getUser());
		soapModel.setTime(model.getTime());
		soapModel.setDetail(model.getDetail());
		soapModel.setChronicle(model.getChronicle());

		return soapModel;
	}

	public static LogWorkSoap[] toSoapModels(LogWork[] models) {
		LogWorkSoap[] soapModels = new LogWorkSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LogWorkSoap[][] toSoapModels(LogWork[][] models) {
		LogWorkSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LogWorkSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LogWorkSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LogWorkSoap[] toSoapModels(List<LogWork> models) {
		List<LogWorkSoap> soapModels = new ArrayList<LogWorkSoap>(models.size());

		for (LogWork model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LogWorkSoap[soapModels.size()]);
	}

	public LogWorkSoap() {
	}

	public long getPrimaryKey() {
		return _logworkId;
	}

	public void setPrimaryKey(long pk) {
		setLogworkId(pk);
	}

	public long getLogworkId() {
		return _logworkId;
	}

	public void setLogworkId(long logworkId) {
		_logworkId = logworkId;
	}

	public String getUser() {
		return _user;
	}

	public void setUser(String user) {
		_user = user;
	}

	public String getTime() {
		return _time;
	}

	public void setTime(String time) {
		_time = time;
	}

	public String getDetail() {
		return _detail;
	}

	public void setDetail(String detail) {
		_detail = detail;
	}

	public String getChronicle() {
		return _chronicle;
	}

	public void setChronicle(String chronicle) {
		_chronicle = chronicle;
	}

	private long _logworkId;
	private String _user;
	private String _time;
	private String _detail;
	private String _chronicle;
}