/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.EmployeeAuditServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.EmployeeAuditServiceSoap
 * @generated
 */
public class EmployeeAuditSoap implements Serializable {
	public static EmployeeAuditSoap toSoapModel(EmployeeAudit model) {
		EmployeeAuditSoap soapModel = new EmployeeAuditSoap();

		soapModel.setAditid(model.getAditid());
		soapModel.setDateonroad(model.getDateonroad());
		soapModel.setDateofincident(model.getDateofincident());
		soapModel.setTimeevent(model.getTimeevent());
		soapModel.setTitleinvestigation(model.getTitleinvestigation());
		soapModel.setTypeofvehicle(model.getTypeofvehicle());
		soapModel.setNoregistration(model.getNoregistration());
		soapModel.setCompany(model.getCompany());
		soapModel.setReportsKjr(model.getReportsKjr());
		soapModel.setReportscmd(model.getReportscmd());
		soapModel.setSrustatus(model.getSrustatus());
		soapModel.setCompletedStatus(model.getCompletedStatus());
		soapModel.setAudidate(model.getAudidate());
		soapModel.setAuditime(model.getAuditime());
		soapModel.setStatusofadudit(model.getStatusofadudit());
		soapModel.setCompleteddate(model.getCompleteddate());
		soapModel.setAddresss(model.getAddresss());
		soapModel.setLocationofincident(model.getLocationofincident());
		soapModel.setTrainingattendance(model.getTrainingattendance());
		soapModel.setAuditaccidents(model.getAuditaccidents());
		soapModel.setTypecertificate(model.getTypecertificate());
		soapModel.setDateofregistration(model.getDateofregistration());
		soapModel.setTrainingdates(model.getTrainingdates());
		soapModel.setEnddate(model.getEnddate());
		soapModel.setTypemod(model.getTypemod());
		soapModel.setTypeoflicens(model.getTypeoflicens());
		soapModel.setTypeofcompany(model.getTypeofcompany());
		soapModel.setPhoneno(model.getPhoneno());
		soapModel.setStatus(model.getStatus());
		soapModel.setAppendixg(model.getAppendixg());
		soapModel.setDateCaseSrU(model.getDateCaseSrU());
		soapModel.setActionSru(model.getActionSru());
		soapModel.setOfficerName(model.getOfficerName());
		soapModel.setVehiclesNo(model.getVehiclesNo());
		soapModel.setCompanyEmail(model.getCompanyEmail());
		soapModel.setRepresentativeName(model.getRepresentativeName());
		soapModel.setCompanieListNumber(model.getCompanieListNumber());

		return soapModel;
	}

	public static EmployeeAuditSoap[] toSoapModels(EmployeeAudit[] models) {
		EmployeeAuditSoap[] soapModels = new EmployeeAuditSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EmployeeAuditSoap[][] toSoapModels(EmployeeAudit[][] models) {
		EmployeeAuditSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EmployeeAuditSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EmployeeAuditSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EmployeeAuditSoap[] toSoapModels(List<EmployeeAudit> models) {
		List<EmployeeAuditSoap> soapModels = new ArrayList<EmployeeAuditSoap>(models.size());

		for (EmployeeAudit model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EmployeeAuditSoap[soapModels.size()]);
	}

	public EmployeeAuditSoap() {
	}

	public long getPrimaryKey() {
		return _aditid;
	}

	public void setPrimaryKey(long pk) {
		setAditid(pk);
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getDateonroad() {
		return _dateonroad;
	}

	public void setDateonroad(String dateonroad) {
		_dateonroad = dateonroad;
	}

	public String getDateofincident() {
		return _dateofincident;
	}

	public void setDateofincident(String dateofincident) {
		_dateofincident = dateofincident;
	}

	public String getTimeevent() {
		return _timeevent;
	}

	public void setTimeevent(String timeevent) {
		_timeevent = timeevent;
	}

	public String getTitleinvestigation() {
		return _titleinvestigation;
	}

	public void setTitleinvestigation(String titleinvestigation) {
		_titleinvestigation = titleinvestigation;
	}

	public String getTypeofvehicle() {
		return _typeofvehicle;
	}

	public void setTypeofvehicle(String typeofvehicle) {
		_typeofvehicle = typeofvehicle;
	}

	public String getNoregistration() {
		return _noregistration;
	}

	public void setNoregistration(String noregistration) {
		_noregistration = noregistration;
	}

	public String getCompany() {
		return _company;
	}

	public void setCompany(String company) {
		_company = company;
	}

	public String getReportsKjr() {
		return _reportsKjr;
	}

	public void setReportsKjr(String reportsKjr) {
		_reportsKjr = reportsKjr;
	}

	public String getReportscmd() {
		return _reportscmd;
	}

	public void setReportscmd(String reportscmd) {
		_reportscmd = reportscmd;
	}

	public String getSrustatus() {
		return _srustatus;
	}

	public void setSrustatus(String srustatus) {
		_srustatus = srustatus;
	}

	public String getCompletedStatus() {
		return _completedStatus;
	}

	public void setCompletedStatus(String completedStatus) {
		_completedStatus = completedStatus;
	}

	public String getAudidate() {
		return _audidate;
	}

	public void setAudidate(String audidate) {
		_audidate = audidate;
	}

	public String getAuditime() {
		return _auditime;
	}

	public void setAuditime(String auditime) {
		_auditime = auditime;
	}

	public String getStatusofadudit() {
		return _statusofadudit;
	}

	public void setStatusofadudit(String statusofadudit) {
		_statusofadudit = statusofadudit;
	}

	public String getCompleteddate() {
		return _completeddate;
	}

	public void setCompleteddate(String completeddate) {
		_completeddate = completeddate;
	}

	public String getAddresss() {
		return _addresss;
	}

	public void setAddresss(String addresss) {
		_addresss = addresss;
	}

	public String getLocationofincident() {
		return _locationofincident;
	}

	public void setLocationofincident(String locationofincident) {
		_locationofincident = locationofincident;
	}

	public String getTrainingattendance() {
		return _trainingattendance;
	}

	public void setTrainingattendance(String trainingattendance) {
		_trainingattendance = trainingattendance;
	}

	public String getAuditaccidents() {
		return _auditaccidents;
	}

	public void setAuditaccidents(String auditaccidents) {
		_auditaccidents = auditaccidents;
	}

	public String getTypecertificate() {
		return _typecertificate;
	}

	public void setTypecertificate(String typecertificate) {
		_typecertificate = typecertificate;
	}

	public String getDateofregistration() {
		return _dateofregistration;
	}

	public void setDateofregistration(String dateofregistration) {
		_dateofregistration = dateofregistration;
	}

	public String getTrainingdates() {
		return _trainingdates;
	}

	public void setTrainingdates(String trainingdates) {
		_trainingdates = trainingdates;
	}

	public String getEnddate() {
		return _enddate;
	}

	public void setEnddate(String enddate) {
		_enddate = enddate;
	}

	public String getTypemod() {
		return _typemod;
	}

	public void setTypemod(String typemod) {
		_typemod = typemod;
	}

	public String getTypeoflicens() {
		return _typeoflicens;
	}

	public void setTypeoflicens(String typeoflicens) {
		_typeoflicens = typeoflicens;
	}

	public String getTypeofcompany() {
		return _typeofcompany;
	}

	public void setTypeofcompany(String typeofcompany) {
		_typeofcompany = typeofcompany;
	}

	public String getPhoneno() {
		return _phoneno;
	}

	public void setPhoneno(String phoneno) {
		_phoneno = phoneno;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public String getAppendixg() {
		return _appendixg;
	}

	public void setAppendixg(String appendixg) {
		_appendixg = appendixg;
	}

	public String getDateCaseSrU() {
		return _dateCaseSrU;
	}

	public void setDateCaseSrU(String dateCaseSrU) {
		_dateCaseSrU = dateCaseSrU;
	}

	public String getActionSru() {
		return _actionSru;
	}

	public void setActionSru(String actionSru) {
		_actionSru = actionSru;
	}

	public String getOfficerName() {
		return _officerName;
	}

	public void setOfficerName(String officerName) {
		_officerName = officerName;
	}

	public String getVehiclesNo() {
		return _vehiclesNo;
	}

	public void setVehiclesNo(String vehiclesNo) {
		_vehiclesNo = vehiclesNo;
	}

	public String getCompanyEmail() {
		return _companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		_companyEmail = companyEmail;
	}

	public String getRepresentativeName() {
		return _representativeName;
	}

	public void setRepresentativeName(String representativeName) {
		_representativeName = representativeName;
	}

	public String getCompanieListNumber() {
		return _companieListNumber;
	}

	public void setCompanieListNumber(String companieListNumber) {
		_companieListNumber = companieListNumber;
	}

	private long _aditid;
	private String _dateonroad;
	private String _dateofincident;
	private String _timeevent;
	private String _titleinvestigation;
	private String _typeofvehicle;
	private String _noregistration;
	private String _company;
	private String _reportsKjr;
	private String _reportscmd;
	private String _srustatus;
	private String _completedStatus;
	private String _audidate;
	private String _auditime;
	private String _statusofadudit;
	private String _completeddate;
	private String _addresss;
	private String _locationofincident;
	private String _trainingattendance;
	private String _auditaccidents;
	private String _typecertificate;
	private String _dateofregistration;
	private String _trainingdates;
	private String _enddate;
	private String _typemod;
	private String _typeoflicens;
	private String _typeofcompany;
	private String _phoneno;
	private String _status;
	private String _appendixg;
	private String _dateCaseSrU;
	private String _actionSru;
	private String _officerName;
	private String _vehiclesNo;
	private String _companyEmail;
	private String _representativeName;
	private String _companieListNumber;
}