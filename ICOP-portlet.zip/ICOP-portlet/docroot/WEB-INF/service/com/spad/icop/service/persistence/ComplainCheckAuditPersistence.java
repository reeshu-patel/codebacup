/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.spad.icop.model.ComplainCheckAudit;

/**
 * The persistence interface for the complain check audit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see ComplainCheckAuditPersistenceImpl
 * @see ComplainCheckAuditUtil
 * @generated
 */
public interface ComplainCheckAuditPersistence extends BasePersistence<ComplainCheckAudit> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link ComplainCheckAuditUtil} to access the complain check audit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the complain check audits where aditid = &#63;.
	*
	* @param aditid the aditid
	* @return the matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findByaditid(
		long aditid) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the complain check audits where aditid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @return the range of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findByaditid(
		long aditid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the complain check audits where aditid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findByaditid(
		long aditid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first complain check audit in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit findByaditid_First(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Returns the first complain check audit in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit fetchByaditid_First(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last complain check audit in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit findByaditid_Last(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Returns the last complain check audit in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit fetchByaditid_Last(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the complain check audits before and after the current complain check audit in the ordered set where aditid = &#63;.
	*
	* @param matterId the primary key of the current complain check audit
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit[] findByaditid_PrevAndNext(
		long matterId, long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Removes all the complain check audits where aditid = &#63; from the database.
	*
	* @param aditid the aditid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByaditid(long aditid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of complain check audits where aditid = &#63;.
	*
	* @param aditid the aditid
	* @return the number of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public int countByaditid(long aditid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the complain check audits where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @return the matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findBymetterAudit(
		long aditid, long matterId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the complain check audits where aditid = &#63; and matterId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @return the range of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findBymetterAudit(
		long aditid, long matterId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the complain check audits where aditid = &#63; and matterId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findBymetterAudit(
		long aditid, long matterId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit findBymetterAudit_First(
		long aditid, long matterId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Returns the first complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit fetchBymetterAudit_First(
		long aditid, long matterId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit findBymetterAudit_Last(
		long aditid, long matterId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Returns the last complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit fetchBymetterAudit_Last(
		long aditid, long matterId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the complain check audits where aditid = &#63; and matterId = &#63; from the database.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBymetterAudit(long aditid, long matterId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of complain check audits where aditid = &#63; and matterId = &#63;.
	*
	* @param aditid the aditid
	* @param matterId the matter ID
	* @return the number of matching complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public int countBymetterAudit(long aditid, long matterId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the complain check audit in the entity cache if it is enabled.
	*
	* @param complainCheckAudit the complain check audit
	*/
	public void cacheResult(
		com.spad.icop.model.ComplainCheckAudit complainCheckAudit);

	/**
	* Caches the complain check audits in the entity cache if it is enabled.
	*
	* @param complainCheckAudits the complain check audits
	*/
	public void cacheResult(
		java.util.List<com.spad.icop.model.ComplainCheckAudit> complainCheckAudits);

	/**
	* Creates a new complain check audit with the primary key. Does not add the complain check audit to the database.
	*
	* @param matterId the primary key for the new complain check audit
	* @return the new complain check audit
	*/
	public com.spad.icop.model.ComplainCheckAudit create(long matterId);

	/**
	* Removes the complain check audit with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param matterId the primary key of the complain check audit
	* @return the complain check audit that was removed
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit remove(long matterId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	public com.spad.icop.model.ComplainCheckAudit updateImpl(
		com.spad.icop.model.ComplainCheckAudit complainCheckAudit)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the complain check audit with the primary key or throws a {@link com.spad.icop.NoSuchComplainCheckAuditException} if it could not be found.
	*
	* @param matterId the primary key of the complain check audit
	* @return the complain check audit
	* @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit findByPrimaryKey(
		long matterId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchComplainCheckAuditException;

	/**
	* Returns the complain check audit with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param matterId the primary key of the complain check audit
	* @return the complain check audit, or <code>null</code> if a complain check audit with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.spad.icop.model.ComplainCheckAudit fetchByPrimaryKey(
		long matterId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the complain check audits.
	*
	* @return the complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the complain check audits.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @return the range of complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the complain check audits.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of complain check audits
	* @param end the upper bound of the range of complain check audits (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.spad.icop.model.ComplainCheckAudit> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the complain check audits from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of complain check audits.
	*
	* @return the number of complain check audits
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}