/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link AppointmentCall}.
 * </p>
 *
 * @author reeshu
 * @see AppointmentCall
 * @generated
 */
public class AppointmentCallWrapper implements AppointmentCall,
	ModelWrapper<AppointmentCall> {
	public AppointmentCallWrapper(AppointmentCall appointmentCall) {
		_appointmentCall = appointmentCall;
	}

	@Override
	public Class<?> getModelClass() {
		return AppointmentCall.class;
	}

	@Override
	public String getModelClassName() {
		return AppointmentCall.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recordcallid", getRecordcallid());
		attributes.put("aditid", getAditid());
		attributes.put("dateonroadsafty", getDateonroadsafty());
		attributes.put("time", getTime());
		attributes.put("investigationtitle", getInvestigationtitle());
		attributes.put("location", getLocation());
		attributes.put("company", getCompany());
		attributes.put("statusverification", getStatusverification());
		attributes.put("operatorname", getOperatorname());
		attributes.put("nameofOfficer", getNameofOfficer());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recordcallid = (Long)attributes.get("recordcallid");

		if (recordcallid != null) {
			setRecordcallid(recordcallid);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String dateonroadsafty = (String)attributes.get("dateonroadsafty");

		if (dateonroadsafty != null) {
			setDateonroadsafty(dateonroadsafty);
		}

		String time = (String)attributes.get("time");

		if (time != null) {
			setTime(time);
		}

		String investigationtitle = (String)attributes.get("investigationtitle");

		if (investigationtitle != null) {
			setInvestigationtitle(investigationtitle);
		}

		String location = (String)attributes.get("location");

		if (location != null) {
			setLocation(location);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String statusverification = (String)attributes.get("statusverification");

		if (statusverification != null) {
			setStatusverification(statusverification);
		}

		String operatorname = (String)attributes.get("operatorname");

		if (operatorname != null) {
			setOperatorname(operatorname);
		}

		String nameofOfficer = (String)attributes.get("nameofOfficer");

		if (nameofOfficer != null) {
			setNameofOfficer(nameofOfficer);
		}
	}

	/**
	* Returns the primary key of this appointment call.
	*
	* @return the primary key of this appointment call
	*/
	@Override
	public long getPrimaryKey() {
		return _appointmentCall.getPrimaryKey();
	}

	/**
	* Sets the primary key of this appointment call.
	*
	* @param primaryKey the primary key of this appointment call
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_appointmentCall.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the recordcallid of this appointment call.
	*
	* @return the recordcallid of this appointment call
	*/
	@Override
	public long getRecordcallid() {
		return _appointmentCall.getRecordcallid();
	}

	/**
	* Sets the recordcallid of this appointment call.
	*
	* @param recordcallid the recordcallid of this appointment call
	*/
	@Override
	public void setRecordcallid(long recordcallid) {
		_appointmentCall.setRecordcallid(recordcallid);
	}

	/**
	* Returns the aditid of this appointment call.
	*
	* @return the aditid of this appointment call
	*/
	@Override
	public long getAditid() {
		return _appointmentCall.getAditid();
	}

	/**
	* Sets the aditid of this appointment call.
	*
	* @param aditid the aditid of this appointment call
	*/
	@Override
	public void setAditid(long aditid) {
		_appointmentCall.setAditid(aditid);
	}

	/**
	* Returns the dateonroadsafty of this appointment call.
	*
	* @return the dateonroadsafty of this appointment call
	*/
	@Override
	public java.lang.String getDateonroadsafty() {
		return _appointmentCall.getDateonroadsafty();
	}

	/**
	* Sets the dateonroadsafty of this appointment call.
	*
	* @param dateonroadsafty the dateonroadsafty of this appointment call
	*/
	@Override
	public void setDateonroadsafty(java.lang.String dateonroadsafty) {
		_appointmentCall.setDateonroadsafty(dateonroadsafty);
	}

	/**
	* Returns the time of this appointment call.
	*
	* @return the time of this appointment call
	*/
	@Override
	public java.lang.String getTime() {
		return _appointmentCall.getTime();
	}

	/**
	* Sets the time of this appointment call.
	*
	* @param time the time of this appointment call
	*/
	@Override
	public void setTime(java.lang.String time) {
		_appointmentCall.setTime(time);
	}

	/**
	* Returns the investigationtitle of this appointment call.
	*
	* @return the investigationtitle of this appointment call
	*/
	@Override
	public java.lang.String getInvestigationtitle() {
		return _appointmentCall.getInvestigationtitle();
	}

	/**
	* Sets the investigationtitle of this appointment call.
	*
	* @param investigationtitle the investigationtitle of this appointment call
	*/
	@Override
	public void setInvestigationtitle(java.lang.String investigationtitle) {
		_appointmentCall.setInvestigationtitle(investigationtitle);
	}

	/**
	* Returns the location of this appointment call.
	*
	* @return the location of this appointment call
	*/
	@Override
	public java.lang.String getLocation() {
		return _appointmentCall.getLocation();
	}

	/**
	* Sets the location of this appointment call.
	*
	* @param location the location of this appointment call
	*/
	@Override
	public void setLocation(java.lang.String location) {
		_appointmentCall.setLocation(location);
	}

	/**
	* Returns the company of this appointment call.
	*
	* @return the company of this appointment call
	*/
	@Override
	public java.lang.String getCompany() {
		return _appointmentCall.getCompany();
	}

	/**
	* Sets the company of this appointment call.
	*
	* @param company the company of this appointment call
	*/
	@Override
	public void setCompany(java.lang.String company) {
		_appointmentCall.setCompany(company);
	}

	/**
	* Returns the statusverification of this appointment call.
	*
	* @return the statusverification of this appointment call
	*/
	@Override
	public java.lang.String getStatusverification() {
		return _appointmentCall.getStatusverification();
	}

	/**
	* Sets the statusverification of this appointment call.
	*
	* @param statusverification the statusverification of this appointment call
	*/
	@Override
	public void setStatusverification(java.lang.String statusverification) {
		_appointmentCall.setStatusverification(statusverification);
	}

	/**
	* Returns the operatorname of this appointment call.
	*
	* @return the operatorname of this appointment call
	*/
	@Override
	public java.lang.String getOperatorname() {
		return _appointmentCall.getOperatorname();
	}

	/**
	* Sets the operatorname of this appointment call.
	*
	* @param operatorname the operatorname of this appointment call
	*/
	@Override
	public void setOperatorname(java.lang.String operatorname) {
		_appointmentCall.setOperatorname(operatorname);
	}

	/**
	* Returns the nameof officer of this appointment call.
	*
	* @return the nameof officer of this appointment call
	*/
	@Override
	public java.lang.String getNameofOfficer() {
		return _appointmentCall.getNameofOfficer();
	}

	/**
	* Sets the nameof officer of this appointment call.
	*
	* @param nameofOfficer the nameof officer of this appointment call
	*/
	@Override
	public void setNameofOfficer(java.lang.String nameofOfficer) {
		_appointmentCall.setNameofOfficer(nameofOfficer);
	}

	@Override
	public boolean isNew() {
		return _appointmentCall.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_appointmentCall.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _appointmentCall.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_appointmentCall.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _appointmentCall.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _appointmentCall.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_appointmentCall.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _appointmentCall.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_appointmentCall.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_appointmentCall.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_appointmentCall.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new AppointmentCallWrapper((AppointmentCall)_appointmentCall.clone());
	}

	@Override
	public int compareTo(com.spad.icop.model.AppointmentCall appointmentCall) {
		return _appointmentCall.compareTo(appointmentCall);
	}

	@Override
	public int hashCode() {
		return _appointmentCall.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.AppointmentCall> toCacheModel() {
		return _appointmentCall.toCacheModel();
	}

	@Override
	public com.spad.icop.model.AppointmentCall toEscapedModel() {
		return new AppointmentCallWrapper(_appointmentCall.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.AppointmentCall toUnescapedModel() {
		return new AppointmentCallWrapper(_appointmentCall.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _appointmentCall.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _appointmentCall.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_appointmentCall.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AppointmentCallWrapper)) {
			return false;
		}

		AppointmentCallWrapper appointmentCallWrapper = (AppointmentCallWrapper)obj;

		if (Validator.equals(_appointmentCall,
					appointmentCallWrapper._appointmentCall)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public AppointmentCall getWrappedAppointmentCall() {
		return _appointmentCall;
	}

	@Override
	public AppointmentCall getWrappedModel() {
		return _appointmentCall;
	}

	@Override
	public void resetOriginalValues() {
		_appointmentCall.resetOriginalValues();
	}

	private AppointmentCall _appointmentCall;
}