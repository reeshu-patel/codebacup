/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.RecordCallAuditServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.RecordCallAuditServiceSoap
 * @generated
 */
public class RecordCallAuditSoap implements Serializable {
	public static RecordCallAuditSoap toSoapModel(RecordCallAudit model) {
		RecordCallAuditSoap soapModel = new RecordCallAuditSoap();

		soapModel.setRecordcallid(model.getRecordcallid());
		soapModel.setAditid(model.getAditid());
		soapModel.setDateonroadsafty(model.getDateonroadsafty());
		soapModel.setInvestigationtitle(model.getInvestigationtitle());
		soapModel.setCompany(model.getCompany());
		soapModel.setStatusverification(model.getStatusverification());

		return soapModel;
	}

	public static RecordCallAuditSoap[] toSoapModels(RecordCallAudit[] models) {
		RecordCallAuditSoap[] soapModels = new RecordCallAuditSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RecordCallAuditSoap[][] toSoapModels(
		RecordCallAudit[][] models) {
		RecordCallAuditSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new RecordCallAuditSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RecordCallAuditSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RecordCallAuditSoap[] toSoapModels(
		List<RecordCallAudit> models) {
		List<RecordCallAuditSoap> soapModels = new ArrayList<RecordCallAuditSoap>(models.size());

		for (RecordCallAudit model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RecordCallAuditSoap[soapModels.size()]);
	}

	public RecordCallAuditSoap() {
	}

	public long getPrimaryKey() {
		return _aditid;
	}

	public void setPrimaryKey(long pk) {
		setAditid(pk);
	}

	public String getRecordcallid() {
		return _recordcallid;
	}

	public void setRecordcallid(String recordcallid) {
		_recordcallid = recordcallid;
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getDateonroadsafty() {
		return _dateonroadsafty;
	}

	public void setDateonroadsafty(String dateonroadsafty) {
		_dateonroadsafty = dateonroadsafty;
	}

	public String getInvestigationtitle() {
		return _investigationtitle;
	}

	public void setInvestigationtitle(String investigationtitle) {
		_investigationtitle = investigationtitle;
	}

	public String getCompany() {
		return _company;
	}

	public void setCompany(String company) {
		_company = company;
	}

	public String getStatusverification() {
		return _statusverification;
	}

	public void setStatusverification(String statusverification) {
		_statusverification = statusverification;
	}

	private String _recordcallid;
	private long _aditid;
	private String _dateonroadsafty;
	private String _investigationtitle;
	private String _company;
	private String _statusverification;
}