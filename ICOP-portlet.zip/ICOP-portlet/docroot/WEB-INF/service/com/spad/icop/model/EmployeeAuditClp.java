/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.ClpSerializer;
import com.spad.icop.service.EmployeeAuditLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class EmployeeAuditClp extends BaseModelImpl<EmployeeAudit>
	implements EmployeeAudit {
	public EmployeeAuditClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return EmployeeAudit.class;
	}

	@Override
	public String getModelClassName() {
		return EmployeeAudit.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _aditid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setAditid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _aditid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("aditid", getAditid());
		attributes.put("dateonroad", getDateonroad());
		attributes.put("dateofincident", getDateofincident());
		attributes.put("timeevent", getTimeevent());
		attributes.put("titleinvestigation", getTitleinvestigation());
		attributes.put("typeofvehicle", getTypeofvehicle());
		attributes.put("noregistration", getNoregistration());
		attributes.put("company", getCompany());
		attributes.put("reportsKjr", getReportsKjr());
		attributes.put("reportscmd", getReportscmd());
		attributes.put("srustatus", getSrustatus());
		attributes.put("completedStatus", getCompletedStatus());
		attributes.put("audidate", getAudidate());
		attributes.put("auditime", getAuditime());
		attributes.put("statusofadudit", getStatusofadudit());
		attributes.put("completeddate", getCompleteddate());
		attributes.put("addresss", getAddresss());
		attributes.put("locationofincident", getLocationofincident());
		attributes.put("trainingattendance", getTrainingattendance());
		attributes.put("auditaccidents", getAuditaccidents());
		attributes.put("typecertificate", getTypecertificate());
		attributes.put("dateofregistration", getDateofregistration());
		attributes.put("trainingdates", getTrainingdates());
		attributes.put("enddate", getEnddate());
		attributes.put("typemod", getTypemod());
		attributes.put("typeoflicens", getTypeoflicens());
		attributes.put("typeofcompany", getTypeofcompany());
		attributes.put("phoneno", getPhoneno());
		attributes.put("status", getStatus());
		attributes.put("appendixg", getAppendixg());
		attributes.put("dateCaseSrU", getDateCaseSrU());
		attributes.put("actionSru", getActionSru());
		attributes.put("officerName", getOfficerName());
		attributes.put("vehiclesNo", getVehiclesNo());
		attributes.put("companyEmail", getCompanyEmail());
		attributes.put("representativeName", getRepresentativeName());
		attributes.put("companieListNumber", getCompanieListNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String dateonroad = (String)attributes.get("dateonroad");

		if (dateonroad != null) {
			setDateonroad(dateonroad);
		}

		String dateofincident = (String)attributes.get("dateofincident");

		if (dateofincident != null) {
			setDateofincident(dateofincident);
		}

		String timeevent = (String)attributes.get("timeevent");

		if (timeevent != null) {
			setTimeevent(timeevent);
		}

		String titleinvestigation = (String)attributes.get("titleinvestigation");

		if (titleinvestigation != null) {
			setTitleinvestigation(titleinvestigation);
		}

		String typeofvehicle = (String)attributes.get("typeofvehicle");

		if (typeofvehicle != null) {
			setTypeofvehicle(typeofvehicle);
		}

		String noregistration = (String)attributes.get("noregistration");

		if (noregistration != null) {
			setNoregistration(noregistration);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String reportsKjr = (String)attributes.get("reportsKjr");

		if (reportsKjr != null) {
			setReportsKjr(reportsKjr);
		}

		String reportscmd = (String)attributes.get("reportscmd");

		if (reportscmd != null) {
			setReportscmd(reportscmd);
		}

		String srustatus = (String)attributes.get("srustatus");

		if (srustatus != null) {
			setSrustatus(srustatus);
		}

		String completedStatus = (String)attributes.get("completedStatus");

		if (completedStatus != null) {
			setCompletedStatus(completedStatus);
		}

		String audidate = (String)attributes.get("audidate");

		if (audidate != null) {
			setAudidate(audidate);
		}

		String auditime = (String)attributes.get("auditime");

		if (auditime != null) {
			setAuditime(auditime);
		}

		String statusofadudit = (String)attributes.get("statusofadudit");

		if (statusofadudit != null) {
			setStatusofadudit(statusofadudit);
		}

		String completeddate = (String)attributes.get("completeddate");

		if (completeddate != null) {
			setCompleteddate(completeddate);
		}

		String addresss = (String)attributes.get("addresss");

		if (addresss != null) {
			setAddresss(addresss);
		}

		String locationofincident = (String)attributes.get("locationofincident");

		if (locationofincident != null) {
			setLocationofincident(locationofincident);
		}

		String trainingattendance = (String)attributes.get("trainingattendance");

		if (trainingattendance != null) {
			setTrainingattendance(trainingattendance);
		}

		String auditaccidents = (String)attributes.get("auditaccidents");

		if (auditaccidents != null) {
			setAuditaccidents(auditaccidents);
		}

		String typecertificate = (String)attributes.get("typecertificate");

		if (typecertificate != null) {
			setTypecertificate(typecertificate);
		}

		String dateofregistration = (String)attributes.get("dateofregistration");

		if (dateofregistration != null) {
			setDateofregistration(dateofregistration);
		}

		String trainingdates = (String)attributes.get("trainingdates");

		if (trainingdates != null) {
			setTrainingdates(trainingdates);
		}

		String enddate = (String)attributes.get("enddate");

		if (enddate != null) {
			setEnddate(enddate);
		}

		String typemod = (String)attributes.get("typemod");

		if (typemod != null) {
			setTypemod(typemod);
		}

		String typeoflicens = (String)attributes.get("typeoflicens");

		if (typeoflicens != null) {
			setTypeoflicens(typeoflicens);
		}

		String typeofcompany = (String)attributes.get("typeofcompany");

		if (typeofcompany != null) {
			setTypeofcompany(typeofcompany);
		}

		String phoneno = (String)attributes.get("phoneno");

		if (phoneno != null) {
			setPhoneno(phoneno);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String appendixg = (String)attributes.get("appendixg");

		if (appendixg != null) {
			setAppendixg(appendixg);
		}

		String dateCaseSrU = (String)attributes.get("dateCaseSrU");

		if (dateCaseSrU != null) {
			setDateCaseSrU(dateCaseSrU);
		}

		String actionSru = (String)attributes.get("actionSru");

		if (actionSru != null) {
			setActionSru(actionSru);
		}

		String officerName = (String)attributes.get("officerName");

		if (officerName != null) {
			setOfficerName(officerName);
		}

		String vehiclesNo = (String)attributes.get("vehiclesNo");

		if (vehiclesNo != null) {
			setVehiclesNo(vehiclesNo);
		}

		String companyEmail = (String)attributes.get("companyEmail");

		if (companyEmail != null) {
			setCompanyEmail(companyEmail);
		}

		String representativeName = (String)attributes.get("representativeName");

		if (representativeName != null) {
			setRepresentativeName(representativeName);
		}

		String companieListNumber = (String)attributes.get("companieListNumber");

		if (companieListNumber != null) {
			setCompanieListNumber(companieListNumber);
		}
	}

	@Override
	public long getAditid() {
		return _aditid;
	}

	@Override
	public void setAditid(long aditid) {
		_aditid = aditid;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAditid", long.class);

				method.invoke(_employeeAuditRemoteModel, aditid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateonroad() {
		return _dateonroad;
	}

	@Override
	public void setDateonroad(String dateonroad) {
		_dateonroad = dateonroad;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setDateonroad", String.class);

				method.invoke(_employeeAuditRemoteModel, dateonroad);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateofincident() {
		return _dateofincident;
	}

	@Override
	public void setDateofincident(String dateofincident) {
		_dateofincident = dateofincident;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setDateofincident",
						String.class);

				method.invoke(_employeeAuditRemoteModel, dateofincident);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTimeevent() {
		return _timeevent;
	}

	@Override
	public void setTimeevent(String timeevent) {
		_timeevent = timeevent;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTimeevent", String.class);

				method.invoke(_employeeAuditRemoteModel, timeevent);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTitleinvestigation() {
		return _titleinvestigation;
	}

	@Override
	public void setTitleinvestigation(String titleinvestigation) {
		_titleinvestigation = titleinvestigation;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTitleinvestigation",
						String.class);

				method.invoke(_employeeAuditRemoteModel, titleinvestigation);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypeofvehicle() {
		return _typeofvehicle;
	}

	@Override
	public void setTypeofvehicle(String typeofvehicle) {
		_typeofvehicle = typeofvehicle;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTypeofvehicle", String.class);

				method.invoke(_employeeAuditRemoteModel, typeofvehicle);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNoregistration() {
		return _noregistration;
	}

	@Override
	public void setNoregistration(String noregistration) {
		_noregistration = noregistration;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setNoregistration",
						String.class);

				method.invoke(_employeeAuditRemoteModel, noregistration);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompany() {
		return _company;
	}

	@Override
	public void setCompany(String company) {
		_company = company;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setCompany", String.class);

				method.invoke(_employeeAuditRemoteModel, company);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getReportsKjr() {
		return _reportsKjr;
	}

	@Override
	public void setReportsKjr(String reportsKjr) {
		_reportsKjr = reportsKjr;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setReportsKjr", String.class);

				method.invoke(_employeeAuditRemoteModel, reportsKjr);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getReportscmd() {
		return _reportscmd;
	}

	@Override
	public void setReportscmd(String reportscmd) {
		_reportscmd = reportscmd;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setReportscmd", String.class);

				method.invoke(_employeeAuditRemoteModel, reportscmd);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSrustatus() {
		return _srustatus;
	}

	@Override
	public void setSrustatus(String srustatus) {
		_srustatus = srustatus;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setSrustatus", String.class);

				method.invoke(_employeeAuditRemoteModel, srustatus);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompletedStatus() {
		return _completedStatus;
	}

	@Override
	public void setCompletedStatus(String completedStatus) {
		_completedStatus = completedStatus;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setCompletedStatus",
						String.class);

				method.invoke(_employeeAuditRemoteModel, completedStatus);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAudidate() {
		return _audidate;
	}

	@Override
	public void setAudidate(String audidate) {
		_audidate = audidate;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAudidate", String.class);

				method.invoke(_employeeAuditRemoteModel, audidate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditime() {
		return _auditime;
	}

	@Override
	public void setAuditime(String auditime) {
		_auditime = auditime;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditime", String.class);

				method.invoke(_employeeAuditRemoteModel, auditime);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatusofadudit() {
		return _statusofadudit;
	}

	@Override
	public void setStatusofadudit(String statusofadudit) {
		_statusofadudit = statusofadudit;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusofadudit",
						String.class);

				method.invoke(_employeeAuditRemoteModel, statusofadudit);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompleteddate() {
		return _completeddate;
	}

	@Override
	public void setCompleteddate(String completeddate) {
		_completeddate = completeddate;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setCompleteddate", String.class);

				method.invoke(_employeeAuditRemoteModel, completeddate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddresss() {
		return _addresss;
	}

	@Override
	public void setAddresss(String addresss) {
		_addresss = addresss;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAddresss", String.class);

				method.invoke(_employeeAuditRemoteModel, addresss);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLocationofincident() {
		return _locationofincident;
	}

	@Override
	public void setLocationofincident(String locationofincident) {
		_locationofincident = locationofincident;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setLocationofincident",
						String.class);

				method.invoke(_employeeAuditRemoteModel, locationofincident);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingattendance() {
		return _trainingattendance;
	}

	@Override
	public void setTrainingattendance(String trainingattendance) {
		_trainingattendance = trainingattendance;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingattendance",
						String.class);

				method.invoke(_employeeAuditRemoteModel, trainingattendance);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditaccidents() {
		return _auditaccidents;
	}

	@Override
	public void setAuditaccidents(String auditaccidents) {
		_auditaccidents = auditaccidents;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditaccidents",
						String.class);

				method.invoke(_employeeAuditRemoteModel, auditaccidents);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypecertificate() {
		return _typecertificate;
	}

	@Override
	public void setTypecertificate(String typecertificate) {
		_typecertificate = typecertificate;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTypecertificate",
						String.class);

				method.invoke(_employeeAuditRemoteModel, typecertificate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateofregistration() {
		return _dateofregistration;
	}

	@Override
	public void setDateofregistration(String dateofregistration) {
		_dateofregistration = dateofregistration;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setDateofregistration",
						String.class);

				method.invoke(_employeeAuditRemoteModel, dateofregistration);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingdates() {
		return _trainingdates;
	}

	@Override
	public void setTrainingdates(String trainingdates) {
		_trainingdates = trainingdates;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingdates", String.class);

				method.invoke(_employeeAuditRemoteModel, trainingdates);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEnddate() {
		return _enddate;
	}

	@Override
	public void setEnddate(String enddate) {
		_enddate = enddate;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setEnddate", String.class);

				method.invoke(_employeeAuditRemoteModel, enddate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypemod() {
		return _typemod;
	}

	@Override
	public void setTypemod(String typemod) {
		_typemod = typemod;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTypemod", String.class);

				method.invoke(_employeeAuditRemoteModel, typemod);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypeoflicens() {
		return _typeoflicens;
	}

	@Override
	public void setTypeoflicens(String typeoflicens) {
		_typeoflicens = typeoflicens;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTypeoflicens", String.class);

				method.invoke(_employeeAuditRemoteModel, typeoflicens);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypeofcompany() {
		return _typeofcompany;
	}

	@Override
	public void setTypeofcompany(String typeofcompany) {
		_typeofcompany = typeofcompany;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setTypeofcompany", String.class);

				method.invoke(_employeeAuditRemoteModel, typeofcompany);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPhoneno() {
		return _phoneno;
	}

	@Override
	public void setPhoneno(String phoneno) {
		_phoneno = phoneno;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setPhoneno", String.class);

				method.invoke(_employeeAuditRemoteModel, phoneno);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_employeeAuditRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAppendixg() {
		return _appendixg;
	}

	@Override
	public void setAppendixg(String appendixg) {
		_appendixg = appendixg;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAppendixg", String.class);

				method.invoke(_employeeAuditRemoteModel, appendixg);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateCaseSrU() {
		return _dateCaseSrU;
	}

	@Override
	public void setDateCaseSrU(String dateCaseSrU) {
		_dateCaseSrU = dateCaseSrU;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setDateCaseSrU", String.class);

				method.invoke(_employeeAuditRemoteModel, dateCaseSrU);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getActionSru() {
		return _actionSru;
	}

	@Override
	public void setActionSru(String actionSru) {
		_actionSru = actionSru;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setActionSru", String.class);

				method.invoke(_employeeAuditRemoteModel, actionSru);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOfficerName() {
		return _officerName;
	}

	@Override
	public void setOfficerName(String officerName) {
		_officerName = officerName;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficerName", String.class);

				method.invoke(_employeeAuditRemoteModel, officerName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehiclesNo() {
		return _vehiclesNo;
	}

	@Override
	public void setVehiclesNo(String vehiclesNo) {
		_vehiclesNo = vehiclesNo;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setVehiclesNo", String.class);

				method.invoke(_employeeAuditRemoteModel, vehiclesNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompanyEmail() {
		return _companyEmail;
	}

	@Override
	public void setCompanyEmail(String companyEmail) {
		_companyEmail = companyEmail;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyEmail", String.class);

				method.invoke(_employeeAuditRemoteModel, companyEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRepresentativeName() {
		return _representativeName;
	}

	@Override
	public void setRepresentativeName(String representativeName) {
		_representativeName = representativeName;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setRepresentativeName",
						String.class);

				method.invoke(_employeeAuditRemoteModel, representativeName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompanieListNumber() {
		return _companieListNumber;
	}

	@Override
	public void setCompanieListNumber(String companieListNumber) {
		_companieListNumber = companieListNumber;

		if (_employeeAuditRemoteModel != null) {
			try {
				Class<?> clazz = _employeeAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanieListNumber",
						String.class);

				method.invoke(_employeeAuditRemoteModel, companieListNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEmployeeAuditRemoteModel() {
		return _employeeAuditRemoteModel;
	}

	public void setEmployeeAuditRemoteModel(
		BaseModel<?> employeeAuditRemoteModel) {
		_employeeAuditRemoteModel = employeeAuditRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _employeeAuditRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_employeeAuditRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EmployeeAuditLocalServiceUtil.addEmployeeAudit(this);
		}
		else {
			EmployeeAuditLocalServiceUtil.updateEmployeeAudit(this);
		}
	}

	@Override
	public EmployeeAudit toEscapedModel() {
		return (EmployeeAudit)ProxyUtil.newProxyInstance(EmployeeAudit.class.getClassLoader(),
			new Class[] { EmployeeAudit.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EmployeeAuditClp clone = new EmployeeAuditClp();

		clone.setAditid(getAditid());
		clone.setDateonroad(getDateonroad());
		clone.setDateofincident(getDateofincident());
		clone.setTimeevent(getTimeevent());
		clone.setTitleinvestigation(getTitleinvestigation());
		clone.setTypeofvehicle(getTypeofvehicle());
		clone.setNoregistration(getNoregistration());
		clone.setCompany(getCompany());
		clone.setReportsKjr(getReportsKjr());
		clone.setReportscmd(getReportscmd());
		clone.setSrustatus(getSrustatus());
		clone.setCompletedStatus(getCompletedStatus());
		clone.setAudidate(getAudidate());
		clone.setAuditime(getAuditime());
		clone.setStatusofadudit(getStatusofadudit());
		clone.setCompleteddate(getCompleteddate());
		clone.setAddresss(getAddresss());
		clone.setLocationofincident(getLocationofincident());
		clone.setTrainingattendance(getTrainingattendance());
		clone.setAuditaccidents(getAuditaccidents());
		clone.setTypecertificate(getTypecertificate());
		clone.setDateofregistration(getDateofregistration());
		clone.setTrainingdates(getTrainingdates());
		clone.setEnddate(getEnddate());
		clone.setTypemod(getTypemod());
		clone.setTypeoflicens(getTypeoflicens());
		clone.setTypeofcompany(getTypeofcompany());
		clone.setPhoneno(getPhoneno());
		clone.setStatus(getStatus());
		clone.setAppendixg(getAppendixg());
		clone.setDateCaseSrU(getDateCaseSrU());
		clone.setActionSru(getActionSru());
		clone.setOfficerName(getOfficerName());
		clone.setVehiclesNo(getVehiclesNo());
		clone.setCompanyEmail(getCompanyEmail());
		clone.setRepresentativeName(getRepresentativeName());
		clone.setCompanieListNumber(getCompanieListNumber());

		return clone;
	}

	@Override
	public int compareTo(EmployeeAudit employeeAudit) {
		int value = 0;

		if (getAditid() < employeeAudit.getAditid()) {
			value = -1;
		}
		else if (getAditid() > employeeAudit.getAditid()) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EmployeeAuditClp)) {
			return false;
		}

		EmployeeAuditClp employeeAudit = (EmployeeAuditClp)obj;

		long primaryKey = employeeAudit.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(75);

		sb.append("{aditid=");
		sb.append(getAditid());
		sb.append(", dateonroad=");
		sb.append(getDateonroad());
		sb.append(", dateofincident=");
		sb.append(getDateofincident());
		sb.append(", timeevent=");
		sb.append(getTimeevent());
		sb.append(", titleinvestigation=");
		sb.append(getTitleinvestigation());
		sb.append(", typeofvehicle=");
		sb.append(getTypeofvehicle());
		sb.append(", noregistration=");
		sb.append(getNoregistration());
		sb.append(", company=");
		sb.append(getCompany());
		sb.append(", reportsKjr=");
		sb.append(getReportsKjr());
		sb.append(", reportscmd=");
		sb.append(getReportscmd());
		sb.append(", srustatus=");
		sb.append(getSrustatus());
		sb.append(", completedStatus=");
		sb.append(getCompletedStatus());
		sb.append(", audidate=");
		sb.append(getAudidate());
		sb.append(", auditime=");
		sb.append(getAuditime());
		sb.append(", statusofadudit=");
		sb.append(getStatusofadudit());
		sb.append(", completeddate=");
		sb.append(getCompleteddate());
		sb.append(", addresss=");
		sb.append(getAddresss());
		sb.append(", locationofincident=");
		sb.append(getLocationofincident());
		sb.append(", trainingattendance=");
		sb.append(getTrainingattendance());
		sb.append(", auditaccidents=");
		sb.append(getAuditaccidents());
		sb.append(", typecertificate=");
		sb.append(getTypecertificate());
		sb.append(", dateofregistration=");
		sb.append(getDateofregistration());
		sb.append(", trainingdates=");
		sb.append(getTrainingdates());
		sb.append(", enddate=");
		sb.append(getEnddate());
		sb.append(", typemod=");
		sb.append(getTypemod());
		sb.append(", typeoflicens=");
		sb.append(getTypeoflicens());
		sb.append(", typeofcompany=");
		sb.append(getTypeofcompany());
		sb.append(", phoneno=");
		sb.append(getPhoneno());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", appendixg=");
		sb.append(getAppendixg());
		sb.append(", dateCaseSrU=");
		sb.append(getDateCaseSrU());
		sb.append(", actionSru=");
		sb.append(getActionSru());
		sb.append(", officerName=");
		sb.append(getOfficerName());
		sb.append(", vehiclesNo=");
		sb.append(getVehiclesNo());
		sb.append(", companyEmail=");
		sb.append(getCompanyEmail());
		sb.append(", representativeName=");
		sb.append(getRepresentativeName());
		sb.append(", companieListNumber=");
		sb.append(getCompanieListNumber());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(115);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.EmployeeAudit");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>aditid</column-name><column-value><![CDATA[");
		sb.append(getAditid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateonroad</column-name><column-value><![CDATA[");
		sb.append(getDateonroad());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateofincident</column-name><column-value><![CDATA[");
		sb.append(getDateofincident());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>timeevent</column-name><column-value><![CDATA[");
		sb.append(getTimeevent());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>titleinvestigation</column-name><column-value><![CDATA[");
		sb.append(getTitleinvestigation());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typeofvehicle</column-name><column-value><![CDATA[");
		sb.append(getTypeofvehicle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>noregistration</column-name><column-value><![CDATA[");
		sb.append(getNoregistration());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>company</column-name><column-value><![CDATA[");
		sb.append(getCompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>reportsKjr</column-name><column-value><![CDATA[");
		sb.append(getReportsKjr());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>reportscmd</column-name><column-value><![CDATA[");
		sb.append(getReportscmd());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>srustatus</column-name><column-value><![CDATA[");
		sb.append(getSrustatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>completedStatus</column-name><column-value><![CDATA[");
		sb.append(getCompletedStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>audidate</column-name><column-value><![CDATA[");
		sb.append(getAudidate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditime</column-name><column-value><![CDATA[");
		sb.append(getAuditime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusofadudit</column-name><column-value><![CDATA[");
		sb.append(getStatusofadudit());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>completeddate</column-name><column-value><![CDATA[");
		sb.append(getCompleteddate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>addresss</column-name><column-value><![CDATA[");
		sb.append(getAddresss());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>locationofincident</column-name><column-value><![CDATA[");
		sb.append(getLocationofincident());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingattendance</column-name><column-value><![CDATA[");
		sb.append(getTrainingattendance());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditaccidents</column-name><column-value><![CDATA[");
		sb.append(getAuditaccidents());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typecertificate</column-name><column-value><![CDATA[");
		sb.append(getTypecertificate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateofregistration</column-name><column-value><![CDATA[");
		sb.append(getDateofregistration());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingdates</column-name><column-value><![CDATA[");
		sb.append(getTrainingdates());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>enddate</column-name><column-value><![CDATA[");
		sb.append(getEnddate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typemod</column-name><column-value><![CDATA[");
		sb.append(getTypemod());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typeoflicens</column-name><column-value><![CDATA[");
		sb.append(getTypeoflicens());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typeofcompany</column-name><column-value><![CDATA[");
		sb.append(getTypeofcompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>phoneno</column-name><column-value><![CDATA[");
		sb.append(getPhoneno());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>appendixg</column-name><column-value><![CDATA[");
		sb.append(getAppendixg());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateCaseSrU</column-name><column-value><![CDATA[");
		sb.append(getDateCaseSrU());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>actionSru</column-name><column-value><![CDATA[");
		sb.append(getActionSru());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>officerName</column-name><column-value><![CDATA[");
		sb.append(getOfficerName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehiclesNo</column-name><column-value><![CDATA[");
		sb.append(getVehiclesNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyEmail</column-name><column-value><![CDATA[");
		sb.append(getCompanyEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>representativeName</column-name><column-value><![CDATA[");
		sb.append(getRepresentativeName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companieListNumber</column-name><column-value><![CDATA[");
		sb.append(getCompanieListNumber());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _aditid;
	private String _dateonroad;
	private String _dateofincident;
	private String _timeevent;
	private String _titleinvestigation;
	private String _typeofvehicle;
	private String _noregistration;
	private String _company;
	private String _reportsKjr;
	private String _reportscmd;
	private String _srustatus;
	private String _completedStatus;
	private String _audidate;
	private String _auditime;
	private String _statusofadudit;
	private String _completeddate;
	private String _addresss;
	private String _locationofincident;
	private String _trainingattendance;
	private String _auditaccidents;
	private String _typecertificate;
	private String _dateofregistration;
	private String _trainingdates;
	private String _enddate;
	private String _typemod;
	private String _typeoflicens;
	private String _typeofcompany;
	private String _phoneno;
	private String _status;
	private String _appendixg;
	private String _dateCaseSrU;
	private String _actionSru;
	private String _officerName;
	private String _vehiclesNo;
	private String _companyEmail;
	private String _representativeName;
	private String _companieListNumber;
	private BaseModel<?> _employeeAuditRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}