/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CompilanceCheckService}.
 *
 * @author reeshu
 * @see CompilanceCheckService
 * @generated
 */
public class CompilanceCheckServiceWrapper implements CompilanceCheckService,
	ServiceWrapper<CompilanceCheckService> {
	public CompilanceCheckServiceWrapper(
		CompilanceCheckService compilanceCheckService) {
		_compilanceCheckService = compilanceCheckService;
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _compilanceCheckService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_compilanceCheckService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _compilanceCheckService.invokeMethod(name, parameterTypes,
			arguments);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public CompilanceCheckService getWrappedCompilanceCheckService() {
		return _compilanceCheckService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedCompilanceCheckService(
		CompilanceCheckService compilanceCheckService) {
		_compilanceCheckService = compilanceCheckService;
	}

	@Override
	public CompilanceCheckService getWrappedService() {
		return _compilanceCheckService;
	}

	@Override
	public void setWrappedService(CompilanceCheckService compilanceCheckService) {
		_compilanceCheckService = compilanceCheckService;
	}

	private CompilanceCheckService _compilanceCheckService;
}