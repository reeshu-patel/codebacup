/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link EmployeeAuditService}.
 *
 * @author reeshu
 * @see EmployeeAuditService
 * @generated
 */
public class EmployeeAuditServiceWrapper implements EmployeeAuditService,
	ServiceWrapper<EmployeeAuditService> {
	public EmployeeAuditServiceWrapper(
		EmployeeAuditService employeeAuditService) {
		_employeeAuditService = employeeAuditService;
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _employeeAuditService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_employeeAuditService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _employeeAuditService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public long addEmployeeAudit(java.lang.String dateonRoad,
		java.lang.String dateofIncident, java.lang.String timeEvent,
		java.lang.String locationofIncident, java.lang.String Company,
		java.lang.String trainingAttendance, java.lang.String auditAccidents,
		java.lang.String statusSRU) {
		return _employeeAuditService.addEmployeeAudit(dateonRoad,
			dateofIncident, timeEvent, locationofIncident, Company,
			trainingAttendance, auditAccidents, statusSRU);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject EmployeeAudit()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.EmployeeAudit();
	}

	@Override
	public com.spad.icop.model.AppointmentCall RecordCallApointmentAudit(
		long aditid, java.lang.String dateonroadsafty, java.lang.String time,
		java.lang.String investigationtitle, java.lang.String company,
		java.lang.String statusverification, java.lang.String operatorname,
		java.lang.String nameofOfficer, java.lang.String location)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.RecordCallApointmentAudit(aditid,
			dateonroadsafty, time, investigationtitle, company,
			statusverification, operatorname, nameofOfficer, location);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject IndexDropDown()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.IndexDropDown();
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject RegistationStatus(
		java.lang.String vehicletype, java.lang.String vehicalNo,
		java.lang.String companyName, java.lang.String statusExercise)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.RegistationStatus(vehicletype, vehicalNo,
			companyName, statusExercise);
	}

	@Override
	public com.spad.icop.model.CompilanceCheck CompilanceCheckPost(
		long compilanceCheckid, long aditid, java.lang.String company,
		java.lang.String audidate, java.lang.String completedStatus,
		java.lang.String auditPercentage, java.lang.String questionSafetyOne,
		java.lang.String questionSafetyTwo,
		java.lang.String questionSafetyThree,
		java.lang.String questionSafetFour, java.lang.String questionSafetFive,
		java.lang.String questionSafetSix,
		java.lang.String questionSafetySeven, java.lang.String questionNoteOne,
		java.lang.String questionNoteTwo, java.lang.String questionNoteThree,
		java.lang.String questionNoteFour, java.lang.String questionNoteFive,
		java.lang.String questionNoteSix, java.lang.String questionNoteSeven,
		java.lang.String questionVehicalOne,
		java.lang.String questionVehicalTwo,
		java.lang.String questionVehicalThree,
		java.lang.String questionVehicalFour,
		java.lang.String questionVehicalFive,
		java.lang.String questionVehicalSix,
		java.lang.String questionVehicalSeven,
		java.lang.String questionVehicalNoteOne,
		java.lang.String questionVehicalNoteTwo,
		java.lang.String questionVehicalNoteThree,
		java.lang.String questionVehicalNoteFour,
		java.lang.String questionVehicalNoteFive,
		java.lang.String questionVehicalNoteSix,
		java.lang.String vehicleRegistrationNo, java.lang.String model,
		java.lang.String color, java.lang.String dateofVehicles,
		java.lang.String investigatorname,
		java.lang.String questionVehicalNoteSeven,
		java.lang.String questionManageOne, java.lang.String questionManageTwo,
		java.lang.String questionManageThree,
		java.lang.String questionManageFour,
		java.lang.String questionManageFive,
		java.lang.String questionManageSix,
		java.lang.String questionManageSeven,
		java.lang.String questionManageNoteOne,
		java.lang.String questionManageNoteTwo,
		java.lang.String questionManageNoteThree,
		java.lang.String questionManageNoteFour,
		java.lang.String questionManageNoteFive,
		java.lang.String questionManageNoteSix,
		java.lang.String questionRecordsOne,
		java.lang.String questionRecordsTwo,
		java.lang.String questionRecordsThree,
		java.lang.String questionRecordsNoteOne,
		java.lang.String questionRecordsNoteTwo,
		java.lang.String questionRecordsNoteThree,
		java.lang.String questionReskOne, java.lang.String questionReskTwo,
		java.lang.String questionReskThree, java.lang.String questionReskFour,
		java.lang.String questionReskFive, java.lang.String questionReskSix,
		java.lang.String questionReskSeven, java.lang.String questionReskEight,
		java.lang.String questionReskNoteOne,
		java.lang.String questionReskNoteTwo,
		java.lang.String questionReskNoteThree,
		java.lang.String questionReskNoteFour,
		java.lang.String questionReskNoteFive,
		java.lang.String questionReskNoteSix,
		java.lang.String questionReskNoteSeven,
		java.lang.String questionReskNoteEight, java.lang.String notcomplied,
		java.lang.String record)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.CompilanceCheckPost(compilanceCheckid,
			aditid, company, audidate, completedStatus, auditPercentage,
			questionSafetyOne, questionSafetyTwo, questionSafetyThree,
			questionSafetFour, questionSafetFive, questionSafetSix,
			questionSafetySeven, questionNoteOne, questionNoteTwo,
			questionNoteThree, questionNoteFour, questionNoteFive,
			questionNoteSix, questionNoteSeven, questionVehicalOne,
			questionVehicalTwo, questionVehicalThree, questionVehicalFour,
			questionVehicalFive, questionVehicalSix, questionVehicalSeven,
			questionVehicalNoteOne, questionVehicalNoteTwo,
			questionVehicalNoteThree, questionVehicalNoteFour,
			questionVehicalNoteFive, questionVehicalNoteSix,
			vehicleRegistrationNo, model, color, dateofVehicles,
			investigatorname, questionVehicalNoteSeven, questionManageOne,
			questionManageTwo, questionManageThree, questionManageFour,
			questionManageFive, questionManageSix, questionManageSeven,
			questionManageNoteOne, questionManageNoteTwo,
			questionManageNoteThree, questionManageNoteFour,
			questionManageNoteFive, questionManageNoteSix, questionRecordsOne,
			questionRecordsTwo, questionRecordsThree, questionRecordsNoteOne,
			questionRecordsNoteTwo, questionRecordsNoteThree, questionReskOne,
			questionReskTwo, questionReskThree, questionReskFour,
			questionReskFive, questionReskSix, questionReskSeven,
			questionReskEight, questionReskNoteOne, questionReskNoteTwo,
			questionReskNoteThree, questionReskNoteFour, questionReskNoteFive,
			questionReskNoteSix, questionReskNoteSeven, questionReskNoteEight,
			notcomplied, record);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject CompilanceCheck(
		long compilanceCheckid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.CompilanceCheck(compilanceCheckid);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject ChiefIcopAudit()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.ChiefIcopAudit();
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject OperatorsList(
		java.lang.String vehicletype, java.lang.String vehicalNo,
		java.lang.String companyName, java.lang.String statusExercise)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.OperatorsList(vehicletype, vehicalNo,
			companyName, statusExercise);
	}

	@Override
	public com.spad.icop.model.ComplainCheckAudit COMPLIANCE_CHECKAUDIT(
		long aditid, java.lang.String auditdate1_1,
		java.lang.String auditdate1_2, java.lang.String auditdate1_3,
		java.lang.String auditdate1_4, java.lang.String auditdate1_5,
		java.lang.String auditdate1_6, java.lang.String auditdate1_7,
		java.lang.String auditdateNote1_1, java.lang.String auditdateNote1_2,
		java.lang.String auditdateNote1_3, java.lang.String auditdateNote1_4,
		java.lang.String auditdateNote1_5, java.lang.String auditdateNote1_6,
		java.lang.String auditdateNote1_7, java.lang.String auditdate2_1,
		java.lang.String auditdate2_2, java.lang.String auditdate2_3,
		java.lang.String auditdate2_4, java.lang.String auditdateNote2_1,
		java.lang.String auditdateNote2_2, java.lang.String auditdateNote2_3,
		java.lang.String auditdateNote2_4, java.lang.String auditdate2_4_1,
		java.lang.String auditdate2_4_2, java.lang.String auditdate2_4_3,
		java.lang.String auditdate2_4_4, java.lang.String auditdateNote2_4_1,
		java.lang.String auditdateNote2_4_2,
		java.lang.String auditdateNote2_4_3,
		java.lang.String auditdateNote2_4_4, java.lang.String auditdate3_1,
		java.lang.String auditdate3_2, java.lang.String auditdate3_3,
		java.lang.String auditdate3_4, java.lang.String auditdate3_5,
		java.lang.String auditdate3_6, java.lang.String auditdateNote3_1,
		java.lang.String auditdateNote3_2, java.lang.String auditdateNote3_3,
		java.lang.String auditdateNote3_4, java.lang.String auditdateNote3_5,
		java.lang.String auditdateNote3_6, java.lang.String auditdate4_1,
		java.lang.String auditdate4_2, java.lang.String auditdate4_3,
		java.lang.String auditdateNote4_1, java.lang.String auditdateNote4_2,
		java.lang.String auditdateNote4_3, java.lang.String auditdate5_1,
		java.lang.String auditdate5_2, java.lang.String auditdate5_3,
		java.lang.String auditdate5_4, java.lang.String auditdate5_5,
		java.lang.String auditdate5_6, java.lang.String auditdate5_7,
		java.lang.String auditdate5_8, java.lang.String auditdateNote5_1,
		java.lang.String auditdateNote5_2, java.lang.String auditdateNote5_3,
		java.lang.String auditdateNote5_4, java.lang.String auditdateNote5_5,
		java.lang.String auditdateNote5_6, java.lang.String auditdateNote5_7,
		java.lang.String auditdateNote5_8)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.COMPLIANCE_CHECKAUDIT(aditid,
			auditdate1_1, auditdate1_2, auditdate1_3, auditdate1_4,
			auditdate1_5, auditdate1_6, auditdate1_7, auditdateNote1_1,
			auditdateNote1_2, auditdateNote1_3, auditdateNote1_4,
			auditdateNote1_5, auditdateNote1_6, auditdateNote1_7, auditdate2_1,
			auditdate2_2, auditdate2_3, auditdate2_4, auditdateNote2_1,
			auditdateNote2_2, auditdateNote2_3, auditdateNote2_4,
			auditdate2_4_1, auditdate2_4_2, auditdate2_4_3, auditdate2_4_4,
			auditdateNote2_4_1, auditdateNote2_4_2, auditdateNote2_4_3,
			auditdateNote2_4_4, auditdate3_1, auditdate3_2, auditdate3_3,
			auditdate3_4, auditdate3_5, auditdate3_6, auditdateNote3_1,
			auditdateNote3_2, auditdateNote3_3, auditdateNote3_4,
			auditdateNote3_5, auditdateNote3_6, auditdate4_1, auditdate4_2,
			auditdate4_3, auditdateNote4_1, auditdateNote4_2, auditdateNote4_3,
			auditdate5_1, auditdate5_2, auditdate5_3, auditdate5_4,
			auditdate5_5, auditdate5_6, auditdate5_7, auditdate5_8,
			auditdateNote5_1, auditdateNote5_2, auditdateNote5_3,
			auditdateNote5_4, auditdateNote5_5, auditdateNote5_6,
			auditdateNote5_7, auditdateNote5_8);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject ComplainChekValidation(
		long matterId, long aditid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _employeeAuditService.ComplainChekValidation(matterId, aditid);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public EmployeeAuditService getWrappedEmployeeAuditService() {
		return _employeeAuditService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedEmployeeAuditService(
		EmployeeAuditService employeeAuditService) {
		_employeeAuditService = employeeAuditService;
	}

	@Override
	public EmployeeAuditService getWrappedService() {
		return _employeeAuditService;
	}

	@Override
	public void setWrappedService(EmployeeAuditService employeeAuditService) {
		_employeeAuditService = employeeAuditService;
	}

	private EmployeeAuditService _employeeAuditService;
}