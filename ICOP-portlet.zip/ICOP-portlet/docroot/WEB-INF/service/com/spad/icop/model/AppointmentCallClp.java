/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.AppointmentCallLocalServiceUtil;
import com.spad.icop.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class AppointmentCallClp extends BaseModelImpl<AppointmentCall>
	implements AppointmentCall {
	public AppointmentCallClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return AppointmentCall.class;
	}

	@Override
	public String getModelClassName() {
		return AppointmentCall.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _recordcallid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setRecordcallid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _recordcallid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recordcallid", getRecordcallid());
		attributes.put("aditid", getAditid());
		attributes.put("dateonroadsafty", getDateonroadsafty());
		attributes.put("time", getTime());
		attributes.put("investigationtitle", getInvestigationtitle());
		attributes.put("location", getLocation());
		attributes.put("company", getCompany());
		attributes.put("statusverification", getStatusverification());
		attributes.put("operatorname", getOperatorname());
		attributes.put("nameofOfficer", getNameofOfficer());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recordcallid = (Long)attributes.get("recordcallid");

		if (recordcallid != null) {
			setRecordcallid(recordcallid);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String dateonroadsafty = (String)attributes.get("dateonroadsafty");

		if (dateonroadsafty != null) {
			setDateonroadsafty(dateonroadsafty);
		}

		String time = (String)attributes.get("time");

		if (time != null) {
			setTime(time);
		}

		String investigationtitle = (String)attributes.get("investigationtitle");

		if (investigationtitle != null) {
			setInvestigationtitle(investigationtitle);
		}

		String location = (String)attributes.get("location");

		if (location != null) {
			setLocation(location);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String statusverification = (String)attributes.get("statusverification");

		if (statusverification != null) {
			setStatusverification(statusverification);
		}

		String operatorname = (String)attributes.get("operatorname");

		if (operatorname != null) {
			setOperatorname(operatorname);
		}

		String nameofOfficer = (String)attributes.get("nameofOfficer");

		if (nameofOfficer != null) {
			setNameofOfficer(nameofOfficer);
		}
	}

	@Override
	public long getRecordcallid() {
		return _recordcallid;
	}

	@Override
	public void setRecordcallid(long recordcallid) {
		_recordcallid = recordcallid;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setRecordcallid", long.class);

				method.invoke(_appointmentCallRemoteModel, recordcallid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAditid() {
		return _aditid;
	}

	@Override
	public void setAditid(long aditid) {
		_aditid = aditid;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setAditid", long.class);

				method.invoke(_appointmentCallRemoteModel, aditid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateonroadsafty() {
		return _dateonroadsafty;
	}

	@Override
	public void setDateonroadsafty(String dateonroadsafty) {
		_dateonroadsafty = dateonroadsafty;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setDateonroadsafty",
						String.class);

				method.invoke(_appointmentCallRemoteModel, dateonroadsafty);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTime() {
		return _time;
	}

	@Override
	public void setTime(String time) {
		_time = time;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setTime", String.class);

				method.invoke(_appointmentCallRemoteModel, time);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getInvestigationtitle() {
		return _investigationtitle;
	}

	@Override
	public void setInvestigationtitle(String investigationtitle) {
		_investigationtitle = investigationtitle;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setInvestigationtitle",
						String.class);

				method.invoke(_appointmentCallRemoteModel, investigationtitle);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLocation() {
		return _location;
	}

	@Override
	public void setLocation(String location) {
		_location = location;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setLocation", String.class);

				method.invoke(_appointmentCallRemoteModel, location);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompany() {
		return _company;
	}

	@Override
	public void setCompany(String company) {
		_company = company;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setCompany", String.class);

				method.invoke(_appointmentCallRemoteModel, company);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatusverification() {
		return _statusverification;
	}

	@Override
	public void setStatusverification(String statusverification) {
		_statusverification = statusverification;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusverification",
						String.class);

				method.invoke(_appointmentCallRemoteModel, statusverification);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOperatorname() {
		return _operatorname;
	}

	@Override
	public void setOperatorname(String operatorname) {
		_operatorname = operatorname;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setOperatorname", String.class);

				method.invoke(_appointmentCallRemoteModel, operatorname);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameofOfficer() {
		return _nameofOfficer;
	}

	@Override
	public void setNameofOfficer(String nameofOfficer) {
		_nameofOfficer = nameofOfficer;

		if (_appointmentCallRemoteModel != null) {
			try {
				Class<?> clazz = _appointmentCallRemoteModel.getClass();

				Method method = clazz.getMethod("setNameofOfficer", String.class);

				method.invoke(_appointmentCallRemoteModel, nameofOfficer);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getAppointmentCallRemoteModel() {
		return _appointmentCallRemoteModel;
	}

	public void setAppointmentCallRemoteModel(
		BaseModel<?> appointmentCallRemoteModel) {
		_appointmentCallRemoteModel = appointmentCallRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _appointmentCallRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_appointmentCallRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			AppointmentCallLocalServiceUtil.addAppointmentCall(this);
		}
		else {
			AppointmentCallLocalServiceUtil.updateAppointmentCall(this);
		}
	}

	@Override
	public AppointmentCall toEscapedModel() {
		return (AppointmentCall)ProxyUtil.newProxyInstance(AppointmentCall.class.getClassLoader(),
			new Class[] { AppointmentCall.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		AppointmentCallClp clone = new AppointmentCallClp();

		clone.setRecordcallid(getRecordcallid());
		clone.setAditid(getAditid());
		clone.setDateonroadsafty(getDateonroadsafty());
		clone.setTime(getTime());
		clone.setInvestigationtitle(getInvestigationtitle());
		clone.setLocation(getLocation());
		clone.setCompany(getCompany());
		clone.setStatusverification(getStatusverification());
		clone.setOperatorname(getOperatorname());
		clone.setNameofOfficer(getNameofOfficer());

		return clone;
	}

	@Override
	public int compareTo(AppointmentCall appointmentCall) {
		int value = 0;

		if (getRecordcallid() < appointmentCall.getRecordcallid()) {
			value = -1;
		}
		else if (getRecordcallid() > appointmentCall.getRecordcallid()) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AppointmentCallClp)) {
			return false;
		}

		AppointmentCallClp appointmentCall = (AppointmentCallClp)obj;

		long primaryKey = appointmentCall.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{recordcallid=");
		sb.append(getRecordcallid());
		sb.append(", aditid=");
		sb.append(getAditid());
		sb.append(", dateonroadsafty=");
		sb.append(getDateonroadsafty());
		sb.append(", time=");
		sb.append(getTime());
		sb.append(", investigationtitle=");
		sb.append(getInvestigationtitle());
		sb.append(", location=");
		sb.append(getLocation());
		sb.append(", company=");
		sb.append(getCompany());
		sb.append(", statusverification=");
		sb.append(getStatusverification());
		sb.append(", operatorname=");
		sb.append(getOperatorname());
		sb.append(", nameofOfficer=");
		sb.append(getNameofOfficer());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(34);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.AppointmentCall");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>recordcallid</column-name><column-value><![CDATA[");
		sb.append(getRecordcallid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>aditid</column-name><column-value><![CDATA[");
		sb.append(getAditid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateonroadsafty</column-name><column-value><![CDATA[");
		sb.append(getDateonroadsafty());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>time</column-name><column-value><![CDATA[");
		sb.append(getTime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>investigationtitle</column-name><column-value><![CDATA[");
		sb.append(getInvestigationtitle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>location</column-name><column-value><![CDATA[");
		sb.append(getLocation());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>company</column-name><column-value><![CDATA[");
		sb.append(getCompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusverification</column-name><column-value><![CDATA[");
		sb.append(getStatusverification());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>operatorname</column-name><column-value><![CDATA[");
		sb.append(getOperatorname());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameofOfficer</column-name><column-value><![CDATA[");
		sb.append(getNameofOfficer());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _recordcallid;
	private long _aditid;
	private String _dateonroadsafty;
	private String _time;
	private String _investigationtitle;
	private String _location;
	private String _company;
	private String _statusverification;
	private String _operatorname;
	private String _nameofOfficer;
	private BaseModel<?> _appointmentCallRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}