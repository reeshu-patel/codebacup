/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EmployeeAudit}.
 * </p>
 *
 * @author reeshu
 * @see EmployeeAudit
 * @generated
 */
public class EmployeeAuditWrapper implements EmployeeAudit,
	ModelWrapper<EmployeeAudit> {
	public EmployeeAuditWrapper(EmployeeAudit employeeAudit) {
		_employeeAudit = employeeAudit;
	}

	@Override
	public Class<?> getModelClass() {
		return EmployeeAudit.class;
	}

	@Override
	public String getModelClassName() {
		return EmployeeAudit.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("aditid", getAditid());
		attributes.put("dateonroad", getDateonroad());
		attributes.put("dateofincident", getDateofincident());
		attributes.put("timeevent", getTimeevent());
		attributes.put("titleinvestigation", getTitleinvestigation());
		attributes.put("typeofvehicle", getTypeofvehicle());
		attributes.put("noregistration", getNoregistration());
		attributes.put("company", getCompany());
		attributes.put("reportsKjr", getReportsKjr());
		attributes.put("reportscmd", getReportscmd());
		attributes.put("srustatus", getSrustatus());
		attributes.put("completedStatus", getCompletedStatus());
		attributes.put("audidate", getAudidate());
		attributes.put("auditime", getAuditime());
		attributes.put("statusofadudit", getStatusofadudit());
		attributes.put("completeddate", getCompleteddate());
		attributes.put("addresss", getAddresss());
		attributes.put("locationofincident", getLocationofincident());
		attributes.put("trainingattendance", getTrainingattendance());
		attributes.put("auditaccidents", getAuditaccidents());
		attributes.put("typecertificate", getTypecertificate());
		attributes.put("dateofregistration", getDateofregistration());
		attributes.put("trainingdates", getTrainingdates());
		attributes.put("enddate", getEnddate());
		attributes.put("typemod", getTypemod());
		attributes.put("typeoflicens", getTypeoflicens());
		attributes.put("typeofcompany", getTypeofcompany());
		attributes.put("phoneno", getPhoneno());
		attributes.put("status", getStatus());
		attributes.put("appendixg", getAppendixg());
		attributes.put("dateCaseSrU", getDateCaseSrU());
		attributes.put("actionSru", getActionSru());
		attributes.put("officerName", getOfficerName());
		attributes.put("vehiclesNo", getVehiclesNo());
		attributes.put("companyEmail", getCompanyEmail());
		attributes.put("representativeName", getRepresentativeName());
		attributes.put("companieListNumber", getCompanieListNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String dateonroad = (String)attributes.get("dateonroad");

		if (dateonroad != null) {
			setDateonroad(dateonroad);
		}

		String dateofincident = (String)attributes.get("dateofincident");

		if (dateofincident != null) {
			setDateofincident(dateofincident);
		}

		String timeevent = (String)attributes.get("timeevent");

		if (timeevent != null) {
			setTimeevent(timeevent);
		}

		String titleinvestigation = (String)attributes.get("titleinvestigation");

		if (titleinvestigation != null) {
			setTitleinvestigation(titleinvestigation);
		}

		String typeofvehicle = (String)attributes.get("typeofvehicle");

		if (typeofvehicle != null) {
			setTypeofvehicle(typeofvehicle);
		}

		String noregistration = (String)attributes.get("noregistration");

		if (noregistration != null) {
			setNoregistration(noregistration);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String reportsKjr = (String)attributes.get("reportsKjr");

		if (reportsKjr != null) {
			setReportsKjr(reportsKjr);
		}

		String reportscmd = (String)attributes.get("reportscmd");

		if (reportscmd != null) {
			setReportscmd(reportscmd);
		}

		String srustatus = (String)attributes.get("srustatus");

		if (srustatus != null) {
			setSrustatus(srustatus);
		}

		String completedStatus = (String)attributes.get("completedStatus");

		if (completedStatus != null) {
			setCompletedStatus(completedStatus);
		}

		String audidate = (String)attributes.get("audidate");

		if (audidate != null) {
			setAudidate(audidate);
		}

		String auditime = (String)attributes.get("auditime");

		if (auditime != null) {
			setAuditime(auditime);
		}

		String statusofadudit = (String)attributes.get("statusofadudit");

		if (statusofadudit != null) {
			setStatusofadudit(statusofadudit);
		}

		String completeddate = (String)attributes.get("completeddate");

		if (completeddate != null) {
			setCompleteddate(completeddate);
		}

		String addresss = (String)attributes.get("addresss");

		if (addresss != null) {
			setAddresss(addresss);
		}

		String locationofincident = (String)attributes.get("locationofincident");

		if (locationofincident != null) {
			setLocationofincident(locationofincident);
		}

		String trainingattendance = (String)attributes.get("trainingattendance");

		if (trainingattendance != null) {
			setTrainingattendance(trainingattendance);
		}

		String auditaccidents = (String)attributes.get("auditaccidents");

		if (auditaccidents != null) {
			setAuditaccidents(auditaccidents);
		}

		String typecertificate = (String)attributes.get("typecertificate");

		if (typecertificate != null) {
			setTypecertificate(typecertificate);
		}

		String dateofregistration = (String)attributes.get("dateofregistration");

		if (dateofregistration != null) {
			setDateofregistration(dateofregistration);
		}

		String trainingdates = (String)attributes.get("trainingdates");

		if (trainingdates != null) {
			setTrainingdates(trainingdates);
		}

		String enddate = (String)attributes.get("enddate");

		if (enddate != null) {
			setEnddate(enddate);
		}

		String typemod = (String)attributes.get("typemod");

		if (typemod != null) {
			setTypemod(typemod);
		}

		String typeoflicens = (String)attributes.get("typeoflicens");

		if (typeoflicens != null) {
			setTypeoflicens(typeoflicens);
		}

		String typeofcompany = (String)attributes.get("typeofcompany");

		if (typeofcompany != null) {
			setTypeofcompany(typeofcompany);
		}

		String phoneno = (String)attributes.get("phoneno");

		if (phoneno != null) {
			setPhoneno(phoneno);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String appendixg = (String)attributes.get("appendixg");

		if (appendixg != null) {
			setAppendixg(appendixg);
		}

		String dateCaseSrU = (String)attributes.get("dateCaseSrU");

		if (dateCaseSrU != null) {
			setDateCaseSrU(dateCaseSrU);
		}

		String actionSru = (String)attributes.get("actionSru");

		if (actionSru != null) {
			setActionSru(actionSru);
		}

		String officerName = (String)attributes.get("officerName");

		if (officerName != null) {
			setOfficerName(officerName);
		}

		String vehiclesNo = (String)attributes.get("vehiclesNo");

		if (vehiclesNo != null) {
			setVehiclesNo(vehiclesNo);
		}

		String companyEmail = (String)attributes.get("companyEmail");

		if (companyEmail != null) {
			setCompanyEmail(companyEmail);
		}

		String representativeName = (String)attributes.get("representativeName");

		if (representativeName != null) {
			setRepresentativeName(representativeName);
		}

		String companieListNumber = (String)attributes.get("companieListNumber");

		if (companieListNumber != null) {
			setCompanieListNumber(companieListNumber);
		}
	}

	/**
	* Returns the primary key of this employee audit.
	*
	* @return the primary key of this employee audit
	*/
	@Override
	public long getPrimaryKey() {
		return _employeeAudit.getPrimaryKey();
	}

	/**
	* Sets the primary key of this employee audit.
	*
	* @param primaryKey the primary key of this employee audit
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_employeeAudit.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the aditid of this employee audit.
	*
	* @return the aditid of this employee audit
	*/
	@Override
	public long getAditid() {
		return _employeeAudit.getAditid();
	}

	/**
	* Sets the aditid of this employee audit.
	*
	* @param aditid the aditid of this employee audit
	*/
	@Override
	public void setAditid(long aditid) {
		_employeeAudit.setAditid(aditid);
	}

	/**
	* Returns the dateonroad of this employee audit.
	*
	* @return the dateonroad of this employee audit
	*/
	@Override
	public java.lang.String getDateonroad() {
		return _employeeAudit.getDateonroad();
	}

	/**
	* Sets the dateonroad of this employee audit.
	*
	* @param dateonroad the dateonroad of this employee audit
	*/
	@Override
	public void setDateonroad(java.lang.String dateonroad) {
		_employeeAudit.setDateonroad(dateonroad);
	}

	/**
	* Returns the dateofincident of this employee audit.
	*
	* @return the dateofincident of this employee audit
	*/
	@Override
	public java.lang.String getDateofincident() {
		return _employeeAudit.getDateofincident();
	}

	/**
	* Sets the dateofincident of this employee audit.
	*
	* @param dateofincident the dateofincident of this employee audit
	*/
	@Override
	public void setDateofincident(java.lang.String dateofincident) {
		_employeeAudit.setDateofincident(dateofincident);
	}

	/**
	* Returns the timeevent of this employee audit.
	*
	* @return the timeevent of this employee audit
	*/
	@Override
	public java.lang.String getTimeevent() {
		return _employeeAudit.getTimeevent();
	}

	/**
	* Sets the timeevent of this employee audit.
	*
	* @param timeevent the timeevent of this employee audit
	*/
	@Override
	public void setTimeevent(java.lang.String timeevent) {
		_employeeAudit.setTimeevent(timeevent);
	}

	/**
	* Returns the titleinvestigation of this employee audit.
	*
	* @return the titleinvestigation of this employee audit
	*/
	@Override
	public java.lang.String getTitleinvestigation() {
		return _employeeAudit.getTitleinvestigation();
	}

	/**
	* Sets the titleinvestigation of this employee audit.
	*
	* @param titleinvestigation the titleinvestigation of this employee audit
	*/
	@Override
	public void setTitleinvestigation(java.lang.String titleinvestigation) {
		_employeeAudit.setTitleinvestigation(titleinvestigation);
	}

	/**
	* Returns the typeofvehicle of this employee audit.
	*
	* @return the typeofvehicle of this employee audit
	*/
	@Override
	public java.lang.String getTypeofvehicle() {
		return _employeeAudit.getTypeofvehicle();
	}

	/**
	* Sets the typeofvehicle of this employee audit.
	*
	* @param typeofvehicle the typeofvehicle of this employee audit
	*/
	@Override
	public void setTypeofvehicle(java.lang.String typeofvehicle) {
		_employeeAudit.setTypeofvehicle(typeofvehicle);
	}

	/**
	* Returns the noregistration of this employee audit.
	*
	* @return the noregistration of this employee audit
	*/
	@Override
	public java.lang.String getNoregistration() {
		return _employeeAudit.getNoregistration();
	}

	/**
	* Sets the noregistration of this employee audit.
	*
	* @param noregistration the noregistration of this employee audit
	*/
	@Override
	public void setNoregistration(java.lang.String noregistration) {
		_employeeAudit.setNoregistration(noregistration);
	}

	/**
	* Returns the company of this employee audit.
	*
	* @return the company of this employee audit
	*/
	@Override
	public java.lang.String getCompany() {
		return _employeeAudit.getCompany();
	}

	/**
	* Sets the company of this employee audit.
	*
	* @param company the company of this employee audit
	*/
	@Override
	public void setCompany(java.lang.String company) {
		_employeeAudit.setCompany(company);
	}

	/**
	* Returns the reports kjr of this employee audit.
	*
	* @return the reports kjr of this employee audit
	*/
	@Override
	public java.lang.String getReportsKjr() {
		return _employeeAudit.getReportsKjr();
	}

	/**
	* Sets the reports kjr of this employee audit.
	*
	* @param reportsKjr the reports kjr of this employee audit
	*/
	@Override
	public void setReportsKjr(java.lang.String reportsKjr) {
		_employeeAudit.setReportsKjr(reportsKjr);
	}

	/**
	* Returns the reportscmd of this employee audit.
	*
	* @return the reportscmd of this employee audit
	*/
	@Override
	public java.lang.String getReportscmd() {
		return _employeeAudit.getReportscmd();
	}

	/**
	* Sets the reportscmd of this employee audit.
	*
	* @param reportscmd the reportscmd of this employee audit
	*/
	@Override
	public void setReportscmd(java.lang.String reportscmd) {
		_employeeAudit.setReportscmd(reportscmd);
	}

	/**
	* Returns the srustatus of this employee audit.
	*
	* @return the srustatus of this employee audit
	*/
	@Override
	public java.lang.String getSrustatus() {
		return _employeeAudit.getSrustatus();
	}

	/**
	* Sets the srustatus of this employee audit.
	*
	* @param srustatus the srustatus of this employee audit
	*/
	@Override
	public void setSrustatus(java.lang.String srustatus) {
		_employeeAudit.setSrustatus(srustatus);
	}

	/**
	* Returns the completed status of this employee audit.
	*
	* @return the completed status of this employee audit
	*/
	@Override
	public java.lang.String getCompletedStatus() {
		return _employeeAudit.getCompletedStatus();
	}

	/**
	* Sets the completed status of this employee audit.
	*
	* @param completedStatus the completed status of this employee audit
	*/
	@Override
	public void setCompletedStatus(java.lang.String completedStatus) {
		_employeeAudit.setCompletedStatus(completedStatus);
	}

	/**
	* Returns the audidate of this employee audit.
	*
	* @return the audidate of this employee audit
	*/
	@Override
	public java.lang.String getAudidate() {
		return _employeeAudit.getAudidate();
	}

	/**
	* Sets the audidate of this employee audit.
	*
	* @param audidate the audidate of this employee audit
	*/
	@Override
	public void setAudidate(java.lang.String audidate) {
		_employeeAudit.setAudidate(audidate);
	}

	/**
	* Returns the auditime of this employee audit.
	*
	* @return the auditime of this employee audit
	*/
	@Override
	public java.lang.String getAuditime() {
		return _employeeAudit.getAuditime();
	}

	/**
	* Sets the auditime of this employee audit.
	*
	* @param auditime the auditime of this employee audit
	*/
	@Override
	public void setAuditime(java.lang.String auditime) {
		_employeeAudit.setAuditime(auditime);
	}

	/**
	* Returns the statusofadudit of this employee audit.
	*
	* @return the statusofadudit of this employee audit
	*/
	@Override
	public java.lang.String getStatusofadudit() {
		return _employeeAudit.getStatusofadudit();
	}

	/**
	* Sets the statusofadudit of this employee audit.
	*
	* @param statusofadudit the statusofadudit of this employee audit
	*/
	@Override
	public void setStatusofadudit(java.lang.String statusofadudit) {
		_employeeAudit.setStatusofadudit(statusofadudit);
	}

	/**
	* Returns the completeddate of this employee audit.
	*
	* @return the completeddate of this employee audit
	*/
	@Override
	public java.lang.String getCompleteddate() {
		return _employeeAudit.getCompleteddate();
	}

	/**
	* Sets the completeddate of this employee audit.
	*
	* @param completeddate the completeddate of this employee audit
	*/
	@Override
	public void setCompleteddate(java.lang.String completeddate) {
		_employeeAudit.setCompleteddate(completeddate);
	}

	/**
	* Returns the addresss of this employee audit.
	*
	* @return the addresss of this employee audit
	*/
	@Override
	public java.lang.String getAddresss() {
		return _employeeAudit.getAddresss();
	}

	/**
	* Sets the addresss of this employee audit.
	*
	* @param addresss the addresss of this employee audit
	*/
	@Override
	public void setAddresss(java.lang.String addresss) {
		_employeeAudit.setAddresss(addresss);
	}

	/**
	* Returns the locationofincident of this employee audit.
	*
	* @return the locationofincident of this employee audit
	*/
	@Override
	public java.lang.String getLocationofincident() {
		return _employeeAudit.getLocationofincident();
	}

	/**
	* Sets the locationofincident of this employee audit.
	*
	* @param locationofincident the locationofincident of this employee audit
	*/
	@Override
	public void setLocationofincident(java.lang.String locationofincident) {
		_employeeAudit.setLocationofincident(locationofincident);
	}

	/**
	* Returns the trainingattendance of this employee audit.
	*
	* @return the trainingattendance of this employee audit
	*/
	@Override
	public java.lang.String getTrainingattendance() {
		return _employeeAudit.getTrainingattendance();
	}

	/**
	* Sets the trainingattendance of this employee audit.
	*
	* @param trainingattendance the trainingattendance of this employee audit
	*/
	@Override
	public void setTrainingattendance(java.lang.String trainingattendance) {
		_employeeAudit.setTrainingattendance(trainingattendance);
	}

	/**
	* Returns the auditaccidents of this employee audit.
	*
	* @return the auditaccidents of this employee audit
	*/
	@Override
	public java.lang.String getAuditaccidents() {
		return _employeeAudit.getAuditaccidents();
	}

	/**
	* Sets the auditaccidents of this employee audit.
	*
	* @param auditaccidents the auditaccidents of this employee audit
	*/
	@Override
	public void setAuditaccidents(java.lang.String auditaccidents) {
		_employeeAudit.setAuditaccidents(auditaccidents);
	}

	/**
	* Returns the typecertificate of this employee audit.
	*
	* @return the typecertificate of this employee audit
	*/
	@Override
	public java.lang.String getTypecertificate() {
		return _employeeAudit.getTypecertificate();
	}

	/**
	* Sets the typecertificate of this employee audit.
	*
	* @param typecertificate the typecertificate of this employee audit
	*/
	@Override
	public void setTypecertificate(java.lang.String typecertificate) {
		_employeeAudit.setTypecertificate(typecertificate);
	}

	/**
	* Returns the dateofregistration of this employee audit.
	*
	* @return the dateofregistration of this employee audit
	*/
	@Override
	public java.lang.String getDateofregistration() {
		return _employeeAudit.getDateofregistration();
	}

	/**
	* Sets the dateofregistration of this employee audit.
	*
	* @param dateofregistration the dateofregistration of this employee audit
	*/
	@Override
	public void setDateofregistration(java.lang.String dateofregistration) {
		_employeeAudit.setDateofregistration(dateofregistration);
	}

	/**
	* Returns the trainingdates of this employee audit.
	*
	* @return the trainingdates of this employee audit
	*/
	@Override
	public java.lang.String getTrainingdates() {
		return _employeeAudit.getTrainingdates();
	}

	/**
	* Sets the trainingdates of this employee audit.
	*
	* @param trainingdates the trainingdates of this employee audit
	*/
	@Override
	public void setTrainingdates(java.lang.String trainingdates) {
		_employeeAudit.setTrainingdates(trainingdates);
	}

	/**
	* Returns the enddate of this employee audit.
	*
	* @return the enddate of this employee audit
	*/
	@Override
	public java.lang.String getEnddate() {
		return _employeeAudit.getEnddate();
	}

	/**
	* Sets the enddate of this employee audit.
	*
	* @param enddate the enddate of this employee audit
	*/
	@Override
	public void setEnddate(java.lang.String enddate) {
		_employeeAudit.setEnddate(enddate);
	}

	/**
	* Returns the typemod of this employee audit.
	*
	* @return the typemod of this employee audit
	*/
	@Override
	public java.lang.String getTypemod() {
		return _employeeAudit.getTypemod();
	}

	/**
	* Sets the typemod of this employee audit.
	*
	* @param typemod the typemod of this employee audit
	*/
	@Override
	public void setTypemod(java.lang.String typemod) {
		_employeeAudit.setTypemod(typemod);
	}

	/**
	* Returns the typeoflicens of this employee audit.
	*
	* @return the typeoflicens of this employee audit
	*/
	@Override
	public java.lang.String getTypeoflicens() {
		return _employeeAudit.getTypeoflicens();
	}

	/**
	* Sets the typeoflicens of this employee audit.
	*
	* @param typeoflicens the typeoflicens of this employee audit
	*/
	@Override
	public void setTypeoflicens(java.lang.String typeoflicens) {
		_employeeAudit.setTypeoflicens(typeoflicens);
	}

	/**
	* Returns the typeofcompany of this employee audit.
	*
	* @return the typeofcompany of this employee audit
	*/
	@Override
	public java.lang.String getTypeofcompany() {
		return _employeeAudit.getTypeofcompany();
	}

	/**
	* Sets the typeofcompany of this employee audit.
	*
	* @param typeofcompany the typeofcompany of this employee audit
	*/
	@Override
	public void setTypeofcompany(java.lang.String typeofcompany) {
		_employeeAudit.setTypeofcompany(typeofcompany);
	}

	/**
	* Returns the phoneno of this employee audit.
	*
	* @return the phoneno of this employee audit
	*/
	@Override
	public java.lang.String getPhoneno() {
		return _employeeAudit.getPhoneno();
	}

	/**
	* Sets the phoneno of this employee audit.
	*
	* @param phoneno the phoneno of this employee audit
	*/
	@Override
	public void setPhoneno(java.lang.String phoneno) {
		_employeeAudit.setPhoneno(phoneno);
	}

	/**
	* Returns the status of this employee audit.
	*
	* @return the status of this employee audit
	*/
	@Override
	public java.lang.String getStatus() {
		return _employeeAudit.getStatus();
	}

	/**
	* Sets the status of this employee audit.
	*
	* @param status the status of this employee audit
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_employeeAudit.setStatus(status);
	}

	/**
	* Returns the appendixg of this employee audit.
	*
	* @return the appendixg of this employee audit
	*/
	@Override
	public java.lang.String getAppendixg() {
		return _employeeAudit.getAppendixg();
	}

	/**
	* Sets the appendixg of this employee audit.
	*
	* @param appendixg the appendixg of this employee audit
	*/
	@Override
	public void setAppendixg(java.lang.String appendixg) {
		_employeeAudit.setAppendixg(appendixg);
	}

	/**
	* Returns the date case sr u of this employee audit.
	*
	* @return the date case sr u of this employee audit
	*/
	@Override
	public java.lang.String getDateCaseSrU() {
		return _employeeAudit.getDateCaseSrU();
	}

	/**
	* Sets the date case sr u of this employee audit.
	*
	* @param dateCaseSrU the date case sr u of this employee audit
	*/
	@Override
	public void setDateCaseSrU(java.lang.String dateCaseSrU) {
		_employeeAudit.setDateCaseSrU(dateCaseSrU);
	}

	/**
	* Returns the action sru of this employee audit.
	*
	* @return the action sru of this employee audit
	*/
	@Override
	public java.lang.String getActionSru() {
		return _employeeAudit.getActionSru();
	}

	/**
	* Sets the action sru of this employee audit.
	*
	* @param actionSru the action sru of this employee audit
	*/
	@Override
	public void setActionSru(java.lang.String actionSru) {
		_employeeAudit.setActionSru(actionSru);
	}

	/**
	* Returns the officer name of this employee audit.
	*
	* @return the officer name of this employee audit
	*/
	@Override
	public java.lang.String getOfficerName() {
		return _employeeAudit.getOfficerName();
	}

	/**
	* Sets the officer name of this employee audit.
	*
	* @param officerName the officer name of this employee audit
	*/
	@Override
	public void setOfficerName(java.lang.String officerName) {
		_employeeAudit.setOfficerName(officerName);
	}

	/**
	* Returns the vehicles no of this employee audit.
	*
	* @return the vehicles no of this employee audit
	*/
	@Override
	public java.lang.String getVehiclesNo() {
		return _employeeAudit.getVehiclesNo();
	}

	/**
	* Sets the vehicles no of this employee audit.
	*
	* @param vehiclesNo the vehicles no of this employee audit
	*/
	@Override
	public void setVehiclesNo(java.lang.String vehiclesNo) {
		_employeeAudit.setVehiclesNo(vehiclesNo);
	}

	/**
	* Returns the company email of this employee audit.
	*
	* @return the company email of this employee audit
	*/
	@Override
	public java.lang.String getCompanyEmail() {
		return _employeeAudit.getCompanyEmail();
	}

	/**
	* Sets the company email of this employee audit.
	*
	* @param companyEmail the company email of this employee audit
	*/
	@Override
	public void setCompanyEmail(java.lang.String companyEmail) {
		_employeeAudit.setCompanyEmail(companyEmail);
	}

	/**
	* Returns the representative name of this employee audit.
	*
	* @return the representative name of this employee audit
	*/
	@Override
	public java.lang.String getRepresentativeName() {
		return _employeeAudit.getRepresentativeName();
	}

	/**
	* Sets the representative name of this employee audit.
	*
	* @param representativeName the representative name of this employee audit
	*/
	@Override
	public void setRepresentativeName(java.lang.String representativeName) {
		_employeeAudit.setRepresentativeName(representativeName);
	}

	/**
	* Returns the companie list number of this employee audit.
	*
	* @return the companie list number of this employee audit
	*/
	@Override
	public java.lang.String getCompanieListNumber() {
		return _employeeAudit.getCompanieListNumber();
	}

	/**
	* Sets the companie list number of this employee audit.
	*
	* @param companieListNumber the companie list number of this employee audit
	*/
	@Override
	public void setCompanieListNumber(java.lang.String companieListNumber) {
		_employeeAudit.setCompanieListNumber(companieListNumber);
	}

	@Override
	public boolean isNew() {
		return _employeeAudit.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_employeeAudit.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _employeeAudit.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_employeeAudit.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _employeeAudit.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _employeeAudit.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_employeeAudit.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _employeeAudit.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_employeeAudit.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_employeeAudit.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_employeeAudit.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EmployeeAuditWrapper((EmployeeAudit)_employeeAudit.clone());
	}

	@Override
	public int compareTo(com.spad.icop.model.EmployeeAudit employeeAudit) {
		return _employeeAudit.compareTo(employeeAudit);
	}

	@Override
	public int hashCode() {
		return _employeeAudit.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.EmployeeAudit> toCacheModel() {
		return _employeeAudit.toCacheModel();
	}

	@Override
	public com.spad.icop.model.EmployeeAudit toEscapedModel() {
		return new EmployeeAuditWrapper(_employeeAudit.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.EmployeeAudit toUnescapedModel() {
		return new EmployeeAuditWrapper(_employeeAudit.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _employeeAudit.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _employeeAudit.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_employeeAudit.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EmployeeAuditWrapper)) {
			return false;
		}

		EmployeeAuditWrapper employeeAuditWrapper = (EmployeeAuditWrapper)obj;

		if (Validator.equals(_employeeAudit, employeeAuditWrapper._employeeAudit)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public EmployeeAudit getWrappedEmployeeAudit() {
		return _employeeAudit;
	}

	@Override
	public EmployeeAudit getWrappedModel() {
		return _employeeAudit;
	}

	@Override
	public void resetOriginalValues() {
		_employeeAudit.resetOriginalValues();
	}

	private EmployeeAudit _employeeAudit;
}