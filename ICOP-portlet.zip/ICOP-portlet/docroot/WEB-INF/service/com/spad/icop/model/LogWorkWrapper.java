/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LogWork}.
 * </p>
 *
 * @author reeshu
 * @see LogWork
 * @generated
 */
public class LogWorkWrapper implements LogWork, ModelWrapper<LogWork> {
	public LogWorkWrapper(LogWork logWork) {
		_logWork = logWork;
	}

	@Override
	public Class<?> getModelClass() {
		return LogWork.class;
	}

	@Override
	public String getModelClassName() {
		return LogWork.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("logworkId", getLogworkId());
		attributes.put("user", getUser());
		attributes.put("time", getTime());
		attributes.put("detail", getDetail());
		attributes.put("chronicle", getChronicle());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long logworkId = (Long)attributes.get("logworkId");

		if (logworkId != null) {
			setLogworkId(logworkId);
		}

		String user = (String)attributes.get("user");

		if (user != null) {
			setUser(user);
		}

		String time = (String)attributes.get("time");

		if (time != null) {
			setTime(time);
		}

		String detail = (String)attributes.get("detail");

		if (detail != null) {
			setDetail(detail);
		}

		String chronicle = (String)attributes.get("chronicle");

		if (chronicle != null) {
			setChronicle(chronicle);
		}
	}

	/**
	* Returns the primary key of this log work.
	*
	* @return the primary key of this log work
	*/
	@Override
	public long getPrimaryKey() {
		return _logWork.getPrimaryKey();
	}

	/**
	* Sets the primary key of this log work.
	*
	* @param primaryKey the primary key of this log work
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_logWork.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the logwork ID of this log work.
	*
	* @return the logwork ID of this log work
	*/
	@Override
	public long getLogworkId() {
		return _logWork.getLogworkId();
	}

	/**
	* Sets the logwork ID of this log work.
	*
	* @param logworkId the logwork ID of this log work
	*/
	@Override
	public void setLogworkId(long logworkId) {
		_logWork.setLogworkId(logworkId);
	}

	/**
	* Returns the user of this log work.
	*
	* @return the user of this log work
	*/
	@Override
	public java.lang.String getUser() {
		return _logWork.getUser();
	}

	/**
	* Sets the user of this log work.
	*
	* @param user the user of this log work
	*/
	@Override
	public void setUser(java.lang.String user) {
		_logWork.setUser(user);
	}

	/**
	* Returns the time of this log work.
	*
	* @return the time of this log work
	*/
	@Override
	public java.lang.String getTime() {
		return _logWork.getTime();
	}

	/**
	* Sets the time of this log work.
	*
	* @param time the time of this log work
	*/
	@Override
	public void setTime(java.lang.String time) {
		_logWork.setTime(time);
	}

	/**
	* Returns the detail of this log work.
	*
	* @return the detail of this log work
	*/
	@Override
	public java.lang.String getDetail() {
		return _logWork.getDetail();
	}

	/**
	* Sets the detail of this log work.
	*
	* @param detail the detail of this log work
	*/
	@Override
	public void setDetail(java.lang.String detail) {
		_logWork.setDetail(detail);
	}

	/**
	* Returns the chronicle of this log work.
	*
	* @return the chronicle of this log work
	*/
	@Override
	public java.lang.String getChronicle() {
		return _logWork.getChronicle();
	}

	/**
	* Sets the chronicle of this log work.
	*
	* @param chronicle the chronicle of this log work
	*/
	@Override
	public void setChronicle(java.lang.String chronicle) {
		_logWork.setChronicle(chronicle);
	}

	@Override
	public boolean isNew() {
		return _logWork.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_logWork.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _logWork.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_logWork.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _logWork.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _logWork.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_logWork.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _logWork.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_logWork.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_logWork.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_logWork.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LogWorkWrapper((LogWork)_logWork.clone());
	}

	@Override
	public int compareTo(com.spad.icop.model.LogWork logWork) {
		return _logWork.compareTo(logWork);
	}

	@Override
	public int hashCode() {
		return _logWork.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.LogWork> toCacheModel() {
		return _logWork.toCacheModel();
	}

	@Override
	public com.spad.icop.model.LogWork toEscapedModel() {
		return new LogWorkWrapper(_logWork.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.LogWork toUnescapedModel() {
		return new LogWorkWrapper(_logWork.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _logWork.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _logWork.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_logWork.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LogWorkWrapper)) {
			return false;
		}

		LogWorkWrapper logWorkWrapper = (LogWorkWrapper)obj;

		if (Validator.equals(_logWork, logWorkWrapper._logWork)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LogWork getWrappedLogWork() {
		return _logWork;
	}

	@Override
	public LogWork getWrappedModel() {
		return _logWork;
	}

	@Override
	public void resetOriginalValues() {
		_logWork.resetOriginalValues();
	}

	private LogWork _logWork;
}