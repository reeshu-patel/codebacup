/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ComplainCheckAudit}.
 * </p>
 *
 * @author reeshu
 * @see ComplainCheckAudit
 * @generated
 */
public class ComplainCheckAuditWrapper implements ComplainCheckAudit,
	ModelWrapper<ComplainCheckAudit> {
	public ComplainCheckAuditWrapper(ComplainCheckAudit complainCheckAudit) {
		_complainCheckAudit = complainCheckAudit;
	}

	@Override
	public Class<?> getModelClass() {
		return ComplainCheckAudit.class;
	}

	@Override
	public String getModelClassName() {
		return ComplainCheckAudit.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("matterId", getMatterId());
		attributes.put("aditid", getAditid());
		attributes.put("auditdate1_1", getAuditdate1_1());
		attributes.put("auditdateNote1_1", getAuditdateNote1_1());
		attributes.put("auditdate1_2", getAuditdate1_2());
		attributes.put("auditdateNote1_2", getAuditdateNote1_2());
		attributes.put("auditdate1_3", getAuditdate1_3());
		attributes.put("auditdateNote1_3", getAuditdateNote1_3());
		attributes.put("auditdate1_4", getAuditdate1_4());
		attributes.put("auditdateNote1_4", getAuditdateNote1_4());
		attributes.put("auditdate1_5", getAuditdate1_5());
		attributes.put("auditdateNote1_5", getAuditdateNote1_5());
		attributes.put("auditdate1_6", getAuditdate1_6());
		attributes.put("auditdateNote1_6", getAuditdateNote1_6());
		attributes.put("auditdate1_7", getAuditdate1_7());
		attributes.put("auditdateNote1_7", getAuditdateNote1_7());
		attributes.put("auditdate2_1", getAuditdate2_1());
		attributes.put("auditdateNote2_1", getAuditdateNote2_1());
		attributes.put("auditdate2_2", getAuditdate2_2());
		attributes.put("auditdateNote2_2", getAuditdateNote2_2());
		attributes.put("auditdate2_3", getAuditdate2_3());
		attributes.put("auditdateNote2_3", getAuditdateNote2_3());
		attributes.put("auditdate2_4", getAuditdate2_4());
		attributes.put("auditdateNote2_4", getAuditdateNote2_4());
		attributes.put("auditdate2_4_1", getAuditdate2_4_1());
		attributes.put("auditdateNote2_4_1", getAuditdateNote2_4_1());
		attributes.put("auditdate2_4_2", getAuditdate2_4_2());
		attributes.put("auditdateNote2_4_2", getAuditdateNote2_4_2());
		attributes.put("auditdate2_4_3", getAuditdate2_4_3());
		attributes.put("auditdateNote2_4_3", getAuditdateNote2_4_3());
		attributes.put("auditdate2_4_4", getAuditdate2_4_4());
		attributes.put("auditdateNote2_4_4", getAuditdateNote2_4_4());
		attributes.put("auditdate2_4_5", getAuditdate2_4_5());
		attributes.put("auditdateNote2_4_5", getAuditdateNote2_4_5());
		attributes.put("auditdate2_4_6", getAuditdate2_4_6());
		attributes.put("auditdateNote2_4_6", getAuditdateNote2_4_6());
		attributes.put("auditdate3_1", getAuditdate3_1());
		attributes.put("auditdate3_2", getAuditdate3_2());
		attributes.put("auditdate3_3", getAuditdate3_3());
		attributes.put("auditdate3_4", getAuditdate3_4());
		attributes.put("auditdate3_5", getAuditdate3_5());
		attributes.put("auditdate3_6", getAuditdate3_6());
		attributes.put("auditdateNote3_1", getAuditdateNote3_1());
		attributes.put("auditdateNote3_2", getAuditdateNote3_2());
		attributes.put("auditdateNote3_3", getAuditdateNote3_3());
		attributes.put("auditdateNote3_4", getAuditdateNote3_4());
		attributes.put("auditdateNote3_5", getAuditdateNote3_5());
		attributes.put("auditdateNote3_6", getAuditdateNote3_6());
		attributes.put("auditdate4_1", getAuditdate4_1());
		attributes.put("auditdate4_2", getAuditdate4_2());
		attributes.put("auditdate4_3", getAuditdate4_3());
		attributes.put("auditdateNote4_1", getAuditdateNote4_1());
		attributes.put("auditdateNote4_2", getAuditdateNote4_2());
		attributes.put("auditdateNote4_3", getAuditdateNote4_3());
		attributes.put("auditdate5_1", getAuditdate5_1());
		attributes.put("auditdate5_2", getAuditdate5_2());
		attributes.put("auditdate5_3", getAuditdate5_3());
		attributes.put("auditdate5_4", getAuditdate5_4());
		attributes.put("auditdate5_5", getAuditdate5_5());
		attributes.put("auditdate5_6", getAuditdate5_6());
		attributes.put("auditdate5_7", getAuditdate5_7());
		attributes.put("auditdate5_8", getAuditdate5_8());
		attributes.put("auditdateNote5_1", getAuditdateNote5_1());
		attributes.put("auditdateNote5_2", getAuditdateNote5_2());
		attributes.put("auditdateNote5_3", getAuditdateNote5_3());
		attributes.put("auditdateNote5_4", getAuditdateNote5_4());
		attributes.put("auditdateNote5_5", getAuditdateNote5_5());
		attributes.put("auditdateNote5_6", getAuditdateNote5_6());
		attributes.put("auditdateNote5_7", getAuditdateNote5_7());
		attributes.put("auditdateNote5_8", getAuditdateNote5_8());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long matterId = (Long)attributes.get("matterId");

		if (matterId != null) {
			setMatterId(matterId);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String auditdate1_1 = (String)attributes.get("auditdate1_1");

		if (auditdate1_1 != null) {
			setAuditdate1_1(auditdate1_1);
		}

		String auditdateNote1_1 = (String)attributes.get("auditdateNote1_1");

		if (auditdateNote1_1 != null) {
			setAuditdateNote1_1(auditdateNote1_1);
		}

		String auditdate1_2 = (String)attributes.get("auditdate1_2");

		if (auditdate1_2 != null) {
			setAuditdate1_2(auditdate1_2);
		}

		String auditdateNote1_2 = (String)attributes.get("auditdateNote1_2");

		if (auditdateNote1_2 != null) {
			setAuditdateNote1_2(auditdateNote1_2);
		}

		String auditdate1_3 = (String)attributes.get("auditdate1_3");

		if (auditdate1_3 != null) {
			setAuditdate1_3(auditdate1_3);
		}

		String auditdateNote1_3 = (String)attributes.get("auditdateNote1_3");

		if (auditdateNote1_3 != null) {
			setAuditdateNote1_3(auditdateNote1_3);
		}

		String auditdate1_4 = (String)attributes.get("auditdate1_4");

		if (auditdate1_4 != null) {
			setAuditdate1_4(auditdate1_4);
		}

		String auditdateNote1_4 = (String)attributes.get("auditdateNote1_4");

		if (auditdateNote1_4 != null) {
			setAuditdateNote1_4(auditdateNote1_4);
		}

		String auditdate1_5 = (String)attributes.get("auditdate1_5");

		if (auditdate1_5 != null) {
			setAuditdate1_5(auditdate1_5);
		}

		String auditdateNote1_5 = (String)attributes.get("auditdateNote1_5");

		if (auditdateNote1_5 != null) {
			setAuditdateNote1_5(auditdateNote1_5);
		}

		String auditdate1_6 = (String)attributes.get("auditdate1_6");

		if (auditdate1_6 != null) {
			setAuditdate1_6(auditdate1_6);
		}

		String auditdateNote1_6 = (String)attributes.get("auditdateNote1_6");

		if (auditdateNote1_6 != null) {
			setAuditdateNote1_6(auditdateNote1_6);
		}

		String auditdate1_7 = (String)attributes.get("auditdate1_7");

		if (auditdate1_7 != null) {
			setAuditdate1_7(auditdate1_7);
		}

		String auditdateNote1_7 = (String)attributes.get("auditdateNote1_7");

		if (auditdateNote1_7 != null) {
			setAuditdateNote1_7(auditdateNote1_7);
		}

		String auditdate2_1 = (String)attributes.get("auditdate2_1");

		if (auditdate2_1 != null) {
			setAuditdate2_1(auditdate2_1);
		}

		String auditdateNote2_1 = (String)attributes.get("auditdateNote2_1");

		if (auditdateNote2_1 != null) {
			setAuditdateNote2_1(auditdateNote2_1);
		}

		String auditdate2_2 = (String)attributes.get("auditdate2_2");

		if (auditdate2_2 != null) {
			setAuditdate2_2(auditdate2_2);
		}

		String auditdateNote2_2 = (String)attributes.get("auditdateNote2_2");

		if (auditdateNote2_2 != null) {
			setAuditdateNote2_2(auditdateNote2_2);
		}

		String auditdate2_3 = (String)attributes.get("auditdate2_3");

		if (auditdate2_3 != null) {
			setAuditdate2_3(auditdate2_3);
		}

		String auditdateNote2_3 = (String)attributes.get("auditdateNote2_3");

		if (auditdateNote2_3 != null) {
			setAuditdateNote2_3(auditdateNote2_3);
		}

		String auditdate2_4 = (String)attributes.get("auditdate2_4");

		if (auditdate2_4 != null) {
			setAuditdate2_4(auditdate2_4);
		}

		String auditdateNote2_4 = (String)attributes.get("auditdateNote2_4");

		if (auditdateNote2_4 != null) {
			setAuditdateNote2_4(auditdateNote2_4);
		}

		String auditdate2_4_1 = (String)attributes.get("auditdate2_4_1");

		if (auditdate2_4_1 != null) {
			setAuditdate2_4_1(auditdate2_4_1);
		}

		String auditdateNote2_4_1 = (String)attributes.get("auditdateNote2_4_1");

		if (auditdateNote2_4_1 != null) {
			setAuditdateNote2_4_1(auditdateNote2_4_1);
		}

		String auditdate2_4_2 = (String)attributes.get("auditdate2_4_2");

		if (auditdate2_4_2 != null) {
			setAuditdate2_4_2(auditdate2_4_2);
		}

		String auditdateNote2_4_2 = (String)attributes.get("auditdateNote2_4_2");

		if (auditdateNote2_4_2 != null) {
			setAuditdateNote2_4_2(auditdateNote2_4_2);
		}

		String auditdate2_4_3 = (String)attributes.get("auditdate2_4_3");

		if (auditdate2_4_3 != null) {
			setAuditdate2_4_3(auditdate2_4_3);
		}

		String auditdateNote2_4_3 = (String)attributes.get("auditdateNote2_4_3");

		if (auditdateNote2_4_3 != null) {
			setAuditdateNote2_4_3(auditdateNote2_4_3);
		}

		String auditdate2_4_4 = (String)attributes.get("auditdate2_4_4");

		if (auditdate2_4_4 != null) {
			setAuditdate2_4_4(auditdate2_4_4);
		}

		String auditdateNote2_4_4 = (String)attributes.get("auditdateNote2_4_4");

		if (auditdateNote2_4_4 != null) {
			setAuditdateNote2_4_4(auditdateNote2_4_4);
		}

		String auditdate2_4_5 = (String)attributes.get("auditdate2_4_5");

		if (auditdate2_4_5 != null) {
			setAuditdate2_4_5(auditdate2_4_5);
		}

		String auditdateNote2_4_5 = (String)attributes.get("auditdateNote2_4_5");

		if (auditdateNote2_4_5 != null) {
			setAuditdateNote2_4_5(auditdateNote2_4_5);
		}

		String auditdate2_4_6 = (String)attributes.get("auditdate2_4_6");

		if (auditdate2_4_6 != null) {
			setAuditdate2_4_6(auditdate2_4_6);
		}

		String auditdateNote2_4_6 = (String)attributes.get("auditdateNote2_4_6");

		if (auditdateNote2_4_6 != null) {
			setAuditdateNote2_4_6(auditdateNote2_4_6);
		}

		String auditdate3_1 = (String)attributes.get("auditdate3_1");

		if (auditdate3_1 != null) {
			setAuditdate3_1(auditdate3_1);
		}

		String auditdate3_2 = (String)attributes.get("auditdate3_2");

		if (auditdate3_2 != null) {
			setAuditdate3_2(auditdate3_2);
		}

		String auditdate3_3 = (String)attributes.get("auditdate3_3");

		if (auditdate3_3 != null) {
			setAuditdate3_3(auditdate3_3);
		}

		String auditdate3_4 = (String)attributes.get("auditdate3_4");

		if (auditdate3_4 != null) {
			setAuditdate3_4(auditdate3_4);
		}

		String auditdate3_5 = (String)attributes.get("auditdate3_5");

		if (auditdate3_5 != null) {
			setAuditdate3_5(auditdate3_5);
		}

		String auditdate3_6 = (String)attributes.get("auditdate3_6");

		if (auditdate3_6 != null) {
			setAuditdate3_6(auditdate3_6);
		}

		String auditdateNote3_1 = (String)attributes.get("auditdateNote3_1");

		if (auditdateNote3_1 != null) {
			setAuditdateNote3_1(auditdateNote3_1);
		}

		String auditdateNote3_2 = (String)attributes.get("auditdateNote3_2");

		if (auditdateNote3_2 != null) {
			setAuditdateNote3_2(auditdateNote3_2);
		}

		String auditdateNote3_3 = (String)attributes.get("auditdateNote3_3");

		if (auditdateNote3_3 != null) {
			setAuditdateNote3_3(auditdateNote3_3);
		}

		String auditdateNote3_4 = (String)attributes.get("auditdateNote3_4");

		if (auditdateNote3_4 != null) {
			setAuditdateNote3_4(auditdateNote3_4);
		}

		String auditdateNote3_5 = (String)attributes.get("auditdateNote3_5");

		if (auditdateNote3_5 != null) {
			setAuditdateNote3_5(auditdateNote3_5);
		}

		String auditdateNote3_6 = (String)attributes.get("auditdateNote3_6");

		if (auditdateNote3_6 != null) {
			setAuditdateNote3_6(auditdateNote3_6);
		}

		String auditdate4_1 = (String)attributes.get("auditdate4_1");

		if (auditdate4_1 != null) {
			setAuditdate4_1(auditdate4_1);
		}

		String auditdate4_2 = (String)attributes.get("auditdate4_2");

		if (auditdate4_2 != null) {
			setAuditdate4_2(auditdate4_2);
		}

		String auditdate4_3 = (String)attributes.get("auditdate4_3");

		if (auditdate4_3 != null) {
			setAuditdate4_3(auditdate4_3);
		}

		String auditdateNote4_1 = (String)attributes.get("auditdateNote4_1");

		if (auditdateNote4_1 != null) {
			setAuditdateNote4_1(auditdateNote4_1);
		}

		String auditdateNote4_2 = (String)attributes.get("auditdateNote4_2");

		if (auditdateNote4_2 != null) {
			setAuditdateNote4_2(auditdateNote4_2);
		}

		String auditdateNote4_3 = (String)attributes.get("auditdateNote4_3");

		if (auditdateNote4_3 != null) {
			setAuditdateNote4_3(auditdateNote4_3);
		}

		String auditdate5_1 = (String)attributes.get("auditdate5_1");

		if (auditdate5_1 != null) {
			setAuditdate5_1(auditdate5_1);
		}

		String auditdate5_2 = (String)attributes.get("auditdate5_2");

		if (auditdate5_2 != null) {
			setAuditdate5_2(auditdate5_2);
		}

		String auditdate5_3 = (String)attributes.get("auditdate5_3");

		if (auditdate5_3 != null) {
			setAuditdate5_3(auditdate5_3);
		}

		String auditdate5_4 = (String)attributes.get("auditdate5_4");

		if (auditdate5_4 != null) {
			setAuditdate5_4(auditdate5_4);
		}

		String auditdate5_5 = (String)attributes.get("auditdate5_5");

		if (auditdate5_5 != null) {
			setAuditdate5_5(auditdate5_5);
		}

		String auditdate5_6 = (String)attributes.get("auditdate5_6");

		if (auditdate5_6 != null) {
			setAuditdate5_6(auditdate5_6);
		}

		String auditdate5_7 = (String)attributes.get("auditdate5_7");

		if (auditdate5_7 != null) {
			setAuditdate5_7(auditdate5_7);
		}

		String auditdate5_8 = (String)attributes.get("auditdate5_8");

		if (auditdate5_8 != null) {
			setAuditdate5_8(auditdate5_8);
		}

		String auditdateNote5_1 = (String)attributes.get("auditdateNote5_1");

		if (auditdateNote5_1 != null) {
			setAuditdateNote5_1(auditdateNote5_1);
		}

		String auditdateNote5_2 = (String)attributes.get("auditdateNote5_2");

		if (auditdateNote5_2 != null) {
			setAuditdateNote5_2(auditdateNote5_2);
		}

		String auditdateNote5_3 = (String)attributes.get("auditdateNote5_3");

		if (auditdateNote5_3 != null) {
			setAuditdateNote5_3(auditdateNote5_3);
		}

		String auditdateNote5_4 = (String)attributes.get("auditdateNote5_4");

		if (auditdateNote5_4 != null) {
			setAuditdateNote5_4(auditdateNote5_4);
		}

		String auditdateNote5_5 = (String)attributes.get("auditdateNote5_5");

		if (auditdateNote5_5 != null) {
			setAuditdateNote5_5(auditdateNote5_5);
		}

		String auditdateNote5_6 = (String)attributes.get("auditdateNote5_6");

		if (auditdateNote5_6 != null) {
			setAuditdateNote5_6(auditdateNote5_6);
		}

		String auditdateNote5_7 = (String)attributes.get("auditdateNote5_7");

		if (auditdateNote5_7 != null) {
			setAuditdateNote5_7(auditdateNote5_7);
		}

		String auditdateNote5_8 = (String)attributes.get("auditdateNote5_8");

		if (auditdateNote5_8 != null) {
			setAuditdateNote5_8(auditdateNote5_8);
		}
	}

	/**
	* Returns the primary key of this complain check audit.
	*
	* @return the primary key of this complain check audit
	*/
	@Override
	public long getPrimaryKey() {
		return _complainCheckAudit.getPrimaryKey();
	}

	/**
	* Sets the primary key of this complain check audit.
	*
	* @param primaryKey the primary key of this complain check audit
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_complainCheckAudit.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the matter ID of this complain check audit.
	*
	* @return the matter ID of this complain check audit
	*/
	@Override
	public long getMatterId() {
		return _complainCheckAudit.getMatterId();
	}

	/**
	* Sets the matter ID of this complain check audit.
	*
	* @param matterId the matter ID of this complain check audit
	*/
	@Override
	public void setMatterId(long matterId) {
		_complainCheckAudit.setMatterId(matterId);
	}

	/**
	* Returns the aditid of this complain check audit.
	*
	* @return the aditid of this complain check audit
	*/
	@Override
	public long getAditid() {
		return _complainCheckAudit.getAditid();
	}

	/**
	* Sets the aditid of this complain check audit.
	*
	* @param aditid the aditid of this complain check audit
	*/
	@Override
	public void setAditid(long aditid) {
		_complainCheckAudit.setAditid(aditid);
	}

	/**
	* Returns the auditdate1_1 of this complain check audit.
	*
	* @return the auditdate1_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_1() {
		return _complainCheckAudit.getAuditdate1_1();
	}

	/**
	* Sets the auditdate1_1 of this complain check audit.
	*
	* @param auditdate1_1 the auditdate1_1 of this complain check audit
	*/
	@Override
	public void setAuditdate1_1(java.lang.String auditdate1_1) {
		_complainCheckAudit.setAuditdate1_1(auditdate1_1);
	}

	/**
	* Returns the auditdate note1_1 of this complain check audit.
	*
	* @return the auditdate note1_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_1() {
		return _complainCheckAudit.getAuditdateNote1_1();
	}

	/**
	* Sets the auditdate note1_1 of this complain check audit.
	*
	* @param auditdateNote1_1 the auditdate note1_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_1(java.lang.String auditdateNote1_1) {
		_complainCheckAudit.setAuditdateNote1_1(auditdateNote1_1);
	}

	/**
	* Returns the auditdate1_2 of this complain check audit.
	*
	* @return the auditdate1_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_2() {
		return _complainCheckAudit.getAuditdate1_2();
	}

	/**
	* Sets the auditdate1_2 of this complain check audit.
	*
	* @param auditdate1_2 the auditdate1_2 of this complain check audit
	*/
	@Override
	public void setAuditdate1_2(java.lang.String auditdate1_2) {
		_complainCheckAudit.setAuditdate1_2(auditdate1_2);
	}

	/**
	* Returns the auditdate note1_2 of this complain check audit.
	*
	* @return the auditdate note1_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_2() {
		return _complainCheckAudit.getAuditdateNote1_2();
	}

	/**
	* Sets the auditdate note1_2 of this complain check audit.
	*
	* @param auditdateNote1_2 the auditdate note1_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_2(java.lang.String auditdateNote1_2) {
		_complainCheckAudit.setAuditdateNote1_2(auditdateNote1_2);
	}

	/**
	* Returns the auditdate1_3 of this complain check audit.
	*
	* @return the auditdate1_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_3() {
		return _complainCheckAudit.getAuditdate1_3();
	}

	/**
	* Sets the auditdate1_3 of this complain check audit.
	*
	* @param auditdate1_3 the auditdate1_3 of this complain check audit
	*/
	@Override
	public void setAuditdate1_3(java.lang.String auditdate1_3) {
		_complainCheckAudit.setAuditdate1_3(auditdate1_3);
	}

	/**
	* Returns the auditdate note1_3 of this complain check audit.
	*
	* @return the auditdate note1_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_3() {
		return _complainCheckAudit.getAuditdateNote1_3();
	}

	/**
	* Sets the auditdate note1_3 of this complain check audit.
	*
	* @param auditdateNote1_3 the auditdate note1_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_3(java.lang.String auditdateNote1_3) {
		_complainCheckAudit.setAuditdateNote1_3(auditdateNote1_3);
	}

	/**
	* Returns the auditdate1_4 of this complain check audit.
	*
	* @return the auditdate1_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_4() {
		return _complainCheckAudit.getAuditdate1_4();
	}

	/**
	* Sets the auditdate1_4 of this complain check audit.
	*
	* @param auditdate1_4 the auditdate1_4 of this complain check audit
	*/
	@Override
	public void setAuditdate1_4(java.lang.String auditdate1_4) {
		_complainCheckAudit.setAuditdate1_4(auditdate1_4);
	}

	/**
	* Returns the auditdate note1_4 of this complain check audit.
	*
	* @return the auditdate note1_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_4() {
		return _complainCheckAudit.getAuditdateNote1_4();
	}

	/**
	* Sets the auditdate note1_4 of this complain check audit.
	*
	* @param auditdateNote1_4 the auditdate note1_4 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_4(java.lang.String auditdateNote1_4) {
		_complainCheckAudit.setAuditdateNote1_4(auditdateNote1_4);
	}

	/**
	* Returns the auditdate1_5 of this complain check audit.
	*
	* @return the auditdate1_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_5() {
		return _complainCheckAudit.getAuditdate1_5();
	}

	/**
	* Sets the auditdate1_5 of this complain check audit.
	*
	* @param auditdate1_5 the auditdate1_5 of this complain check audit
	*/
	@Override
	public void setAuditdate1_5(java.lang.String auditdate1_5) {
		_complainCheckAudit.setAuditdate1_5(auditdate1_5);
	}

	/**
	* Returns the auditdate note1_5 of this complain check audit.
	*
	* @return the auditdate note1_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_5() {
		return _complainCheckAudit.getAuditdateNote1_5();
	}

	/**
	* Sets the auditdate note1_5 of this complain check audit.
	*
	* @param auditdateNote1_5 the auditdate note1_5 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_5(java.lang.String auditdateNote1_5) {
		_complainCheckAudit.setAuditdateNote1_5(auditdateNote1_5);
	}

	/**
	* Returns the auditdate1_6 of this complain check audit.
	*
	* @return the auditdate1_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_6() {
		return _complainCheckAudit.getAuditdate1_6();
	}

	/**
	* Sets the auditdate1_6 of this complain check audit.
	*
	* @param auditdate1_6 the auditdate1_6 of this complain check audit
	*/
	@Override
	public void setAuditdate1_6(java.lang.String auditdate1_6) {
		_complainCheckAudit.setAuditdate1_6(auditdate1_6);
	}

	/**
	* Returns the auditdate note1_6 of this complain check audit.
	*
	* @return the auditdate note1_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_6() {
		return _complainCheckAudit.getAuditdateNote1_6();
	}

	/**
	* Sets the auditdate note1_6 of this complain check audit.
	*
	* @param auditdateNote1_6 the auditdate note1_6 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_6(java.lang.String auditdateNote1_6) {
		_complainCheckAudit.setAuditdateNote1_6(auditdateNote1_6);
	}

	/**
	* Returns the auditdate1_7 of this complain check audit.
	*
	* @return the auditdate1_7 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate1_7() {
		return _complainCheckAudit.getAuditdate1_7();
	}

	/**
	* Sets the auditdate1_7 of this complain check audit.
	*
	* @param auditdate1_7 the auditdate1_7 of this complain check audit
	*/
	@Override
	public void setAuditdate1_7(java.lang.String auditdate1_7) {
		_complainCheckAudit.setAuditdate1_7(auditdate1_7);
	}

	/**
	* Returns the auditdate note1_7 of this complain check audit.
	*
	* @return the auditdate note1_7 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote1_7() {
		return _complainCheckAudit.getAuditdateNote1_7();
	}

	/**
	* Sets the auditdate note1_7 of this complain check audit.
	*
	* @param auditdateNote1_7 the auditdate note1_7 of this complain check audit
	*/
	@Override
	public void setAuditdateNote1_7(java.lang.String auditdateNote1_7) {
		_complainCheckAudit.setAuditdateNote1_7(auditdateNote1_7);
	}

	/**
	* Returns the auditdate2_1 of this complain check audit.
	*
	* @return the auditdate2_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_1() {
		return _complainCheckAudit.getAuditdate2_1();
	}

	/**
	* Sets the auditdate2_1 of this complain check audit.
	*
	* @param auditdate2_1 the auditdate2_1 of this complain check audit
	*/
	@Override
	public void setAuditdate2_1(java.lang.String auditdate2_1) {
		_complainCheckAudit.setAuditdate2_1(auditdate2_1);
	}

	/**
	* Returns the auditdate note2_1 of this complain check audit.
	*
	* @return the auditdate note2_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_1() {
		return _complainCheckAudit.getAuditdateNote2_1();
	}

	/**
	* Sets the auditdate note2_1 of this complain check audit.
	*
	* @param auditdateNote2_1 the auditdate note2_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_1(java.lang.String auditdateNote2_1) {
		_complainCheckAudit.setAuditdateNote2_1(auditdateNote2_1);
	}

	/**
	* Returns the auditdate2_2 of this complain check audit.
	*
	* @return the auditdate2_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_2() {
		return _complainCheckAudit.getAuditdate2_2();
	}

	/**
	* Sets the auditdate2_2 of this complain check audit.
	*
	* @param auditdate2_2 the auditdate2_2 of this complain check audit
	*/
	@Override
	public void setAuditdate2_2(java.lang.String auditdate2_2) {
		_complainCheckAudit.setAuditdate2_2(auditdate2_2);
	}

	/**
	* Returns the auditdate note2_2 of this complain check audit.
	*
	* @return the auditdate note2_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_2() {
		return _complainCheckAudit.getAuditdateNote2_2();
	}

	/**
	* Sets the auditdate note2_2 of this complain check audit.
	*
	* @param auditdateNote2_2 the auditdate note2_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_2(java.lang.String auditdateNote2_2) {
		_complainCheckAudit.setAuditdateNote2_2(auditdateNote2_2);
	}

	/**
	* Returns the auditdate2_3 of this complain check audit.
	*
	* @return the auditdate2_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_3() {
		return _complainCheckAudit.getAuditdate2_3();
	}

	/**
	* Sets the auditdate2_3 of this complain check audit.
	*
	* @param auditdate2_3 the auditdate2_3 of this complain check audit
	*/
	@Override
	public void setAuditdate2_3(java.lang.String auditdate2_3) {
		_complainCheckAudit.setAuditdate2_3(auditdate2_3);
	}

	/**
	* Returns the auditdate note2_3 of this complain check audit.
	*
	* @return the auditdate note2_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_3() {
		return _complainCheckAudit.getAuditdateNote2_3();
	}

	/**
	* Sets the auditdate note2_3 of this complain check audit.
	*
	* @param auditdateNote2_3 the auditdate note2_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_3(java.lang.String auditdateNote2_3) {
		_complainCheckAudit.setAuditdateNote2_3(auditdateNote2_3);
	}

	/**
	* Returns the auditdate2_4 of this complain check audit.
	*
	* @return the auditdate2_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4() {
		return _complainCheckAudit.getAuditdate2_4();
	}

	/**
	* Sets the auditdate2_4 of this complain check audit.
	*
	* @param auditdate2_4 the auditdate2_4 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4(java.lang.String auditdate2_4) {
		_complainCheckAudit.setAuditdate2_4(auditdate2_4);
	}

	/**
	* Returns the auditdate note2_4 of this complain check audit.
	*
	* @return the auditdate note2_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4() {
		return _complainCheckAudit.getAuditdateNote2_4();
	}

	/**
	* Sets the auditdate note2_4 of this complain check audit.
	*
	* @param auditdateNote2_4 the auditdate note2_4 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4(java.lang.String auditdateNote2_4) {
		_complainCheckAudit.setAuditdateNote2_4(auditdateNote2_4);
	}

	/**
	* Returns the auditdate2_4_1 of this complain check audit.
	*
	* @return the auditdate2_4_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_1() {
		return _complainCheckAudit.getAuditdate2_4_1();
	}

	/**
	* Sets the auditdate2_4_1 of this complain check audit.
	*
	* @param auditdate2_4_1 the auditdate2_4_1 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_1(java.lang.String auditdate2_4_1) {
		_complainCheckAudit.setAuditdate2_4_1(auditdate2_4_1);
	}

	/**
	* Returns the auditdate note2_4_1 of this complain check audit.
	*
	* @return the auditdate note2_4_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_1() {
		return _complainCheckAudit.getAuditdateNote2_4_1();
	}

	/**
	* Sets the auditdate note2_4_1 of this complain check audit.
	*
	* @param auditdateNote2_4_1 the auditdate note2_4_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_1(java.lang.String auditdateNote2_4_1) {
		_complainCheckAudit.setAuditdateNote2_4_1(auditdateNote2_4_1);
	}

	/**
	* Returns the auditdate2_4_2 of this complain check audit.
	*
	* @return the auditdate2_4_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_2() {
		return _complainCheckAudit.getAuditdate2_4_2();
	}

	/**
	* Sets the auditdate2_4_2 of this complain check audit.
	*
	* @param auditdate2_4_2 the auditdate2_4_2 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_2(java.lang.String auditdate2_4_2) {
		_complainCheckAudit.setAuditdate2_4_2(auditdate2_4_2);
	}

	/**
	* Returns the auditdate note2_4_2 of this complain check audit.
	*
	* @return the auditdate note2_4_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_2() {
		return _complainCheckAudit.getAuditdateNote2_4_2();
	}

	/**
	* Sets the auditdate note2_4_2 of this complain check audit.
	*
	* @param auditdateNote2_4_2 the auditdate note2_4_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_2(java.lang.String auditdateNote2_4_2) {
		_complainCheckAudit.setAuditdateNote2_4_2(auditdateNote2_4_2);
	}

	/**
	* Returns the auditdate2_4_3 of this complain check audit.
	*
	* @return the auditdate2_4_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_3() {
		return _complainCheckAudit.getAuditdate2_4_3();
	}

	/**
	* Sets the auditdate2_4_3 of this complain check audit.
	*
	* @param auditdate2_4_3 the auditdate2_4_3 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_3(java.lang.String auditdate2_4_3) {
		_complainCheckAudit.setAuditdate2_4_3(auditdate2_4_3);
	}

	/**
	* Returns the auditdate note2_4_3 of this complain check audit.
	*
	* @return the auditdate note2_4_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_3() {
		return _complainCheckAudit.getAuditdateNote2_4_3();
	}

	/**
	* Sets the auditdate note2_4_3 of this complain check audit.
	*
	* @param auditdateNote2_4_3 the auditdate note2_4_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_3(java.lang.String auditdateNote2_4_3) {
		_complainCheckAudit.setAuditdateNote2_4_3(auditdateNote2_4_3);
	}

	/**
	* Returns the auditdate2_4_4 of this complain check audit.
	*
	* @return the auditdate2_4_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_4() {
		return _complainCheckAudit.getAuditdate2_4_4();
	}

	/**
	* Sets the auditdate2_4_4 of this complain check audit.
	*
	* @param auditdate2_4_4 the auditdate2_4_4 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_4(java.lang.String auditdate2_4_4) {
		_complainCheckAudit.setAuditdate2_4_4(auditdate2_4_4);
	}

	/**
	* Returns the auditdate note2_4_4 of this complain check audit.
	*
	* @return the auditdate note2_4_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_4() {
		return _complainCheckAudit.getAuditdateNote2_4_4();
	}

	/**
	* Sets the auditdate note2_4_4 of this complain check audit.
	*
	* @param auditdateNote2_4_4 the auditdate note2_4_4 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_4(java.lang.String auditdateNote2_4_4) {
		_complainCheckAudit.setAuditdateNote2_4_4(auditdateNote2_4_4);
	}

	/**
	* Returns the auditdate2_4_5 of this complain check audit.
	*
	* @return the auditdate2_4_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_5() {
		return _complainCheckAudit.getAuditdate2_4_5();
	}

	/**
	* Sets the auditdate2_4_5 of this complain check audit.
	*
	* @param auditdate2_4_5 the auditdate2_4_5 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_5(java.lang.String auditdate2_4_5) {
		_complainCheckAudit.setAuditdate2_4_5(auditdate2_4_5);
	}

	/**
	* Returns the auditdate note2_4_5 of this complain check audit.
	*
	* @return the auditdate note2_4_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_5() {
		return _complainCheckAudit.getAuditdateNote2_4_5();
	}

	/**
	* Sets the auditdate note2_4_5 of this complain check audit.
	*
	* @param auditdateNote2_4_5 the auditdate note2_4_5 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_5(java.lang.String auditdateNote2_4_5) {
		_complainCheckAudit.setAuditdateNote2_4_5(auditdateNote2_4_5);
	}

	/**
	* Returns the auditdate2_4_6 of this complain check audit.
	*
	* @return the auditdate2_4_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate2_4_6() {
		return _complainCheckAudit.getAuditdate2_4_6();
	}

	/**
	* Sets the auditdate2_4_6 of this complain check audit.
	*
	* @param auditdate2_4_6 the auditdate2_4_6 of this complain check audit
	*/
	@Override
	public void setAuditdate2_4_6(java.lang.String auditdate2_4_6) {
		_complainCheckAudit.setAuditdate2_4_6(auditdate2_4_6);
	}

	/**
	* Returns the auditdate note2_4_6 of this complain check audit.
	*
	* @return the auditdate note2_4_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote2_4_6() {
		return _complainCheckAudit.getAuditdateNote2_4_6();
	}

	/**
	* Sets the auditdate note2_4_6 of this complain check audit.
	*
	* @param auditdateNote2_4_6 the auditdate note2_4_6 of this complain check audit
	*/
	@Override
	public void setAuditdateNote2_4_6(java.lang.String auditdateNote2_4_6) {
		_complainCheckAudit.setAuditdateNote2_4_6(auditdateNote2_4_6);
	}

	/**
	* Returns the auditdate3_1 of this complain check audit.
	*
	* @return the auditdate3_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_1() {
		return _complainCheckAudit.getAuditdate3_1();
	}

	/**
	* Sets the auditdate3_1 of this complain check audit.
	*
	* @param auditdate3_1 the auditdate3_1 of this complain check audit
	*/
	@Override
	public void setAuditdate3_1(java.lang.String auditdate3_1) {
		_complainCheckAudit.setAuditdate3_1(auditdate3_1);
	}

	/**
	* Returns the auditdate3_2 of this complain check audit.
	*
	* @return the auditdate3_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_2() {
		return _complainCheckAudit.getAuditdate3_2();
	}

	/**
	* Sets the auditdate3_2 of this complain check audit.
	*
	* @param auditdate3_2 the auditdate3_2 of this complain check audit
	*/
	@Override
	public void setAuditdate3_2(java.lang.String auditdate3_2) {
		_complainCheckAudit.setAuditdate3_2(auditdate3_2);
	}

	/**
	* Returns the auditdate3_3 of this complain check audit.
	*
	* @return the auditdate3_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_3() {
		return _complainCheckAudit.getAuditdate3_3();
	}

	/**
	* Sets the auditdate3_3 of this complain check audit.
	*
	* @param auditdate3_3 the auditdate3_3 of this complain check audit
	*/
	@Override
	public void setAuditdate3_3(java.lang.String auditdate3_3) {
		_complainCheckAudit.setAuditdate3_3(auditdate3_3);
	}

	/**
	* Returns the auditdate3_4 of this complain check audit.
	*
	* @return the auditdate3_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_4() {
		return _complainCheckAudit.getAuditdate3_4();
	}

	/**
	* Sets the auditdate3_4 of this complain check audit.
	*
	* @param auditdate3_4 the auditdate3_4 of this complain check audit
	*/
	@Override
	public void setAuditdate3_4(java.lang.String auditdate3_4) {
		_complainCheckAudit.setAuditdate3_4(auditdate3_4);
	}

	/**
	* Returns the auditdate3_5 of this complain check audit.
	*
	* @return the auditdate3_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_5() {
		return _complainCheckAudit.getAuditdate3_5();
	}

	/**
	* Sets the auditdate3_5 of this complain check audit.
	*
	* @param auditdate3_5 the auditdate3_5 of this complain check audit
	*/
	@Override
	public void setAuditdate3_5(java.lang.String auditdate3_5) {
		_complainCheckAudit.setAuditdate3_5(auditdate3_5);
	}

	/**
	* Returns the auditdate3_6 of this complain check audit.
	*
	* @return the auditdate3_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate3_6() {
		return _complainCheckAudit.getAuditdate3_6();
	}

	/**
	* Sets the auditdate3_6 of this complain check audit.
	*
	* @param auditdate3_6 the auditdate3_6 of this complain check audit
	*/
	@Override
	public void setAuditdate3_6(java.lang.String auditdate3_6) {
		_complainCheckAudit.setAuditdate3_6(auditdate3_6);
	}

	/**
	* Returns the auditdate note3_1 of this complain check audit.
	*
	* @return the auditdate note3_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_1() {
		return _complainCheckAudit.getAuditdateNote3_1();
	}

	/**
	* Sets the auditdate note3_1 of this complain check audit.
	*
	* @param auditdateNote3_1 the auditdate note3_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_1(java.lang.String auditdateNote3_1) {
		_complainCheckAudit.setAuditdateNote3_1(auditdateNote3_1);
	}

	/**
	* Returns the auditdate note3_2 of this complain check audit.
	*
	* @return the auditdate note3_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_2() {
		return _complainCheckAudit.getAuditdateNote3_2();
	}

	/**
	* Sets the auditdate note3_2 of this complain check audit.
	*
	* @param auditdateNote3_2 the auditdate note3_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_2(java.lang.String auditdateNote3_2) {
		_complainCheckAudit.setAuditdateNote3_2(auditdateNote3_2);
	}

	/**
	* Returns the auditdate note3_3 of this complain check audit.
	*
	* @return the auditdate note3_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_3() {
		return _complainCheckAudit.getAuditdateNote3_3();
	}

	/**
	* Sets the auditdate note3_3 of this complain check audit.
	*
	* @param auditdateNote3_3 the auditdate note3_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_3(java.lang.String auditdateNote3_3) {
		_complainCheckAudit.setAuditdateNote3_3(auditdateNote3_3);
	}

	/**
	* Returns the auditdate note3_4 of this complain check audit.
	*
	* @return the auditdate note3_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_4() {
		return _complainCheckAudit.getAuditdateNote3_4();
	}

	/**
	* Sets the auditdate note3_4 of this complain check audit.
	*
	* @param auditdateNote3_4 the auditdate note3_4 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_4(java.lang.String auditdateNote3_4) {
		_complainCheckAudit.setAuditdateNote3_4(auditdateNote3_4);
	}

	/**
	* Returns the auditdate note3_5 of this complain check audit.
	*
	* @return the auditdate note3_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_5() {
		return _complainCheckAudit.getAuditdateNote3_5();
	}

	/**
	* Sets the auditdate note3_5 of this complain check audit.
	*
	* @param auditdateNote3_5 the auditdate note3_5 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_5(java.lang.String auditdateNote3_5) {
		_complainCheckAudit.setAuditdateNote3_5(auditdateNote3_5);
	}

	/**
	* Returns the auditdate note3_6 of this complain check audit.
	*
	* @return the auditdate note3_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote3_6() {
		return _complainCheckAudit.getAuditdateNote3_6();
	}

	/**
	* Sets the auditdate note3_6 of this complain check audit.
	*
	* @param auditdateNote3_6 the auditdate note3_6 of this complain check audit
	*/
	@Override
	public void setAuditdateNote3_6(java.lang.String auditdateNote3_6) {
		_complainCheckAudit.setAuditdateNote3_6(auditdateNote3_6);
	}

	/**
	* Returns the auditdate4_1 of this complain check audit.
	*
	* @return the auditdate4_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate4_1() {
		return _complainCheckAudit.getAuditdate4_1();
	}

	/**
	* Sets the auditdate4_1 of this complain check audit.
	*
	* @param auditdate4_1 the auditdate4_1 of this complain check audit
	*/
	@Override
	public void setAuditdate4_1(java.lang.String auditdate4_1) {
		_complainCheckAudit.setAuditdate4_1(auditdate4_1);
	}

	/**
	* Returns the auditdate4_2 of this complain check audit.
	*
	* @return the auditdate4_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate4_2() {
		return _complainCheckAudit.getAuditdate4_2();
	}

	/**
	* Sets the auditdate4_2 of this complain check audit.
	*
	* @param auditdate4_2 the auditdate4_2 of this complain check audit
	*/
	@Override
	public void setAuditdate4_2(java.lang.String auditdate4_2) {
		_complainCheckAudit.setAuditdate4_2(auditdate4_2);
	}

	/**
	* Returns the auditdate4_3 of this complain check audit.
	*
	* @return the auditdate4_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate4_3() {
		return _complainCheckAudit.getAuditdate4_3();
	}

	/**
	* Sets the auditdate4_3 of this complain check audit.
	*
	* @param auditdate4_3 the auditdate4_3 of this complain check audit
	*/
	@Override
	public void setAuditdate4_3(java.lang.String auditdate4_3) {
		_complainCheckAudit.setAuditdate4_3(auditdate4_3);
	}

	/**
	* Returns the auditdate note4_1 of this complain check audit.
	*
	* @return the auditdate note4_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote4_1() {
		return _complainCheckAudit.getAuditdateNote4_1();
	}

	/**
	* Sets the auditdate note4_1 of this complain check audit.
	*
	* @param auditdateNote4_1 the auditdate note4_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote4_1(java.lang.String auditdateNote4_1) {
		_complainCheckAudit.setAuditdateNote4_1(auditdateNote4_1);
	}

	/**
	* Returns the auditdate note4_2 of this complain check audit.
	*
	* @return the auditdate note4_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote4_2() {
		return _complainCheckAudit.getAuditdateNote4_2();
	}

	/**
	* Sets the auditdate note4_2 of this complain check audit.
	*
	* @param auditdateNote4_2 the auditdate note4_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote4_2(java.lang.String auditdateNote4_2) {
		_complainCheckAudit.setAuditdateNote4_2(auditdateNote4_2);
	}

	/**
	* Returns the auditdate note4_3 of this complain check audit.
	*
	* @return the auditdate note4_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote4_3() {
		return _complainCheckAudit.getAuditdateNote4_3();
	}

	/**
	* Sets the auditdate note4_3 of this complain check audit.
	*
	* @param auditdateNote4_3 the auditdate note4_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote4_3(java.lang.String auditdateNote4_3) {
		_complainCheckAudit.setAuditdateNote4_3(auditdateNote4_3);
	}

	/**
	* Returns the auditdate5_1 of this complain check audit.
	*
	* @return the auditdate5_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_1() {
		return _complainCheckAudit.getAuditdate5_1();
	}

	/**
	* Sets the auditdate5_1 of this complain check audit.
	*
	* @param auditdate5_1 the auditdate5_1 of this complain check audit
	*/
	@Override
	public void setAuditdate5_1(java.lang.String auditdate5_1) {
		_complainCheckAudit.setAuditdate5_1(auditdate5_1);
	}

	/**
	* Returns the auditdate5_2 of this complain check audit.
	*
	* @return the auditdate5_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_2() {
		return _complainCheckAudit.getAuditdate5_2();
	}

	/**
	* Sets the auditdate5_2 of this complain check audit.
	*
	* @param auditdate5_2 the auditdate5_2 of this complain check audit
	*/
	@Override
	public void setAuditdate5_2(java.lang.String auditdate5_2) {
		_complainCheckAudit.setAuditdate5_2(auditdate5_2);
	}

	/**
	* Returns the auditdate5_3 of this complain check audit.
	*
	* @return the auditdate5_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_3() {
		return _complainCheckAudit.getAuditdate5_3();
	}

	/**
	* Sets the auditdate5_3 of this complain check audit.
	*
	* @param auditdate5_3 the auditdate5_3 of this complain check audit
	*/
	@Override
	public void setAuditdate5_3(java.lang.String auditdate5_3) {
		_complainCheckAudit.setAuditdate5_3(auditdate5_3);
	}

	/**
	* Returns the auditdate5_4 of this complain check audit.
	*
	* @return the auditdate5_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_4() {
		return _complainCheckAudit.getAuditdate5_4();
	}

	/**
	* Sets the auditdate5_4 of this complain check audit.
	*
	* @param auditdate5_4 the auditdate5_4 of this complain check audit
	*/
	@Override
	public void setAuditdate5_4(java.lang.String auditdate5_4) {
		_complainCheckAudit.setAuditdate5_4(auditdate5_4);
	}

	/**
	* Returns the auditdate5_5 of this complain check audit.
	*
	* @return the auditdate5_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_5() {
		return _complainCheckAudit.getAuditdate5_5();
	}

	/**
	* Sets the auditdate5_5 of this complain check audit.
	*
	* @param auditdate5_5 the auditdate5_5 of this complain check audit
	*/
	@Override
	public void setAuditdate5_5(java.lang.String auditdate5_5) {
		_complainCheckAudit.setAuditdate5_5(auditdate5_5);
	}

	/**
	* Returns the auditdate5_6 of this complain check audit.
	*
	* @return the auditdate5_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_6() {
		return _complainCheckAudit.getAuditdate5_6();
	}

	/**
	* Sets the auditdate5_6 of this complain check audit.
	*
	* @param auditdate5_6 the auditdate5_6 of this complain check audit
	*/
	@Override
	public void setAuditdate5_6(java.lang.String auditdate5_6) {
		_complainCheckAudit.setAuditdate5_6(auditdate5_6);
	}

	/**
	* Returns the auditdate5_7 of this complain check audit.
	*
	* @return the auditdate5_7 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_7() {
		return _complainCheckAudit.getAuditdate5_7();
	}

	/**
	* Sets the auditdate5_7 of this complain check audit.
	*
	* @param auditdate5_7 the auditdate5_7 of this complain check audit
	*/
	@Override
	public void setAuditdate5_7(java.lang.String auditdate5_7) {
		_complainCheckAudit.setAuditdate5_7(auditdate5_7);
	}

	/**
	* Returns the auditdate5_8 of this complain check audit.
	*
	* @return the auditdate5_8 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdate5_8() {
		return _complainCheckAudit.getAuditdate5_8();
	}

	/**
	* Sets the auditdate5_8 of this complain check audit.
	*
	* @param auditdate5_8 the auditdate5_8 of this complain check audit
	*/
	@Override
	public void setAuditdate5_8(java.lang.String auditdate5_8) {
		_complainCheckAudit.setAuditdate5_8(auditdate5_8);
	}

	/**
	* Returns the auditdate note5_1 of this complain check audit.
	*
	* @return the auditdate note5_1 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_1() {
		return _complainCheckAudit.getAuditdateNote5_1();
	}

	/**
	* Sets the auditdate note5_1 of this complain check audit.
	*
	* @param auditdateNote5_1 the auditdate note5_1 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_1(java.lang.String auditdateNote5_1) {
		_complainCheckAudit.setAuditdateNote5_1(auditdateNote5_1);
	}

	/**
	* Returns the auditdate note5_2 of this complain check audit.
	*
	* @return the auditdate note5_2 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_2() {
		return _complainCheckAudit.getAuditdateNote5_2();
	}

	/**
	* Sets the auditdate note5_2 of this complain check audit.
	*
	* @param auditdateNote5_2 the auditdate note5_2 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_2(java.lang.String auditdateNote5_2) {
		_complainCheckAudit.setAuditdateNote5_2(auditdateNote5_2);
	}

	/**
	* Returns the auditdate note5_3 of this complain check audit.
	*
	* @return the auditdate note5_3 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_3() {
		return _complainCheckAudit.getAuditdateNote5_3();
	}

	/**
	* Sets the auditdate note5_3 of this complain check audit.
	*
	* @param auditdateNote5_3 the auditdate note5_3 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_3(java.lang.String auditdateNote5_3) {
		_complainCheckAudit.setAuditdateNote5_3(auditdateNote5_3);
	}

	/**
	* Returns the auditdate note5_4 of this complain check audit.
	*
	* @return the auditdate note5_4 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_4() {
		return _complainCheckAudit.getAuditdateNote5_4();
	}

	/**
	* Sets the auditdate note5_4 of this complain check audit.
	*
	* @param auditdateNote5_4 the auditdate note5_4 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_4(java.lang.String auditdateNote5_4) {
		_complainCheckAudit.setAuditdateNote5_4(auditdateNote5_4);
	}

	/**
	* Returns the auditdate note5_5 of this complain check audit.
	*
	* @return the auditdate note5_5 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_5() {
		return _complainCheckAudit.getAuditdateNote5_5();
	}

	/**
	* Sets the auditdate note5_5 of this complain check audit.
	*
	* @param auditdateNote5_5 the auditdate note5_5 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_5(java.lang.String auditdateNote5_5) {
		_complainCheckAudit.setAuditdateNote5_5(auditdateNote5_5);
	}

	/**
	* Returns the auditdate note5_6 of this complain check audit.
	*
	* @return the auditdate note5_6 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_6() {
		return _complainCheckAudit.getAuditdateNote5_6();
	}

	/**
	* Sets the auditdate note5_6 of this complain check audit.
	*
	* @param auditdateNote5_6 the auditdate note5_6 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_6(java.lang.String auditdateNote5_6) {
		_complainCheckAudit.setAuditdateNote5_6(auditdateNote5_6);
	}

	/**
	* Returns the auditdate note5_7 of this complain check audit.
	*
	* @return the auditdate note5_7 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_7() {
		return _complainCheckAudit.getAuditdateNote5_7();
	}

	/**
	* Sets the auditdate note5_7 of this complain check audit.
	*
	* @param auditdateNote5_7 the auditdate note5_7 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_7(java.lang.String auditdateNote5_7) {
		_complainCheckAudit.setAuditdateNote5_7(auditdateNote5_7);
	}

	/**
	* Returns the auditdate note5_8 of this complain check audit.
	*
	* @return the auditdate note5_8 of this complain check audit
	*/
	@Override
	public java.lang.String getAuditdateNote5_8() {
		return _complainCheckAudit.getAuditdateNote5_8();
	}

	/**
	* Sets the auditdate note5_8 of this complain check audit.
	*
	* @param auditdateNote5_8 the auditdate note5_8 of this complain check audit
	*/
	@Override
	public void setAuditdateNote5_8(java.lang.String auditdateNote5_8) {
		_complainCheckAudit.setAuditdateNote5_8(auditdateNote5_8);
	}

	@Override
	public boolean isNew() {
		return _complainCheckAudit.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_complainCheckAudit.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _complainCheckAudit.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_complainCheckAudit.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _complainCheckAudit.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _complainCheckAudit.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_complainCheckAudit.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _complainCheckAudit.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_complainCheckAudit.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_complainCheckAudit.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_complainCheckAudit.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ComplainCheckAuditWrapper((ComplainCheckAudit)_complainCheckAudit.clone());
	}

	@Override
	public int compareTo(
		com.spad.icop.model.ComplainCheckAudit complainCheckAudit) {
		return _complainCheckAudit.compareTo(complainCheckAudit);
	}

	@Override
	public int hashCode() {
		return _complainCheckAudit.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.ComplainCheckAudit> toCacheModel() {
		return _complainCheckAudit.toCacheModel();
	}

	@Override
	public com.spad.icop.model.ComplainCheckAudit toEscapedModel() {
		return new ComplainCheckAuditWrapper(_complainCheckAudit.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.ComplainCheckAudit toUnescapedModel() {
		return new ComplainCheckAuditWrapper(_complainCheckAudit.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _complainCheckAudit.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _complainCheckAudit.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_complainCheckAudit.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ComplainCheckAuditWrapper)) {
			return false;
		}

		ComplainCheckAuditWrapper complainCheckAuditWrapper = (ComplainCheckAuditWrapper)obj;

		if (Validator.equals(_complainCheckAudit,
					complainCheckAuditWrapper._complainCheckAudit)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ComplainCheckAudit getWrappedComplainCheckAudit() {
		return _complainCheckAudit;
	}

	@Override
	public ComplainCheckAudit getWrappedModel() {
		return _complainCheckAudit;
	}

	@Override
	public void resetOriginalValues() {
		_complainCheckAudit.resetOriginalValues();
	}

	private ComplainCheckAudit _complainCheckAudit;
}