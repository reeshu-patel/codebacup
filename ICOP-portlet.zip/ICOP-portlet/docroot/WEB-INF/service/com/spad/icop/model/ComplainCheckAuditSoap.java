/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.ComplainCheckAuditServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.ComplainCheckAuditServiceSoap
 * @generated
 */
public class ComplainCheckAuditSoap implements Serializable {
	public static ComplainCheckAuditSoap toSoapModel(ComplainCheckAudit model) {
		ComplainCheckAuditSoap soapModel = new ComplainCheckAuditSoap();

		soapModel.setMatterId(model.getMatterId());
		soapModel.setAditid(model.getAditid());
		soapModel.setAuditdate1_1(model.getAuditdate1_1());
		soapModel.setAuditdateNote1_1(model.getAuditdateNote1_1());
		soapModel.setAuditdate1_2(model.getAuditdate1_2());
		soapModel.setAuditdateNote1_2(model.getAuditdateNote1_2());
		soapModel.setAuditdate1_3(model.getAuditdate1_3());
		soapModel.setAuditdateNote1_3(model.getAuditdateNote1_3());
		soapModel.setAuditdate1_4(model.getAuditdate1_4());
		soapModel.setAuditdateNote1_4(model.getAuditdateNote1_4());
		soapModel.setAuditdate1_5(model.getAuditdate1_5());
		soapModel.setAuditdateNote1_5(model.getAuditdateNote1_5());
		soapModel.setAuditdate1_6(model.getAuditdate1_6());
		soapModel.setAuditdateNote1_6(model.getAuditdateNote1_6());
		soapModel.setAuditdate1_7(model.getAuditdate1_7());
		soapModel.setAuditdateNote1_7(model.getAuditdateNote1_7());
		soapModel.setAuditdate2_1(model.getAuditdate2_1());
		soapModel.setAuditdateNote2_1(model.getAuditdateNote2_1());
		soapModel.setAuditdate2_2(model.getAuditdate2_2());
		soapModel.setAuditdateNote2_2(model.getAuditdateNote2_2());
		soapModel.setAuditdate2_3(model.getAuditdate2_3());
		soapModel.setAuditdateNote2_3(model.getAuditdateNote2_3());
		soapModel.setAuditdate2_4(model.getAuditdate2_4());
		soapModel.setAuditdateNote2_4(model.getAuditdateNote2_4());
		soapModel.setAuditdate2_4_1(model.getAuditdate2_4_1());
		soapModel.setAuditdateNote2_4_1(model.getAuditdateNote2_4_1());
		soapModel.setAuditdate2_4_2(model.getAuditdate2_4_2());
		soapModel.setAuditdateNote2_4_2(model.getAuditdateNote2_4_2());
		soapModel.setAuditdate2_4_3(model.getAuditdate2_4_3());
		soapModel.setAuditdateNote2_4_3(model.getAuditdateNote2_4_3());
		soapModel.setAuditdate2_4_4(model.getAuditdate2_4_4());
		soapModel.setAuditdateNote2_4_4(model.getAuditdateNote2_4_4());
		soapModel.setAuditdate2_4_5(model.getAuditdate2_4_5());
		soapModel.setAuditdateNote2_4_5(model.getAuditdateNote2_4_5());
		soapModel.setAuditdate2_4_6(model.getAuditdate2_4_6());
		soapModel.setAuditdateNote2_4_6(model.getAuditdateNote2_4_6());
		soapModel.setAuditdate3_1(model.getAuditdate3_1());
		soapModel.setAuditdate3_2(model.getAuditdate3_2());
		soapModel.setAuditdate3_3(model.getAuditdate3_3());
		soapModel.setAuditdate3_4(model.getAuditdate3_4());
		soapModel.setAuditdate3_5(model.getAuditdate3_5());
		soapModel.setAuditdate3_6(model.getAuditdate3_6());
		soapModel.setAuditdateNote3_1(model.getAuditdateNote3_1());
		soapModel.setAuditdateNote3_2(model.getAuditdateNote3_2());
		soapModel.setAuditdateNote3_3(model.getAuditdateNote3_3());
		soapModel.setAuditdateNote3_4(model.getAuditdateNote3_4());
		soapModel.setAuditdateNote3_5(model.getAuditdateNote3_5());
		soapModel.setAuditdateNote3_6(model.getAuditdateNote3_6());
		soapModel.setAuditdate4_1(model.getAuditdate4_1());
		soapModel.setAuditdate4_2(model.getAuditdate4_2());
		soapModel.setAuditdate4_3(model.getAuditdate4_3());
		soapModel.setAuditdateNote4_1(model.getAuditdateNote4_1());
		soapModel.setAuditdateNote4_2(model.getAuditdateNote4_2());
		soapModel.setAuditdateNote4_3(model.getAuditdateNote4_3());
		soapModel.setAuditdate5_1(model.getAuditdate5_1());
		soapModel.setAuditdate5_2(model.getAuditdate5_2());
		soapModel.setAuditdate5_3(model.getAuditdate5_3());
		soapModel.setAuditdate5_4(model.getAuditdate5_4());
		soapModel.setAuditdate5_5(model.getAuditdate5_5());
		soapModel.setAuditdate5_6(model.getAuditdate5_6());
		soapModel.setAuditdate5_7(model.getAuditdate5_7());
		soapModel.setAuditdate5_8(model.getAuditdate5_8());
		soapModel.setAuditdateNote5_1(model.getAuditdateNote5_1());
		soapModel.setAuditdateNote5_2(model.getAuditdateNote5_2());
		soapModel.setAuditdateNote5_3(model.getAuditdateNote5_3());
		soapModel.setAuditdateNote5_4(model.getAuditdateNote5_4());
		soapModel.setAuditdateNote5_5(model.getAuditdateNote5_5());
		soapModel.setAuditdateNote5_6(model.getAuditdateNote5_6());
		soapModel.setAuditdateNote5_7(model.getAuditdateNote5_7());
		soapModel.setAuditdateNote5_8(model.getAuditdateNote5_8());

		return soapModel;
	}

	public static ComplainCheckAuditSoap[] toSoapModels(
		ComplainCheckAudit[] models) {
		ComplainCheckAuditSoap[] soapModels = new ComplainCheckAuditSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ComplainCheckAuditSoap[][] toSoapModels(
		ComplainCheckAudit[][] models) {
		ComplainCheckAuditSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ComplainCheckAuditSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ComplainCheckAuditSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ComplainCheckAuditSoap[] toSoapModels(
		List<ComplainCheckAudit> models) {
		List<ComplainCheckAuditSoap> soapModels = new ArrayList<ComplainCheckAuditSoap>(models.size());

		for (ComplainCheckAudit model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ComplainCheckAuditSoap[soapModels.size()]);
	}

	public ComplainCheckAuditSoap() {
	}

	public long getPrimaryKey() {
		return _matterId;
	}

	public void setPrimaryKey(long pk) {
		setMatterId(pk);
	}

	public long getMatterId() {
		return _matterId;
	}

	public void setMatterId(long matterId) {
		_matterId = matterId;
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getAuditdate1_1() {
		return _auditdate1_1;
	}

	public void setAuditdate1_1(String auditdate1_1) {
		_auditdate1_1 = auditdate1_1;
	}

	public String getAuditdateNote1_1() {
		return _auditdateNote1_1;
	}

	public void setAuditdateNote1_1(String auditdateNote1_1) {
		_auditdateNote1_1 = auditdateNote1_1;
	}

	public String getAuditdate1_2() {
		return _auditdate1_2;
	}

	public void setAuditdate1_2(String auditdate1_2) {
		_auditdate1_2 = auditdate1_2;
	}

	public String getAuditdateNote1_2() {
		return _auditdateNote1_2;
	}

	public void setAuditdateNote1_2(String auditdateNote1_2) {
		_auditdateNote1_2 = auditdateNote1_2;
	}

	public String getAuditdate1_3() {
		return _auditdate1_3;
	}

	public void setAuditdate1_3(String auditdate1_3) {
		_auditdate1_3 = auditdate1_3;
	}

	public String getAuditdateNote1_3() {
		return _auditdateNote1_3;
	}

	public void setAuditdateNote1_3(String auditdateNote1_3) {
		_auditdateNote1_3 = auditdateNote1_3;
	}

	public String getAuditdate1_4() {
		return _auditdate1_4;
	}

	public void setAuditdate1_4(String auditdate1_4) {
		_auditdate1_4 = auditdate1_4;
	}

	public String getAuditdateNote1_4() {
		return _auditdateNote1_4;
	}

	public void setAuditdateNote1_4(String auditdateNote1_4) {
		_auditdateNote1_4 = auditdateNote1_4;
	}

	public String getAuditdate1_5() {
		return _auditdate1_5;
	}

	public void setAuditdate1_5(String auditdate1_5) {
		_auditdate1_5 = auditdate1_5;
	}

	public String getAuditdateNote1_5() {
		return _auditdateNote1_5;
	}

	public void setAuditdateNote1_5(String auditdateNote1_5) {
		_auditdateNote1_5 = auditdateNote1_5;
	}

	public String getAuditdate1_6() {
		return _auditdate1_6;
	}

	public void setAuditdate1_6(String auditdate1_6) {
		_auditdate1_6 = auditdate1_6;
	}

	public String getAuditdateNote1_6() {
		return _auditdateNote1_6;
	}

	public void setAuditdateNote1_6(String auditdateNote1_6) {
		_auditdateNote1_6 = auditdateNote1_6;
	}

	public String getAuditdate1_7() {
		return _auditdate1_7;
	}

	public void setAuditdate1_7(String auditdate1_7) {
		_auditdate1_7 = auditdate1_7;
	}

	public String getAuditdateNote1_7() {
		return _auditdateNote1_7;
	}

	public void setAuditdateNote1_7(String auditdateNote1_7) {
		_auditdateNote1_7 = auditdateNote1_7;
	}

	public String getAuditdate2_1() {
		return _auditdate2_1;
	}

	public void setAuditdate2_1(String auditdate2_1) {
		_auditdate2_1 = auditdate2_1;
	}

	public String getAuditdateNote2_1() {
		return _auditdateNote2_1;
	}

	public void setAuditdateNote2_1(String auditdateNote2_1) {
		_auditdateNote2_1 = auditdateNote2_1;
	}

	public String getAuditdate2_2() {
		return _auditdate2_2;
	}

	public void setAuditdate2_2(String auditdate2_2) {
		_auditdate2_2 = auditdate2_2;
	}

	public String getAuditdateNote2_2() {
		return _auditdateNote2_2;
	}

	public void setAuditdateNote2_2(String auditdateNote2_2) {
		_auditdateNote2_2 = auditdateNote2_2;
	}

	public String getAuditdate2_3() {
		return _auditdate2_3;
	}

	public void setAuditdate2_3(String auditdate2_3) {
		_auditdate2_3 = auditdate2_3;
	}

	public String getAuditdateNote2_3() {
		return _auditdateNote2_3;
	}

	public void setAuditdateNote2_3(String auditdateNote2_3) {
		_auditdateNote2_3 = auditdateNote2_3;
	}

	public String getAuditdate2_4() {
		return _auditdate2_4;
	}

	public void setAuditdate2_4(String auditdate2_4) {
		_auditdate2_4 = auditdate2_4;
	}

	public String getAuditdateNote2_4() {
		return _auditdateNote2_4;
	}

	public void setAuditdateNote2_4(String auditdateNote2_4) {
		_auditdateNote2_4 = auditdateNote2_4;
	}

	public String getAuditdate2_4_1() {
		return _auditdate2_4_1;
	}

	public void setAuditdate2_4_1(String auditdate2_4_1) {
		_auditdate2_4_1 = auditdate2_4_1;
	}

	public String getAuditdateNote2_4_1() {
		return _auditdateNote2_4_1;
	}

	public void setAuditdateNote2_4_1(String auditdateNote2_4_1) {
		_auditdateNote2_4_1 = auditdateNote2_4_1;
	}

	public String getAuditdate2_4_2() {
		return _auditdate2_4_2;
	}

	public void setAuditdate2_4_2(String auditdate2_4_2) {
		_auditdate2_4_2 = auditdate2_4_2;
	}

	public String getAuditdateNote2_4_2() {
		return _auditdateNote2_4_2;
	}

	public void setAuditdateNote2_4_2(String auditdateNote2_4_2) {
		_auditdateNote2_4_2 = auditdateNote2_4_2;
	}

	public String getAuditdate2_4_3() {
		return _auditdate2_4_3;
	}

	public void setAuditdate2_4_3(String auditdate2_4_3) {
		_auditdate2_4_3 = auditdate2_4_3;
	}

	public String getAuditdateNote2_4_3() {
		return _auditdateNote2_4_3;
	}

	public void setAuditdateNote2_4_3(String auditdateNote2_4_3) {
		_auditdateNote2_4_3 = auditdateNote2_4_3;
	}

	public String getAuditdate2_4_4() {
		return _auditdate2_4_4;
	}

	public void setAuditdate2_4_4(String auditdate2_4_4) {
		_auditdate2_4_4 = auditdate2_4_4;
	}

	public String getAuditdateNote2_4_4() {
		return _auditdateNote2_4_4;
	}

	public void setAuditdateNote2_4_4(String auditdateNote2_4_4) {
		_auditdateNote2_4_4 = auditdateNote2_4_4;
	}

	public String getAuditdate2_4_5() {
		return _auditdate2_4_5;
	}

	public void setAuditdate2_4_5(String auditdate2_4_5) {
		_auditdate2_4_5 = auditdate2_4_5;
	}

	public String getAuditdateNote2_4_5() {
		return _auditdateNote2_4_5;
	}

	public void setAuditdateNote2_4_5(String auditdateNote2_4_5) {
		_auditdateNote2_4_5 = auditdateNote2_4_5;
	}

	public String getAuditdate2_4_6() {
		return _auditdate2_4_6;
	}

	public void setAuditdate2_4_6(String auditdate2_4_6) {
		_auditdate2_4_6 = auditdate2_4_6;
	}

	public String getAuditdateNote2_4_6() {
		return _auditdateNote2_4_6;
	}

	public void setAuditdateNote2_4_6(String auditdateNote2_4_6) {
		_auditdateNote2_4_6 = auditdateNote2_4_6;
	}

	public String getAuditdate3_1() {
		return _auditdate3_1;
	}

	public void setAuditdate3_1(String auditdate3_1) {
		_auditdate3_1 = auditdate3_1;
	}

	public String getAuditdate3_2() {
		return _auditdate3_2;
	}

	public void setAuditdate3_2(String auditdate3_2) {
		_auditdate3_2 = auditdate3_2;
	}

	public String getAuditdate3_3() {
		return _auditdate3_3;
	}

	public void setAuditdate3_3(String auditdate3_3) {
		_auditdate3_3 = auditdate3_3;
	}

	public String getAuditdate3_4() {
		return _auditdate3_4;
	}

	public void setAuditdate3_4(String auditdate3_4) {
		_auditdate3_4 = auditdate3_4;
	}

	public String getAuditdate3_5() {
		return _auditdate3_5;
	}

	public void setAuditdate3_5(String auditdate3_5) {
		_auditdate3_5 = auditdate3_5;
	}

	public String getAuditdate3_6() {
		return _auditdate3_6;
	}

	public void setAuditdate3_6(String auditdate3_6) {
		_auditdate3_6 = auditdate3_6;
	}

	public String getAuditdateNote3_1() {
		return _auditdateNote3_1;
	}

	public void setAuditdateNote3_1(String auditdateNote3_1) {
		_auditdateNote3_1 = auditdateNote3_1;
	}

	public String getAuditdateNote3_2() {
		return _auditdateNote3_2;
	}

	public void setAuditdateNote3_2(String auditdateNote3_2) {
		_auditdateNote3_2 = auditdateNote3_2;
	}

	public String getAuditdateNote3_3() {
		return _auditdateNote3_3;
	}

	public void setAuditdateNote3_3(String auditdateNote3_3) {
		_auditdateNote3_3 = auditdateNote3_3;
	}

	public String getAuditdateNote3_4() {
		return _auditdateNote3_4;
	}

	public void setAuditdateNote3_4(String auditdateNote3_4) {
		_auditdateNote3_4 = auditdateNote3_4;
	}

	public String getAuditdateNote3_5() {
		return _auditdateNote3_5;
	}

	public void setAuditdateNote3_5(String auditdateNote3_5) {
		_auditdateNote3_5 = auditdateNote3_5;
	}

	public String getAuditdateNote3_6() {
		return _auditdateNote3_6;
	}

	public void setAuditdateNote3_6(String auditdateNote3_6) {
		_auditdateNote3_6 = auditdateNote3_6;
	}

	public String getAuditdate4_1() {
		return _auditdate4_1;
	}

	public void setAuditdate4_1(String auditdate4_1) {
		_auditdate4_1 = auditdate4_1;
	}

	public String getAuditdate4_2() {
		return _auditdate4_2;
	}

	public void setAuditdate4_2(String auditdate4_2) {
		_auditdate4_2 = auditdate4_2;
	}

	public String getAuditdate4_3() {
		return _auditdate4_3;
	}

	public void setAuditdate4_3(String auditdate4_3) {
		_auditdate4_3 = auditdate4_3;
	}

	public String getAuditdateNote4_1() {
		return _auditdateNote4_1;
	}

	public void setAuditdateNote4_1(String auditdateNote4_1) {
		_auditdateNote4_1 = auditdateNote4_1;
	}

	public String getAuditdateNote4_2() {
		return _auditdateNote4_2;
	}

	public void setAuditdateNote4_2(String auditdateNote4_2) {
		_auditdateNote4_2 = auditdateNote4_2;
	}

	public String getAuditdateNote4_3() {
		return _auditdateNote4_3;
	}

	public void setAuditdateNote4_3(String auditdateNote4_3) {
		_auditdateNote4_3 = auditdateNote4_3;
	}

	public String getAuditdate5_1() {
		return _auditdate5_1;
	}

	public void setAuditdate5_1(String auditdate5_1) {
		_auditdate5_1 = auditdate5_1;
	}

	public String getAuditdate5_2() {
		return _auditdate5_2;
	}

	public void setAuditdate5_2(String auditdate5_2) {
		_auditdate5_2 = auditdate5_2;
	}

	public String getAuditdate5_3() {
		return _auditdate5_3;
	}

	public void setAuditdate5_3(String auditdate5_3) {
		_auditdate5_3 = auditdate5_3;
	}

	public String getAuditdate5_4() {
		return _auditdate5_4;
	}

	public void setAuditdate5_4(String auditdate5_4) {
		_auditdate5_4 = auditdate5_4;
	}

	public String getAuditdate5_5() {
		return _auditdate5_5;
	}

	public void setAuditdate5_5(String auditdate5_5) {
		_auditdate5_5 = auditdate5_5;
	}

	public String getAuditdate5_6() {
		return _auditdate5_6;
	}

	public void setAuditdate5_6(String auditdate5_6) {
		_auditdate5_6 = auditdate5_6;
	}

	public String getAuditdate5_7() {
		return _auditdate5_7;
	}

	public void setAuditdate5_7(String auditdate5_7) {
		_auditdate5_7 = auditdate5_7;
	}

	public String getAuditdate5_8() {
		return _auditdate5_8;
	}

	public void setAuditdate5_8(String auditdate5_8) {
		_auditdate5_8 = auditdate5_8;
	}

	public String getAuditdateNote5_1() {
		return _auditdateNote5_1;
	}

	public void setAuditdateNote5_1(String auditdateNote5_1) {
		_auditdateNote5_1 = auditdateNote5_1;
	}

	public String getAuditdateNote5_2() {
		return _auditdateNote5_2;
	}

	public void setAuditdateNote5_2(String auditdateNote5_2) {
		_auditdateNote5_2 = auditdateNote5_2;
	}

	public String getAuditdateNote5_3() {
		return _auditdateNote5_3;
	}

	public void setAuditdateNote5_3(String auditdateNote5_3) {
		_auditdateNote5_3 = auditdateNote5_3;
	}

	public String getAuditdateNote5_4() {
		return _auditdateNote5_4;
	}

	public void setAuditdateNote5_4(String auditdateNote5_4) {
		_auditdateNote5_4 = auditdateNote5_4;
	}

	public String getAuditdateNote5_5() {
		return _auditdateNote5_5;
	}

	public void setAuditdateNote5_5(String auditdateNote5_5) {
		_auditdateNote5_5 = auditdateNote5_5;
	}

	public String getAuditdateNote5_6() {
		return _auditdateNote5_6;
	}

	public void setAuditdateNote5_6(String auditdateNote5_6) {
		_auditdateNote5_6 = auditdateNote5_6;
	}

	public String getAuditdateNote5_7() {
		return _auditdateNote5_7;
	}

	public void setAuditdateNote5_7(String auditdateNote5_7) {
		_auditdateNote5_7 = auditdateNote5_7;
	}

	public String getAuditdateNote5_8() {
		return _auditdateNote5_8;
	}

	public void setAuditdateNote5_8(String auditdateNote5_8) {
		_auditdateNote5_8 = auditdateNote5_8;
	}

	private long _matterId;
	private long _aditid;
	private String _auditdate1_1;
	private String _auditdateNote1_1;
	private String _auditdate1_2;
	private String _auditdateNote1_2;
	private String _auditdate1_3;
	private String _auditdateNote1_3;
	private String _auditdate1_4;
	private String _auditdateNote1_4;
	private String _auditdate1_5;
	private String _auditdateNote1_5;
	private String _auditdate1_6;
	private String _auditdateNote1_6;
	private String _auditdate1_7;
	private String _auditdateNote1_7;
	private String _auditdate2_1;
	private String _auditdateNote2_1;
	private String _auditdate2_2;
	private String _auditdateNote2_2;
	private String _auditdate2_3;
	private String _auditdateNote2_3;
	private String _auditdate2_4;
	private String _auditdateNote2_4;
	private String _auditdate2_4_1;
	private String _auditdateNote2_4_1;
	private String _auditdate2_4_2;
	private String _auditdateNote2_4_2;
	private String _auditdate2_4_3;
	private String _auditdateNote2_4_3;
	private String _auditdate2_4_4;
	private String _auditdateNote2_4_4;
	private String _auditdate2_4_5;
	private String _auditdateNote2_4_5;
	private String _auditdate2_4_6;
	private String _auditdateNote2_4_6;
	private String _auditdate3_1;
	private String _auditdate3_2;
	private String _auditdate3_3;
	private String _auditdate3_4;
	private String _auditdate3_5;
	private String _auditdate3_6;
	private String _auditdateNote3_1;
	private String _auditdateNote3_2;
	private String _auditdateNote3_3;
	private String _auditdateNote3_4;
	private String _auditdateNote3_5;
	private String _auditdateNote3_6;
	private String _auditdate4_1;
	private String _auditdate4_2;
	private String _auditdate4_3;
	private String _auditdateNote4_1;
	private String _auditdateNote4_2;
	private String _auditdateNote4_3;
	private String _auditdate5_1;
	private String _auditdate5_2;
	private String _auditdate5_3;
	private String _auditdate5_4;
	private String _auditdate5_5;
	private String _auditdate5_6;
	private String _auditdate5_7;
	private String _auditdate5_8;
	private String _auditdateNote5_1;
	private String _auditdateNote5_2;
	private String _auditdateNote5_3;
	private String _auditdateNote5_4;
	private String _auditdateNote5_5;
	private String _auditdateNote5_6;
	private String _auditdateNote5_7;
	private String _auditdateNote5_8;
}