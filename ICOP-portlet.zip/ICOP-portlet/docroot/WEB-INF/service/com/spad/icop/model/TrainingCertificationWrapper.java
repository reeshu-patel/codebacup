/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link TrainingCertification}.
 * </p>
 *
 * @author reeshu
 * @see TrainingCertification
 * @generated
 */
public class TrainingCertificationWrapper implements TrainingCertification,
	ModelWrapper<TrainingCertification> {
	public TrainingCertificationWrapper(
		TrainingCertification trainingCertification) {
		_trainingCertification = trainingCertification;
	}

	@Override
	public Class<?> getModelClass() {
		return TrainingCertification.class;
	}

	@Override
	public String getModelClassName() {
		return TrainingCertification.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("trainingCertifiId", getTrainingCertifiId());
		attributes.put("aditid", getAditid());
		attributes.put("trainingDates", getTrainingDates());
		attributes.put("exerciseName", getExerciseName());
		attributes.put("pointsExercise", getPointsExercise());
		attributes.put("nameOfficer", getNameOfficer());
		attributes.put("number", getNumber());
		attributes.put("statusExercise", getStatusExercise());
		attributes.put("statusMoulds", getStatusMoulds());
		attributes.put("companyName", getCompanyName());
		attributes.put("address", getAddress());
		attributes.put("email", getEmail());
		attributes.put("operatorName", getOperatorName());
		attributes.put("typeVehicle", getTypeVehicle());
		attributes.put("noVehicles", getNoVehicles());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long trainingCertifiId = (Long)attributes.get("trainingCertifiId");

		if (trainingCertifiId != null) {
			setTrainingCertifiId(trainingCertifiId);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String trainingDates = (String)attributes.get("trainingDates");

		if (trainingDates != null) {
			setTrainingDates(trainingDates);
		}

		String exerciseName = (String)attributes.get("exerciseName");

		if (exerciseName != null) {
			setExerciseName(exerciseName);
		}

		String pointsExercise = (String)attributes.get("pointsExercise");

		if (pointsExercise != null) {
			setPointsExercise(pointsExercise);
		}

		String nameOfficer = (String)attributes.get("nameOfficer");

		if (nameOfficer != null) {
			setNameOfficer(nameOfficer);
		}

		String number = (String)attributes.get("number");

		if (number != null) {
			setNumber(number);
		}

		String statusExercise = (String)attributes.get("statusExercise");

		if (statusExercise != null) {
			setStatusExercise(statusExercise);
		}

		String statusMoulds = (String)attributes.get("statusMoulds");

		if (statusMoulds != null) {
			setStatusMoulds(statusMoulds);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String operatorName = (String)attributes.get("operatorName");

		if (operatorName != null) {
			setOperatorName(operatorName);
		}

		String typeVehicle = (String)attributes.get("typeVehicle");

		if (typeVehicle != null) {
			setTypeVehicle(typeVehicle);
		}

		String noVehicles = (String)attributes.get("noVehicles");

		if (noVehicles != null) {
			setNoVehicles(noVehicles);
		}
	}

	/**
	* Returns the primary key of this training certification.
	*
	* @return the primary key of this training certification
	*/
	@Override
	public long getPrimaryKey() {
		return _trainingCertification.getPrimaryKey();
	}

	/**
	* Sets the primary key of this training certification.
	*
	* @param primaryKey the primary key of this training certification
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_trainingCertification.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the training certifi ID of this training certification.
	*
	* @return the training certifi ID of this training certification
	*/
	@Override
	public long getTrainingCertifiId() {
		return _trainingCertification.getTrainingCertifiId();
	}

	/**
	* Sets the training certifi ID of this training certification.
	*
	* @param trainingCertifiId the training certifi ID of this training certification
	*/
	@Override
	public void setTrainingCertifiId(long trainingCertifiId) {
		_trainingCertification.setTrainingCertifiId(trainingCertifiId);
	}

	/**
	* Returns the aditid of this training certification.
	*
	* @return the aditid of this training certification
	*/
	@Override
	public long getAditid() {
		return _trainingCertification.getAditid();
	}

	/**
	* Sets the aditid of this training certification.
	*
	* @param aditid the aditid of this training certification
	*/
	@Override
	public void setAditid(long aditid) {
		_trainingCertification.setAditid(aditid);
	}

	/**
	* Returns the training dates of this training certification.
	*
	* @return the training dates of this training certification
	*/
	@Override
	public java.lang.String getTrainingDates() {
		return _trainingCertification.getTrainingDates();
	}

	/**
	* Sets the training dates of this training certification.
	*
	* @param trainingDates the training dates of this training certification
	*/
	@Override
	public void setTrainingDates(java.lang.String trainingDates) {
		_trainingCertification.setTrainingDates(trainingDates);
	}

	/**
	* Returns the exercise name of this training certification.
	*
	* @return the exercise name of this training certification
	*/
	@Override
	public java.lang.String getExerciseName() {
		return _trainingCertification.getExerciseName();
	}

	/**
	* Sets the exercise name of this training certification.
	*
	* @param exerciseName the exercise name of this training certification
	*/
	@Override
	public void setExerciseName(java.lang.String exerciseName) {
		_trainingCertification.setExerciseName(exerciseName);
	}

	/**
	* Returns the points exercise of this training certification.
	*
	* @return the points exercise of this training certification
	*/
	@Override
	public java.lang.String getPointsExercise() {
		return _trainingCertification.getPointsExercise();
	}

	/**
	* Sets the points exercise of this training certification.
	*
	* @param pointsExercise the points exercise of this training certification
	*/
	@Override
	public void setPointsExercise(java.lang.String pointsExercise) {
		_trainingCertification.setPointsExercise(pointsExercise);
	}

	/**
	* Returns the name officer of this training certification.
	*
	* @return the name officer of this training certification
	*/
	@Override
	public java.lang.String getNameOfficer() {
		return _trainingCertification.getNameOfficer();
	}

	/**
	* Sets the name officer of this training certification.
	*
	* @param nameOfficer the name officer of this training certification
	*/
	@Override
	public void setNameOfficer(java.lang.String nameOfficer) {
		_trainingCertification.setNameOfficer(nameOfficer);
	}

	/**
	* Returns the number of this training certification.
	*
	* @return the number of this training certification
	*/
	@Override
	public java.lang.String getNumber() {
		return _trainingCertification.getNumber();
	}

	/**
	* Sets the number of this training certification.
	*
	* @param number the number of this training certification
	*/
	@Override
	public void setNumber(java.lang.String number) {
		_trainingCertification.setNumber(number);
	}

	/**
	* Returns the status exercise of this training certification.
	*
	* @return the status exercise of this training certification
	*/
	@Override
	public java.lang.String getStatusExercise() {
		return _trainingCertification.getStatusExercise();
	}

	/**
	* Sets the status exercise of this training certification.
	*
	* @param statusExercise the status exercise of this training certification
	*/
	@Override
	public void setStatusExercise(java.lang.String statusExercise) {
		_trainingCertification.setStatusExercise(statusExercise);
	}

	/**
	* Returns the status moulds of this training certification.
	*
	* @return the status moulds of this training certification
	*/
	@Override
	public java.lang.String getStatusMoulds() {
		return _trainingCertification.getStatusMoulds();
	}

	/**
	* Sets the status moulds of this training certification.
	*
	* @param statusMoulds the status moulds of this training certification
	*/
	@Override
	public void setStatusMoulds(java.lang.String statusMoulds) {
		_trainingCertification.setStatusMoulds(statusMoulds);
	}

	/**
	* Returns the company name of this training certification.
	*
	* @return the company name of this training certification
	*/
	@Override
	public java.lang.String getCompanyName() {
		return _trainingCertification.getCompanyName();
	}

	/**
	* Sets the company name of this training certification.
	*
	* @param companyName the company name of this training certification
	*/
	@Override
	public void setCompanyName(java.lang.String companyName) {
		_trainingCertification.setCompanyName(companyName);
	}

	/**
	* Returns the address of this training certification.
	*
	* @return the address of this training certification
	*/
	@Override
	public java.lang.String getAddress() {
		return _trainingCertification.getAddress();
	}

	/**
	* Sets the address of this training certification.
	*
	* @param address the address of this training certification
	*/
	@Override
	public void setAddress(java.lang.String address) {
		_trainingCertification.setAddress(address);
	}

	/**
	* Returns the email of this training certification.
	*
	* @return the email of this training certification
	*/
	@Override
	public java.lang.String getEmail() {
		return _trainingCertification.getEmail();
	}

	/**
	* Sets the email of this training certification.
	*
	* @param email the email of this training certification
	*/
	@Override
	public void setEmail(java.lang.String email) {
		_trainingCertification.setEmail(email);
	}

	/**
	* Returns the operator name of this training certification.
	*
	* @return the operator name of this training certification
	*/
	@Override
	public java.lang.String getOperatorName() {
		return _trainingCertification.getOperatorName();
	}

	/**
	* Sets the operator name of this training certification.
	*
	* @param operatorName the operator name of this training certification
	*/
	@Override
	public void setOperatorName(java.lang.String operatorName) {
		_trainingCertification.setOperatorName(operatorName);
	}

	/**
	* Returns the type vehicle of this training certification.
	*
	* @return the type vehicle of this training certification
	*/
	@Override
	public java.lang.String getTypeVehicle() {
		return _trainingCertification.getTypeVehicle();
	}

	/**
	* Sets the type vehicle of this training certification.
	*
	* @param typeVehicle the type vehicle of this training certification
	*/
	@Override
	public void setTypeVehicle(java.lang.String typeVehicle) {
		_trainingCertification.setTypeVehicle(typeVehicle);
	}

	/**
	* Returns the no vehicles of this training certification.
	*
	* @return the no vehicles of this training certification
	*/
	@Override
	public java.lang.String getNoVehicles() {
		return _trainingCertification.getNoVehicles();
	}

	/**
	* Sets the no vehicles of this training certification.
	*
	* @param noVehicles the no vehicles of this training certification
	*/
	@Override
	public void setNoVehicles(java.lang.String noVehicles) {
		_trainingCertification.setNoVehicles(noVehicles);
	}

	@Override
	public boolean isNew() {
		return _trainingCertification.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_trainingCertification.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _trainingCertification.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_trainingCertification.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _trainingCertification.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _trainingCertification.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_trainingCertification.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _trainingCertification.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_trainingCertification.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_trainingCertification.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_trainingCertification.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new TrainingCertificationWrapper((TrainingCertification)_trainingCertification.clone());
	}

	@Override
	public int compareTo(
		com.spad.icop.model.TrainingCertification trainingCertification) {
		return _trainingCertification.compareTo(trainingCertification);
	}

	@Override
	public int hashCode() {
		return _trainingCertification.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.TrainingCertification> toCacheModel() {
		return _trainingCertification.toCacheModel();
	}

	@Override
	public com.spad.icop.model.TrainingCertification toEscapedModel() {
		return new TrainingCertificationWrapper(_trainingCertification.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.TrainingCertification toUnescapedModel() {
		return new TrainingCertificationWrapper(_trainingCertification.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _trainingCertification.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _trainingCertification.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_trainingCertification.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TrainingCertificationWrapper)) {
			return false;
		}

		TrainingCertificationWrapper trainingCertificationWrapper = (TrainingCertificationWrapper)obj;

		if (Validator.equals(_trainingCertification,
					trainingCertificationWrapper._trainingCertification)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public TrainingCertification getWrappedTrainingCertification() {
		return _trainingCertification;
	}

	@Override
	public TrainingCertification getWrappedModel() {
		return _trainingCertification;
	}

	@Override
	public void resetOriginalValues() {
		_trainingCertification.resetOriginalValues();
	}

	private TrainingCertification _trainingCertification;
}