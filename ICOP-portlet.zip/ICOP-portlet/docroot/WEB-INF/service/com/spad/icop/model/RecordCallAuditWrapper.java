/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link RecordCallAudit}.
 * </p>
 *
 * @author reeshu
 * @see RecordCallAudit
 * @generated
 */
public class RecordCallAuditWrapper implements RecordCallAudit,
	ModelWrapper<RecordCallAudit> {
	public RecordCallAuditWrapper(RecordCallAudit recordCallAudit) {
		_recordCallAudit = recordCallAudit;
	}

	@Override
	public Class<?> getModelClass() {
		return RecordCallAudit.class;
	}

	@Override
	public String getModelClassName() {
		return RecordCallAudit.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recordcallid", getRecordcallid());
		attributes.put("aditid", getAditid());
		attributes.put("dateonroadsafty", getDateonroadsafty());
		attributes.put("investigationtitle", getInvestigationtitle());
		attributes.put("company", getCompany());
		attributes.put("statusverification", getStatusverification());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String recordcallid = (String)attributes.get("recordcallid");

		if (recordcallid != null) {
			setRecordcallid(recordcallid);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String dateonroadsafty = (String)attributes.get("dateonroadsafty");

		if (dateonroadsafty != null) {
			setDateonroadsafty(dateonroadsafty);
		}

		String investigationtitle = (String)attributes.get("investigationtitle");

		if (investigationtitle != null) {
			setInvestigationtitle(investigationtitle);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String statusverification = (String)attributes.get("statusverification");

		if (statusverification != null) {
			setStatusverification(statusverification);
		}
	}

	/**
	* Returns the primary key of this record call audit.
	*
	* @return the primary key of this record call audit
	*/
	@Override
	public long getPrimaryKey() {
		return _recordCallAudit.getPrimaryKey();
	}

	/**
	* Sets the primary key of this record call audit.
	*
	* @param primaryKey the primary key of this record call audit
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_recordCallAudit.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the recordcallid of this record call audit.
	*
	* @return the recordcallid of this record call audit
	*/
	@Override
	public java.lang.String getRecordcallid() {
		return _recordCallAudit.getRecordcallid();
	}

	/**
	* Sets the recordcallid of this record call audit.
	*
	* @param recordcallid the recordcallid of this record call audit
	*/
	@Override
	public void setRecordcallid(java.lang.String recordcallid) {
		_recordCallAudit.setRecordcallid(recordcallid);
	}

	/**
	* Returns the aditid of this record call audit.
	*
	* @return the aditid of this record call audit
	*/
	@Override
	public long getAditid() {
		return _recordCallAudit.getAditid();
	}

	/**
	* Sets the aditid of this record call audit.
	*
	* @param aditid the aditid of this record call audit
	*/
	@Override
	public void setAditid(long aditid) {
		_recordCallAudit.setAditid(aditid);
	}

	/**
	* Returns the dateonroadsafty of this record call audit.
	*
	* @return the dateonroadsafty of this record call audit
	*/
	@Override
	public java.lang.String getDateonroadsafty() {
		return _recordCallAudit.getDateonroadsafty();
	}

	/**
	* Sets the dateonroadsafty of this record call audit.
	*
	* @param dateonroadsafty the dateonroadsafty of this record call audit
	*/
	@Override
	public void setDateonroadsafty(java.lang.String dateonroadsafty) {
		_recordCallAudit.setDateonroadsafty(dateonroadsafty);
	}

	/**
	* Returns the investigationtitle of this record call audit.
	*
	* @return the investigationtitle of this record call audit
	*/
	@Override
	public java.lang.String getInvestigationtitle() {
		return _recordCallAudit.getInvestigationtitle();
	}

	/**
	* Sets the investigationtitle of this record call audit.
	*
	* @param investigationtitle the investigationtitle of this record call audit
	*/
	@Override
	public void setInvestigationtitle(java.lang.String investigationtitle) {
		_recordCallAudit.setInvestigationtitle(investigationtitle);
	}

	/**
	* Returns the company of this record call audit.
	*
	* @return the company of this record call audit
	*/
	@Override
	public java.lang.String getCompany() {
		return _recordCallAudit.getCompany();
	}

	/**
	* Sets the company of this record call audit.
	*
	* @param company the company of this record call audit
	*/
	@Override
	public void setCompany(java.lang.String company) {
		_recordCallAudit.setCompany(company);
	}

	/**
	* Returns the statusverification of this record call audit.
	*
	* @return the statusverification of this record call audit
	*/
	@Override
	public java.lang.String getStatusverification() {
		return _recordCallAudit.getStatusverification();
	}

	/**
	* Sets the statusverification of this record call audit.
	*
	* @param statusverification the statusverification of this record call audit
	*/
	@Override
	public void setStatusverification(java.lang.String statusverification) {
		_recordCallAudit.setStatusverification(statusverification);
	}

	@Override
	public boolean isNew() {
		return _recordCallAudit.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_recordCallAudit.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _recordCallAudit.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_recordCallAudit.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _recordCallAudit.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _recordCallAudit.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_recordCallAudit.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _recordCallAudit.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_recordCallAudit.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_recordCallAudit.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_recordCallAudit.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new RecordCallAuditWrapper((RecordCallAudit)_recordCallAudit.clone());
	}

	@Override
	public int compareTo(RecordCallAudit recordCallAudit) {
		return _recordCallAudit.compareTo(recordCallAudit);
	}

	@Override
	public int hashCode() {
		return _recordCallAudit.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<RecordCallAudit> toCacheModel() {
		return _recordCallAudit.toCacheModel();
	}

	@Override
	public RecordCallAudit toEscapedModel() {
		return new RecordCallAuditWrapper(_recordCallAudit.toEscapedModel());
	}

	@Override
	public RecordCallAudit toUnescapedModel() {
		return new RecordCallAuditWrapper(_recordCallAudit.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _recordCallAudit.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _recordCallAudit.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_recordCallAudit.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RecordCallAuditWrapper)) {
			return false;
		}

		RecordCallAuditWrapper recordCallAuditWrapper = (RecordCallAuditWrapper)obj;

		if (Validator.equals(_recordCallAudit,
					recordCallAuditWrapper._recordCallAudit)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public RecordCallAudit getWrappedRecordCallAudit() {
		return _recordCallAudit;
	}

	@Override
	public RecordCallAudit getWrappedModel() {
		return _recordCallAudit;
	}

	@Override
	public void resetOriginalValues() {
		_recordCallAudit.resetOriginalValues();
	}

	private RecordCallAudit _recordCallAudit;
}