/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.CompilanceCheckServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.CompilanceCheckServiceSoap
 * @generated
 */
public class CompilanceCheckSoap implements Serializable {
	public static CompilanceCheckSoap toSoapModel(CompilanceCheck model) {
		CompilanceCheckSoap soapModel = new CompilanceCheckSoap();

		soapModel.setCompilanceCheckid(model.getCompilanceCheckid());
		soapModel.setAditid(model.getAditid());
		soapModel.setCompany(model.getCompany());
		soapModel.setAudidate(model.getAudidate());
		soapModel.setCompletedStatus(model.getCompletedStatus());
		soapModel.setAuditPercentage(model.getAuditPercentage());
		soapModel.setQuestionSafetyOne(model.getQuestionSafetyOne());
		soapModel.setQuestionSafetyTwo(model.getQuestionSafetyTwo());
		soapModel.setQuestionSafetyThree(model.getQuestionSafetyThree());
		soapModel.setQuestionSafetFour(model.getQuestionSafetFour());
		soapModel.setQuestionSafetFive(model.getQuestionSafetFive());
		soapModel.setQuestionSafetSix(model.getQuestionSafetSix());
		soapModel.setQuestionSafetySeven(model.getQuestionSafetySeven());
		soapModel.setQuestionNoteOne(model.getQuestionNoteOne());
		soapModel.setQuestionNoteTwo(model.getQuestionNoteTwo());
		soapModel.setQuestionNoteThree(model.getQuestionNoteThree());
		soapModel.setQuestionNoteFour(model.getQuestionNoteFour());
		soapModel.setQuestionNoteFive(model.getQuestionNoteFive());
		soapModel.setQuestionNoteSix(model.getQuestionNoteSix());
		soapModel.setQuestionNoteSeven(model.getQuestionNoteSeven());
		soapModel.setQuestionVehicalOne(model.getQuestionVehicalOne());
		soapModel.setQuestionVehicalTwo(model.getQuestionVehicalTwo());
		soapModel.setQuestionVehicalThree(model.getQuestionVehicalThree());
		soapModel.setQuestionVehicalFour(model.getQuestionVehicalFour());
		soapModel.setQuestionVehicalFive(model.getQuestionVehicalFive());
		soapModel.setQuestionVehicalSix(model.getQuestionVehicalSix());
		soapModel.setQuestionVehicalSeven(model.getQuestionVehicalSeven());
		soapModel.setQuestionVehicalNoteOne(model.getQuestionVehicalNoteOne());
		soapModel.setQuestionVehicalNoteTwo(model.getQuestionVehicalNoteTwo());
		soapModel.setQuestionVehicalNoteThree(model.getQuestionVehicalNoteThree());
		soapModel.setQuestionVehicalNoteFour(model.getQuestionVehicalNoteFour());
		soapModel.setQuestionVehicalNoteFive(model.getQuestionVehicalNoteFive());
		soapModel.setQuestionVehicalNoteSix(model.getQuestionVehicalNoteSix());
		soapModel.setQuestionVehicalNoteSeven(model.getQuestionVehicalNoteSeven());
		soapModel.setQuestionManageOne(model.getQuestionManageOne());
		soapModel.setQuestionManageTwo(model.getQuestionManageTwo());
		soapModel.setQuestionManageThree(model.getQuestionManageThree());
		soapModel.setQuestionManageFour(model.getQuestionManageFour());
		soapModel.setQuestionManageFive(model.getQuestionManageFive());
		soapModel.setQuestionManageSix(model.getQuestionManageSix());
		soapModel.setQuestionManageSeven(model.getQuestionManageSeven());
		soapModel.setQuestionManageNoteOne(model.getQuestionManageNoteOne());
		soapModel.setQuestionManageNoteTwo(model.getQuestionManageNoteTwo());
		soapModel.setQuestionManageNoteThree(model.getQuestionManageNoteThree());
		soapModel.setQuestionManageNoteFour(model.getQuestionManageNoteFour());
		soapModel.setQuestionManageNoteFive(model.getQuestionManageNoteFive());
		soapModel.setQuestionManageNoteSix(model.getQuestionManageNoteSix());
		soapModel.setQuestionRecordsOne(model.getQuestionRecordsOne());
		soapModel.setQuestionRecordsTwo(model.getQuestionRecordsTwo());
		soapModel.setQuestionRecordsThree(model.getQuestionRecordsThree());
		soapModel.setQuestionRecordsNoteOne(model.getQuestionRecordsNoteOne());
		soapModel.setQuestionRecordsNoteTwo(model.getQuestionRecordsNoteTwo());
		soapModel.setQuestionRecordsNoteThree(model.getQuestionRecordsNoteThree());
		soapModel.setQuestionReskOne(model.getQuestionReskOne());
		soapModel.setQuestionReskTwo(model.getQuestionReskTwo());
		soapModel.setQuestionReskThree(model.getQuestionReskThree());
		soapModel.setQuestionReskFour(model.getQuestionReskFour());
		soapModel.setQuestionReskFive(model.getQuestionReskFive());
		soapModel.setQuestionReskSix(model.getQuestionReskSix());
		soapModel.setQuestionReskSeven(model.getQuestionReskSeven());
		soapModel.setQuestionReskEight(model.getQuestionReskEight());
		soapModel.setQuestionReskNoteOne(model.getQuestionReskNoteOne());
		soapModel.setQuestionReskNoteTwo(model.getQuestionReskNoteTwo());
		soapModel.setQuestionReskNoteThree(model.getQuestionReskNoteThree());
		soapModel.setQuestionReskNoteFour(model.getQuestionReskNoteFour());
		soapModel.setQuestionReskNoteFive(model.getQuestionReskNoteFive());
		soapModel.setQuestionReskNoteSix(model.getQuestionReskNoteSix());
		soapModel.setQuestionReskNoteSeven(model.getQuestionReskNoteSeven());
		soapModel.setQuestionReskNoteEight(model.getQuestionReskNoteEight());
		soapModel.setNotcomplied(model.getNotcomplied());
		soapModel.setRecord(model.getRecord());

		return soapModel;
	}

	public static CompilanceCheckSoap[] toSoapModels(CompilanceCheck[] models) {
		CompilanceCheckSoap[] soapModels = new CompilanceCheckSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CompilanceCheckSoap[][] toSoapModels(
		CompilanceCheck[][] models) {
		CompilanceCheckSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CompilanceCheckSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CompilanceCheckSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CompilanceCheckSoap[] toSoapModels(
		List<CompilanceCheck> models) {
		List<CompilanceCheckSoap> soapModels = new ArrayList<CompilanceCheckSoap>(models.size());

		for (CompilanceCheck model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CompilanceCheckSoap[soapModels.size()]);
	}

	public CompilanceCheckSoap() {
	}

	public long getPrimaryKey() {
		return _compilanceCheckid;
	}

	public void setPrimaryKey(long pk) {
		setCompilanceCheckid(pk);
	}

	public long getCompilanceCheckid() {
		return _compilanceCheckid;
	}

	public void setCompilanceCheckid(long compilanceCheckid) {
		_compilanceCheckid = compilanceCheckid;
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getCompany() {
		return _company;
	}

	public void setCompany(String company) {
		_company = company;
	}

	public String getAudidate() {
		return _audidate;
	}

	public void setAudidate(String audidate) {
		_audidate = audidate;
	}

	public String getCompletedStatus() {
		return _completedStatus;
	}

	public void setCompletedStatus(String completedStatus) {
		_completedStatus = completedStatus;
	}

	public String getAuditPercentage() {
		return _auditPercentage;
	}

	public void setAuditPercentage(String auditPercentage) {
		_auditPercentage = auditPercentage;
	}

	public String getQuestionSafetyOne() {
		return _questionSafetyOne;
	}

	public void setQuestionSafetyOne(String questionSafetyOne) {
		_questionSafetyOne = questionSafetyOne;
	}

	public String getQuestionSafetyTwo() {
		return _questionSafetyTwo;
	}

	public void setQuestionSafetyTwo(String questionSafetyTwo) {
		_questionSafetyTwo = questionSafetyTwo;
	}

	public String getQuestionSafetyThree() {
		return _questionSafetyThree;
	}

	public void setQuestionSafetyThree(String questionSafetyThree) {
		_questionSafetyThree = questionSafetyThree;
	}

	public String getQuestionSafetFour() {
		return _questionSafetFour;
	}

	public void setQuestionSafetFour(String questionSafetFour) {
		_questionSafetFour = questionSafetFour;
	}

	public String getQuestionSafetFive() {
		return _questionSafetFive;
	}

	public void setQuestionSafetFive(String questionSafetFive) {
		_questionSafetFive = questionSafetFive;
	}

	public String getQuestionSafetSix() {
		return _questionSafetSix;
	}

	public void setQuestionSafetSix(String questionSafetSix) {
		_questionSafetSix = questionSafetSix;
	}

	public String getQuestionSafetySeven() {
		return _questionSafetySeven;
	}

	public void setQuestionSafetySeven(String questionSafetySeven) {
		_questionSafetySeven = questionSafetySeven;
	}

	public String getQuestionNoteOne() {
		return _questionNoteOne;
	}

	public void setQuestionNoteOne(String questionNoteOne) {
		_questionNoteOne = questionNoteOne;
	}

	public String getQuestionNoteTwo() {
		return _questionNoteTwo;
	}

	public void setQuestionNoteTwo(String questionNoteTwo) {
		_questionNoteTwo = questionNoteTwo;
	}

	public String getQuestionNoteThree() {
		return _questionNoteThree;
	}

	public void setQuestionNoteThree(String questionNoteThree) {
		_questionNoteThree = questionNoteThree;
	}

	public String getQuestionNoteFour() {
		return _questionNoteFour;
	}

	public void setQuestionNoteFour(String questionNoteFour) {
		_questionNoteFour = questionNoteFour;
	}

	public String getQuestionNoteFive() {
		return _questionNoteFive;
	}

	public void setQuestionNoteFive(String questionNoteFive) {
		_questionNoteFive = questionNoteFive;
	}

	public String getQuestionNoteSix() {
		return _questionNoteSix;
	}

	public void setQuestionNoteSix(String questionNoteSix) {
		_questionNoteSix = questionNoteSix;
	}

	public String getQuestionNoteSeven() {
		return _questionNoteSeven;
	}

	public void setQuestionNoteSeven(String questionNoteSeven) {
		_questionNoteSeven = questionNoteSeven;
	}

	public String getQuestionVehicalOne() {
		return _questionVehicalOne;
	}

	public void setQuestionVehicalOne(String questionVehicalOne) {
		_questionVehicalOne = questionVehicalOne;
	}

	public String getQuestionVehicalTwo() {
		return _questionVehicalTwo;
	}

	public void setQuestionVehicalTwo(String questionVehicalTwo) {
		_questionVehicalTwo = questionVehicalTwo;
	}

	public String getQuestionVehicalThree() {
		return _questionVehicalThree;
	}

	public void setQuestionVehicalThree(String questionVehicalThree) {
		_questionVehicalThree = questionVehicalThree;
	}

	public String getQuestionVehicalFour() {
		return _questionVehicalFour;
	}

	public void setQuestionVehicalFour(String questionVehicalFour) {
		_questionVehicalFour = questionVehicalFour;
	}

	public String getQuestionVehicalFive() {
		return _questionVehicalFive;
	}

	public void setQuestionVehicalFive(String questionVehicalFive) {
		_questionVehicalFive = questionVehicalFive;
	}

	public String getQuestionVehicalSix() {
		return _questionVehicalSix;
	}

	public void setQuestionVehicalSix(String questionVehicalSix) {
		_questionVehicalSix = questionVehicalSix;
	}

	public String getQuestionVehicalSeven() {
		return _questionVehicalSeven;
	}

	public void setQuestionVehicalSeven(String questionVehicalSeven) {
		_questionVehicalSeven = questionVehicalSeven;
	}

	public String getQuestionVehicalNoteOne() {
		return _questionVehicalNoteOne;
	}

	public void setQuestionVehicalNoteOne(String questionVehicalNoteOne) {
		_questionVehicalNoteOne = questionVehicalNoteOne;
	}

	public String getQuestionVehicalNoteTwo() {
		return _questionVehicalNoteTwo;
	}

	public void setQuestionVehicalNoteTwo(String questionVehicalNoteTwo) {
		_questionVehicalNoteTwo = questionVehicalNoteTwo;
	}

	public String getQuestionVehicalNoteThree() {
		return _questionVehicalNoteThree;
	}

	public void setQuestionVehicalNoteThree(String questionVehicalNoteThree) {
		_questionVehicalNoteThree = questionVehicalNoteThree;
	}

	public String getQuestionVehicalNoteFour() {
		return _questionVehicalNoteFour;
	}

	public void setQuestionVehicalNoteFour(String questionVehicalNoteFour) {
		_questionVehicalNoteFour = questionVehicalNoteFour;
	}

	public String getQuestionVehicalNoteFive() {
		return _questionVehicalNoteFive;
	}

	public void setQuestionVehicalNoteFive(String questionVehicalNoteFive) {
		_questionVehicalNoteFive = questionVehicalNoteFive;
	}

	public String getQuestionVehicalNoteSix() {
		return _questionVehicalNoteSix;
	}

	public void setQuestionVehicalNoteSix(String questionVehicalNoteSix) {
		_questionVehicalNoteSix = questionVehicalNoteSix;
	}

	public String getQuestionVehicalNoteSeven() {
		return _questionVehicalNoteSeven;
	}

	public void setQuestionVehicalNoteSeven(String questionVehicalNoteSeven) {
		_questionVehicalNoteSeven = questionVehicalNoteSeven;
	}

	public String getQuestionManageOne() {
		return _questionManageOne;
	}

	public void setQuestionManageOne(String questionManageOne) {
		_questionManageOne = questionManageOne;
	}

	public String getQuestionManageTwo() {
		return _questionManageTwo;
	}

	public void setQuestionManageTwo(String questionManageTwo) {
		_questionManageTwo = questionManageTwo;
	}

	public String getQuestionManageThree() {
		return _questionManageThree;
	}

	public void setQuestionManageThree(String questionManageThree) {
		_questionManageThree = questionManageThree;
	}

	public String getQuestionManageFour() {
		return _questionManageFour;
	}

	public void setQuestionManageFour(String questionManageFour) {
		_questionManageFour = questionManageFour;
	}

	public String getQuestionManageFive() {
		return _questionManageFive;
	}

	public void setQuestionManageFive(String questionManageFive) {
		_questionManageFive = questionManageFive;
	}

	public String getQuestionManageSix() {
		return _questionManageSix;
	}

	public void setQuestionManageSix(String questionManageSix) {
		_questionManageSix = questionManageSix;
	}

	public String getQuestionManageSeven() {
		return _questionManageSeven;
	}

	public void setQuestionManageSeven(String questionManageSeven) {
		_questionManageSeven = questionManageSeven;
	}

	public String getQuestionManageNoteOne() {
		return _questionManageNoteOne;
	}

	public void setQuestionManageNoteOne(String questionManageNoteOne) {
		_questionManageNoteOne = questionManageNoteOne;
	}

	public String getQuestionManageNoteTwo() {
		return _questionManageNoteTwo;
	}

	public void setQuestionManageNoteTwo(String questionManageNoteTwo) {
		_questionManageNoteTwo = questionManageNoteTwo;
	}

	public String getQuestionManageNoteThree() {
		return _questionManageNoteThree;
	}

	public void setQuestionManageNoteThree(String questionManageNoteThree) {
		_questionManageNoteThree = questionManageNoteThree;
	}

	public String getQuestionManageNoteFour() {
		return _questionManageNoteFour;
	}

	public void setQuestionManageNoteFour(String questionManageNoteFour) {
		_questionManageNoteFour = questionManageNoteFour;
	}

	public String getQuestionManageNoteFive() {
		return _questionManageNoteFive;
	}

	public void setQuestionManageNoteFive(String questionManageNoteFive) {
		_questionManageNoteFive = questionManageNoteFive;
	}

	public String getQuestionManageNoteSix() {
		return _questionManageNoteSix;
	}

	public void setQuestionManageNoteSix(String questionManageNoteSix) {
		_questionManageNoteSix = questionManageNoteSix;
	}

	public String getQuestionRecordsOne() {
		return _questionRecordsOne;
	}

	public void setQuestionRecordsOne(String questionRecordsOne) {
		_questionRecordsOne = questionRecordsOne;
	}

	public String getQuestionRecordsTwo() {
		return _questionRecordsTwo;
	}

	public void setQuestionRecordsTwo(String questionRecordsTwo) {
		_questionRecordsTwo = questionRecordsTwo;
	}

	public String getQuestionRecordsThree() {
		return _questionRecordsThree;
	}

	public void setQuestionRecordsThree(String questionRecordsThree) {
		_questionRecordsThree = questionRecordsThree;
	}

	public String getQuestionRecordsNoteOne() {
		return _questionRecordsNoteOne;
	}

	public void setQuestionRecordsNoteOne(String questionRecordsNoteOne) {
		_questionRecordsNoteOne = questionRecordsNoteOne;
	}

	public String getQuestionRecordsNoteTwo() {
		return _questionRecordsNoteTwo;
	}

	public void setQuestionRecordsNoteTwo(String questionRecordsNoteTwo) {
		_questionRecordsNoteTwo = questionRecordsNoteTwo;
	}

	public String getQuestionRecordsNoteThree() {
		return _questionRecordsNoteThree;
	}

	public void setQuestionRecordsNoteThree(String questionRecordsNoteThree) {
		_questionRecordsNoteThree = questionRecordsNoteThree;
	}

	public String getQuestionReskOne() {
		return _questionReskOne;
	}

	public void setQuestionReskOne(String questionReskOne) {
		_questionReskOne = questionReskOne;
	}

	public String getQuestionReskTwo() {
		return _questionReskTwo;
	}

	public void setQuestionReskTwo(String questionReskTwo) {
		_questionReskTwo = questionReskTwo;
	}

	public String getQuestionReskThree() {
		return _questionReskThree;
	}

	public void setQuestionReskThree(String questionReskThree) {
		_questionReskThree = questionReskThree;
	}

	public String getQuestionReskFour() {
		return _questionReskFour;
	}

	public void setQuestionReskFour(String questionReskFour) {
		_questionReskFour = questionReskFour;
	}

	public String getQuestionReskFive() {
		return _questionReskFive;
	}

	public void setQuestionReskFive(String questionReskFive) {
		_questionReskFive = questionReskFive;
	}

	public String getQuestionReskSix() {
		return _questionReskSix;
	}

	public void setQuestionReskSix(String questionReskSix) {
		_questionReskSix = questionReskSix;
	}

	public String getQuestionReskSeven() {
		return _questionReskSeven;
	}

	public void setQuestionReskSeven(String questionReskSeven) {
		_questionReskSeven = questionReskSeven;
	}

	public String getQuestionReskEight() {
		return _questionReskEight;
	}

	public void setQuestionReskEight(String questionReskEight) {
		_questionReskEight = questionReskEight;
	}

	public String getQuestionReskNoteOne() {
		return _questionReskNoteOne;
	}

	public void setQuestionReskNoteOne(String questionReskNoteOne) {
		_questionReskNoteOne = questionReskNoteOne;
	}

	public String getQuestionReskNoteTwo() {
		return _questionReskNoteTwo;
	}

	public void setQuestionReskNoteTwo(String questionReskNoteTwo) {
		_questionReskNoteTwo = questionReskNoteTwo;
	}

	public String getQuestionReskNoteThree() {
		return _questionReskNoteThree;
	}

	public void setQuestionReskNoteThree(String questionReskNoteThree) {
		_questionReskNoteThree = questionReskNoteThree;
	}

	public String getQuestionReskNoteFour() {
		return _questionReskNoteFour;
	}

	public void setQuestionReskNoteFour(String questionReskNoteFour) {
		_questionReskNoteFour = questionReskNoteFour;
	}

	public String getQuestionReskNoteFive() {
		return _questionReskNoteFive;
	}

	public void setQuestionReskNoteFive(String questionReskNoteFive) {
		_questionReskNoteFive = questionReskNoteFive;
	}

	public String getQuestionReskNoteSix() {
		return _questionReskNoteSix;
	}

	public void setQuestionReskNoteSix(String questionReskNoteSix) {
		_questionReskNoteSix = questionReskNoteSix;
	}

	public String getQuestionReskNoteSeven() {
		return _questionReskNoteSeven;
	}

	public void setQuestionReskNoteSeven(String questionReskNoteSeven) {
		_questionReskNoteSeven = questionReskNoteSeven;
	}

	public String getQuestionReskNoteEight() {
		return _questionReskNoteEight;
	}

	public void setQuestionReskNoteEight(String questionReskNoteEight) {
		_questionReskNoteEight = questionReskNoteEight;
	}

	public String getNotcomplied() {
		return _notcomplied;
	}

	public void setNotcomplied(String notcomplied) {
		_notcomplied = notcomplied;
	}

	public String getRecord() {
		return _record;
	}

	public void setRecord(String record) {
		_record = record;
	}

	private long _compilanceCheckid;
	private long _aditid;
	private String _company;
	private String _audidate;
	private String _completedStatus;
	private String _auditPercentage;
	private String _questionSafetyOne;
	private String _questionSafetyTwo;
	private String _questionSafetyThree;
	private String _questionSafetFour;
	private String _questionSafetFive;
	private String _questionSafetSix;
	private String _questionSafetySeven;
	private String _questionNoteOne;
	private String _questionNoteTwo;
	private String _questionNoteThree;
	private String _questionNoteFour;
	private String _questionNoteFive;
	private String _questionNoteSix;
	private String _questionNoteSeven;
	private String _questionVehicalOne;
	private String _questionVehicalTwo;
	private String _questionVehicalThree;
	private String _questionVehicalFour;
	private String _questionVehicalFive;
	private String _questionVehicalSix;
	private String _questionVehicalSeven;
	private String _questionVehicalNoteOne;
	private String _questionVehicalNoteTwo;
	private String _questionVehicalNoteThree;
	private String _questionVehicalNoteFour;
	private String _questionVehicalNoteFive;
	private String _questionVehicalNoteSix;
	private String _questionVehicalNoteSeven;
	private String _questionManageOne;
	private String _questionManageTwo;
	private String _questionManageThree;
	private String _questionManageFour;
	private String _questionManageFive;
	private String _questionManageSix;
	private String _questionManageSeven;
	private String _questionManageNoteOne;
	private String _questionManageNoteTwo;
	private String _questionManageNoteThree;
	private String _questionManageNoteFour;
	private String _questionManageNoteFive;
	private String _questionManageNoteSix;
	private String _questionRecordsOne;
	private String _questionRecordsTwo;
	private String _questionRecordsThree;
	private String _questionRecordsNoteOne;
	private String _questionRecordsNoteTwo;
	private String _questionRecordsNoteThree;
	private String _questionReskOne;
	private String _questionReskTwo;
	private String _questionReskThree;
	private String _questionReskFour;
	private String _questionReskFive;
	private String _questionReskSix;
	private String _questionReskSeven;
	private String _questionReskEight;
	private String _questionReskNoteOne;
	private String _questionReskNoteTwo;
	private String _questionReskNoteThree;
	private String _questionReskNoteFour;
	private String _questionReskNoteFive;
	private String _questionReskNoteSix;
	private String _questionReskNoteSeven;
	private String _questionReskNoteEight;
	private String _notcomplied;
	private String _record;
}