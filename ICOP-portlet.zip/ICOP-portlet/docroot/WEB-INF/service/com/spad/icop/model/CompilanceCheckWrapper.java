/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link CompilanceCheck}.
 * </p>
 *
 * @author reeshu
 * @see CompilanceCheck
 * @generated
 */
public class CompilanceCheckWrapper implements CompilanceCheck,
	ModelWrapper<CompilanceCheck> {
	public CompilanceCheckWrapper(CompilanceCheck compilanceCheck) {
		_compilanceCheck = compilanceCheck;
	}

	@Override
	public Class<?> getModelClass() {
		return CompilanceCheck.class;
	}

	@Override
	public String getModelClassName() {
		return CompilanceCheck.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("compilanceCheckid", getCompilanceCheckid());
		attributes.put("aditid", getAditid());
		attributes.put("company", getCompany());
		attributes.put("audidate", getAudidate());
		attributes.put("completedStatus", getCompletedStatus());
		attributes.put("auditPercentage", getAuditPercentage());
		attributes.put("questionSafetyOne", getQuestionSafetyOne());
		attributes.put("questionSafetyTwo", getQuestionSafetyTwo());
		attributes.put("questionSafetyThree", getQuestionSafetyThree());
		attributes.put("questionSafetFour", getQuestionSafetFour());
		attributes.put("questionSafetFive", getQuestionSafetFive());
		attributes.put("questionSafetSix", getQuestionSafetSix());
		attributes.put("questionSafetySeven", getQuestionSafetySeven());
		attributes.put("questionNoteOne", getQuestionNoteOne());
		attributes.put("questionNoteTwo", getQuestionNoteTwo());
		attributes.put("questionNoteThree", getQuestionNoteThree());
		attributes.put("questionNoteFour", getQuestionNoteFour());
		attributes.put("questionNoteFive", getQuestionNoteFive());
		attributes.put("questionNoteSix", getQuestionNoteSix());
		attributes.put("questionNoteSeven", getQuestionNoteSeven());
		attributes.put("questionVehicalOne", getQuestionVehicalOne());
		attributes.put("questionVehicalTwo", getQuestionVehicalTwo());
		attributes.put("questionVehicalThree", getQuestionVehicalThree());
		attributes.put("questionVehicalFour", getQuestionVehicalFour());
		attributes.put("questionVehicalFive", getQuestionVehicalFive());
		attributes.put("questionVehicalSix", getQuestionVehicalSix());
		attributes.put("questionVehicalSeven", getQuestionVehicalSeven());
		attributes.put("questionVehicalNoteOne", getQuestionVehicalNoteOne());
		attributes.put("questionVehicalNoteTwo", getQuestionVehicalNoteTwo());
		attributes.put("questionVehicalNoteThree", getQuestionVehicalNoteThree());
		attributes.put("questionVehicalNoteFour", getQuestionVehicalNoteFour());
		attributes.put("questionVehicalNoteFive", getQuestionVehicalNoteFive());
		attributes.put("questionVehicalNoteSix", getQuestionVehicalNoteSix());
		attributes.put("questionVehicalNoteSeven", getQuestionVehicalNoteSeven());
		attributes.put("questionManageOne", getQuestionManageOne());
		attributes.put("questionManageTwo", getQuestionManageTwo());
		attributes.put("questionManageThree", getQuestionManageThree());
		attributes.put("questionManageFour", getQuestionManageFour());
		attributes.put("questionManageFive", getQuestionManageFive());
		attributes.put("questionManageSix", getQuestionManageSix());
		attributes.put("questionManageSeven", getQuestionManageSeven());
		attributes.put("questionManageNoteOne", getQuestionManageNoteOne());
		attributes.put("questionManageNoteTwo", getQuestionManageNoteTwo());
		attributes.put("questionManageNoteThree", getQuestionManageNoteThree());
		attributes.put("questionManageNoteFour", getQuestionManageNoteFour());
		attributes.put("questionManageNoteFive", getQuestionManageNoteFive());
		attributes.put("questionManageNoteSix", getQuestionManageNoteSix());
		attributes.put("questionRecordsOne", getQuestionRecordsOne());
		attributes.put("questionRecordsTwo", getQuestionRecordsTwo());
		attributes.put("questionRecordsThree", getQuestionRecordsThree());
		attributes.put("questionRecordsNoteOne", getQuestionRecordsNoteOne());
		attributes.put("questionRecordsNoteTwo", getQuestionRecordsNoteTwo());
		attributes.put("questionRecordsNoteThree", getQuestionRecordsNoteThree());
		attributes.put("questionReskOne", getQuestionReskOne());
		attributes.put("questionReskTwo", getQuestionReskTwo());
		attributes.put("questionReskThree", getQuestionReskThree());
		attributes.put("questionReskFour", getQuestionReskFour());
		attributes.put("questionReskFive", getQuestionReskFive());
		attributes.put("questionReskSix", getQuestionReskSix());
		attributes.put("questionReskSeven", getQuestionReskSeven());
		attributes.put("questionReskEight", getQuestionReskEight());
		attributes.put("questionReskNoteOne", getQuestionReskNoteOne());
		attributes.put("questionReskNoteTwo", getQuestionReskNoteTwo());
		attributes.put("questionReskNoteThree", getQuestionReskNoteThree());
		attributes.put("questionReskNoteFour", getQuestionReskNoteFour());
		attributes.put("questionReskNoteFive", getQuestionReskNoteFive());
		attributes.put("questionReskNoteSix", getQuestionReskNoteSix());
		attributes.put("questionReskNoteSeven", getQuestionReskNoteSeven());
		attributes.put("questionReskNoteEight", getQuestionReskNoteEight());
		attributes.put("notcomplied", getNotcomplied());
		attributes.put("record", getRecord());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long compilanceCheckid = (Long)attributes.get("compilanceCheckid");

		if (compilanceCheckid != null) {
			setCompilanceCheckid(compilanceCheckid);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String audidate = (String)attributes.get("audidate");

		if (audidate != null) {
			setAudidate(audidate);
		}

		String completedStatus = (String)attributes.get("completedStatus");

		if (completedStatus != null) {
			setCompletedStatus(completedStatus);
		}

		String auditPercentage = (String)attributes.get("auditPercentage");

		if (auditPercentage != null) {
			setAuditPercentage(auditPercentage);
		}

		String questionSafetyOne = (String)attributes.get("questionSafetyOne");

		if (questionSafetyOne != null) {
			setQuestionSafetyOne(questionSafetyOne);
		}

		String questionSafetyTwo = (String)attributes.get("questionSafetyTwo");

		if (questionSafetyTwo != null) {
			setQuestionSafetyTwo(questionSafetyTwo);
		}

		String questionSafetyThree = (String)attributes.get(
				"questionSafetyThree");

		if (questionSafetyThree != null) {
			setQuestionSafetyThree(questionSafetyThree);
		}

		String questionSafetFour = (String)attributes.get("questionSafetFour");

		if (questionSafetFour != null) {
			setQuestionSafetFour(questionSafetFour);
		}

		String questionSafetFive = (String)attributes.get("questionSafetFive");

		if (questionSafetFive != null) {
			setQuestionSafetFive(questionSafetFive);
		}

		String questionSafetSix = (String)attributes.get("questionSafetSix");

		if (questionSafetSix != null) {
			setQuestionSafetSix(questionSafetSix);
		}

		String questionSafetySeven = (String)attributes.get(
				"questionSafetySeven");

		if (questionSafetySeven != null) {
			setQuestionSafetySeven(questionSafetySeven);
		}

		String questionNoteOne = (String)attributes.get("questionNoteOne");

		if (questionNoteOne != null) {
			setQuestionNoteOne(questionNoteOne);
		}

		String questionNoteTwo = (String)attributes.get("questionNoteTwo");

		if (questionNoteTwo != null) {
			setQuestionNoteTwo(questionNoteTwo);
		}

		String questionNoteThree = (String)attributes.get("questionNoteThree");

		if (questionNoteThree != null) {
			setQuestionNoteThree(questionNoteThree);
		}

		String questionNoteFour = (String)attributes.get("questionNoteFour");

		if (questionNoteFour != null) {
			setQuestionNoteFour(questionNoteFour);
		}

		String questionNoteFive = (String)attributes.get("questionNoteFive");

		if (questionNoteFive != null) {
			setQuestionNoteFive(questionNoteFive);
		}

		String questionNoteSix = (String)attributes.get("questionNoteSix");

		if (questionNoteSix != null) {
			setQuestionNoteSix(questionNoteSix);
		}

		String questionNoteSeven = (String)attributes.get("questionNoteSeven");

		if (questionNoteSeven != null) {
			setQuestionNoteSeven(questionNoteSeven);
		}

		String questionVehicalOne = (String)attributes.get("questionVehicalOne");

		if (questionVehicalOne != null) {
			setQuestionVehicalOne(questionVehicalOne);
		}

		String questionVehicalTwo = (String)attributes.get("questionVehicalTwo");

		if (questionVehicalTwo != null) {
			setQuestionVehicalTwo(questionVehicalTwo);
		}

		String questionVehicalThree = (String)attributes.get(
				"questionVehicalThree");

		if (questionVehicalThree != null) {
			setQuestionVehicalThree(questionVehicalThree);
		}

		String questionVehicalFour = (String)attributes.get(
				"questionVehicalFour");

		if (questionVehicalFour != null) {
			setQuestionVehicalFour(questionVehicalFour);
		}

		String questionVehicalFive = (String)attributes.get(
				"questionVehicalFive");

		if (questionVehicalFive != null) {
			setQuestionVehicalFive(questionVehicalFive);
		}

		String questionVehicalSix = (String)attributes.get("questionVehicalSix");

		if (questionVehicalSix != null) {
			setQuestionVehicalSix(questionVehicalSix);
		}

		String questionVehicalSeven = (String)attributes.get(
				"questionVehicalSeven");

		if (questionVehicalSeven != null) {
			setQuestionVehicalSeven(questionVehicalSeven);
		}

		String questionVehicalNoteOne = (String)attributes.get(
				"questionVehicalNoteOne");

		if (questionVehicalNoteOne != null) {
			setQuestionVehicalNoteOne(questionVehicalNoteOne);
		}

		String questionVehicalNoteTwo = (String)attributes.get(
				"questionVehicalNoteTwo");

		if (questionVehicalNoteTwo != null) {
			setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
		}

		String questionVehicalNoteThree = (String)attributes.get(
				"questionVehicalNoteThree");

		if (questionVehicalNoteThree != null) {
			setQuestionVehicalNoteThree(questionVehicalNoteThree);
		}

		String questionVehicalNoteFour = (String)attributes.get(
				"questionVehicalNoteFour");

		if (questionVehicalNoteFour != null) {
			setQuestionVehicalNoteFour(questionVehicalNoteFour);
		}

		String questionVehicalNoteFive = (String)attributes.get(
				"questionVehicalNoteFive");

		if (questionVehicalNoteFive != null) {
			setQuestionVehicalNoteFive(questionVehicalNoteFive);
		}

		String questionVehicalNoteSix = (String)attributes.get(
				"questionVehicalNoteSix");

		if (questionVehicalNoteSix != null) {
			setQuestionVehicalNoteSix(questionVehicalNoteSix);
		}

		String questionVehicalNoteSeven = (String)attributes.get(
				"questionVehicalNoteSeven");

		if (questionVehicalNoteSeven != null) {
			setQuestionVehicalNoteSeven(questionVehicalNoteSeven);
		}

		String questionManageOne = (String)attributes.get("questionManageOne");

		if (questionManageOne != null) {
			setQuestionManageOne(questionManageOne);
		}

		String questionManageTwo = (String)attributes.get("questionManageTwo");

		if (questionManageTwo != null) {
			setQuestionManageTwo(questionManageTwo);
		}

		String questionManageThree = (String)attributes.get(
				"questionManageThree");

		if (questionManageThree != null) {
			setQuestionManageThree(questionManageThree);
		}

		String questionManageFour = (String)attributes.get("questionManageFour");

		if (questionManageFour != null) {
			setQuestionManageFour(questionManageFour);
		}

		String questionManageFive = (String)attributes.get("questionManageFive");

		if (questionManageFive != null) {
			setQuestionManageFive(questionManageFive);
		}

		String questionManageSix = (String)attributes.get("questionManageSix");

		if (questionManageSix != null) {
			setQuestionManageSix(questionManageSix);
		}

		String questionManageSeven = (String)attributes.get(
				"questionManageSeven");

		if (questionManageSeven != null) {
			setQuestionManageSeven(questionManageSeven);
		}

		String questionManageNoteOne = (String)attributes.get(
				"questionManageNoteOne");

		if (questionManageNoteOne != null) {
			setQuestionManageNoteOne(questionManageNoteOne);
		}

		String questionManageNoteTwo = (String)attributes.get(
				"questionManageNoteTwo");

		if (questionManageNoteTwo != null) {
			setQuestionManageNoteTwo(questionManageNoteTwo);
		}

		String questionManageNoteThree = (String)attributes.get(
				"questionManageNoteThree");

		if (questionManageNoteThree != null) {
			setQuestionManageNoteThree(questionManageNoteThree);
		}

		String questionManageNoteFour = (String)attributes.get(
				"questionManageNoteFour");

		if (questionManageNoteFour != null) {
			setQuestionManageNoteFour(questionManageNoteFour);
		}

		String questionManageNoteFive = (String)attributes.get(
				"questionManageNoteFive");

		if (questionManageNoteFive != null) {
			setQuestionManageNoteFive(questionManageNoteFive);
		}

		String questionManageNoteSix = (String)attributes.get(
				"questionManageNoteSix");

		if (questionManageNoteSix != null) {
			setQuestionManageNoteSix(questionManageNoteSix);
		}

		String questionRecordsOne = (String)attributes.get("questionRecordsOne");

		if (questionRecordsOne != null) {
			setQuestionRecordsOne(questionRecordsOne);
		}

		String questionRecordsTwo = (String)attributes.get("questionRecordsTwo");

		if (questionRecordsTwo != null) {
			setQuestionRecordsTwo(questionRecordsTwo);
		}

		String questionRecordsThree = (String)attributes.get(
				"questionRecordsThree");

		if (questionRecordsThree != null) {
			setQuestionRecordsThree(questionRecordsThree);
		}

		String questionRecordsNoteOne = (String)attributes.get(
				"questionRecordsNoteOne");

		if (questionRecordsNoteOne != null) {
			setQuestionRecordsNoteOne(questionRecordsNoteOne);
		}

		String questionRecordsNoteTwo = (String)attributes.get(
				"questionRecordsNoteTwo");

		if (questionRecordsNoteTwo != null) {
			setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
		}

		String questionRecordsNoteThree = (String)attributes.get(
				"questionRecordsNoteThree");

		if (questionRecordsNoteThree != null) {
			setQuestionRecordsNoteThree(questionRecordsNoteThree);
		}

		String questionReskOne = (String)attributes.get("questionReskOne");

		if (questionReskOne != null) {
			setQuestionReskOne(questionReskOne);
		}

		String questionReskTwo = (String)attributes.get("questionReskTwo");

		if (questionReskTwo != null) {
			setQuestionReskTwo(questionReskTwo);
		}

		String questionReskThree = (String)attributes.get("questionReskThree");

		if (questionReskThree != null) {
			setQuestionReskThree(questionReskThree);
		}

		String questionReskFour = (String)attributes.get("questionReskFour");

		if (questionReskFour != null) {
			setQuestionReskFour(questionReskFour);
		}

		String questionReskFive = (String)attributes.get("questionReskFive");

		if (questionReskFive != null) {
			setQuestionReskFive(questionReskFive);
		}

		String questionReskSix = (String)attributes.get("questionReskSix");

		if (questionReskSix != null) {
			setQuestionReskSix(questionReskSix);
		}

		String questionReskSeven = (String)attributes.get("questionReskSeven");

		if (questionReskSeven != null) {
			setQuestionReskSeven(questionReskSeven);
		}

		String questionReskEight = (String)attributes.get("questionReskEight");

		if (questionReskEight != null) {
			setQuestionReskEight(questionReskEight);
		}

		String questionReskNoteOne = (String)attributes.get(
				"questionReskNoteOne");

		if (questionReskNoteOne != null) {
			setQuestionReskNoteOne(questionReskNoteOne);
		}

		String questionReskNoteTwo = (String)attributes.get(
				"questionReskNoteTwo");

		if (questionReskNoteTwo != null) {
			setQuestionReskNoteTwo(questionReskNoteTwo);
		}

		String questionReskNoteThree = (String)attributes.get(
				"questionReskNoteThree");

		if (questionReskNoteThree != null) {
			setQuestionReskNoteThree(questionReskNoteThree);
		}

		String questionReskNoteFour = (String)attributes.get(
				"questionReskNoteFour");

		if (questionReskNoteFour != null) {
			setQuestionReskNoteFour(questionReskNoteFour);
		}

		String questionReskNoteFive = (String)attributes.get(
				"questionReskNoteFive");

		if (questionReskNoteFive != null) {
			setQuestionReskNoteFive(questionReskNoteFive);
		}

		String questionReskNoteSix = (String)attributes.get(
				"questionReskNoteSix");

		if (questionReskNoteSix != null) {
			setQuestionReskNoteSix(questionReskNoteSix);
		}

		String questionReskNoteSeven = (String)attributes.get(
				"questionReskNoteSeven");

		if (questionReskNoteSeven != null) {
			setQuestionReskNoteSeven(questionReskNoteSeven);
		}

		String questionReskNoteEight = (String)attributes.get(
				"questionReskNoteEight");

		if (questionReskNoteEight != null) {
			setQuestionReskNoteEight(questionReskNoteEight);
		}

		String notcomplied = (String)attributes.get("notcomplied");

		if (notcomplied != null) {
			setNotcomplied(notcomplied);
		}

		String record = (String)attributes.get("record");

		if (record != null) {
			setRecord(record);
		}
	}

	/**
	* Returns the primary key of this compilance check.
	*
	* @return the primary key of this compilance check
	*/
	@Override
	public long getPrimaryKey() {
		return _compilanceCheck.getPrimaryKey();
	}

	/**
	* Sets the primary key of this compilance check.
	*
	* @param primaryKey the primary key of this compilance check
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_compilanceCheck.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the compilance checkid of this compilance check.
	*
	* @return the compilance checkid of this compilance check
	*/
	@Override
	public long getCompilanceCheckid() {
		return _compilanceCheck.getCompilanceCheckid();
	}

	/**
	* Sets the compilance checkid of this compilance check.
	*
	* @param compilanceCheckid the compilance checkid of this compilance check
	*/
	@Override
	public void setCompilanceCheckid(long compilanceCheckid) {
		_compilanceCheck.setCompilanceCheckid(compilanceCheckid);
	}

	/**
	* Returns the aditid of this compilance check.
	*
	* @return the aditid of this compilance check
	*/
	@Override
	public long getAditid() {
		return _compilanceCheck.getAditid();
	}

	/**
	* Sets the aditid of this compilance check.
	*
	* @param aditid the aditid of this compilance check
	*/
	@Override
	public void setAditid(long aditid) {
		_compilanceCheck.setAditid(aditid);
	}

	/**
	* Returns the company of this compilance check.
	*
	* @return the company of this compilance check
	*/
	@Override
	public java.lang.String getCompany() {
		return _compilanceCheck.getCompany();
	}

	/**
	* Sets the company of this compilance check.
	*
	* @param company the company of this compilance check
	*/
	@Override
	public void setCompany(java.lang.String company) {
		_compilanceCheck.setCompany(company);
	}

	/**
	* Returns the audidate of this compilance check.
	*
	* @return the audidate of this compilance check
	*/
	@Override
	public java.lang.String getAudidate() {
		return _compilanceCheck.getAudidate();
	}

	/**
	* Sets the audidate of this compilance check.
	*
	* @param audidate the audidate of this compilance check
	*/
	@Override
	public void setAudidate(java.lang.String audidate) {
		_compilanceCheck.setAudidate(audidate);
	}

	/**
	* Returns the completed status of this compilance check.
	*
	* @return the completed status of this compilance check
	*/
	@Override
	public java.lang.String getCompletedStatus() {
		return _compilanceCheck.getCompletedStatus();
	}

	/**
	* Sets the completed status of this compilance check.
	*
	* @param completedStatus the completed status of this compilance check
	*/
	@Override
	public void setCompletedStatus(java.lang.String completedStatus) {
		_compilanceCheck.setCompletedStatus(completedStatus);
	}

	/**
	* Returns the audit percentage of this compilance check.
	*
	* @return the audit percentage of this compilance check
	*/
	@Override
	public java.lang.String getAuditPercentage() {
		return _compilanceCheck.getAuditPercentage();
	}

	/**
	* Sets the audit percentage of this compilance check.
	*
	* @param auditPercentage the audit percentage of this compilance check
	*/
	@Override
	public void setAuditPercentage(java.lang.String auditPercentage) {
		_compilanceCheck.setAuditPercentage(auditPercentage);
	}

	/**
	* Returns the question safety one of this compilance check.
	*
	* @return the question safety one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetyOne() {
		return _compilanceCheck.getQuestionSafetyOne();
	}

	/**
	* Sets the question safety one of this compilance check.
	*
	* @param questionSafetyOne the question safety one of this compilance check
	*/
	@Override
	public void setQuestionSafetyOne(java.lang.String questionSafetyOne) {
		_compilanceCheck.setQuestionSafetyOne(questionSafetyOne);
	}

	/**
	* Returns the question safety two of this compilance check.
	*
	* @return the question safety two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetyTwo() {
		return _compilanceCheck.getQuestionSafetyTwo();
	}

	/**
	* Sets the question safety two of this compilance check.
	*
	* @param questionSafetyTwo the question safety two of this compilance check
	*/
	@Override
	public void setQuestionSafetyTwo(java.lang.String questionSafetyTwo) {
		_compilanceCheck.setQuestionSafetyTwo(questionSafetyTwo);
	}

	/**
	* Returns the question safety three of this compilance check.
	*
	* @return the question safety three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetyThree() {
		return _compilanceCheck.getQuestionSafetyThree();
	}

	/**
	* Sets the question safety three of this compilance check.
	*
	* @param questionSafetyThree the question safety three of this compilance check
	*/
	@Override
	public void setQuestionSafetyThree(java.lang.String questionSafetyThree) {
		_compilanceCheck.setQuestionSafetyThree(questionSafetyThree);
	}

	/**
	* Returns the question safet four of this compilance check.
	*
	* @return the question safet four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetFour() {
		return _compilanceCheck.getQuestionSafetFour();
	}

	/**
	* Sets the question safet four of this compilance check.
	*
	* @param questionSafetFour the question safet four of this compilance check
	*/
	@Override
	public void setQuestionSafetFour(java.lang.String questionSafetFour) {
		_compilanceCheck.setQuestionSafetFour(questionSafetFour);
	}

	/**
	* Returns the question safet five of this compilance check.
	*
	* @return the question safet five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetFive() {
		return _compilanceCheck.getQuestionSafetFive();
	}

	/**
	* Sets the question safet five of this compilance check.
	*
	* @param questionSafetFive the question safet five of this compilance check
	*/
	@Override
	public void setQuestionSafetFive(java.lang.String questionSafetFive) {
		_compilanceCheck.setQuestionSafetFive(questionSafetFive);
	}

	/**
	* Returns the question safet six of this compilance check.
	*
	* @return the question safet six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetSix() {
		return _compilanceCheck.getQuestionSafetSix();
	}

	/**
	* Sets the question safet six of this compilance check.
	*
	* @param questionSafetSix the question safet six of this compilance check
	*/
	@Override
	public void setQuestionSafetSix(java.lang.String questionSafetSix) {
		_compilanceCheck.setQuestionSafetSix(questionSafetSix);
	}

	/**
	* Returns the question safety seven of this compilance check.
	*
	* @return the question safety seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionSafetySeven() {
		return _compilanceCheck.getQuestionSafetySeven();
	}

	/**
	* Sets the question safety seven of this compilance check.
	*
	* @param questionSafetySeven the question safety seven of this compilance check
	*/
	@Override
	public void setQuestionSafetySeven(java.lang.String questionSafetySeven) {
		_compilanceCheck.setQuestionSafetySeven(questionSafetySeven);
	}

	/**
	* Returns the question note one of this compilance check.
	*
	* @return the question note one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteOne() {
		return _compilanceCheck.getQuestionNoteOne();
	}

	/**
	* Sets the question note one of this compilance check.
	*
	* @param questionNoteOne the question note one of this compilance check
	*/
	@Override
	public void setQuestionNoteOne(java.lang.String questionNoteOne) {
		_compilanceCheck.setQuestionNoteOne(questionNoteOne);
	}

	/**
	* Returns the question note two of this compilance check.
	*
	* @return the question note two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteTwo() {
		return _compilanceCheck.getQuestionNoteTwo();
	}

	/**
	* Sets the question note two of this compilance check.
	*
	* @param questionNoteTwo the question note two of this compilance check
	*/
	@Override
	public void setQuestionNoteTwo(java.lang.String questionNoteTwo) {
		_compilanceCheck.setQuestionNoteTwo(questionNoteTwo);
	}

	/**
	* Returns the question note three of this compilance check.
	*
	* @return the question note three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteThree() {
		return _compilanceCheck.getQuestionNoteThree();
	}

	/**
	* Sets the question note three of this compilance check.
	*
	* @param questionNoteThree the question note three of this compilance check
	*/
	@Override
	public void setQuestionNoteThree(java.lang.String questionNoteThree) {
		_compilanceCheck.setQuestionNoteThree(questionNoteThree);
	}

	/**
	* Returns the question note four of this compilance check.
	*
	* @return the question note four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteFour() {
		return _compilanceCheck.getQuestionNoteFour();
	}

	/**
	* Sets the question note four of this compilance check.
	*
	* @param questionNoteFour the question note four of this compilance check
	*/
	@Override
	public void setQuestionNoteFour(java.lang.String questionNoteFour) {
		_compilanceCheck.setQuestionNoteFour(questionNoteFour);
	}

	/**
	* Returns the question note five of this compilance check.
	*
	* @return the question note five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteFive() {
		return _compilanceCheck.getQuestionNoteFive();
	}

	/**
	* Sets the question note five of this compilance check.
	*
	* @param questionNoteFive the question note five of this compilance check
	*/
	@Override
	public void setQuestionNoteFive(java.lang.String questionNoteFive) {
		_compilanceCheck.setQuestionNoteFive(questionNoteFive);
	}

	/**
	* Returns the question note six of this compilance check.
	*
	* @return the question note six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteSix() {
		return _compilanceCheck.getQuestionNoteSix();
	}

	/**
	* Sets the question note six of this compilance check.
	*
	* @param questionNoteSix the question note six of this compilance check
	*/
	@Override
	public void setQuestionNoteSix(java.lang.String questionNoteSix) {
		_compilanceCheck.setQuestionNoteSix(questionNoteSix);
	}

	/**
	* Returns the question note seven of this compilance check.
	*
	* @return the question note seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionNoteSeven() {
		return _compilanceCheck.getQuestionNoteSeven();
	}

	/**
	* Sets the question note seven of this compilance check.
	*
	* @param questionNoteSeven the question note seven of this compilance check
	*/
	@Override
	public void setQuestionNoteSeven(java.lang.String questionNoteSeven) {
		_compilanceCheck.setQuestionNoteSeven(questionNoteSeven);
	}

	/**
	* Returns the question vehical one of this compilance check.
	*
	* @return the question vehical one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalOne() {
		return _compilanceCheck.getQuestionVehicalOne();
	}

	/**
	* Sets the question vehical one of this compilance check.
	*
	* @param questionVehicalOne the question vehical one of this compilance check
	*/
	@Override
	public void setQuestionVehicalOne(java.lang.String questionVehicalOne) {
		_compilanceCheck.setQuestionVehicalOne(questionVehicalOne);
	}

	/**
	* Returns the question vehical two of this compilance check.
	*
	* @return the question vehical two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalTwo() {
		return _compilanceCheck.getQuestionVehicalTwo();
	}

	/**
	* Sets the question vehical two of this compilance check.
	*
	* @param questionVehicalTwo the question vehical two of this compilance check
	*/
	@Override
	public void setQuestionVehicalTwo(java.lang.String questionVehicalTwo) {
		_compilanceCheck.setQuestionVehicalTwo(questionVehicalTwo);
	}

	/**
	* Returns the question vehical three of this compilance check.
	*
	* @return the question vehical three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalThree() {
		return _compilanceCheck.getQuestionVehicalThree();
	}

	/**
	* Sets the question vehical three of this compilance check.
	*
	* @param questionVehicalThree the question vehical three of this compilance check
	*/
	@Override
	public void setQuestionVehicalThree(java.lang.String questionVehicalThree) {
		_compilanceCheck.setQuestionVehicalThree(questionVehicalThree);
	}

	/**
	* Returns the question vehical four of this compilance check.
	*
	* @return the question vehical four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalFour() {
		return _compilanceCheck.getQuestionVehicalFour();
	}

	/**
	* Sets the question vehical four of this compilance check.
	*
	* @param questionVehicalFour the question vehical four of this compilance check
	*/
	@Override
	public void setQuestionVehicalFour(java.lang.String questionVehicalFour) {
		_compilanceCheck.setQuestionVehicalFour(questionVehicalFour);
	}

	/**
	* Returns the question vehical five of this compilance check.
	*
	* @return the question vehical five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalFive() {
		return _compilanceCheck.getQuestionVehicalFive();
	}

	/**
	* Sets the question vehical five of this compilance check.
	*
	* @param questionVehicalFive the question vehical five of this compilance check
	*/
	@Override
	public void setQuestionVehicalFive(java.lang.String questionVehicalFive) {
		_compilanceCheck.setQuestionVehicalFive(questionVehicalFive);
	}

	/**
	* Returns the question vehical six of this compilance check.
	*
	* @return the question vehical six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalSix() {
		return _compilanceCheck.getQuestionVehicalSix();
	}

	/**
	* Sets the question vehical six of this compilance check.
	*
	* @param questionVehicalSix the question vehical six of this compilance check
	*/
	@Override
	public void setQuestionVehicalSix(java.lang.String questionVehicalSix) {
		_compilanceCheck.setQuestionVehicalSix(questionVehicalSix);
	}

	/**
	* Returns the question vehical seven of this compilance check.
	*
	* @return the question vehical seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalSeven() {
		return _compilanceCheck.getQuestionVehicalSeven();
	}

	/**
	* Sets the question vehical seven of this compilance check.
	*
	* @param questionVehicalSeven the question vehical seven of this compilance check
	*/
	@Override
	public void setQuestionVehicalSeven(java.lang.String questionVehicalSeven) {
		_compilanceCheck.setQuestionVehicalSeven(questionVehicalSeven);
	}

	/**
	* Returns the question vehical note one of this compilance check.
	*
	* @return the question vehical note one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteOne() {
		return _compilanceCheck.getQuestionVehicalNoteOne();
	}

	/**
	* Sets the question vehical note one of this compilance check.
	*
	* @param questionVehicalNoteOne the question vehical note one of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteOne(
		java.lang.String questionVehicalNoteOne) {
		_compilanceCheck.setQuestionVehicalNoteOne(questionVehicalNoteOne);
	}

	/**
	* Returns the question vehical note two of this compilance check.
	*
	* @return the question vehical note two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteTwo() {
		return _compilanceCheck.getQuestionVehicalNoteTwo();
	}

	/**
	* Sets the question vehical note two of this compilance check.
	*
	* @param questionVehicalNoteTwo the question vehical note two of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteTwo(
		java.lang.String questionVehicalNoteTwo) {
		_compilanceCheck.setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
	}

	/**
	* Returns the question vehical note three of this compilance check.
	*
	* @return the question vehical note three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteThree() {
		return _compilanceCheck.getQuestionVehicalNoteThree();
	}

	/**
	* Sets the question vehical note three of this compilance check.
	*
	* @param questionVehicalNoteThree the question vehical note three of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteThree(
		java.lang.String questionVehicalNoteThree) {
		_compilanceCheck.setQuestionVehicalNoteThree(questionVehicalNoteThree);
	}

	/**
	* Returns the question vehical note four of this compilance check.
	*
	* @return the question vehical note four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteFour() {
		return _compilanceCheck.getQuestionVehicalNoteFour();
	}

	/**
	* Sets the question vehical note four of this compilance check.
	*
	* @param questionVehicalNoteFour the question vehical note four of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteFour(
		java.lang.String questionVehicalNoteFour) {
		_compilanceCheck.setQuestionVehicalNoteFour(questionVehicalNoteFour);
	}

	/**
	* Returns the question vehical note five of this compilance check.
	*
	* @return the question vehical note five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteFive() {
		return _compilanceCheck.getQuestionVehicalNoteFive();
	}

	/**
	* Sets the question vehical note five of this compilance check.
	*
	* @param questionVehicalNoteFive the question vehical note five of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteFive(
		java.lang.String questionVehicalNoteFive) {
		_compilanceCheck.setQuestionVehicalNoteFive(questionVehicalNoteFive);
	}

	/**
	* Returns the question vehical note six of this compilance check.
	*
	* @return the question vehical note six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteSix() {
		return _compilanceCheck.getQuestionVehicalNoteSix();
	}

	/**
	* Sets the question vehical note six of this compilance check.
	*
	* @param questionVehicalNoteSix the question vehical note six of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteSix(
		java.lang.String questionVehicalNoteSix) {
		_compilanceCheck.setQuestionVehicalNoteSix(questionVehicalNoteSix);
	}

	/**
	* Returns the question vehical note seven of this compilance check.
	*
	* @return the question vehical note seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionVehicalNoteSeven() {
		return _compilanceCheck.getQuestionVehicalNoteSeven();
	}

	/**
	* Sets the question vehical note seven of this compilance check.
	*
	* @param questionVehicalNoteSeven the question vehical note seven of this compilance check
	*/
	@Override
	public void setQuestionVehicalNoteSeven(
		java.lang.String questionVehicalNoteSeven) {
		_compilanceCheck.setQuestionVehicalNoteSeven(questionVehicalNoteSeven);
	}

	/**
	* Returns the question manage one of this compilance check.
	*
	* @return the question manage one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageOne() {
		return _compilanceCheck.getQuestionManageOne();
	}

	/**
	* Sets the question manage one of this compilance check.
	*
	* @param questionManageOne the question manage one of this compilance check
	*/
	@Override
	public void setQuestionManageOne(java.lang.String questionManageOne) {
		_compilanceCheck.setQuestionManageOne(questionManageOne);
	}

	/**
	* Returns the question manage two of this compilance check.
	*
	* @return the question manage two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageTwo() {
		return _compilanceCheck.getQuestionManageTwo();
	}

	/**
	* Sets the question manage two of this compilance check.
	*
	* @param questionManageTwo the question manage two of this compilance check
	*/
	@Override
	public void setQuestionManageTwo(java.lang.String questionManageTwo) {
		_compilanceCheck.setQuestionManageTwo(questionManageTwo);
	}

	/**
	* Returns the question manage three of this compilance check.
	*
	* @return the question manage three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageThree() {
		return _compilanceCheck.getQuestionManageThree();
	}

	/**
	* Sets the question manage three of this compilance check.
	*
	* @param questionManageThree the question manage three of this compilance check
	*/
	@Override
	public void setQuestionManageThree(java.lang.String questionManageThree) {
		_compilanceCheck.setQuestionManageThree(questionManageThree);
	}

	/**
	* Returns the question manage four of this compilance check.
	*
	* @return the question manage four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageFour() {
		return _compilanceCheck.getQuestionManageFour();
	}

	/**
	* Sets the question manage four of this compilance check.
	*
	* @param questionManageFour the question manage four of this compilance check
	*/
	@Override
	public void setQuestionManageFour(java.lang.String questionManageFour) {
		_compilanceCheck.setQuestionManageFour(questionManageFour);
	}

	/**
	* Returns the question manage five of this compilance check.
	*
	* @return the question manage five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageFive() {
		return _compilanceCheck.getQuestionManageFive();
	}

	/**
	* Sets the question manage five of this compilance check.
	*
	* @param questionManageFive the question manage five of this compilance check
	*/
	@Override
	public void setQuestionManageFive(java.lang.String questionManageFive) {
		_compilanceCheck.setQuestionManageFive(questionManageFive);
	}

	/**
	* Returns the question manage six of this compilance check.
	*
	* @return the question manage six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageSix() {
		return _compilanceCheck.getQuestionManageSix();
	}

	/**
	* Sets the question manage six of this compilance check.
	*
	* @param questionManageSix the question manage six of this compilance check
	*/
	@Override
	public void setQuestionManageSix(java.lang.String questionManageSix) {
		_compilanceCheck.setQuestionManageSix(questionManageSix);
	}

	/**
	* Returns the question manage seven of this compilance check.
	*
	* @return the question manage seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageSeven() {
		return _compilanceCheck.getQuestionManageSeven();
	}

	/**
	* Sets the question manage seven of this compilance check.
	*
	* @param questionManageSeven the question manage seven of this compilance check
	*/
	@Override
	public void setQuestionManageSeven(java.lang.String questionManageSeven) {
		_compilanceCheck.setQuestionManageSeven(questionManageSeven);
	}

	/**
	* Returns the question manage note one of this compilance check.
	*
	* @return the question manage note one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteOne() {
		return _compilanceCheck.getQuestionManageNoteOne();
	}

	/**
	* Sets the question manage note one of this compilance check.
	*
	* @param questionManageNoteOne the question manage note one of this compilance check
	*/
	@Override
	public void setQuestionManageNoteOne(java.lang.String questionManageNoteOne) {
		_compilanceCheck.setQuestionManageNoteOne(questionManageNoteOne);
	}

	/**
	* Returns the question manage note two of this compilance check.
	*
	* @return the question manage note two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteTwo() {
		return _compilanceCheck.getQuestionManageNoteTwo();
	}

	/**
	* Sets the question manage note two of this compilance check.
	*
	* @param questionManageNoteTwo the question manage note two of this compilance check
	*/
	@Override
	public void setQuestionManageNoteTwo(java.lang.String questionManageNoteTwo) {
		_compilanceCheck.setQuestionManageNoteTwo(questionManageNoteTwo);
	}

	/**
	* Returns the question manage note three of this compilance check.
	*
	* @return the question manage note three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteThree() {
		return _compilanceCheck.getQuestionManageNoteThree();
	}

	/**
	* Sets the question manage note three of this compilance check.
	*
	* @param questionManageNoteThree the question manage note three of this compilance check
	*/
	@Override
	public void setQuestionManageNoteThree(
		java.lang.String questionManageNoteThree) {
		_compilanceCheck.setQuestionManageNoteThree(questionManageNoteThree);
	}

	/**
	* Returns the question manage note four of this compilance check.
	*
	* @return the question manage note four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteFour() {
		return _compilanceCheck.getQuestionManageNoteFour();
	}

	/**
	* Sets the question manage note four of this compilance check.
	*
	* @param questionManageNoteFour the question manage note four of this compilance check
	*/
	@Override
	public void setQuestionManageNoteFour(
		java.lang.String questionManageNoteFour) {
		_compilanceCheck.setQuestionManageNoteFour(questionManageNoteFour);
	}

	/**
	* Returns the question manage note five of this compilance check.
	*
	* @return the question manage note five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteFive() {
		return _compilanceCheck.getQuestionManageNoteFive();
	}

	/**
	* Sets the question manage note five of this compilance check.
	*
	* @param questionManageNoteFive the question manage note five of this compilance check
	*/
	@Override
	public void setQuestionManageNoteFive(
		java.lang.String questionManageNoteFive) {
		_compilanceCheck.setQuestionManageNoteFive(questionManageNoteFive);
	}

	/**
	* Returns the question manage note six of this compilance check.
	*
	* @return the question manage note six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionManageNoteSix() {
		return _compilanceCheck.getQuestionManageNoteSix();
	}

	/**
	* Sets the question manage note six of this compilance check.
	*
	* @param questionManageNoteSix the question manage note six of this compilance check
	*/
	@Override
	public void setQuestionManageNoteSix(java.lang.String questionManageNoteSix) {
		_compilanceCheck.setQuestionManageNoteSix(questionManageNoteSix);
	}

	/**
	* Returns the question records one of this compilance check.
	*
	* @return the question records one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsOne() {
		return _compilanceCheck.getQuestionRecordsOne();
	}

	/**
	* Sets the question records one of this compilance check.
	*
	* @param questionRecordsOne the question records one of this compilance check
	*/
	@Override
	public void setQuestionRecordsOne(java.lang.String questionRecordsOne) {
		_compilanceCheck.setQuestionRecordsOne(questionRecordsOne);
	}

	/**
	* Returns the question records two of this compilance check.
	*
	* @return the question records two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsTwo() {
		return _compilanceCheck.getQuestionRecordsTwo();
	}

	/**
	* Sets the question records two of this compilance check.
	*
	* @param questionRecordsTwo the question records two of this compilance check
	*/
	@Override
	public void setQuestionRecordsTwo(java.lang.String questionRecordsTwo) {
		_compilanceCheck.setQuestionRecordsTwo(questionRecordsTwo);
	}

	/**
	* Returns the question records three of this compilance check.
	*
	* @return the question records three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsThree() {
		return _compilanceCheck.getQuestionRecordsThree();
	}

	/**
	* Sets the question records three of this compilance check.
	*
	* @param questionRecordsThree the question records three of this compilance check
	*/
	@Override
	public void setQuestionRecordsThree(java.lang.String questionRecordsThree) {
		_compilanceCheck.setQuestionRecordsThree(questionRecordsThree);
	}

	/**
	* Returns the question records note one of this compilance check.
	*
	* @return the question records note one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsNoteOne() {
		return _compilanceCheck.getQuestionRecordsNoteOne();
	}

	/**
	* Sets the question records note one of this compilance check.
	*
	* @param questionRecordsNoteOne the question records note one of this compilance check
	*/
	@Override
	public void setQuestionRecordsNoteOne(
		java.lang.String questionRecordsNoteOne) {
		_compilanceCheck.setQuestionRecordsNoteOne(questionRecordsNoteOne);
	}

	/**
	* Returns the question records note two of this compilance check.
	*
	* @return the question records note two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsNoteTwo() {
		return _compilanceCheck.getQuestionRecordsNoteTwo();
	}

	/**
	* Sets the question records note two of this compilance check.
	*
	* @param questionRecordsNoteTwo the question records note two of this compilance check
	*/
	@Override
	public void setQuestionRecordsNoteTwo(
		java.lang.String questionRecordsNoteTwo) {
		_compilanceCheck.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
	}

	/**
	* Returns the question records note three of this compilance check.
	*
	* @return the question records note three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionRecordsNoteThree() {
		return _compilanceCheck.getQuestionRecordsNoteThree();
	}

	/**
	* Sets the question records note three of this compilance check.
	*
	* @param questionRecordsNoteThree the question records note three of this compilance check
	*/
	@Override
	public void setQuestionRecordsNoteThree(
		java.lang.String questionRecordsNoteThree) {
		_compilanceCheck.setQuestionRecordsNoteThree(questionRecordsNoteThree);
	}

	/**
	* Returns the question resk one of this compilance check.
	*
	* @return the question resk one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskOne() {
		return _compilanceCheck.getQuestionReskOne();
	}

	/**
	* Sets the question resk one of this compilance check.
	*
	* @param questionReskOne the question resk one of this compilance check
	*/
	@Override
	public void setQuestionReskOne(java.lang.String questionReskOne) {
		_compilanceCheck.setQuestionReskOne(questionReskOne);
	}

	/**
	* Returns the question resk two of this compilance check.
	*
	* @return the question resk two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskTwo() {
		return _compilanceCheck.getQuestionReskTwo();
	}

	/**
	* Sets the question resk two of this compilance check.
	*
	* @param questionReskTwo the question resk two of this compilance check
	*/
	@Override
	public void setQuestionReskTwo(java.lang.String questionReskTwo) {
		_compilanceCheck.setQuestionReskTwo(questionReskTwo);
	}

	/**
	* Returns the question resk three of this compilance check.
	*
	* @return the question resk three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskThree() {
		return _compilanceCheck.getQuestionReskThree();
	}

	/**
	* Sets the question resk three of this compilance check.
	*
	* @param questionReskThree the question resk three of this compilance check
	*/
	@Override
	public void setQuestionReskThree(java.lang.String questionReskThree) {
		_compilanceCheck.setQuestionReskThree(questionReskThree);
	}

	/**
	* Returns the question resk four of this compilance check.
	*
	* @return the question resk four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskFour() {
		return _compilanceCheck.getQuestionReskFour();
	}

	/**
	* Sets the question resk four of this compilance check.
	*
	* @param questionReskFour the question resk four of this compilance check
	*/
	@Override
	public void setQuestionReskFour(java.lang.String questionReskFour) {
		_compilanceCheck.setQuestionReskFour(questionReskFour);
	}

	/**
	* Returns the question resk five of this compilance check.
	*
	* @return the question resk five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskFive() {
		return _compilanceCheck.getQuestionReskFive();
	}

	/**
	* Sets the question resk five of this compilance check.
	*
	* @param questionReskFive the question resk five of this compilance check
	*/
	@Override
	public void setQuestionReskFive(java.lang.String questionReskFive) {
		_compilanceCheck.setQuestionReskFive(questionReskFive);
	}

	/**
	* Returns the question resk six of this compilance check.
	*
	* @return the question resk six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskSix() {
		return _compilanceCheck.getQuestionReskSix();
	}

	/**
	* Sets the question resk six of this compilance check.
	*
	* @param questionReskSix the question resk six of this compilance check
	*/
	@Override
	public void setQuestionReskSix(java.lang.String questionReskSix) {
		_compilanceCheck.setQuestionReskSix(questionReskSix);
	}

	/**
	* Returns the question resk seven of this compilance check.
	*
	* @return the question resk seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskSeven() {
		return _compilanceCheck.getQuestionReskSeven();
	}

	/**
	* Sets the question resk seven of this compilance check.
	*
	* @param questionReskSeven the question resk seven of this compilance check
	*/
	@Override
	public void setQuestionReskSeven(java.lang.String questionReskSeven) {
		_compilanceCheck.setQuestionReskSeven(questionReskSeven);
	}

	/**
	* Returns the question resk eight of this compilance check.
	*
	* @return the question resk eight of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskEight() {
		return _compilanceCheck.getQuestionReskEight();
	}

	/**
	* Sets the question resk eight of this compilance check.
	*
	* @param questionReskEight the question resk eight of this compilance check
	*/
	@Override
	public void setQuestionReskEight(java.lang.String questionReskEight) {
		_compilanceCheck.setQuestionReskEight(questionReskEight);
	}

	/**
	* Returns the question resk note one of this compilance check.
	*
	* @return the question resk note one of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteOne() {
		return _compilanceCheck.getQuestionReskNoteOne();
	}

	/**
	* Sets the question resk note one of this compilance check.
	*
	* @param questionReskNoteOne the question resk note one of this compilance check
	*/
	@Override
	public void setQuestionReskNoteOne(java.lang.String questionReskNoteOne) {
		_compilanceCheck.setQuestionReskNoteOne(questionReskNoteOne);
	}

	/**
	* Returns the question resk note two of this compilance check.
	*
	* @return the question resk note two of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteTwo() {
		return _compilanceCheck.getQuestionReskNoteTwo();
	}

	/**
	* Sets the question resk note two of this compilance check.
	*
	* @param questionReskNoteTwo the question resk note two of this compilance check
	*/
	@Override
	public void setQuestionReskNoteTwo(java.lang.String questionReskNoteTwo) {
		_compilanceCheck.setQuestionReskNoteTwo(questionReskNoteTwo);
	}

	/**
	* Returns the question resk note three of this compilance check.
	*
	* @return the question resk note three of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteThree() {
		return _compilanceCheck.getQuestionReskNoteThree();
	}

	/**
	* Sets the question resk note three of this compilance check.
	*
	* @param questionReskNoteThree the question resk note three of this compilance check
	*/
	@Override
	public void setQuestionReskNoteThree(java.lang.String questionReskNoteThree) {
		_compilanceCheck.setQuestionReskNoteThree(questionReskNoteThree);
	}

	/**
	* Returns the question resk note four of this compilance check.
	*
	* @return the question resk note four of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteFour() {
		return _compilanceCheck.getQuestionReskNoteFour();
	}

	/**
	* Sets the question resk note four of this compilance check.
	*
	* @param questionReskNoteFour the question resk note four of this compilance check
	*/
	@Override
	public void setQuestionReskNoteFour(java.lang.String questionReskNoteFour) {
		_compilanceCheck.setQuestionReskNoteFour(questionReskNoteFour);
	}

	/**
	* Returns the question resk note five of this compilance check.
	*
	* @return the question resk note five of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteFive() {
		return _compilanceCheck.getQuestionReskNoteFive();
	}

	/**
	* Sets the question resk note five of this compilance check.
	*
	* @param questionReskNoteFive the question resk note five of this compilance check
	*/
	@Override
	public void setQuestionReskNoteFive(java.lang.String questionReskNoteFive) {
		_compilanceCheck.setQuestionReskNoteFive(questionReskNoteFive);
	}

	/**
	* Returns the question resk note six of this compilance check.
	*
	* @return the question resk note six of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteSix() {
		return _compilanceCheck.getQuestionReskNoteSix();
	}

	/**
	* Sets the question resk note six of this compilance check.
	*
	* @param questionReskNoteSix the question resk note six of this compilance check
	*/
	@Override
	public void setQuestionReskNoteSix(java.lang.String questionReskNoteSix) {
		_compilanceCheck.setQuestionReskNoteSix(questionReskNoteSix);
	}

	/**
	* Returns the question resk note seven of this compilance check.
	*
	* @return the question resk note seven of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteSeven() {
		return _compilanceCheck.getQuestionReskNoteSeven();
	}

	/**
	* Sets the question resk note seven of this compilance check.
	*
	* @param questionReskNoteSeven the question resk note seven of this compilance check
	*/
	@Override
	public void setQuestionReskNoteSeven(java.lang.String questionReskNoteSeven) {
		_compilanceCheck.setQuestionReskNoteSeven(questionReskNoteSeven);
	}

	/**
	* Returns the question resk note eight of this compilance check.
	*
	* @return the question resk note eight of this compilance check
	*/
	@Override
	public java.lang.String getQuestionReskNoteEight() {
		return _compilanceCheck.getQuestionReskNoteEight();
	}

	/**
	* Sets the question resk note eight of this compilance check.
	*
	* @param questionReskNoteEight the question resk note eight of this compilance check
	*/
	@Override
	public void setQuestionReskNoteEight(java.lang.String questionReskNoteEight) {
		_compilanceCheck.setQuestionReskNoteEight(questionReskNoteEight);
	}

	/**
	* Returns the notcomplied of this compilance check.
	*
	* @return the notcomplied of this compilance check
	*/
	@Override
	public java.lang.String getNotcomplied() {
		return _compilanceCheck.getNotcomplied();
	}

	/**
	* Sets the notcomplied of this compilance check.
	*
	* @param notcomplied the notcomplied of this compilance check
	*/
	@Override
	public void setNotcomplied(java.lang.String notcomplied) {
		_compilanceCheck.setNotcomplied(notcomplied);
	}

	/**
	* Returns the record of this compilance check.
	*
	* @return the record of this compilance check
	*/
	@Override
	public java.lang.String getRecord() {
		return _compilanceCheck.getRecord();
	}

	/**
	* Sets the record of this compilance check.
	*
	* @param record the record of this compilance check
	*/
	@Override
	public void setRecord(java.lang.String record) {
		_compilanceCheck.setRecord(record);
	}

	@Override
	public boolean isNew() {
		return _compilanceCheck.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_compilanceCheck.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _compilanceCheck.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_compilanceCheck.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _compilanceCheck.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _compilanceCheck.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_compilanceCheck.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _compilanceCheck.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_compilanceCheck.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_compilanceCheck.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_compilanceCheck.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new CompilanceCheckWrapper((CompilanceCheck)_compilanceCheck.clone());
	}

	@Override
	public int compareTo(com.spad.icop.model.CompilanceCheck compilanceCheck) {
		return _compilanceCheck.compareTo(compilanceCheck);
	}

	@Override
	public int hashCode() {
		return _compilanceCheck.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.spad.icop.model.CompilanceCheck> toCacheModel() {
		return _compilanceCheck.toCacheModel();
	}

	@Override
	public com.spad.icop.model.CompilanceCheck toEscapedModel() {
		return new CompilanceCheckWrapper(_compilanceCheck.toEscapedModel());
	}

	@Override
	public com.spad.icop.model.CompilanceCheck toUnescapedModel() {
		return new CompilanceCheckWrapper(_compilanceCheck.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _compilanceCheck.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _compilanceCheck.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_compilanceCheck.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CompilanceCheckWrapper)) {
			return false;
		}

		CompilanceCheckWrapper compilanceCheckWrapper = (CompilanceCheckWrapper)obj;

		if (Validator.equals(_compilanceCheck,
					compilanceCheckWrapper._compilanceCheck)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public CompilanceCheck getWrappedCompilanceCheck() {
		return _compilanceCheck;
	}

	@Override
	public CompilanceCheck getWrappedModel() {
		return _compilanceCheck;
	}

	@Override
	public void resetOriginalValues() {
		_compilanceCheck.resetOriginalValues();
	}

	private CompilanceCheck _compilanceCheck;
}