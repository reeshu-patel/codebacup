/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.ClpSerializer;
import com.spad.icop.service.ComplainCheckAuditLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class ComplainCheckAuditClp extends BaseModelImpl<ComplainCheckAudit>
	implements ComplainCheckAudit {
	public ComplainCheckAuditClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return ComplainCheckAudit.class;
	}

	@Override
	public String getModelClassName() {
		return ComplainCheckAudit.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _matterId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setMatterId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _matterId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("matterId", getMatterId());
		attributes.put("aditid", getAditid());
		attributes.put("auditdate1_1", getAuditdate1_1());
		attributes.put("auditdateNote1_1", getAuditdateNote1_1());
		attributes.put("auditdate1_2", getAuditdate1_2());
		attributes.put("auditdateNote1_2", getAuditdateNote1_2());
		attributes.put("auditdate1_3", getAuditdate1_3());
		attributes.put("auditdateNote1_3", getAuditdateNote1_3());
		attributes.put("auditdate1_4", getAuditdate1_4());
		attributes.put("auditdateNote1_4", getAuditdateNote1_4());
		attributes.put("auditdate1_5", getAuditdate1_5());
		attributes.put("auditdateNote1_5", getAuditdateNote1_5());
		attributes.put("auditdate1_6", getAuditdate1_6());
		attributes.put("auditdateNote1_6", getAuditdateNote1_6());
		attributes.put("auditdate1_7", getAuditdate1_7());
		attributes.put("auditdateNote1_7", getAuditdateNote1_7());
		attributes.put("auditdate2_1", getAuditdate2_1());
		attributes.put("auditdateNote2_1", getAuditdateNote2_1());
		attributes.put("auditdate2_2", getAuditdate2_2());
		attributes.put("auditdateNote2_2", getAuditdateNote2_2());
		attributes.put("auditdate2_3", getAuditdate2_3());
		attributes.put("auditdateNote2_3", getAuditdateNote2_3());
		attributes.put("auditdate2_4", getAuditdate2_4());
		attributes.put("auditdateNote2_4", getAuditdateNote2_4());
		attributes.put("auditdate2_4_1", getAuditdate2_4_1());
		attributes.put("auditdateNote2_4_1", getAuditdateNote2_4_1());
		attributes.put("auditdate2_4_2", getAuditdate2_4_2());
		attributes.put("auditdateNote2_4_2", getAuditdateNote2_4_2());
		attributes.put("auditdate2_4_3", getAuditdate2_4_3());
		attributes.put("auditdateNote2_4_3", getAuditdateNote2_4_3());
		attributes.put("auditdate2_4_4", getAuditdate2_4_4());
		attributes.put("auditdateNote2_4_4", getAuditdateNote2_4_4());
		attributes.put("auditdate2_4_5", getAuditdate2_4_5());
		attributes.put("auditdateNote2_4_5", getAuditdateNote2_4_5());
		attributes.put("auditdate2_4_6", getAuditdate2_4_6());
		attributes.put("auditdateNote2_4_6", getAuditdateNote2_4_6());
		attributes.put("auditdate3_1", getAuditdate3_1());
		attributes.put("auditdate3_2", getAuditdate3_2());
		attributes.put("auditdate3_3", getAuditdate3_3());
		attributes.put("auditdate3_4", getAuditdate3_4());
		attributes.put("auditdate3_5", getAuditdate3_5());
		attributes.put("auditdate3_6", getAuditdate3_6());
		attributes.put("auditdateNote3_1", getAuditdateNote3_1());
		attributes.put("auditdateNote3_2", getAuditdateNote3_2());
		attributes.put("auditdateNote3_3", getAuditdateNote3_3());
		attributes.put("auditdateNote3_4", getAuditdateNote3_4());
		attributes.put("auditdateNote3_5", getAuditdateNote3_5());
		attributes.put("auditdateNote3_6", getAuditdateNote3_6());
		attributes.put("auditdate4_1", getAuditdate4_1());
		attributes.put("auditdate4_2", getAuditdate4_2());
		attributes.put("auditdate4_3", getAuditdate4_3());
		attributes.put("auditdateNote4_1", getAuditdateNote4_1());
		attributes.put("auditdateNote4_2", getAuditdateNote4_2());
		attributes.put("auditdateNote4_3", getAuditdateNote4_3());
		attributes.put("auditdate5_1", getAuditdate5_1());
		attributes.put("auditdate5_2", getAuditdate5_2());
		attributes.put("auditdate5_3", getAuditdate5_3());
		attributes.put("auditdate5_4", getAuditdate5_4());
		attributes.put("auditdate5_5", getAuditdate5_5());
		attributes.put("auditdate5_6", getAuditdate5_6());
		attributes.put("auditdate5_7", getAuditdate5_7());
		attributes.put("auditdate5_8", getAuditdate5_8());
		attributes.put("auditdateNote5_1", getAuditdateNote5_1());
		attributes.put("auditdateNote5_2", getAuditdateNote5_2());
		attributes.put("auditdateNote5_3", getAuditdateNote5_3());
		attributes.put("auditdateNote5_4", getAuditdateNote5_4());
		attributes.put("auditdateNote5_5", getAuditdateNote5_5());
		attributes.put("auditdateNote5_6", getAuditdateNote5_6());
		attributes.put("auditdateNote5_7", getAuditdateNote5_7());
		attributes.put("auditdateNote5_8", getAuditdateNote5_8());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long matterId = (Long)attributes.get("matterId");

		if (matterId != null) {
			setMatterId(matterId);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String auditdate1_1 = (String)attributes.get("auditdate1_1");

		if (auditdate1_1 != null) {
			setAuditdate1_1(auditdate1_1);
		}

		String auditdateNote1_1 = (String)attributes.get("auditdateNote1_1");

		if (auditdateNote1_1 != null) {
			setAuditdateNote1_1(auditdateNote1_1);
		}

		String auditdate1_2 = (String)attributes.get("auditdate1_2");

		if (auditdate1_2 != null) {
			setAuditdate1_2(auditdate1_2);
		}

		String auditdateNote1_2 = (String)attributes.get("auditdateNote1_2");

		if (auditdateNote1_2 != null) {
			setAuditdateNote1_2(auditdateNote1_2);
		}

		String auditdate1_3 = (String)attributes.get("auditdate1_3");

		if (auditdate1_3 != null) {
			setAuditdate1_3(auditdate1_3);
		}

		String auditdateNote1_3 = (String)attributes.get("auditdateNote1_3");

		if (auditdateNote1_3 != null) {
			setAuditdateNote1_3(auditdateNote1_3);
		}

		String auditdate1_4 = (String)attributes.get("auditdate1_4");

		if (auditdate1_4 != null) {
			setAuditdate1_4(auditdate1_4);
		}

		String auditdateNote1_4 = (String)attributes.get("auditdateNote1_4");

		if (auditdateNote1_4 != null) {
			setAuditdateNote1_4(auditdateNote1_4);
		}

		String auditdate1_5 = (String)attributes.get("auditdate1_5");

		if (auditdate1_5 != null) {
			setAuditdate1_5(auditdate1_5);
		}

		String auditdateNote1_5 = (String)attributes.get("auditdateNote1_5");

		if (auditdateNote1_5 != null) {
			setAuditdateNote1_5(auditdateNote1_5);
		}

		String auditdate1_6 = (String)attributes.get("auditdate1_6");

		if (auditdate1_6 != null) {
			setAuditdate1_6(auditdate1_6);
		}

		String auditdateNote1_6 = (String)attributes.get("auditdateNote1_6");

		if (auditdateNote1_6 != null) {
			setAuditdateNote1_6(auditdateNote1_6);
		}

		String auditdate1_7 = (String)attributes.get("auditdate1_7");

		if (auditdate1_7 != null) {
			setAuditdate1_7(auditdate1_7);
		}

		String auditdateNote1_7 = (String)attributes.get("auditdateNote1_7");

		if (auditdateNote1_7 != null) {
			setAuditdateNote1_7(auditdateNote1_7);
		}

		String auditdate2_1 = (String)attributes.get("auditdate2_1");

		if (auditdate2_1 != null) {
			setAuditdate2_1(auditdate2_1);
		}

		String auditdateNote2_1 = (String)attributes.get("auditdateNote2_1");

		if (auditdateNote2_1 != null) {
			setAuditdateNote2_1(auditdateNote2_1);
		}

		String auditdate2_2 = (String)attributes.get("auditdate2_2");

		if (auditdate2_2 != null) {
			setAuditdate2_2(auditdate2_2);
		}

		String auditdateNote2_2 = (String)attributes.get("auditdateNote2_2");

		if (auditdateNote2_2 != null) {
			setAuditdateNote2_2(auditdateNote2_2);
		}

		String auditdate2_3 = (String)attributes.get("auditdate2_3");

		if (auditdate2_3 != null) {
			setAuditdate2_3(auditdate2_3);
		}

		String auditdateNote2_3 = (String)attributes.get("auditdateNote2_3");

		if (auditdateNote2_3 != null) {
			setAuditdateNote2_3(auditdateNote2_3);
		}

		String auditdate2_4 = (String)attributes.get("auditdate2_4");

		if (auditdate2_4 != null) {
			setAuditdate2_4(auditdate2_4);
		}

		String auditdateNote2_4 = (String)attributes.get("auditdateNote2_4");

		if (auditdateNote2_4 != null) {
			setAuditdateNote2_4(auditdateNote2_4);
		}

		String auditdate2_4_1 = (String)attributes.get("auditdate2_4_1");

		if (auditdate2_4_1 != null) {
			setAuditdate2_4_1(auditdate2_4_1);
		}

		String auditdateNote2_4_1 = (String)attributes.get("auditdateNote2_4_1");

		if (auditdateNote2_4_1 != null) {
			setAuditdateNote2_4_1(auditdateNote2_4_1);
		}

		String auditdate2_4_2 = (String)attributes.get("auditdate2_4_2");

		if (auditdate2_4_2 != null) {
			setAuditdate2_4_2(auditdate2_4_2);
		}

		String auditdateNote2_4_2 = (String)attributes.get("auditdateNote2_4_2");

		if (auditdateNote2_4_2 != null) {
			setAuditdateNote2_4_2(auditdateNote2_4_2);
		}

		String auditdate2_4_3 = (String)attributes.get("auditdate2_4_3");

		if (auditdate2_4_3 != null) {
			setAuditdate2_4_3(auditdate2_4_3);
		}

		String auditdateNote2_4_3 = (String)attributes.get("auditdateNote2_4_3");

		if (auditdateNote2_4_3 != null) {
			setAuditdateNote2_4_3(auditdateNote2_4_3);
		}

		String auditdate2_4_4 = (String)attributes.get("auditdate2_4_4");

		if (auditdate2_4_4 != null) {
			setAuditdate2_4_4(auditdate2_4_4);
		}

		String auditdateNote2_4_4 = (String)attributes.get("auditdateNote2_4_4");

		if (auditdateNote2_4_4 != null) {
			setAuditdateNote2_4_4(auditdateNote2_4_4);
		}

		String auditdate2_4_5 = (String)attributes.get("auditdate2_4_5");

		if (auditdate2_4_5 != null) {
			setAuditdate2_4_5(auditdate2_4_5);
		}

		String auditdateNote2_4_5 = (String)attributes.get("auditdateNote2_4_5");

		if (auditdateNote2_4_5 != null) {
			setAuditdateNote2_4_5(auditdateNote2_4_5);
		}

		String auditdate2_4_6 = (String)attributes.get("auditdate2_4_6");

		if (auditdate2_4_6 != null) {
			setAuditdate2_4_6(auditdate2_4_6);
		}

		String auditdateNote2_4_6 = (String)attributes.get("auditdateNote2_4_6");

		if (auditdateNote2_4_6 != null) {
			setAuditdateNote2_4_6(auditdateNote2_4_6);
		}

		String auditdate3_1 = (String)attributes.get("auditdate3_1");

		if (auditdate3_1 != null) {
			setAuditdate3_1(auditdate3_1);
		}

		String auditdate3_2 = (String)attributes.get("auditdate3_2");

		if (auditdate3_2 != null) {
			setAuditdate3_2(auditdate3_2);
		}

		String auditdate3_3 = (String)attributes.get("auditdate3_3");

		if (auditdate3_3 != null) {
			setAuditdate3_3(auditdate3_3);
		}

		String auditdate3_4 = (String)attributes.get("auditdate3_4");

		if (auditdate3_4 != null) {
			setAuditdate3_4(auditdate3_4);
		}

		String auditdate3_5 = (String)attributes.get("auditdate3_5");

		if (auditdate3_5 != null) {
			setAuditdate3_5(auditdate3_5);
		}

		String auditdate3_6 = (String)attributes.get("auditdate3_6");

		if (auditdate3_6 != null) {
			setAuditdate3_6(auditdate3_6);
		}

		String auditdateNote3_1 = (String)attributes.get("auditdateNote3_1");

		if (auditdateNote3_1 != null) {
			setAuditdateNote3_1(auditdateNote3_1);
		}

		String auditdateNote3_2 = (String)attributes.get("auditdateNote3_2");

		if (auditdateNote3_2 != null) {
			setAuditdateNote3_2(auditdateNote3_2);
		}

		String auditdateNote3_3 = (String)attributes.get("auditdateNote3_3");

		if (auditdateNote3_3 != null) {
			setAuditdateNote3_3(auditdateNote3_3);
		}

		String auditdateNote3_4 = (String)attributes.get("auditdateNote3_4");

		if (auditdateNote3_4 != null) {
			setAuditdateNote3_4(auditdateNote3_4);
		}

		String auditdateNote3_5 = (String)attributes.get("auditdateNote3_5");

		if (auditdateNote3_5 != null) {
			setAuditdateNote3_5(auditdateNote3_5);
		}

		String auditdateNote3_6 = (String)attributes.get("auditdateNote3_6");

		if (auditdateNote3_6 != null) {
			setAuditdateNote3_6(auditdateNote3_6);
		}

		String auditdate4_1 = (String)attributes.get("auditdate4_1");

		if (auditdate4_1 != null) {
			setAuditdate4_1(auditdate4_1);
		}

		String auditdate4_2 = (String)attributes.get("auditdate4_2");

		if (auditdate4_2 != null) {
			setAuditdate4_2(auditdate4_2);
		}

		String auditdate4_3 = (String)attributes.get("auditdate4_3");

		if (auditdate4_3 != null) {
			setAuditdate4_3(auditdate4_3);
		}

		String auditdateNote4_1 = (String)attributes.get("auditdateNote4_1");

		if (auditdateNote4_1 != null) {
			setAuditdateNote4_1(auditdateNote4_1);
		}

		String auditdateNote4_2 = (String)attributes.get("auditdateNote4_2");

		if (auditdateNote4_2 != null) {
			setAuditdateNote4_2(auditdateNote4_2);
		}

		String auditdateNote4_3 = (String)attributes.get("auditdateNote4_3");

		if (auditdateNote4_3 != null) {
			setAuditdateNote4_3(auditdateNote4_3);
		}

		String auditdate5_1 = (String)attributes.get("auditdate5_1");

		if (auditdate5_1 != null) {
			setAuditdate5_1(auditdate5_1);
		}

		String auditdate5_2 = (String)attributes.get("auditdate5_2");

		if (auditdate5_2 != null) {
			setAuditdate5_2(auditdate5_2);
		}

		String auditdate5_3 = (String)attributes.get("auditdate5_3");

		if (auditdate5_3 != null) {
			setAuditdate5_3(auditdate5_3);
		}

		String auditdate5_4 = (String)attributes.get("auditdate5_4");

		if (auditdate5_4 != null) {
			setAuditdate5_4(auditdate5_4);
		}

		String auditdate5_5 = (String)attributes.get("auditdate5_5");

		if (auditdate5_5 != null) {
			setAuditdate5_5(auditdate5_5);
		}

		String auditdate5_6 = (String)attributes.get("auditdate5_6");

		if (auditdate5_6 != null) {
			setAuditdate5_6(auditdate5_6);
		}

		String auditdate5_7 = (String)attributes.get("auditdate5_7");

		if (auditdate5_7 != null) {
			setAuditdate5_7(auditdate5_7);
		}

		String auditdate5_8 = (String)attributes.get("auditdate5_8");

		if (auditdate5_8 != null) {
			setAuditdate5_8(auditdate5_8);
		}

		String auditdateNote5_1 = (String)attributes.get("auditdateNote5_1");

		if (auditdateNote5_1 != null) {
			setAuditdateNote5_1(auditdateNote5_1);
		}

		String auditdateNote5_2 = (String)attributes.get("auditdateNote5_2");

		if (auditdateNote5_2 != null) {
			setAuditdateNote5_2(auditdateNote5_2);
		}

		String auditdateNote5_3 = (String)attributes.get("auditdateNote5_3");

		if (auditdateNote5_3 != null) {
			setAuditdateNote5_3(auditdateNote5_3);
		}

		String auditdateNote5_4 = (String)attributes.get("auditdateNote5_4");

		if (auditdateNote5_4 != null) {
			setAuditdateNote5_4(auditdateNote5_4);
		}

		String auditdateNote5_5 = (String)attributes.get("auditdateNote5_5");

		if (auditdateNote5_5 != null) {
			setAuditdateNote5_5(auditdateNote5_5);
		}

		String auditdateNote5_6 = (String)attributes.get("auditdateNote5_6");

		if (auditdateNote5_6 != null) {
			setAuditdateNote5_6(auditdateNote5_6);
		}

		String auditdateNote5_7 = (String)attributes.get("auditdateNote5_7");

		if (auditdateNote5_7 != null) {
			setAuditdateNote5_7(auditdateNote5_7);
		}

		String auditdateNote5_8 = (String)attributes.get("auditdateNote5_8");

		if (auditdateNote5_8 != null) {
			setAuditdateNote5_8(auditdateNote5_8);
		}
	}

	@Override
	public long getMatterId() {
		return _matterId;
	}

	@Override
	public void setMatterId(long matterId) {
		_matterId = matterId;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setMatterId", long.class);

				method.invoke(_complainCheckAuditRemoteModel, matterId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAditid() {
		return _aditid;
	}

	@Override
	public void setAditid(long aditid) {
		_aditid = aditid;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAditid", long.class);

				method.invoke(_complainCheckAuditRemoteModel, aditid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_1() {
		return _auditdate1_1;
	}

	@Override
	public void setAuditdate1_1(String auditdate1_1) {
		_auditdate1_1 = auditdate1_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_1", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_1() {
		return _auditdateNote1_1;
	}

	@Override
	public void setAuditdateNote1_1(String auditdateNote1_1) {
		_auditdateNote1_1 = auditdateNote1_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_2() {
		return _auditdate1_2;
	}

	@Override
	public void setAuditdate1_2(String auditdate1_2) {
		_auditdate1_2 = auditdate1_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_2", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_2() {
		return _auditdateNote1_2;
	}

	@Override
	public void setAuditdateNote1_2(String auditdateNote1_2) {
		_auditdateNote1_2 = auditdateNote1_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_3() {
		return _auditdate1_3;
	}

	@Override
	public void setAuditdate1_3(String auditdate1_3) {
		_auditdate1_3 = auditdate1_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_3", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_3() {
		return _auditdateNote1_3;
	}

	@Override
	public void setAuditdateNote1_3(String auditdateNote1_3) {
		_auditdateNote1_3 = auditdateNote1_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_4() {
		return _auditdate1_4;
	}

	@Override
	public void setAuditdate1_4(String auditdate1_4) {
		_auditdate1_4 = auditdate1_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_4", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_4() {
		return _auditdateNote1_4;
	}

	@Override
	public void setAuditdateNote1_4(String auditdateNote1_4) {
		_auditdateNote1_4 = auditdateNote1_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_5() {
		return _auditdate1_5;
	}

	@Override
	public void setAuditdate1_5(String auditdate1_5) {
		_auditdate1_5 = auditdate1_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_5", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_5() {
		return _auditdateNote1_5;
	}

	@Override
	public void setAuditdateNote1_5(String auditdateNote1_5) {
		_auditdateNote1_5 = auditdateNote1_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_5",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_6() {
		return _auditdate1_6;
	}

	@Override
	public void setAuditdate1_6(String auditdate1_6) {
		_auditdate1_6 = auditdate1_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_6", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_6() {
		return _auditdateNote1_6;
	}

	@Override
	public void setAuditdateNote1_6(String auditdateNote1_6) {
		_auditdateNote1_6 = auditdateNote1_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_6",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate1_7() {
		return _auditdate1_7;
	}

	@Override
	public void setAuditdate1_7(String auditdate1_7) {
		_auditdate1_7 = auditdate1_7;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate1_7", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate1_7);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote1_7() {
		return _auditdateNote1_7;
	}

	@Override
	public void setAuditdateNote1_7(String auditdateNote1_7) {
		_auditdateNote1_7 = auditdateNote1_7;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote1_7",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote1_7);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_1() {
		return _auditdate2_1;
	}

	@Override
	public void setAuditdate2_1(String auditdate2_1) {
		_auditdate2_1 = auditdate2_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_1", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_1() {
		return _auditdateNote2_1;
	}

	@Override
	public void setAuditdateNote2_1(String auditdateNote2_1) {
		_auditdateNote2_1 = auditdateNote2_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_2() {
		return _auditdate2_2;
	}

	@Override
	public void setAuditdate2_2(String auditdate2_2) {
		_auditdate2_2 = auditdate2_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_2", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_2() {
		return _auditdateNote2_2;
	}

	@Override
	public void setAuditdateNote2_2(String auditdateNote2_2) {
		_auditdateNote2_2 = auditdateNote2_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_3() {
		return _auditdate2_3;
	}

	@Override
	public void setAuditdate2_3(String auditdate2_3) {
		_auditdate2_3 = auditdate2_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_3", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_3() {
		return _auditdateNote2_3;
	}

	@Override
	public void setAuditdateNote2_3(String auditdateNote2_3) {
		_auditdateNote2_3 = auditdateNote2_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4() {
		return _auditdate2_4;
	}

	@Override
	public void setAuditdate2_4(String auditdate2_4) {
		_auditdate2_4 = auditdate2_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4() {
		return _auditdateNote2_4;
	}

	@Override
	public void setAuditdateNote2_4(String auditdateNote2_4) {
		_auditdateNote2_4 = auditdateNote2_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_1() {
		return _auditdate2_4_1;
	}

	@Override
	public void setAuditdate2_4_1(String auditdate2_4_1) {
		_auditdate2_4_1 = auditdate2_4_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_1() {
		return _auditdateNote2_4_1;
	}

	@Override
	public void setAuditdateNote2_4_1(String auditdateNote2_4_1) {
		_auditdateNote2_4_1 = auditdateNote2_4_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_2() {
		return _auditdate2_4_2;
	}

	@Override
	public void setAuditdate2_4_2(String auditdate2_4_2) {
		_auditdate2_4_2 = auditdate2_4_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_2() {
		return _auditdateNote2_4_2;
	}

	@Override
	public void setAuditdateNote2_4_2(String auditdateNote2_4_2) {
		_auditdateNote2_4_2 = auditdateNote2_4_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_3() {
		return _auditdate2_4_3;
	}

	@Override
	public void setAuditdate2_4_3(String auditdate2_4_3) {
		_auditdate2_4_3 = auditdate2_4_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_3() {
		return _auditdateNote2_4_3;
	}

	@Override
	public void setAuditdateNote2_4_3(String auditdateNote2_4_3) {
		_auditdateNote2_4_3 = auditdateNote2_4_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_4() {
		return _auditdate2_4_4;
	}

	@Override
	public void setAuditdate2_4_4(String auditdate2_4_4) {
		_auditdate2_4_4 = auditdate2_4_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_4() {
		return _auditdateNote2_4_4;
	}

	@Override
	public void setAuditdateNote2_4_4(String auditdateNote2_4_4) {
		_auditdateNote2_4_4 = auditdateNote2_4_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_5() {
		return _auditdate2_4_5;
	}

	@Override
	public void setAuditdate2_4_5(String auditdate2_4_5) {
		_auditdate2_4_5 = auditdate2_4_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_5",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_5() {
		return _auditdateNote2_4_5;
	}

	@Override
	public void setAuditdateNote2_4_5(String auditdateNote2_4_5) {
		_auditdateNote2_4_5 = auditdateNote2_4_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_5",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate2_4_6() {
		return _auditdate2_4_6;
	}

	@Override
	public void setAuditdate2_4_6(String auditdate2_4_6) {
		_auditdate2_4_6 = auditdate2_4_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate2_4_6",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate2_4_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote2_4_6() {
		return _auditdateNote2_4_6;
	}

	@Override
	public void setAuditdateNote2_4_6(String auditdateNote2_4_6) {
		_auditdateNote2_4_6 = auditdateNote2_4_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote2_4_6",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote2_4_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_1() {
		return _auditdate3_1;
	}

	@Override
	public void setAuditdate3_1(String auditdate3_1) {
		_auditdate3_1 = auditdate3_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_1", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_2() {
		return _auditdate3_2;
	}

	@Override
	public void setAuditdate3_2(String auditdate3_2) {
		_auditdate3_2 = auditdate3_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_2", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_3() {
		return _auditdate3_3;
	}

	@Override
	public void setAuditdate3_3(String auditdate3_3) {
		_auditdate3_3 = auditdate3_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_3", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_4() {
		return _auditdate3_4;
	}

	@Override
	public void setAuditdate3_4(String auditdate3_4) {
		_auditdate3_4 = auditdate3_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_4", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_5() {
		return _auditdate3_5;
	}

	@Override
	public void setAuditdate3_5(String auditdate3_5) {
		_auditdate3_5 = auditdate3_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_5", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate3_6() {
		return _auditdate3_6;
	}

	@Override
	public void setAuditdate3_6(String auditdate3_6) {
		_auditdate3_6 = auditdate3_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate3_6", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate3_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_1() {
		return _auditdateNote3_1;
	}

	@Override
	public void setAuditdateNote3_1(String auditdateNote3_1) {
		_auditdateNote3_1 = auditdateNote3_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_2() {
		return _auditdateNote3_2;
	}

	@Override
	public void setAuditdateNote3_2(String auditdateNote3_2) {
		_auditdateNote3_2 = auditdateNote3_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_3() {
		return _auditdateNote3_3;
	}

	@Override
	public void setAuditdateNote3_3(String auditdateNote3_3) {
		_auditdateNote3_3 = auditdateNote3_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_4() {
		return _auditdateNote3_4;
	}

	@Override
	public void setAuditdateNote3_4(String auditdateNote3_4) {
		_auditdateNote3_4 = auditdateNote3_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_5() {
		return _auditdateNote3_5;
	}

	@Override
	public void setAuditdateNote3_5(String auditdateNote3_5) {
		_auditdateNote3_5 = auditdateNote3_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_5",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote3_6() {
		return _auditdateNote3_6;
	}

	@Override
	public void setAuditdateNote3_6(String auditdateNote3_6) {
		_auditdateNote3_6 = auditdateNote3_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote3_6",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote3_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate4_1() {
		return _auditdate4_1;
	}

	@Override
	public void setAuditdate4_1(String auditdate4_1) {
		_auditdate4_1 = auditdate4_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate4_1", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate4_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate4_2() {
		return _auditdate4_2;
	}

	@Override
	public void setAuditdate4_2(String auditdate4_2) {
		_auditdate4_2 = auditdate4_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate4_2", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate4_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate4_3() {
		return _auditdate4_3;
	}

	@Override
	public void setAuditdate4_3(String auditdate4_3) {
		_auditdate4_3 = auditdate4_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate4_3", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate4_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote4_1() {
		return _auditdateNote4_1;
	}

	@Override
	public void setAuditdateNote4_1(String auditdateNote4_1) {
		_auditdateNote4_1 = auditdateNote4_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote4_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote4_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote4_2() {
		return _auditdateNote4_2;
	}

	@Override
	public void setAuditdateNote4_2(String auditdateNote4_2) {
		_auditdateNote4_2 = auditdateNote4_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote4_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote4_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote4_3() {
		return _auditdateNote4_3;
	}

	@Override
	public void setAuditdateNote4_3(String auditdateNote4_3) {
		_auditdateNote4_3 = auditdateNote4_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote4_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote4_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_1() {
		return _auditdate5_1;
	}

	@Override
	public void setAuditdate5_1(String auditdate5_1) {
		_auditdate5_1 = auditdate5_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_1", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_2() {
		return _auditdate5_2;
	}

	@Override
	public void setAuditdate5_2(String auditdate5_2) {
		_auditdate5_2 = auditdate5_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_2", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_3() {
		return _auditdate5_3;
	}

	@Override
	public void setAuditdate5_3(String auditdate5_3) {
		_auditdate5_3 = auditdate5_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_3", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_4() {
		return _auditdate5_4;
	}

	@Override
	public void setAuditdate5_4(String auditdate5_4) {
		_auditdate5_4 = auditdate5_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_4", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_5() {
		return _auditdate5_5;
	}

	@Override
	public void setAuditdate5_5(String auditdate5_5) {
		_auditdate5_5 = auditdate5_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_5", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_6() {
		return _auditdate5_6;
	}

	@Override
	public void setAuditdate5_6(String auditdate5_6) {
		_auditdate5_6 = auditdate5_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_6", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_7() {
		return _auditdate5_7;
	}

	@Override
	public void setAuditdate5_7(String auditdate5_7) {
		_auditdate5_7 = auditdate5_7;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_7", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_7);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdate5_8() {
		return _auditdate5_8;
	}

	@Override
	public void setAuditdate5_8(String auditdate5_8) {
		_auditdate5_8 = auditdate5_8;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdate5_8", String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdate5_8);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_1() {
		return _auditdateNote5_1;
	}

	@Override
	public void setAuditdateNote5_1(String auditdateNote5_1) {
		_auditdateNote5_1 = auditdateNote5_1;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_1",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_2() {
		return _auditdateNote5_2;
	}

	@Override
	public void setAuditdateNote5_2(String auditdateNote5_2) {
		_auditdateNote5_2 = auditdateNote5_2;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_2",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_3() {
		return _auditdateNote5_3;
	}

	@Override
	public void setAuditdateNote5_3(String auditdateNote5_3) {
		_auditdateNote5_3 = auditdateNote5_3;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_3",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_3);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_4() {
		return _auditdateNote5_4;
	}

	@Override
	public void setAuditdateNote5_4(String auditdateNote5_4) {
		_auditdateNote5_4 = auditdateNote5_4;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_4",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_4);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_5() {
		return _auditdateNote5_5;
	}

	@Override
	public void setAuditdateNote5_5(String auditdateNote5_5) {
		_auditdateNote5_5 = auditdateNote5_5;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_5",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_5);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_6() {
		return _auditdateNote5_6;
	}

	@Override
	public void setAuditdateNote5_6(String auditdateNote5_6) {
		_auditdateNote5_6 = auditdateNote5_6;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_6",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_6);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_7() {
		return _auditdateNote5_7;
	}

	@Override
	public void setAuditdateNote5_7(String auditdateNote5_7) {
		_auditdateNote5_7 = auditdateNote5_7;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_7",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_7);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditdateNote5_8() {
		return _auditdateNote5_8;
	}

	@Override
	public void setAuditdateNote5_8(String auditdateNote5_8) {
		_auditdateNote5_8 = auditdateNote5_8;

		if (_complainCheckAuditRemoteModel != null) {
			try {
				Class<?> clazz = _complainCheckAuditRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditdateNote5_8",
						String.class);

				method.invoke(_complainCheckAuditRemoteModel, auditdateNote5_8);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getComplainCheckAuditRemoteModel() {
		return _complainCheckAuditRemoteModel;
	}

	public void setComplainCheckAuditRemoteModel(
		BaseModel<?> complainCheckAuditRemoteModel) {
		_complainCheckAuditRemoteModel = complainCheckAuditRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _complainCheckAuditRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_complainCheckAuditRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			ComplainCheckAuditLocalServiceUtil.addComplainCheckAudit(this);
		}
		else {
			ComplainCheckAuditLocalServiceUtil.updateComplainCheckAudit(this);
		}
	}

	@Override
	public ComplainCheckAudit toEscapedModel() {
		return (ComplainCheckAudit)ProxyUtil.newProxyInstance(ComplainCheckAudit.class.getClassLoader(),
			new Class[] { ComplainCheckAudit.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		ComplainCheckAuditClp clone = new ComplainCheckAuditClp();

		clone.setMatterId(getMatterId());
		clone.setAditid(getAditid());
		clone.setAuditdate1_1(getAuditdate1_1());
		clone.setAuditdateNote1_1(getAuditdateNote1_1());
		clone.setAuditdate1_2(getAuditdate1_2());
		clone.setAuditdateNote1_2(getAuditdateNote1_2());
		clone.setAuditdate1_3(getAuditdate1_3());
		clone.setAuditdateNote1_3(getAuditdateNote1_3());
		clone.setAuditdate1_4(getAuditdate1_4());
		clone.setAuditdateNote1_4(getAuditdateNote1_4());
		clone.setAuditdate1_5(getAuditdate1_5());
		clone.setAuditdateNote1_5(getAuditdateNote1_5());
		clone.setAuditdate1_6(getAuditdate1_6());
		clone.setAuditdateNote1_6(getAuditdateNote1_6());
		clone.setAuditdate1_7(getAuditdate1_7());
		clone.setAuditdateNote1_7(getAuditdateNote1_7());
		clone.setAuditdate2_1(getAuditdate2_1());
		clone.setAuditdateNote2_1(getAuditdateNote2_1());
		clone.setAuditdate2_2(getAuditdate2_2());
		clone.setAuditdateNote2_2(getAuditdateNote2_2());
		clone.setAuditdate2_3(getAuditdate2_3());
		clone.setAuditdateNote2_3(getAuditdateNote2_3());
		clone.setAuditdate2_4(getAuditdate2_4());
		clone.setAuditdateNote2_4(getAuditdateNote2_4());
		clone.setAuditdate2_4_1(getAuditdate2_4_1());
		clone.setAuditdateNote2_4_1(getAuditdateNote2_4_1());
		clone.setAuditdate2_4_2(getAuditdate2_4_2());
		clone.setAuditdateNote2_4_2(getAuditdateNote2_4_2());
		clone.setAuditdate2_4_3(getAuditdate2_4_3());
		clone.setAuditdateNote2_4_3(getAuditdateNote2_4_3());
		clone.setAuditdate2_4_4(getAuditdate2_4_4());
		clone.setAuditdateNote2_4_4(getAuditdateNote2_4_4());
		clone.setAuditdate2_4_5(getAuditdate2_4_5());
		clone.setAuditdateNote2_4_5(getAuditdateNote2_4_5());
		clone.setAuditdate2_4_6(getAuditdate2_4_6());
		clone.setAuditdateNote2_4_6(getAuditdateNote2_4_6());
		clone.setAuditdate3_1(getAuditdate3_1());
		clone.setAuditdate3_2(getAuditdate3_2());
		clone.setAuditdate3_3(getAuditdate3_3());
		clone.setAuditdate3_4(getAuditdate3_4());
		clone.setAuditdate3_5(getAuditdate3_5());
		clone.setAuditdate3_6(getAuditdate3_6());
		clone.setAuditdateNote3_1(getAuditdateNote3_1());
		clone.setAuditdateNote3_2(getAuditdateNote3_2());
		clone.setAuditdateNote3_3(getAuditdateNote3_3());
		clone.setAuditdateNote3_4(getAuditdateNote3_4());
		clone.setAuditdateNote3_5(getAuditdateNote3_5());
		clone.setAuditdateNote3_6(getAuditdateNote3_6());
		clone.setAuditdate4_1(getAuditdate4_1());
		clone.setAuditdate4_2(getAuditdate4_2());
		clone.setAuditdate4_3(getAuditdate4_3());
		clone.setAuditdateNote4_1(getAuditdateNote4_1());
		clone.setAuditdateNote4_2(getAuditdateNote4_2());
		clone.setAuditdateNote4_3(getAuditdateNote4_3());
		clone.setAuditdate5_1(getAuditdate5_1());
		clone.setAuditdate5_2(getAuditdate5_2());
		clone.setAuditdate5_3(getAuditdate5_3());
		clone.setAuditdate5_4(getAuditdate5_4());
		clone.setAuditdate5_5(getAuditdate5_5());
		clone.setAuditdate5_6(getAuditdate5_6());
		clone.setAuditdate5_7(getAuditdate5_7());
		clone.setAuditdate5_8(getAuditdate5_8());
		clone.setAuditdateNote5_1(getAuditdateNote5_1());
		clone.setAuditdateNote5_2(getAuditdateNote5_2());
		clone.setAuditdateNote5_3(getAuditdateNote5_3());
		clone.setAuditdateNote5_4(getAuditdateNote5_4());
		clone.setAuditdateNote5_5(getAuditdateNote5_5());
		clone.setAuditdateNote5_6(getAuditdateNote5_6());
		clone.setAuditdateNote5_7(getAuditdateNote5_7());
		clone.setAuditdateNote5_8(getAuditdateNote5_8());

		return clone;
	}

	@Override
	public int compareTo(ComplainCheckAudit complainCheckAudit) {
		long primaryKey = complainCheckAudit.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ComplainCheckAuditClp)) {
			return false;
		}

		ComplainCheckAuditClp complainCheckAudit = (ComplainCheckAuditClp)obj;

		long primaryKey = complainCheckAudit.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(141);

		sb.append("{matterId=");
		sb.append(getMatterId());
		sb.append(", aditid=");
		sb.append(getAditid());
		sb.append(", auditdate1_1=");
		sb.append(getAuditdate1_1());
		sb.append(", auditdateNote1_1=");
		sb.append(getAuditdateNote1_1());
		sb.append(", auditdate1_2=");
		sb.append(getAuditdate1_2());
		sb.append(", auditdateNote1_2=");
		sb.append(getAuditdateNote1_2());
		sb.append(", auditdate1_3=");
		sb.append(getAuditdate1_3());
		sb.append(", auditdateNote1_3=");
		sb.append(getAuditdateNote1_3());
		sb.append(", auditdate1_4=");
		sb.append(getAuditdate1_4());
		sb.append(", auditdateNote1_4=");
		sb.append(getAuditdateNote1_4());
		sb.append(", auditdate1_5=");
		sb.append(getAuditdate1_5());
		sb.append(", auditdateNote1_5=");
		sb.append(getAuditdateNote1_5());
		sb.append(", auditdate1_6=");
		sb.append(getAuditdate1_6());
		sb.append(", auditdateNote1_6=");
		sb.append(getAuditdateNote1_6());
		sb.append(", auditdate1_7=");
		sb.append(getAuditdate1_7());
		sb.append(", auditdateNote1_7=");
		sb.append(getAuditdateNote1_7());
		sb.append(", auditdate2_1=");
		sb.append(getAuditdate2_1());
		sb.append(", auditdateNote2_1=");
		sb.append(getAuditdateNote2_1());
		sb.append(", auditdate2_2=");
		sb.append(getAuditdate2_2());
		sb.append(", auditdateNote2_2=");
		sb.append(getAuditdateNote2_2());
		sb.append(", auditdate2_3=");
		sb.append(getAuditdate2_3());
		sb.append(", auditdateNote2_3=");
		sb.append(getAuditdateNote2_3());
		sb.append(", auditdate2_4=");
		sb.append(getAuditdate2_4());
		sb.append(", auditdateNote2_4=");
		sb.append(getAuditdateNote2_4());
		sb.append(", auditdate2_4_1=");
		sb.append(getAuditdate2_4_1());
		sb.append(", auditdateNote2_4_1=");
		sb.append(getAuditdateNote2_4_1());
		sb.append(", auditdate2_4_2=");
		sb.append(getAuditdate2_4_2());
		sb.append(", auditdateNote2_4_2=");
		sb.append(getAuditdateNote2_4_2());
		sb.append(", auditdate2_4_3=");
		sb.append(getAuditdate2_4_3());
		sb.append(", auditdateNote2_4_3=");
		sb.append(getAuditdateNote2_4_3());
		sb.append(", auditdate2_4_4=");
		sb.append(getAuditdate2_4_4());
		sb.append(", auditdateNote2_4_4=");
		sb.append(getAuditdateNote2_4_4());
		sb.append(", auditdate2_4_5=");
		sb.append(getAuditdate2_4_5());
		sb.append(", auditdateNote2_4_5=");
		sb.append(getAuditdateNote2_4_5());
		sb.append(", auditdate2_4_6=");
		sb.append(getAuditdate2_4_6());
		sb.append(", auditdateNote2_4_6=");
		sb.append(getAuditdateNote2_4_6());
		sb.append(", auditdate3_1=");
		sb.append(getAuditdate3_1());
		sb.append(", auditdate3_2=");
		sb.append(getAuditdate3_2());
		sb.append(", auditdate3_3=");
		sb.append(getAuditdate3_3());
		sb.append(", auditdate3_4=");
		sb.append(getAuditdate3_4());
		sb.append(", auditdate3_5=");
		sb.append(getAuditdate3_5());
		sb.append(", auditdate3_6=");
		sb.append(getAuditdate3_6());
		sb.append(", auditdateNote3_1=");
		sb.append(getAuditdateNote3_1());
		sb.append(", auditdateNote3_2=");
		sb.append(getAuditdateNote3_2());
		sb.append(", auditdateNote3_3=");
		sb.append(getAuditdateNote3_3());
		sb.append(", auditdateNote3_4=");
		sb.append(getAuditdateNote3_4());
		sb.append(", auditdateNote3_5=");
		sb.append(getAuditdateNote3_5());
		sb.append(", auditdateNote3_6=");
		sb.append(getAuditdateNote3_6());
		sb.append(", auditdate4_1=");
		sb.append(getAuditdate4_1());
		sb.append(", auditdate4_2=");
		sb.append(getAuditdate4_2());
		sb.append(", auditdate4_3=");
		sb.append(getAuditdate4_3());
		sb.append(", auditdateNote4_1=");
		sb.append(getAuditdateNote4_1());
		sb.append(", auditdateNote4_2=");
		sb.append(getAuditdateNote4_2());
		sb.append(", auditdateNote4_3=");
		sb.append(getAuditdateNote4_3());
		sb.append(", auditdate5_1=");
		sb.append(getAuditdate5_1());
		sb.append(", auditdate5_2=");
		sb.append(getAuditdate5_2());
		sb.append(", auditdate5_3=");
		sb.append(getAuditdate5_3());
		sb.append(", auditdate5_4=");
		sb.append(getAuditdate5_4());
		sb.append(", auditdate5_5=");
		sb.append(getAuditdate5_5());
		sb.append(", auditdate5_6=");
		sb.append(getAuditdate5_6());
		sb.append(", auditdate5_7=");
		sb.append(getAuditdate5_7());
		sb.append(", auditdate5_8=");
		sb.append(getAuditdate5_8());
		sb.append(", auditdateNote5_1=");
		sb.append(getAuditdateNote5_1());
		sb.append(", auditdateNote5_2=");
		sb.append(getAuditdateNote5_2());
		sb.append(", auditdateNote5_3=");
		sb.append(getAuditdateNote5_3());
		sb.append(", auditdateNote5_4=");
		sb.append(getAuditdateNote5_4());
		sb.append(", auditdateNote5_5=");
		sb.append(getAuditdateNote5_5());
		sb.append(", auditdateNote5_6=");
		sb.append(getAuditdateNote5_6());
		sb.append(", auditdateNote5_7=");
		sb.append(getAuditdateNote5_7());
		sb.append(", auditdateNote5_8=");
		sb.append(getAuditdateNote5_8());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(214);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.ComplainCheckAudit");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>matterId</column-name><column-value><![CDATA[");
		sb.append(getMatterId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>aditid</column-name><column-value><![CDATA[");
		sb.append(getAditid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate1_7</column-name><column-value><![CDATA[");
		sb.append(getAuditdate1_7());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote1_7</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote1_7());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate2_4_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdate2_4_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote2_4_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote2_4_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate3_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdate3_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote3_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote3_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate4_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate4_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate4_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate4_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate4_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate4_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote4_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote4_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote4_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote4_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote4_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote4_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_7</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_7());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdate5_8</column-name><column-value><![CDATA[");
		sb.append(getAuditdate5_8());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_1</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_2</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_3</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_3());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_4</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_4());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_5</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_5());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_6</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_6());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_7</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_7());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditdateNote5_8</column-name><column-value><![CDATA[");
		sb.append(getAuditdateNote5_8());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _matterId;
	private long _aditid;
	private String _auditdate1_1;
	private String _auditdateNote1_1;
	private String _auditdate1_2;
	private String _auditdateNote1_2;
	private String _auditdate1_3;
	private String _auditdateNote1_3;
	private String _auditdate1_4;
	private String _auditdateNote1_4;
	private String _auditdate1_5;
	private String _auditdateNote1_5;
	private String _auditdate1_6;
	private String _auditdateNote1_6;
	private String _auditdate1_7;
	private String _auditdateNote1_7;
	private String _auditdate2_1;
	private String _auditdateNote2_1;
	private String _auditdate2_2;
	private String _auditdateNote2_2;
	private String _auditdate2_3;
	private String _auditdateNote2_3;
	private String _auditdate2_4;
	private String _auditdateNote2_4;
	private String _auditdate2_4_1;
	private String _auditdateNote2_4_1;
	private String _auditdate2_4_2;
	private String _auditdateNote2_4_2;
	private String _auditdate2_4_3;
	private String _auditdateNote2_4_3;
	private String _auditdate2_4_4;
	private String _auditdateNote2_4_4;
	private String _auditdate2_4_5;
	private String _auditdateNote2_4_5;
	private String _auditdate2_4_6;
	private String _auditdateNote2_4_6;
	private String _auditdate3_1;
	private String _auditdate3_2;
	private String _auditdate3_3;
	private String _auditdate3_4;
	private String _auditdate3_5;
	private String _auditdate3_6;
	private String _auditdateNote3_1;
	private String _auditdateNote3_2;
	private String _auditdateNote3_3;
	private String _auditdateNote3_4;
	private String _auditdateNote3_5;
	private String _auditdateNote3_6;
	private String _auditdate4_1;
	private String _auditdate4_2;
	private String _auditdate4_3;
	private String _auditdateNote4_1;
	private String _auditdateNote4_2;
	private String _auditdateNote4_3;
	private String _auditdate5_1;
	private String _auditdate5_2;
	private String _auditdate5_3;
	private String _auditdate5_4;
	private String _auditdate5_5;
	private String _auditdate5_6;
	private String _auditdate5_7;
	private String _auditdate5_8;
	private String _auditdateNote5_1;
	private String _auditdateNote5_2;
	private String _auditdateNote5_3;
	private String _auditdateNote5_4;
	private String _auditdateNote5_5;
	private String _auditdateNote5_6;
	private String _auditdateNote5_7;
	private String _auditdateNote5_8;
	private BaseModel<?> _complainCheckAuditRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}