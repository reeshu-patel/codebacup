/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.ClpSerializer;
import com.spad.icop.service.CompilanceCheckLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class CompilanceCheckClp extends BaseModelImpl<CompilanceCheck>
	implements CompilanceCheck {
	public CompilanceCheckClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return CompilanceCheck.class;
	}

	@Override
	public String getModelClassName() {
		return CompilanceCheck.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _compilanceCheckid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCompilanceCheckid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _compilanceCheckid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("compilanceCheckid", getCompilanceCheckid());
		attributes.put("aditid", getAditid());
		attributes.put("company", getCompany());
		attributes.put("audidate", getAudidate());
		attributes.put("completedStatus", getCompletedStatus());
		attributes.put("auditPercentage", getAuditPercentage());
		attributes.put("questionSafetyOne", getQuestionSafetyOne());
		attributes.put("questionSafetyTwo", getQuestionSafetyTwo());
		attributes.put("questionSafetyThree", getQuestionSafetyThree());
		attributes.put("questionSafetFour", getQuestionSafetFour());
		attributes.put("questionSafetFive", getQuestionSafetFive());
		attributes.put("questionSafetSix", getQuestionSafetSix());
		attributes.put("questionSafetySeven", getQuestionSafetySeven());
		attributes.put("questionNoteOne", getQuestionNoteOne());
		attributes.put("questionNoteTwo", getQuestionNoteTwo());
		attributes.put("questionNoteThree", getQuestionNoteThree());
		attributes.put("questionNoteFour", getQuestionNoteFour());
		attributes.put("questionNoteFive", getQuestionNoteFive());
		attributes.put("questionNoteSix", getQuestionNoteSix());
		attributes.put("questionNoteSeven", getQuestionNoteSeven());
		attributes.put("questionVehicalOne", getQuestionVehicalOne());
		attributes.put("questionVehicalTwo", getQuestionVehicalTwo());
		attributes.put("questionVehicalThree", getQuestionVehicalThree());
		attributes.put("questionVehicalFour", getQuestionVehicalFour());
		attributes.put("questionVehicalFive", getQuestionVehicalFive());
		attributes.put("questionVehicalSix", getQuestionVehicalSix());
		attributes.put("questionVehicalSeven", getQuestionVehicalSeven());
		attributes.put("questionVehicalNoteOne", getQuestionVehicalNoteOne());
		attributes.put("questionVehicalNoteTwo", getQuestionVehicalNoteTwo());
		attributes.put("questionVehicalNoteThree", getQuestionVehicalNoteThree());
		attributes.put("questionVehicalNoteFour", getQuestionVehicalNoteFour());
		attributes.put("questionVehicalNoteFive", getQuestionVehicalNoteFive());
		attributes.put("questionVehicalNoteSix", getQuestionVehicalNoteSix());
		attributes.put("questionVehicalNoteSeven", getQuestionVehicalNoteSeven());
		attributes.put("questionManageOne", getQuestionManageOne());
		attributes.put("questionManageTwo", getQuestionManageTwo());
		attributes.put("questionManageThree", getQuestionManageThree());
		attributes.put("questionManageFour", getQuestionManageFour());
		attributes.put("questionManageFive", getQuestionManageFive());
		attributes.put("questionManageSix", getQuestionManageSix());
		attributes.put("questionManageSeven", getQuestionManageSeven());
		attributes.put("questionManageNoteOne", getQuestionManageNoteOne());
		attributes.put("questionManageNoteTwo", getQuestionManageNoteTwo());
		attributes.put("questionManageNoteThree", getQuestionManageNoteThree());
		attributes.put("questionManageNoteFour", getQuestionManageNoteFour());
		attributes.put("questionManageNoteFive", getQuestionManageNoteFive());
		attributes.put("questionManageNoteSix", getQuestionManageNoteSix());
		attributes.put("questionRecordsOne", getQuestionRecordsOne());
		attributes.put("questionRecordsTwo", getQuestionRecordsTwo());
		attributes.put("questionRecordsThree", getQuestionRecordsThree());
		attributes.put("questionRecordsNoteOne", getQuestionRecordsNoteOne());
		attributes.put("questionRecordsNoteTwo", getQuestionRecordsNoteTwo());
		attributes.put("questionRecordsNoteThree", getQuestionRecordsNoteThree());
		attributes.put("questionReskOne", getQuestionReskOne());
		attributes.put("questionReskTwo", getQuestionReskTwo());
		attributes.put("questionReskThree", getQuestionReskThree());
		attributes.put("questionReskFour", getQuestionReskFour());
		attributes.put("questionReskFive", getQuestionReskFive());
		attributes.put("questionReskSix", getQuestionReskSix());
		attributes.put("questionReskSeven", getQuestionReskSeven());
		attributes.put("questionReskEight", getQuestionReskEight());
		attributes.put("questionReskNoteOne", getQuestionReskNoteOne());
		attributes.put("questionReskNoteTwo", getQuestionReskNoteTwo());
		attributes.put("questionReskNoteThree", getQuestionReskNoteThree());
		attributes.put("questionReskNoteFour", getQuestionReskNoteFour());
		attributes.put("questionReskNoteFive", getQuestionReskNoteFive());
		attributes.put("questionReskNoteSix", getQuestionReskNoteSix());
		attributes.put("questionReskNoteSeven", getQuestionReskNoteSeven());
		attributes.put("questionReskNoteEight", getQuestionReskNoteEight());
		attributes.put("notcomplied", getNotcomplied());
		attributes.put("record", getRecord());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long compilanceCheckid = (Long)attributes.get("compilanceCheckid");

		if (compilanceCheckid != null) {
			setCompilanceCheckid(compilanceCheckid);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String company = (String)attributes.get("company");

		if (company != null) {
			setCompany(company);
		}

		String audidate = (String)attributes.get("audidate");

		if (audidate != null) {
			setAudidate(audidate);
		}

		String completedStatus = (String)attributes.get("completedStatus");

		if (completedStatus != null) {
			setCompletedStatus(completedStatus);
		}

		String auditPercentage = (String)attributes.get("auditPercentage");

		if (auditPercentage != null) {
			setAuditPercentage(auditPercentage);
		}

		String questionSafetyOne = (String)attributes.get("questionSafetyOne");

		if (questionSafetyOne != null) {
			setQuestionSafetyOne(questionSafetyOne);
		}

		String questionSafetyTwo = (String)attributes.get("questionSafetyTwo");

		if (questionSafetyTwo != null) {
			setQuestionSafetyTwo(questionSafetyTwo);
		}

		String questionSafetyThree = (String)attributes.get(
				"questionSafetyThree");

		if (questionSafetyThree != null) {
			setQuestionSafetyThree(questionSafetyThree);
		}

		String questionSafetFour = (String)attributes.get("questionSafetFour");

		if (questionSafetFour != null) {
			setQuestionSafetFour(questionSafetFour);
		}

		String questionSafetFive = (String)attributes.get("questionSafetFive");

		if (questionSafetFive != null) {
			setQuestionSafetFive(questionSafetFive);
		}

		String questionSafetSix = (String)attributes.get("questionSafetSix");

		if (questionSafetSix != null) {
			setQuestionSafetSix(questionSafetSix);
		}

		String questionSafetySeven = (String)attributes.get(
				"questionSafetySeven");

		if (questionSafetySeven != null) {
			setQuestionSafetySeven(questionSafetySeven);
		}

		String questionNoteOne = (String)attributes.get("questionNoteOne");

		if (questionNoteOne != null) {
			setQuestionNoteOne(questionNoteOne);
		}

		String questionNoteTwo = (String)attributes.get("questionNoteTwo");

		if (questionNoteTwo != null) {
			setQuestionNoteTwo(questionNoteTwo);
		}

		String questionNoteThree = (String)attributes.get("questionNoteThree");

		if (questionNoteThree != null) {
			setQuestionNoteThree(questionNoteThree);
		}

		String questionNoteFour = (String)attributes.get("questionNoteFour");

		if (questionNoteFour != null) {
			setQuestionNoteFour(questionNoteFour);
		}

		String questionNoteFive = (String)attributes.get("questionNoteFive");

		if (questionNoteFive != null) {
			setQuestionNoteFive(questionNoteFive);
		}

		String questionNoteSix = (String)attributes.get("questionNoteSix");

		if (questionNoteSix != null) {
			setQuestionNoteSix(questionNoteSix);
		}

		String questionNoteSeven = (String)attributes.get("questionNoteSeven");

		if (questionNoteSeven != null) {
			setQuestionNoteSeven(questionNoteSeven);
		}

		String questionVehicalOne = (String)attributes.get("questionVehicalOne");

		if (questionVehicalOne != null) {
			setQuestionVehicalOne(questionVehicalOne);
		}

		String questionVehicalTwo = (String)attributes.get("questionVehicalTwo");

		if (questionVehicalTwo != null) {
			setQuestionVehicalTwo(questionVehicalTwo);
		}

		String questionVehicalThree = (String)attributes.get(
				"questionVehicalThree");

		if (questionVehicalThree != null) {
			setQuestionVehicalThree(questionVehicalThree);
		}

		String questionVehicalFour = (String)attributes.get(
				"questionVehicalFour");

		if (questionVehicalFour != null) {
			setQuestionVehicalFour(questionVehicalFour);
		}

		String questionVehicalFive = (String)attributes.get(
				"questionVehicalFive");

		if (questionVehicalFive != null) {
			setQuestionVehicalFive(questionVehicalFive);
		}

		String questionVehicalSix = (String)attributes.get("questionVehicalSix");

		if (questionVehicalSix != null) {
			setQuestionVehicalSix(questionVehicalSix);
		}

		String questionVehicalSeven = (String)attributes.get(
				"questionVehicalSeven");

		if (questionVehicalSeven != null) {
			setQuestionVehicalSeven(questionVehicalSeven);
		}

		String questionVehicalNoteOne = (String)attributes.get(
				"questionVehicalNoteOne");

		if (questionVehicalNoteOne != null) {
			setQuestionVehicalNoteOne(questionVehicalNoteOne);
		}

		String questionVehicalNoteTwo = (String)attributes.get(
				"questionVehicalNoteTwo");

		if (questionVehicalNoteTwo != null) {
			setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
		}

		String questionVehicalNoteThree = (String)attributes.get(
				"questionVehicalNoteThree");

		if (questionVehicalNoteThree != null) {
			setQuestionVehicalNoteThree(questionVehicalNoteThree);
		}

		String questionVehicalNoteFour = (String)attributes.get(
				"questionVehicalNoteFour");

		if (questionVehicalNoteFour != null) {
			setQuestionVehicalNoteFour(questionVehicalNoteFour);
		}

		String questionVehicalNoteFive = (String)attributes.get(
				"questionVehicalNoteFive");

		if (questionVehicalNoteFive != null) {
			setQuestionVehicalNoteFive(questionVehicalNoteFive);
		}

		String questionVehicalNoteSix = (String)attributes.get(
				"questionVehicalNoteSix");

		if (questionVehicalNoteSix != null) {
			setQuestionVehicalNoteSix(questionVehicalNoteSix);
		}

		String questionVehicalNoteSeven = (String)attributes.get(
				"questionVehicalNoteSeven");

		if (questionVehicalNoteSeven != null) {
			setQuestionVehicalNoteSeven(questionVehicalNoteSeven);
		}

		String questionManageOne = (String)attributes.get("questionManageOne");

		if (questionManageOne != null) {
			setQuestionManageOne(questionManageOne);
		}

		String questionManageTwo = (String)attributes.get("questionManageTwo");

		if (questionManageTwo != null) {
			setQuestionManageTwo(questionManageTwo);
		}

		String questionManageThree = (String)attributes.get(
				"questionManageThree");

		if (questionManageThree != null) {
			setQuestionManageThree(questionManageThree);
		}

		String questionManageFour = (String)attributes.get("questionManageFour");

		if (questionManageFour != null) {
			setQuestionManageFour(questionManageFour);
		}

		String questionManageFive = (String)attributes.get("questionManageFive");

		if (questionManageFive != null) {
			setQuestionManageFive(questionManageFive);
		}

		String questionManageSix = (String)attributes.get("questionManageSix");

		if (questionManageSix != null) {
			setQuestionManageSix(questionManageSix);
		}

		String questionManageSeven = (String)attributes.get(
				"questionManageSeven");

		if (questionManageSeven != null) {
			setQuestionManageSeven(questionManageSeven);
		}

		String questionManageNoteOne = (String)attributes.get(
				"questionManageNoteOne");

		if (questionManageNoteOne != null) {
			setQuestionManageNoteOne(questionManageNoteOne);
		}

		String questionManageNoteTwo = (String)attributes.get(
				"questionManageNoteTwo");

		if (questionManageNoteTwo != null) {
			setQuestionManageNoteTwo(questionManageNoteTwo);
		}

		String questionManageNoteThree = (String)attributes.get(
				"questionManageNoteThree");

		if (questionManageNoteThree != null) {
			setQuestionManageNoteThree(questionManageNoteThree);
		}

		String questionManageNoteFour = (String)attributes.get(
				"questionManageNoteFour");

		if (questionManageNoteFour != null) {
			setQuestionManageNoteFour(questionManageNoteFour);
		}

		String questionManageNoteFive = (String)attributes.get(
				"questionManageNoteFive");

		if (questionManageNoteFive != null) {
			setQuestionManageNoteFive(questionManageNoteFive);
		}

		String questionManageNoteSix = (String)attributes.get(
				"questionManageNoteSix");

		if (questionManageNoteSix != null) {
			setQuestionManageNoteSix(questionManageNoteSix);
		}

		String questionRecordsOne = (String)attributes.get("questionRecordsOne");

		if (questionRecordsOne != null) {
			setQuestionRecordsOne(questionRecordsOne);
		}

		String questionRecordsTwo = (String)attributes.get("questionRecordsTwo");

		if (questionRecordsTwo != null) {
			setQuestionRecordsTwo(questionRecordsTwo);
		}

		String questionRecordsThree = (String)attributes.get(
				"questionRecordsThree");

		if (questionRecordsThree != null) {
			setQuestionRecordsThree(questionRecordsThree);
		}

		String questionRecordsNoteOne = (String)attributes.get(
				"questionRecordsNoteOne");

		if (questionRecordsNoteOne != null) {
			setQuestionRecordsNoteOne(questionRecordsNoteOne);
		}

		String questionRecordsNoteTwo = (String)attributes.get(
				"questionRecordsNoteTwo");

		if (questionRecordsNoteTwo != null) {
			setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
		}

		String questionRecordsNoteThree = (String)attributes.get(
				"questionRecordsNoteThree");

		if (questionRecordsNoteThree != null) {
			setQuestionRecordsNoteThree(questionRecordsNoteThree);
		}

		String questionReskOne = (String)attributes.get("questionReskOne");

		if (questionReskOne != null) {
			setQuestionReskOne(questionReskOne);
		}

		String questionReskTwo = (String)attributes.get("questionReskTwo");

		if (questionReskTwo != null) {
			setQuestionReskTwo(questionReskTwo);
		}

		String questionReskThree = (String)attributes.get("questionReskThree");

		if (questionReskThree != null) {
			setQuestionReskThree(questionReskThree);
		}

		String questionReskFour = (String)attributes.get("questionReskFour");

		if (questionReskFour != null) {
			setQuestionReskFour(questionReskFour);
		}

		String questionReskFive = (String)attributes.get("questionReskFive");

		if (questionReskFive != null) {
			setQuestionReskFive(questionReskFive);
		}

		String questionReskSix = (String)attributes.get("questionReskSix");

		if (questionReskSix != null) {
			setQuestionReskSix(questionReskSix);
		}

		String questionReskSeven = (String)attributes.get("questionReskSeven");

		if (questionReskSeven != null) {
			setQuestionReskSeven(questionReskSeven);
		}

		String questionReskEight = (String)attributes.get("questionReskEight");

		if (questionReskEight != null) {
			setQuestionReskEight(questionReskEight);
		}

		String questionReskNoteOne = (String)attributes.get(
				"questionReskNoteOne");

		if (questionReskNoteOne != null) {
			setQuestionReskNoteOne(questionReskNoteOne);
		}

		String questionReskNoteTwo = (String)attributes.get(
				"questionReskNoteTwo");

		if (questionReskNoteTwo != null) {
			setQuestionReskNoteTwo(questionReskNoteTwo);
		}

		String questionReskNoteThree = (String)attributes.get(
				"questionReskNoteThree");

		if (questionReskNoteThree != null) {
			setQuestionReskNoteThree(questionReskNoteThree);
		}

		String questionReskNoteFour = (String)attributes.get(
				"questionReskNoteFour");

		if (questionReskNoteFour != null) {
			setQuestionReskNoteFour(questionReskNoteFour);
		}

		String questionReskNoteFive = (String)attributes.get(
				"questionReskNoteFive");

		if (questionReskNoteFive != null) {
			setQuestionReskNoteFive(questionReskNoteFive);
		}

		String questionReskNoteSix = (String)attributes.get(
				"questionReskNoteSix");

		if (questionReskNoteSix != null) {
			setQuestionReskNoteSix(questionReskNoteSix);
		}

		String questionReskNoteSeven = (String)attributes.get(
				"questionReskNoteSeven");

		if (questionReskNoteSeven != null) {
			setQuestionReskNoteSeven(questionReskNoteSeven);
		}

		String questionReskNoteEight = (String)attributes.get(
				"questionReskNoteEight");

		if (questionReskNoteEight != null) {
			setQuestionReskNoteEight(questionReskNoteEight);
		}

		String notcomplied = (String)attributes.get("notcomplied");

		if (notcomplied != null) {
			setNotcomplied(notcomplied);
		}

		String record = (String)attributes.get("record");

		if (record != null) {
			setRecord(record);
		}
	}

	@Override
	public long getCompilanceCheckid() {
		return _compilanceCheckid;
	}

	@Override
	public void setCompilanceCheckid(long compilanceCheckid) {
		_compilanceCheckid = compilanceCheckid;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setCompilanceCheckid",
						long.class);

				method.invoke(_compilanceCheckRemoteModel, compilanceCheckid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAditid() {
		return _aditid;
	}

	@Override
	public void setAditid(long aditid) {
		_aditid = aditid;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setAditid", long.class);

				method.invoke(_compilanceCheckRemoteModel, aditid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompany() {
		return _company;
	}

	@Override
	public void setCompany(String company) {
		_company = company;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setCompany", String.class);

				method.invoke(_compilanceCheckRemoteModel, company);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAudidate() {
		return _audidate;
	}

	@Override
	public void setAudidate(String audidate) {
		_audidate = audidate;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setAudidate", String.class);

				method.invoke(_compilanceCheckRemoteModel, audidate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompletedStatus() {
		return _completedStatus;
	}

	@Override
	public void setCompletedStatus(String completedStatus) {
		_completedStatus = completedStatus;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setCompletedStatus",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, completedStatus);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuditPercentage() {
		return _auditPercentage;
	}

	@Override
	public void setAuditPercentage(String auditPercentage) {
		_auditPercentage = auditPercentage;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setAuditPercentage",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, auditPercentage);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetyOne() {
		return _questionSafetyOne;
	}

	@Override
	public void setQuestionSafetyOne(String questionSafetyOne) {
		_questionSafetyOne = questionSafetyOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetyOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetyOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetyTwo() {
		return _questionSafetyTwo;
	}

	@Override
	public void setQuestionSafetyTwo(String questionSafetyTwo) {
		_questionSafetyTwo = questionSafetyTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetyTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetyTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetyThree() {
		return _questionSafetyThree;
	}

	@Override
	public void setQuestionSafetyThree(String questionSafetyThree) {
		_questionSafetyThree = questionSafetyThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetyThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetyThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetFour() {
		return _questionSafetFour;
	}

	@Override
	public void setQuestionSafetFour(String questionSafetFour) {
		_questionSafetFour = questionSafetFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetFive() {
		return _questionSafetFive;
	}

	@Override
	public void setQuestionSafetFive(String questionSafetFive) {
		_questionSafetFive = questionSafetFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetSix() {
		return _questionSafetSix;
	}

	@Override
	public void setQuestionSafetSix(String questionSafetSix) {
		_questionSafetSix = questionSafetSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionSafetySeven() {
		return _questionSafetySeven;
	}

	@Override
	public void setQuestionSafetySeven(String questionSafetySeven) {
		_questionSafetySeven = questionSafetySeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionSafetySeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionSafetySeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteOne() {
		return _questionNoteOne;
	}

	@Override
	public void setQuestionNoteOne(String questionNoteOne) {
		_questionNoteOne = questionNoteOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteTwo() {
		return _questionNoteTwo;
	}

	@Override
	public void setQuestionNoteTwo(String questionNoteTwo) {
		_questionNoteTwo = questionNoteTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteThree() {
		return _questionNoteThree;
	}

	@Override
	public void setQuestionNoteThree(String questionNoteThree) {
		_questionNoteThree = questionNoteThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteFour() {
		return _questionNoteFour;
	}

	@Override
	public void setQuestionNoteFour(String questionNoteFour) {
		_questionNoteFour = questionNoteFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteFive() {
		return _questionNoteFive;
	}

	@Override
	public void setQuestionNoteFive(String questionNoteFive) {
		_questionNoteFive = questionNoteFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteSix() {
		return _questionNoteSix;
	}

	@Override
	public void setQuestionNoteSix(String questionNoteSix) {
		_questionNoteSix = questionNoteSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionNoteSeven() {
		return _questionNoteSeven;
	}

	@Override
	public void setQuestionNoteSeven(String questionNoteSeven) {
		_questionNoteSeven = questionNoteSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionNoteSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionNoteSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalOne() {
		return _questionVehicalOne;
	}

	@Override
	public void setQuestionVehicalOne(String questionVehicalOne) {
		_questionVehicalOne = questionVehicalOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalTwo() {
		return _questionVehicalTwo;
	}

	@Override
	public void setQuestionVehicalTwo(String questionVehicalTwo) {
		_questionVehicalTwo = questionVehicalTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalThree() {
		return _questionVehicalThree;
	}

	@Override
	public void setQuestionVehicalThree(String questionVehicalThree) {
		_questionVehicalThree = questionVehicalThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalFour() {
		return _questionVehicalFour;
	}

	@Override
	public void setQuestionVehicalFour(String questionVehicalFour) {
		_questionVehicalFour = questionVehicalFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalFive() {
		return _questionVehicalFive;
	}

	@Override
	public void setQuestionVehicalFive(String questionVehicalFive) {
		_questionVehicalFive = questionVehicalFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalSix() {
		return _questionVehicalSix;
	}

	@Override
	public void setQuestionVehicalSix(String questionVehicalSix) {
		_questionVehicalSix = questionVehicalSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalSeven() {
		return _questionVehicalSeven;
	}

	@Override
	public void setQuestionVehicalSeven(String questionVehicalSeven) {
		_questionVehicalSeven = questionVehicalSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionVehicalSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteOne() {
		return _questionVehicalNoteOne;
	}

	@Override
	public void setQuestionVehicalNoteOne(String questionVehicalNoteOne) {
		_questionVehicalNoteOne = questionVehicalNoteOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteTwo() {
		return _questionVehicalNoteTwo;
	}

	@Override
	public void setQuestionVehicalNoteTwo(String questionVehicalNoteTwo) {
		_questionVehicalNoteTwo = questionVehicalNoteTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteThree() {
		return _questionVehicalNoteThree;
	}

	@Override
	public void setQuestionVehicalNoteThree(String questionVehicalNoteThree) {
		_questionVehicalNoteThree = questionVehicalNoteThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteFour() {
		return _questionVehicalNoteFour;
	}

	@Override
	public void setQuestionVehicalNoteFour(String questionVehicalNoteFour) {
		_questionVehicalNoteFour = questionVehicalNoteFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteFive() {
		return _questionVehicalNoteFive;
	}

	@Override
	public void setQuestionVehicalNoteFive(String questionVehicalNoteFive) {
		_questionVehicalNoteFive = questionVehicalNoteFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteSix() {
		return _questionVehicalNoteSix;
	}

	@Override
	public void setQuestionVehicalNoteSix(String questionVehicalNoteSix) {
		_questionVehicalNoteSix = questionVehicalNoteSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionVehicalNoteSeven() {
		return _questionVehicalNoteSeven;
	}

	@Override
	public void setQuestionVehicalNoteSeven(String questionVehicalNoteSeven) {
		_questionVehicalNoteSeven = questionVehicalNoteSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionVehicalNoteSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionVehicalNoteSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageOne() {
		return _questionManageOne;
	}

	@Override
	public void setQuestionManageOne(String questionManageOne) {
		_questionManageOne = questionManageOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageTwo() {
		return _questionManageTwo;
	}

	@Override
	public void setQuestionManageTwo(String questionManageTwo) {
		_questionManageTwo = questionManageTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageThree() {
		return _questionManageThree;
	}

	@Override
	public void setQuestionManageThree(String questionManageThree) {
		_questionManageThree = questionManageThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageFour() {
		return _questionManageFour;
	}

	@Override
	public void setQuestionManageFour(String questionManageFour) {
		_questionManageFour = questionManageFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageFive() {
		return _questionManageFive;
	}

	@Override
	public void setQuestionManageFive(String questionManageFive) {
		_questionManageFive = questionManageFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageSix() {
		return _questionManageSix;
	}

	@Override
	public void setQuestionManageSix(String questionManageSix) {
		_questionManageSix = questionManageSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageSeven() {
		return _questionManageSeven;
	}

	@Override
	public void setQuestionManageSeven(String questionManageSeven) {
		_questionManageSeven = questionManageSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteOne() {
		return _questionManageNoteOne;
	}

	@Override
	public void setQuestionManageNoteOne(String questionManageNoteOne) {
		_questionManageNoteOne = questionManageNoteOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageNoteOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteTwo() {
		return _questionManageNoteTwo;
	}

	@Override
	public void setQuestionManageNoteTwo(String questionManageNoteTwo) {
		_questionManageNoteTwo = questionManageNoteTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageNoteTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteThree() {
		return _questionManageNoteThree;
	}

	@Override
	public void setQuestionManageNoteThree(String questionManageNoteThree) {
		_questionManageNoteThree = questionManageNoteThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionManageNoteThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteFour() {
		return _questionManageNoteFour;
	}

	@Override
	public void setQuestionManageNoteFour(String questionManageNoteFour) {
		_questionManageNoteFour = questionManageNoteFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionManageNoteFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteFive() {
		return _questionManageNoteFive;
	}

	@Override
	public void setQuestionManageNoteFive(String questionManageNoteFive) {
		_questionManageNoteFive = questionManageNoteFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionManageNoteFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionManageNoteSix() {
		return _questionManageNoteSix;
	}

	@Override
	public void setQuestionManageNoteSix(String questionManageNoteSix) {
		_questionManageNoteSix = questionManageNoteSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionManageNoteSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionManageNoteSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsOne() {
		return _questionRecordsOne;
	}

	@Override
	public void setQuestionRecordsOne(String questionRecordsOne) {
		_questionRecordsOne = questionRecordsOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionRecordsOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsTwo() {
		return _questionRecordsTwo;
	}

	@Override
	public void setQuestionRecordsTwo(String questionRecordsTwo) {
		_questionRecordsTwo = questionRecordsTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionRecordsTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsThree() {
		return _questionRecordsThree;
	}

	@Override
	public void setQuestionRecordsThree(String questionRecordsThree) {
		_questionRecordsThree = questionRecordsThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionRecordsThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsNoteOne() {
		return _questionRecordsNoteOne;
	}

	@Override
	public void setQuestionRecordsNoteOne(String questionRecordsNoteOne) {
		_questionRecordsNoteOne = questionRecordsNoteOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsNoteOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionRecordsNoteOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsNoteTwo() {
		return _questionRecordsNoteTwo;
	}

	@Override
	public void setQuestionRecordsNoteTwo(String questionRecordsNoteTwo) {
		_questionRecordsNoteTwo = questionRecordsNoteTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsNoteTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionRecordsNoteTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionRecordsNoteThree() {
		return _questionRecordsNoteThree;
	}

	@Override
	public void setQuestionRecordsNoteThree(String questionRecordsNoteThree) {
		_questionRecordsNoteThree = questionRecordsNoteThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionRecordsNoteThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel,
					questionRecordsNoteThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskOne() {
		return _questionReskOne;
	}

	@Override
	public void setQuestionReskOne(String questionReskOne) {
		_questionReskOne = questionReskOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskTwo() {
		return _questionReskTwo;
	}

	@Override
	public void setQuestionReskTwo(String questionReskTwo) {
		_questionReskTwo = questionReskTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskThree() {
		return _questionReskThree;
	}

	@Override
	public void setQuestionReskThree(String questionReskThree) {
		_questionReskThree = questionReskThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskFour() {
		return _questionReskFour;
	}

	@Override
	public void setQuestionReskFour(String questionReskFour) {
		_questionReskFour = questionReskFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskFive() {
		return _questionReskFive;
	}

	@Override
	public void setQuestionReskFive(String questionReskFive) {
		_questionReskFive = questionReskFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskSix() {
		return _questionReskSix;
	}

	@Override
	public void setQuestionReskSix(String questionReskSix) {
		_questionReskSix = questionReskSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskSeven() {
		return _questionReskSeven;
	}

	@Override
	public void setQuestionReskSeven(String questionReskSeven) {
		_questionReskSeven = questionReskSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskEight() {
		return _questionReskEight;
	}

	@Override
	public void setQuestionReskEight(String questionReskEight) {
		_questionReskEight = questionReskEight;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskEight",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskEight);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteOne() {
		return _questionReskNoteOne;
	}

	@Override
	public void setQuestionReskNoteOne(String questionReskNoteOne) {
		_questionReskNoteOne = questionReskNoteOne;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteOne",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteOne);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteTwo() {
		return _questionReskNoteTwo;
	}

	@Override
	public void setQuestionReskNoteTwo(String questionReskNoteTwo) {
		_questionReskNoteTwo = questionReskNoteTwo;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteTwo",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteThree() {
		return _questionReskNoteThree;
	}

	@Override
	public void setQuestionReskNoteThree(String questionReskNoteThree) {
		_questionReskNoteThree = questionReskNoteThree;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteThree",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteThree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteFour() {
		return _questionReskNoteFour;
	}

	@Override
	public void setQuestionReskNoteFour(String questionReskNoteFour) {
		_questionReskNoteFour = questionReskNoteFour;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteFour",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteFour);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteFive() {
		return _questionReskNoteFive;
	}

	@Override
	public void setQuestionReskNoteFive(String questionReskNoteFive) {
		_questionReskNoteFive = questionReskNoteFive;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteFive",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteFive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteSix() {
		return _questionReskNoteSix;
	}

	@Override
	public void setQuestionReskNoteSix(String questionReskNoteSix) {
		_questionReskNoteSix = questionReskNoteSix;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteSix",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteSix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteSeven() {
		return _questionReskNoteSeven;
	}

	@Override
	public void setQuestionReskNoteSeven(String questionReskNoteSeven) {
		_questionReskNoteSeven = questionReskNoteSeven;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteSeven",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteSeven);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQuestionReskNoteEight() {
		return _questionReskNoteEight;
	}

	@Override
	public void setQuestionReskNoteEight(String questionReskNoteEight) {
		_questionReskNoteEight = questionReskNoteEight;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setQuestionReskNoteEight",
						String.class);

				method.invoke(_compilanceCheckRemoteModel, questionReskNoteEight);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNotcomplied() {
		return _notcomplied;
	}

	@Override
	public void setNotcomplied(String notcomplied) {
		_notcomplied = notcomplied;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setNotcomplied", String.class);

				method.invoke(_compilanceCheckRemoteModel, notcomplied);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecord() {
		return _record;
	}

	@Override
	public void setRecord(String record) {
		_record = record;

		if (_compilanceCheckRemoteModel != null) {
			try {
				Class<?> clazz = _compilanceCheckRemoteModel.getClass();

				Method method = clazz.getMethod("setRecord", String.class);

				method.invoke(_compilanceCheckRemoteModel, record);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getCompilanceCheckRemoteModel() {
		return _compilanceCheckRemoteModel;
	}

	public void setCompilanceCheckRemoteModel(
		BaseModel<?> compilanceCheckRemoteModel) {
		_compilanceCheckRemoteModel = compilanceCheckRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _compilanceCheckRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_compilanceCheckRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			CompilanceCheckLocalServiceUtil.addCompilanceCheck(this);
		}
		else {
			CompilanceCheckLocalServiceUtil.updateCompilanceCheck(this);
		}
	}

	@Override
	public CompilanceCheck toEscapedModel() {
		return (CompilanceCheck)ProxyUtil.newProxyInstance(CompilanceCheck.class.getClassLoader(),
			new Class[] { CompilanceCheck.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		CompilanceCheckClp clone = new CompilanceCheckClp();

		clone.setCompilanceCheckid(getCompilanceCheckid());
		clone.setAditid(getAditid());
		clone.setCompany(getCompany());
		clone.setAudidate(getAudidate());
		clone.setCompletedStatus(getCompletedStatus());
		clone.setAuditPercentage(getAuditPercentage());
		clone.setQuestionSafetyOne(getQuestionSafetyOne());
		clone.setQuestionSafetyTwo(getQuestionSafetyTwo());
		clone.setQuestionSafetyThree(getQuestionSafetyThree());
		clone.setQuestionSafetFour(getQuestionSafetFour());
		clone.setQuestionSafetFive(getQuestionSafetFive());
		clone.setQuestionSafetSix(getQuestionSafetSix());
		clone.setQuestionSafetySeven(getQuestionSafetySeven());
		clone.setQuestionNoteOne(getQuestionNoteOne());
		clone.setQuestionNoteTwo(getQuestionNoteTwo());
		clone.setQuestionNoteThree(getQuestionNoteThree());
		clone.setQuestionNoteFour(getQuestionNoteFour());
		clone.setQuestionNoteFive(getQuestionNoteFive());
		clone.setQuestionNoteSix(getQuestionNoteSix());
		clone.setQuestionNoteSeven(getQuestionNoteSeven());
		clone.setQuestionVehicalOne(getQuestionVehicalOne());
		clone.setQuestionVehicalTwo(getQuestionVehicalTwo());
		clone.setQuestionVehicalThree(getQuestionVehicalThree());
		clone.setQuestionVehicalFour(getQuestionVehicalFour());
		clone.setQuestionVehicalFive(getQuestionVehicalFive());
		clone.setQuestionVehicalSix(getQuestionVehicalSix());
		clone.setQuestionVehicalSeven(getQuestionVehicalSeven());
		clone.setQuestionVehicalNoteOne(getQuestionVehicalNoteOne());
		clone.setQuestionVehicalNoteTwo(getQuestionVehicalNoteTwo());
		clone.setQuestionVehicalNoteThree(getQuestionVehicalNoteThree());
		clone.setQuestionVehicalNoteFour(getQuestionVehicalNoteFour());
		clone.setQuestionVehicalNoteFive(getQuestionVehicalNoteFive());
		clone.setQuestionVehicalNoteSix(getQuestionVehicalNoteSix());
		clone.setQuestionVehicalNoteSeven(getQuestionVehicalNoteSeven());
		clone.setQuestionManageOne(getQuestionManageOne());
		clone.setQuestionManageTwo(getQuestionManageTwo());
		clone.setQuestionManageThree(getQuestionManageThree());
		clone.setQuestionManageFour(getQuestionManageFour());
		clone.setQuestionManageFive(getQuestionManageFive());
		clone.setQuestionManageSix(getQuestionManageSix());
		clone.setQuestionManageSeven(getQuestionManageSeven());
		clone.setQuestionManageNoteOne(getQuestionManageNoteOne());
		clone.setQuestionManageNoteTwo(getQuestionManageNoteTwo());
		clone.setQuestionManageNoteThree(getQuestionManageNoteThree());
		clone.setQuestionManageNoteFour(getQuestionManageNoteFour());
		clone.setQuestionManageNoteFive(getQuestionManageNoteFive());
		clone.setQuestionManageNoteSix(getQuestionManageNoteSix());
		clone.setQuestionRecordsOne(getQuestionRecordsOne());
		clone.setQuestionRecordsTwo(getQuestionRecordsTwo());
		clone.setQuestionRecordsThree(getQuestionRecordsThree());
		clone.setQuestionRecordsNoteOne(getQuestionRecordsNoteOne());
		clone.setQuestionRecordsNoteTwo(getQuestionRecordsNoteTwo());
		clone.setQuestionRecordsNoteThree(getQuestionRecordsNoteThree());
		clone.setQuestionReskOne(getQuestionReskOne());
		clone.setQuestionReskTwo(getQuestionReskTwo());
		clone.setQuestionReskThree(getQuestionReskThree());
		clone.setQuestionReskFour(getQuestionReskFour());
		clone.setQuestionReskFive(getQuestionReskFive());
		clone.setQuestionReskSix(getQuestionReskSix());
		clone.setQuestionReskSeven(getQuestionReskSeven());
		clone.setQuestionReskEight(getQuestionReskEight());
		clone.setQuestionReskNoteOne(getQuestionReskNoteOne());
		clone.setQuestionReskNoteTwo(getQuestionReskNoteTwo());
		clone.setQuestionReskNoteThree(getQuestionReskNoteThree());
		clone.setQuestionReskNoteFour(getQuestionReskNoteFour());
		clone.setQuestionReskNoteFive(getQuestionReskNoteFive());
		clone.setQuestionReskNoteSix(getQuestionReskNoteSix());
		clone.setQuestionReskNoteSeven(getQuestionReskNoteSeven());
		clone.setQuestionReskNoteEight(getQuestionReskNoteEight());
		clone.setNotcomplied(getNotcomplied());
		clone.setRecord(getRecord());

		return clone;
	}

	@Override
	public int compareTo(CompilanceCheck compilanceCheck) {
		long primaryKey = compilanceCheck.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CompilanceCheckClp)) {
			return false;
		}

		CompilanceCheckClp compilanceCheck = (CompilanceCheckClp)obj;

		long primaryKey = compilanceCheck.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(143);

		sb.append("{compilanceCheckid=");
		sb.append(getCompilanceCheckid());
		sb.append(", aditid=");
		sb.append(getAditid());
		sb.append(", company=");
		sb.append(getCompany());
		sb.append(", audidate=");
		sb.append(getAudidate());
		sb.append(", completedStatus=");
		sb.append(getCompletedStatus());
		sb.append(", auditPercentage=");
		sb.append(getAuditPercentage());
		sb.append(", questionSafetyOne=");
		sb.append(getQuestionSafetyOne());
		sb.append(", questionSafetyTwo=");
		sb.append(getQuestionSafetyTwo());
		sb.append(", questionSafetyThree=");
		sb.append(getQuestionSafetyThree());
		sb.append(", questionSafetFour=");
		sb.append(getQuestionSafetFour());
		sb.append(", questionSafetFive=");
		sb.append(getQuestionSafetFive());
		sb.append(", questionSafetSix=");
		sb.append(getQuestionSafetSix());
		sb.append(", questionSafetySeven=");
		sb.append(getQuestionSafetySeven());
		sb.append(", questionNoteOne=");
		sb.append(getQuestionNoteOne());
		sb.append(", questionNoteTwo=");
		sb.append(getQuestionNoteTwo());
		sb.append(", questionNoteThree=");
		sb.append(getQuestionNoteThree());
		sb.append(", questionNoteFour=");
		sb.append(getQuestionNoteFour());
		sb.append(", questionNoteFive=");
		sb.append(getQuestionNoteFive());
		sb.append(", questionNoteSix=");
		sb.append(getQuestionNoteSix());
		sb.append(", questionNoteSeven=");
		sb.append(getQuestionNoteSeven());
		sb.append(", questionVehicalOne=");
		sb.append(getQuestionVehicalOne());
		sb.append(", questionVehicalTwo=");
		sb.append(getQuestionVehicalTwo());
		sb.append(", questionVehicalThree=");
		sb.append(getQuestionVehicalThree());
		sb.append(", questionVehicalFour=");
		sb.append(getQuestionVehicalFour());
		sb.append(", questionVehicalFive=");
		sb.append(getQuestionVehicalFive());
		sb.append(", questionVehicalSix=");
		sb.append(getQuestionVehicalSix());
		sb.append(", questionVehicalSeven=");
		sb.append(getQuestionVehicalSeven());
		sb.append(", questionVehicalNoteOne=");
		sb.append(getQuestionVehicalNoteOne());
		sb.append(", questionVehicalNoteTwo=");
		sb.append(getQuestionVehicalNoteTwo());
		sb.append(", questionVehicalNoteThree=");
		sb.append(getQuestionVehicalNoteThree());
		sb.append(", questionVehicalNoteFour=");
		sb.append(getQuestionVehicalNoteFour());
		sb.append(", questionVehicalNoteFive=");
		sb.append(getQuestionVehicalNoteFive());
		sb.append(", questionVehicalNoteSix=");
		sb.append(getQuestionVehicalNoteSix());
		sb.append(", questionVehicalNoteSeven=");
		sb.append(getQuestionVehicalNoteSeven());
		sb.append(", questionManageOne=");
		sb.append(getQuestionManageOne());
		sb.append(", questionManageTwo=");
		sb.append(getQuestionManageTwo());
		sb.append(", questionManageThree=");
		sb.append(getQuestionManageThree());
		sb.append(", questionManageFour=");
		sb.append(getQuestionManageFour());
		sb.append(", questionManageFive=");
		sb.append(getQuestionManageFive());
		sb.append(", questionManageSix=");
		sb.append(getQuestionManageSix());
		sb.append(", questionManageSeven=");
		sb.append(getQuestionManageSeven());
		sb.append(", questionManageNoteOne=");
		sb.append(getQuestionManageNoteOne());
		sb.append(", questionManageNoteTwo=");
		sb.append(getQuestionManageNoteTwo());
		sb.append(", questionManageNoteThree=");
		sb.append(getQuestionManageNoteThree());
		sb.append(", questionManageNoteFour=");
		sb.append(getQuestionManageNoteFour());
		sb.append(", questionManageNoteFive=");
		sb.append(getQuestionManageNoteFive());
		sb.append(", questionManageNoteSix=");
		sb.append(getQuestionManageNoteSix());
		sb.append(", questionRecordsOne=");
		sb.append(getQuestionRecordsOne());
		sb.append(", questionRecordsTwo=");
		sb.append(getQuestionRecordsTwo());
		sb.append(", questionRecordsThree=");
		sb.append(getQuestionRecordsThree());
		sb.append(", questionRecordsNoteOne=");
		sb.append(getQuestionRecordsNoteOne());
		sb.append(", questionRecordsNoteTwo=");
		sb.append(getQuestionRecordsNoteTwo());
		sb.append(", questionRecordsNoteThree=");
		sb.append(getQuestionRecordsNoteThree());
		sb.append(", questionReskOne=");
		sb.append(getQuestionReskOne());
		sb.append(", questionReskTwo=");
		sb.append(getQuestionReskTwo());
		sb.append(", questionReskThree=");
		sb.append(getQuestionReskThree());
		sb.append(", questionReskFour=");
		sb.append(getQuestionReskFour());
		sb.append(", questionReskFive=");
		sb.append(getQuestionReskFive());
		sb.append(", questionReskSix=");
		sb.append(getQuestionReskSix());
		sb.append(", questionReskSeven=");
		sb.append(getQuestionReskSeven());
		sb.append(", questionReskEight=");
		sb.append(getQuestionReskEight());
		sb.append(", questionReskNoteOne=");
		sb.append(getQuestionReskNoteOne());
		sb.append(", questionReskNoteTwo=");
		sb.append(getQuestionReskNoteTwo());
		sb.append(", questionReskNoteThree=");
		sb.append(getQuestionReskNoteThree());
		sb.append(", questionReskNoteFour=");
		sb.append(getQuestionReskNoteFour());
		sb.append(", questionReskNoteFive=");
		sb.append(getQuestionReskNoteFive());
		sb.append(", questionReskNoteSix=");
		sb.append(getQuestionReskNoteSix());
		sb.append(", questionReskNoteSeven=");
		sb.append(getQuestionReskNoteSeven());
		sb.append(", questionReskNoteEight=");
		sb.append(getQuestionReskNoteEight());
		sb.append(", notcomplied=");
		sb.append(getNotcomplied());
		sb.append(", record=");
		sb.append(getRecord());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(217);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.CompilanceCheck");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>compilanceCheckid</column-name><column-value><![CDATA[");
		sb.append(getCompilanceCheckid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>aditid</column-name><column-value><![CDATA[");
		sb.append(getAditid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>company</column-name><column-value><![CDATA[");
		sb.append(getCompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>audidate</column-name><column-value><![CDATA[");
		sb.append(getAudidate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>completedStatus</column-name><column-value><![CDATA[");
		sb.append(getCompletedStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>auditPercentage</column-name><column-value><![CDATA[");
		sb.append(getAuditPercentage());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetyOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetyOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetyTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetyTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetyThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetyThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionSafetySeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionSafetySeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionNoteSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionNoteSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionVehicalNoteSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionVehicalNoteSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionManageNoteSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionManageNoteSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsNoteOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsNoteOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsNoteTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsNoteTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionRecordsNoteThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionRecordsNoteThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskEight</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskEight());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteOne</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteOne());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteTwo</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteThree</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteThree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteFour</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteFour());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteFive</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteFive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteSix</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteSix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteSeven</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteSeven());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>questionReskNoteEight</column-name><column-value><![CDATA[");
		sb.append(getQuestionReskNoteEight());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>notcomplied</column-name><column-value><![CDATA[");
		sb.append(getNotcomplied());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>record</column-name><column-value><![CDATA[");
		sb.append(getRecord());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _compilanceCheckid;
	private long _aditid;
	private String _company;
	private String _audidate;
	private String _completedStatus;
	private String _auditPercentage;
	private String _questionSafetyOne;
	private String _questionSafetyTwo;
	private String _questionSafetyThree;
	private String _questionSafetFour;
	private String _questionSafetFive;
	private String _questionSafetSix;
	private String _questionSafetySeven;
	private String _questionNoteOne;
	private String _questionNoteTwo;
	private String _questionNoteThree;
	private String _questionNoteFour;
	private String _questionNoteFive;
	private String _questionNoteSix;
	private String _questionNoteSeven;
	private String _questionVehicalOne;
	private String _questionVehicalTwo;
	private String _questionVehicalThree;
	private String _questionVehicalFour;
	private String _questionVehicalFive;
	private String _questionVehicalSix;
	private String _questionVehicalSeven;
	private String _questionVehicalNoteOne;
	private String _questionVehicalNoteTwo;
	private String _questionVehicalNoteThree;
	private String _questionVehicalNoteFour;
	private String _questionVehicalNoteFive;
	private String _questionVehicalNoteSix;
	private String _questionVehicalNoteSeven;
	private String _questionManageOne;
	private String _questionManageTwo;
	private String _questionManageThree;
	private String _questionManageFour;
	private String _questionManageFive;
	private String _questionManageSix;
	private String _questionManageSeven;
	private String _questionManageNoteOne;
	private String _questionManageNoteTwo;
	private String _questionManageNoteThree;
	private String _questionManageNoteFour;
	private String _questionManageNoteFive;
	private String _questionManageNoteSix;
	private String _questionRecordsOne;
	private String _questionRecordsTwo;
	private String _questionRecordsThree;
	private String _questionRecordsNoteOne;
	private String _questionRecordsNoteTwo;
	private String _questionRecordsNoteThree;
	private String _questionReskOne;
	private String _questionReskTwo;
	private String _questionReskThree;
	private String _questionReskFour;
	private String _questionReskFive;
	private String _questionReskSix;
	private String _questionReskSeven;
	private String _questionReskEight;
	private String _questionReskNoteOne;
	private String _questionReskNoteTwo;
	private String _questionReskNoteThree;
	private String _questionReskNoteFour;
	private String _questionReskNoteFive;
	private String _questionReskNoteSix;
	private String _questionReskNoteSeven;
	private String _questionReskNoteEight;
	private String _notcomplied;
	private String _record;
	private BaseModel<?> _compilanceCheckRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}