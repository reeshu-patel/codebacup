/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.AppointmentCallServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.AppointmentCallServiceSoap
 * @generated
 */
public class AppointmentCallSoap implements Serializable {
	public static AppointmentCallSoap toSoapModel(AppointmentCall model) {
		AppointmentCallSoap soapModel = new AppointmentCallSoap();

		soapModel.setRecordcallid(model.getRecordcallid());
		soapModel.setAditid(model.getAditid());
		soapModel.setDateonroadsafty(model.getDateonroadsafty());
		soapModel.setTime(model.getTime());
		soapModel.setInvestigationtitle(model.getInvestigationtitle());
		soapModel.setLocation(model.getLocation());
		soapModel.setCompany(model.getCompany());
		soapModel.setStatusverification(model.getStatusverification());
		soapModel.setOperatorname(model.getOperatorname());
		soapModel.setNameofOfficer(model.getNameofOfficer());

		return soapModel;
	}

	public static AppointmentCallSoap[] toSoapModels(AppointmentCall[] models) {
		AppointmentCallSoap[] soapModels = new AppointmentCallSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static AppointmentCallSoap[][] toSoapModels(
		AppointmentCall[][] models) {
		AppointmentCallSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new AppointmentCallSoap[models.length][models[0].length];
		}
		else {
			soapModels = new AppointmentCallSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static AppointmentCallSoap[] toSoapModels(
		List<AppointmentCall> models) {
		List<AppointmentCallSoap> soapModels = new ArrayList<AppointmentCallSoap>(models.size());

		for (AppointmentCall model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new AppointmentCallSoap[soapModels.size()]);
	}

	public AppointmentCallSoap() {
	}

	public long getPrimaryKey() {
		return _recordcallid;
	}

	public void setPrimaryKey(long pk) {
		setRecordcallid(pk);
	}

	public long getRecordcallid() {
		return _recordcallid;
	}

	public void setRecordcallid(long recordcallid) {
		_recordcallid = recordcallid;
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getDateonroadsafty() {
		return _dateonroadsafty;
	}

	public void setDateonroadsafty(String dateonroadsafty) {
		_dateonroadsafty = dateonroadsafty;
	}

	public String getTime() {
		return _time;
	}

	public void setTime(String time) {
		_time = time;
	}

	public String getInvestigationtitle() {
		return _investigationtitle;
	}

	public void setInvestigationtitle(String investigationtitle) {
		_investigationtitle = investigationtitle;
	}

	public String getLocation() {
		return _location;
	}

	public void setLocation(String location) {
		_location = location;
	}

	public String getCompany() {
		return _company;
	}

	public void setCompany(String company) {
		_company = company;
	}

	public String getStatusverification() {
		return _statusverification;
	}

	public void setStatusverification(String statusverification) {
		_statusverification = statusverification;
	}

	public String getOperatorname() {
		return _operatorname;
	}

	public void setOperatorname(String operatorname) {
		_operatorname = operatorname;
	}

	public String getNameofOfficer() {
		return _nameofOfficer;
	}

	public void setNameofOfficer(String nameofOfficer) {
		_nameofOfficer = nameofOfficer;
	}

	private long _recordcallid;
	private long _aditid;
	private String _dateonroadsafty;
	private String _time;
	private String _investigationtitle;
	private String _location;
	private String _company;
	private String _statusverification;
	private String _operatorname;
	private String _nameofOfficer;
}