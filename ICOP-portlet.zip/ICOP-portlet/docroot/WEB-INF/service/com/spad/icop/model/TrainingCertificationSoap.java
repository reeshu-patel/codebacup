/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.spad.icop.service.http.TrainingCertificationServiceSoap}.
 *
 * @author reeshu
 * @see com.spad.icop.service.http.TrainingCertificationServiceSoap
 * @generated
 */
public class TrainingCertificationSoap implements Serializable {
	public static TrainingCertificationSoap toSoapModel(
		TrainingCertification model) {
		TrainingCertificationSoap soapModel = new TrainingCertificationSoap();

		soapModel.setTrainingCertifiId(model.getTrainingCertifiId());
		soapModel.setAditid(model.getAditid());
		soapModel.setTrainingDates(model.getTrainingDates());
		soapModel.setExerciseName(model.getExerciseName());
		soapModel.setPointsExercise(model.getPointsExercise());
		soapModel.setNameOfficer(model.getNameOfficer());
		soapModel.setNumber(model.getNumber());
		soapModel.setStatusExercise(model.getStatusExercise());
		soapModel.setStatusMoulds(model.getStatusMoulds());
		soapModel.setCompanyName(model.getCompanyName());
		soapModel.setAddress(model.getAddress());
		soapModel.setEmail(model.getEmail());
		soapModel.setOperatorName(model.getOperatorName());
		soapModel.setTypeVehicle(model.getTypeVehicle());
		soapModel.setNoVehicles(model.getNoVehicles());

		return soapModel;
	}

	public static TrainingCertificationSoap[] toSoapModels(
		TrainingCertification[] models) {
		TrainingCertificationSoap[] soapModels = new TrainingCertificationSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static TrainingCertificationSoap[][] toSoapModels(
		TrainingCertification[][] models) {
		TrainingCertificationSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new TrainingCertificationSoap[models.length][models[0].length];
		}
		else {
			soapModels = new TrainingCertificationSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static TrainingCertificationSoap[] toSoapModels(
		List<TrainingCertification> models) {
		List<TrainingCertificationSoap> soapModels = new ArrayList<TrainingCertificationSoap>(models.size());

		for (TrainingCertification model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new TrainingCertificationSoap[soapModels.size()]);
	}

	public TrainingCertificationSoap() {
	}

	public long getPrimaryKey() {
		return _trainingCertifiId;
	}

	public void setPrimaryKey(long pk) {
		setTrainingCertifiId(pk);
	}

	public long getTrainingCertifiId() {
		return _trainingCertifiId;
	}

	public void setTrainingCertifiId(long trainingCertifiId) {
		_trainingCertifiId = trainingCertifiId;
	}

	public long getAditid() {
		return _aditid;
	}

	public void setAditid(long aditid) {
		_aditid = aditid;
	}

	public String getTrainingDates() {
		return _trainingDates;
	}

	public void setTrainingDates(String trainingDates) {
		_trainingDates = trainingDates;
	}

	public String getExerciseName() {
		return _exerciseName;
	}

	public void setExerciseName(String exerciseName) {
		_exerciseName = exerciseName;
	}

	public String getPointsExercise() {
		return _pointsExercise;
	}

	public void setPointsExercise(String pointsExercise) {
		_pointsExercise = pointsExercise;
	}

	public String getNameOfficer() {
		return _nameOfficer;
	}

	public void setNameOfficer(String nameOfficer) {
		_nameOfficer = nameOfficer;
	}

	public String getNumber() {
		return _number;
	}

	public void setNumber(String number) {
		_number = number;
	}

	public String getStatusExercise() {
		return _statusExercise;
	}

	public void setStatusExercise(String statusExercise) {
		_statusExercise = statusExercise;
	}

	public String getStatusMoulds() {
		return _statusMoulds;
	}

	public void setStatusMoulds(String statusMoulds) {
		_statusMoulds = statusMoulds;
	}

	public String getCompanyName() {
		return _companyName;
	}

	public void setCompanyName(String companyName) {
		_companyName = companyName;
	}

	public String getAddress() {
		return _address;
	}

	public void setAddress(String address) {
		_address = address;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getOperatorName() {
		return _operatorName;
	}

	public void setOperatorName(String operatorName) {
		_operatorName = operatorName;
	}

	public String getTypeVehicle() {
		return _typeVehicle;
	}

	public void setTypeVehicle(String typeVehicle) {
		_typeVehicle = typeVehicle;
	}

	public String getNoVehicles() {
		return _noVehicles;
	}

	public void setNoVehicles(String noVehicles) {
		_noVehicles = noVehicles;
	}

	private long _trainingCertifiId;
	private long _aditid;
	private String _trainingDates;
	private String _exerciseName;
	private String _pointsExercise;
	private String _nameOfficer;
	private String _number;
	private String _statusExercise;
	private String _statusMoulds;
	private String _companyName;
	private String _address;
	private String _email;
	private String _operatorName;
	private String _typeVehicle;
	private String _noVehicles;
}