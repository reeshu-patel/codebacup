/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.spad.icop.model.TrainingCertification;

import java.util.List;

/**
 * The persistence utility for the training certification service. This utility wraps {@link TrainingCertificationPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see TrainingCertificationPersistence
 * @see TrainingCertificationPersistenceImpl
 * @generated
 */
public class TrainingCertificationUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(TrainingCertification trainingCertification) {
		getPersistence().clearCache(trainingCertification);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<TrainingCertification> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<TrainingCertification> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<TrainingCertification> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static TrainingCertification update(
		TrainingCertification trainingCertification) throws SystemException {
		return getPersistence().update(trainingCertification);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static TrainingCertification update(
		TrainingCertification trainingCertification,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(trainingCertification, serviceContext);
	}

	/**
	* Returns all the training certifications where aditid = &#63;.
	*
	* @param aditid the aditid
	* @return the matching training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findByaditid(
		long aditid) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByaditid(aditid);
	}

	/**
	* Returns a range of all the training certifications where aditid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.TrainingCertificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param start the lower bound of the range of training certifications
	* @param end the upper bound of the range of training certifications (not inclusive)
	* @return the range of matching training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findByaditid(
		long aditid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByaditid(aditid, start, end);
	}

	/**
	* Returns an ordered range of all the training certifications where aditid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.TrainingCertificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param aditid the aditid
	* @param start the lower bound of the range of training certifications
	* @param end the upper bound of the range of training certifications (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findByaditid(
		long aditid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByaditid(aditid, start, end, orderByComparator);
	}

	/**
	* Returns the first training certification in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training certification
	* @throws com.spad.icop.NoSuchTrainingCertificationException if a matching training certification could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification findByaditid_First(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchTrainingCertificationException {
		return getPersistence().findByaditid_First(aditid, orderByComparator);
	}

	/**
	* Returns the first training certification in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training certification, or <code>null</code> if a matching training certification could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification fetchByaditid_First(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByaditid_First(aditid, orderByComparator);
	}

	/**
	* Returns the last training certification in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training certification
	* @throws com.spad.icop.NoSuchTrainingCertificationException if a matching training certification could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification findByaditid_Last(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchTrainingCertificationException {
		return getPersistence().findByaditid_Last(aditid, orderByComparator);
	}

	/**
	* Returns the last training certification in the ordered set where aditid = &#63;.
	*
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training certification, or <code>null</code> if a matching training certification could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification fetchByaditid_Last(
		long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByaditid_Last(aditid, orderByComparator);
	}

	/**
	* Returns the training certifications before and after the current training certification in the ordered set where aditid = &#63;.
	*
	* @param trainingCertifiId the primary key of the current training certification
	* @param aditid the aditid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next training certification
	* @throws com.spad.icop.NoSuchTrainingCertificationException if a training certification with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification[] findByaditid_PrevAndNext(
		long trainingCertifiId, long aditid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchTrainingCertificationException {
		return getPersistence()
				   .findByaditid_PrevAndNext(trainingCertifiId, aditid,
			orderByComparator);
	}

	/**
	* Removes all the training certifications where aditid = &#63; from the database.
	*
	* @param aditid the aditid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByaditid(long aditid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByaditid(aditid);
	}

	/**
	* Returns the number of training certifications where aditid = &#63;.
	*
	* @param aditid the aditid
	* @return the number of matching training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static int countByaditid(long aditid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByaditid(aditid);
	}

	/**
	* Caches the training certification in the entity cache if it is enabled.
	*
	* @param trainingCertification the training certification
	*/
	public static void cacheResult(
		com.spad.icop.model.TrainingCertification trainingCertification) {
		getPersistence().cacheResult(trainingCertification);
	}

	/**
	* Caches the training certifications in the entity cache if it is enabled.
	*
	* @param trainingCertifications the training certifications
	*/
	public static void cacheResult(
		java.util.List<com.spad.icop.model.TrainingCertification> trainingCertifications) {
		getPersistence().cacheResult(trainingCertifications);
	}

	/**
	* Creates a new training certification with the primary key. Does not add the training certification to the database.
	*
	* @param trainingCertifiId the primary key for the new training certification
	* @return the new training certification
	*/
	public static com.spad.icop.model.TrainingCertification create(
		long trainingCertifiId) {
		return getPersistence().create(trainingCertifiId);
	}

	/**
	* Removes the training certification with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param trainingCertifiId the primary key of the training certification
	* @return the training certification that was removed
	* @throws com.spad.icop.NoSuchTrainingCertificationException if a training certification with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification remove(
		long trainingCertifiId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchTrainingCertificationException {
		return getPersistence().remove(trainingCertifiId);
	}

	public static com.spad.icop.model.TrainingCertification updateImpl(
		com.spad.icop.model.TrainingCertification trainingCertification)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(trainingCertification);
	}

	/**
	* Returns the training certification with the primary key or throws a {@link com.spad.icop.NoSuchTrainingCertificationException} if it could not be found.
	*
	* @param trainingCertifiId the primary key of the training certification
	* @return the training certification
	* @throws com.spad.icop.NoSuchTrainingCertificationException if a training certification with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification findByPrimaryKey(
		long trainingCertifiId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.spad.icop.NoSuchTrainingCertificationException {
		return getPersistence().findByPrimaryKey(trainingCertifiId);
	}

	/**
	* Returns the training certification with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param trainingCertifiId the primary key of the training certification
	* @return the training certification, or <code>null</code> if a training certification with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.spad.icop.model.TrainingCertification fetchByPrimaryKey(
		long trainingCertifiId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(trainingCertifiId);
	}

	/**
	* Returns all the training certifications.
	*
	* @return the training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the training certifications.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.TrainingCertificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of training certifications
	* @param end the upper bound of the range of training certifications (not inclusive)
	* @return the range of training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the training certifications.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.TrainingCertificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of training certifications
	* @param end the upper bound of the range of training certifications (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.spad.icop.model.TrainingCertification> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the training certifications from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of training certifications.
	*
	* @return the number of training certifications
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static TrainingCertificationPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (TrainingCertificationPersistence)PortletBeanLocatorUtil.locate(com.spad.icop.service.ClpSerializer.getServletContextName(),
					TrainingCertificationPersistence.class.getName());

			ReferenceRegistry.registerReference(TrainingCertificationUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(TrainingCertificationPersistence persistence) {
	}

	private static TrainingCertificationPersistence _persistence;
}