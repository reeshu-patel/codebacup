/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.ClpSerializer;
import com.spad.icop.service.TrainingCertificationLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class TrainingCertificationClp extends BaseModelImpl<TrainingCertification>
	implements TrainingCertification {
	public TrainingCertificationClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return TrainingCertification.class;
	}

	@Override
	public String getModelClassName() {
		return TrainingCertification.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _trainingCertifiId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setTrainingCertifiId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _trainingCertifiId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("trainingCertifiId", getTrainingCertifiId());
		attributes.put("aditid", getAditid());
		attributes.put("trainingDates", getTrainingDates());
		attributes.put("exerciseName", getExerciseName());
		attributes.put("pointsExercise", getPointsExercise());
		attributes.put("nameOfficer", getNameOfficer());
		attributes.put("number", getNumber());
		attributes.put("statusExercise", getStatusExercise());
		attributes.put("statusMoulds", getStatusMoulds());
		attributes.put("companyName", getCompanyName());
		attributes.put("address", getAddress());
		attributes.put("email", getEmail());
		attributes.put("operatorName", getOperatorName());
		attributes.put("typeVehicle", getTypeVehicle());
		attributes.put("noVehicles", getNoVehicles());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long trainingCertifiId = (Long)attributes.get("trainingCertifiId");

		if (trainingCertifiId != null) {
			setTrainingCertifiId(trainingCertifiId);
		}

		Long aditid = (Long)attributes.get("aditid");

		if (aditid != null) {
			setAditid(aditid);
		}

		String trainingDates = (String)attributes.get("trainingDates");

		if (trainingDates != null) {
			setTrainingDates(trainingDates);
		}

		String exerciseName = (String)attributes.get("exerciseName");

		if (exerciseName != null) {
			setExerciseName(exerciseName);
		}

		String pointsExercise = (String)attributes.get("pointsExercise");

		if (pointsExercise != null) {
			setPointsExercise(pointsExercise);
		}

		String nameOfficer = (String)attributes.get("nameOfficer");

		if (nameOfficer != null) {
			setNameOfficer(nameOfficer);
		}

		String number = (String)attributes.get("number");

		if (number != null) {
			setNumber(number);
		}

		String statusExercise = (String)attributes.get("statusExercise");

		if (statusExercise != null) {
			setStatusExercise(statusExercise);
		}

		String statusMoulds = (String)attributes.get("statusMoulds");

		if (statusMoulds != null) {
			setStatusMoulds(statusMoulds);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String operatorName = (String)attributes.get("operatorName");

		if (operatorName != null) {
			setOperatorName(operatorName);
		}

		String typeVehicle = (String)attributes.get("typeVehicle");

		if (typeVehicle != null) {
			setTypeVehicle(typeVehicle);
		}

		String noVehicles = (String)attributes.get("noVehicles");

		if (noVehicles != null) {
			setNoVehicles(noVehicles);
		}
	}

	@Override
	public long getTrainingCertifiId() {
		return _trainingCertifiId;
	}

	@Override
	public void setTrainingCertifiId(long trainingCertifiId) {
		_trainingCertifiId = trainingCertifiId;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingCertifiId",
						long.class);

				method.invoke(_trainingCertificationRemoteModel,
					trainingCertifiId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAditid() {
		return _aditid;
	}

	@Override
	public void setAditid(long aditid) {
		_aditid = aditid;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setAditid", long.class);

				method.invoke(_trainingCertificationRemoteModel, aditid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingDates() {
		return _trainingDates;
	}

	@Override
	public void setTrainingDates(String trainingDates) {
		_trainingDates = trainingDates;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingDates", String.class);

				method.invoke(_trainingCertificationRemoteModel, trainingDates);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getExerciseName() {
		return _exerciseName;
	}

	@Override
	public void setExerciseName(String exerciseName) {
		_exerciseName = exerciseName;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setExerciseName", String.class);

				method.invoke(_trainingCertificationRemoteModel, exerciseName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPointsExercise() {
		return _pointsExercise;
	}

	@Override
	public void setPointsExercise(String pointsExercise) {
		_pointsExercise = pointsExercise;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setPointsExercise",
						String.class);

				method.invoke(_trainingCertificationRemoteModel, pointsExercise);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameOfficer() {
		return _nameOfficer;
	}

	@Override
	public void setNameOfficer(String nameOfficer) {
		_nameOfficer = nameOfficer;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setNameOfficer", String.class);

				method.invoke(_trainingCertificationRemoteModel, nameOfficer);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNumber() {
		return _number;
	}

	@Override
	public void setNumber(String number) {
		_number = number;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setNumber", String.class);

				method.invoke(_trainingCertificationRemoteModel, number);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatusExercise() {
		return _statusExercise;
	}

	@Override
	public void setStatusExercise(String statusExercise) {
		_statusExercise = statusExercise;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusExercise",
						String.class);

				method.invoke(_trainingCertificationRemoteModel, statusExercise);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatusMoulds() {
		return _statusMoulds;
	}

	@Override
	public void setStatusMoulds(String statusMoulds) {
		_statusMoulds = statusMoulds;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusMoulds", String.class);

				method.invoke(_trainingCertificationRemoteModel, statusMoulds);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompanyName() {
		return _companyName;
	}

	@Override
	public void setCompanyName(String companyName) {
		_companyName = companyName;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyName", String.class);

				method.invoke(_trainingCertificationRemoteModel, companyName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddress() {
		return _address;
	}

	@Override
	public void setAddress(String address) {
		_address = address;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setAddress", String.class);

				method.invoke(_trainingCertificationRemoteModel, address);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_trainingCertificationRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOperatorName() {
		return _operatorName;
	}

	@Override
	public void setOperatorName(String operatorName) {
		_operatorName = operatorName;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setOperatorName", String.class);

				method.invoke(_trainingCertificationRemoteModel, operatorName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTypeVehicle() {
		return _typeVehicle;
	}

	@Override
	public void setTypeVehicle(String typeVehicle) {
		_typeVehicle = typeVehicle;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setTypeVehicle", String.class);

				method.invoke(_trainingCertificationRemoteModel, typeVehicle);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNoVehicles() {
		return _noVehicles;
	}

	@Override
	public void setNoVehicles(String noVehicles) {
		_noVehicles = noVehicles;

		if (_trainingCertificationRemoteModel != null) {
			try {
				Class<?> clazz = _trainingCertificationRemoteModel.getClass();

				Method method = clazz.getMethod("setNoVehicles", String.class);

				method.invoke(_trainingCertificationRemoteModel, noVehicles);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getTrainingCertificationRemoteModel() {
		return _trainingCertificationRemoteModel;
	}

	public void setTrainingCertificationRemoteModel(
		BaseModel<?> trainingCertificationRemoteModel) {
		_trainingCertificationRemoteModel = trainingCertificationRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _trainingCertificationRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_trainingCertificationRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			TrainingCertificationLocalServiceUtil.addTrainingCertification(this);
		}
		else {
			TrainingCertificationLocalServiceUtil.updateTrainingCertification(this);
		}
	}

	@Override
	public TrainingCertification toEscapedModel() {
		return (TrainingCertification)ProxyUtil.newProxyInstance(TrainingCertification.class.getClassLoader(),
			new Class[] { TrainingCertification.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		TrainingCertificationClp clone = new TrainingCertificationClp();

		clone.setTrainingCertifiId(getTrainingCertifiId());
		clone.setAditid(getAditid());
		clone.setTrainingDates(getTrainingDates());
		clone.setExerciseName(getExerciseName());
		clone.setPointsExercise(getPointsExercise());
		clone.setNameOfficer(getNameOfficer());
		clone.setNumber(getNumber());
		clone.setStatusExercise(getStatusExercise());
		clone.setStatusMoulds(getStatusMoulds());
		clone.setCompanyName(getCompanyName());
		clone.setAddress(getAddress());
		clone.setEmail(getEmail());
		clone.setOperatorName(getOperatorName());
		clone.setTypeVehicle(getTypeVehicle());
		clone.setNoVehicles(getNoVehicles());

		return clone;
	}

	@Override
	public int compareTo(TrainingCertification trainingCertification) {
		int value = 0;

		if (getTrainingCertifiId() < trainingCertification.getTrainingCertifiId()) {
			value = -1;
		}
		else if (getTrainingCertifiId() > trainingCertification.getTrainingCertifiId()) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TrainingCertificationClp)) {
			return false;
		}

		TrainingCertificationClp trainingCertification = (TrainingCertificationClp)obj;

		long primaryKey = trainingCertification.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{trainingCertifiId=");
		sb.append(getTrainingCertifiId());
		sb.append(", aditid=");
		sb.append(getAditid());
		sb.append(", trainingDates=");
		sb.append(getTrainingDates());
		sb.append(", exerciseName=");
		sb.append(getExerciseName());
		sb.append(", pointsExercise=");
		sb.append(getPointsExercise());
		sb.append(", nameOfficer=");
		sb.append(getNameOfficer());
		sb.append(", number=");
		sb.append(getNumber());
		sb.append(", statusExercise=");
		sb.append(getStatusExercise());
		sb.append(", statusMoulds=");
		sb.append(getStatusMoulds());
		sb.append(", companyName=");
		sb.append(getCompanyName());
		sb.append(", address=");
		sb.append(getAddress());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", operatorName=");
		sb.append(getOperatorName());
		sb.append(", typeVehicle=");
		sb.append(getTypeVehicle());
		sb.append(", noVehicles=");
		sb.append(getNoVehicles());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(49);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.TrainingCertification");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>trainingCertifiId</column-name><column-value><![CDATA[");
		sb.append(getTrainingCertifiId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>aditid</column-name><column-value><![CDATA[");
		sb.append(getAditid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingDates</column-name><column-value><![CDATA[");
		sb.append(getTrainingDates());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>exerciseName</column-name><column-value><![CDATA[");
		sb.append(getExerciseName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>pointsExercise</column-name><column-value><![CDATA[");
		sb.append(getPointsExercise());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameOfficer</column-name><column-value><![CDATA[");
		sb.append(getNameOfficer());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>number</column-name><column-value><![CDATA[");
		sb.append(getNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusExercise</column-name><column-value><![CDATA[");
		sb.append(getStatusExercise());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusMoulds</column-name><column-value><![CDATA[");
		sb.append(getStatusMoulds());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyName</column-name><column-value><![CDATA[");
		sb.append(getCompanyName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>address</column-name><column-value><![CDATA[");
		sb.append(getAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>operatorName</column-name><column-value><![CDATA[");
		sb.append(getOperatorName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>typeVehicle</column-name><column-value><![CDATA[");
		sb.append(getTypeVehicle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>noVehicles</column-name><column-value><![CDATA[");
		sb.append(getNoVehicles());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _trainingCertifiId;
	private long _aditid;
	private String _trainingDates;
	private String _exerciseName;
	private String _pointsExercise;
	private String _nameOfficer;
	private String _number;
	private String _statusExercise;
	private String _statusMoulds;
	private String _companyName;
	private String _address;
	private String _email;
	private String _operatorName;
	private String _typeVehicle;
	private String _noVehicles;
	private BaseModel<?> _trainingCertificationRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}