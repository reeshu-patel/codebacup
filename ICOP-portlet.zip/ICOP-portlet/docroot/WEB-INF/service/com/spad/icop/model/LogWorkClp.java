/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.spad.icop.service.ClpSerializer;
import com.spad.icop.service.LogWorkLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class LogWorkClp extends BaseModelImpl<LogWork> implements LogWork {
	public LogWorkClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return LogWork.class;
	}

	@Override
	public String getModelClassName() {
		return LogWork.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _logworkId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setLogworkId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _logworkId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("logworkId", getLogworkId());
		attributes.put("user", getUser());
		attributes.put("time", getTime());
		attributes.put("detail", getDetail());
		attributes.put("chronicle", getChronicle());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long logworkId = (Long)attributes.get("logworkId");

		if (logworkId != null) {
			setLogworkId(logworkId);
		}

		String user = (String)attributes.get("user");

		if (user != null) {
			setUser(user);
		}

		String time = (String)attributes.get("time");

		if (time != null) {
			setTime(time);
		}

		String detail = (String)attributes.get("detail");

		if (detail != null) {
			setDetail(detail);
		}

		String chronicle = (String)attributes.get("chronicle");

		if (chronicle != null) {
			setChronicle(chronicle);
		}
	}

	@Override
	public long getLogworkId() {
		return _logworkId;
	}

	@Override
	public void setLogworkId(long logworkId) {
		_logworkId = logworkId;

		if (_logWorkRemoteModel != null) {
			try {
				Class<?> clazz = _logWorkRemoteModel.getClass();

				Method method = clazz.getMethod("setLogworkId", long.class);

				method.invoke(_logWorkRemoteModel, logworkId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUser() {
		return _user;
	}

	@Override
	public void setUser(String user) {
		_user = user;

		if (_logWorkRemoteModel != null) {
			try {
				Class<?> clazz = _logWorkRemoteModel.getClass();

				Method method = clazz.getMethod("setUser", String.class);

				method.invoke(_logWorkRemoteModel, user);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTime() {
		return _time;
	}

	@Override
	public void setTime(String time) {
		_time = time;

		if (_logWorkRemoteModel != null) {
			try {
				Class<?> clazz = _logWorkRemoteModel.getClass();

				Method method = clazz.getMethod("setTime", String.class);

				method.invoke(_logWorkRemoteModel, time);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDetail() {
		return _detail;
	}

	@Override
	public void setDetail(String detail) {
		_detail = detail;

		if (_logWorkRemoteModel != null) {
			try {
				Class<?> clazz = _logWorkRemoteModel.getClass();

				Method method = clazz.getMethod("setDetail", String.class);

				method.invoke(_logWorkRemoteModel, detail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getChronicle() {
		return _chronicle;
	}

	@Override
	public void setChronicle(String chronicle) {
		_chronicle = chronicle;

		if (_logWorkRemoteModel != null) {
			try {
				Class<?> clazz = _logWorkRemoteModel.getClass();

				Method method = clazz.getMethod("setChronicle", String.class);

				method.invoke(_logWorkRemoteModel, chronicle);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getLogWorkRemoteModel() {
		return _logWorkRemoteModel;
	}

	public void setLogWorkRemoteModel(BaseModel<?> logWorkRemoteModel) {
		_logWorkRemoteModel = logWorkRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _logWorkRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_logWorkRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			LogWorkLocalServiceUtil.addLogWork(this);
		}
		else {
			LogWorkLocalServiceUtil.updateLogWork(this);
		}
	}

	@Override
	public LogWork toEscapedModel() {
		return (LogWork)ProxyUtil.newProxyInstance(LogWork.class.getClassLoader(),
			new Class[] { LogWork.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		LogWorkClp clone = new LogWorkClp();

		clone.setLogworkId(getLogworkId());
		clone.setUser(getUser());
		clone.setTime(getTime());
		clone.setDetail(getDetail());
		clone.setChronicle(getChronicle());

		return clone;
	}

	@Override
	public int compareTo(LogWork logWork) {
		long primaryKey = logWork.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LogWorkClp)) {
			return false;
		}

		LogWorkClp logWork = (LogWorkClp)obj;

		long primaryKey = logWork.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{logworkId=");
		sb.append(getLogworkId());
		sb.append(", user=");
		sb.append(getUser());
		sb.append(", time=");
		sb.append(getTime());
		sb.append(", detail=");
		sb.append(getDetail());
		sb.append(", chronicle=");
		sb.append(getChronicle());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.spad.icop.model.LogWork");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>logworkId</column-name><column-value><![CDATA[");
		sb.append(getLogworkId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>user</column-name><column-value><![CDATA[");
		sb.append(getUser());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>time</column-name><column-value><![CDATA[");
		sb.append(getTime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>detail</column-name><column-value><![CDATA[");
		sb.append(getDetail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>chronicle</column-name><column-value><![CDATA[");
		sb.append(getChronicle());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _logworkId;
	private String _user;
	private String _time;
	private String _detail;
	private String _chronicle;
	private BaseModel<?> _logWorkRemoteModel;
	private Class<?> _clpSerializerClass = com.spad.icop.service.ClpSerializer.class;
}