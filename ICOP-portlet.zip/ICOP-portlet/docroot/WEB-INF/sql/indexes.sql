create index IX_3E4A2646 on icop_CompilanceCheck (aditid);

create index IX_FA3AA103 on icop_ComplainCheckAudit (aditid);
create index IX_DE1A90F3 on icop_ComplainCheckAudit (aditid, matterId);

create index IX_C146433F on icop_TrainingCertification (aditid);