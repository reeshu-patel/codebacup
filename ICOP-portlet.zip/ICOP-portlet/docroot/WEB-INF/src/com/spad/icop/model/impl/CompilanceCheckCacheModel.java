/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.CompilanceCheck;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing CompilanceCheck in entity cache.
 *
 * @author reeshu
 * @see CompilanceCheck
 * @generated
 */
public class CompilanceCheckCacheModel implements CacheModel<CompilanceCheck>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(143);

		sb.append("{compilanceCheckid=");
		sb.append(compilanceCheckid);
		sb.append(", aditid=");
		sb.append(aditid);
		sb.append(", company=");
		sb.append(company);
		sb.append(", audidate=");
		sb.append(audidate);
		sb.append(", completedStatus=");
		sb.append(completedStatus);
		sb.append(", auditPercentage=");
		sb.append(auditPercentage);
		sb.append(", questionSafetyOne=");
		sb.append(questionSafetyOne);
		sb.append(", questionSafetyTwo=");
		sb.append(questionSafetyTwo);
		sb.append(", questionSafetyThree=");
		sb.append(questionSafetyThree);
		sb.append(", questionSafetFour=");
		sb.append(questionSafetFour);
		sb.append(", questionSafetFive=");
		sb.append(questionSafetFive);
		sb.append(", questionSafetSix=");
		sb.append(questionSafetSix);
		sb.append(", questionSafetySeven=");
		sb.append(questionSafetySeven);
		sb.append(", questionNoteOne=");
		sb.append(questionNoteOne);
		sb.append(", questionNoteTwo=");
		sb.append(questionNoteTwo);
		sb.append(", questionNoteThree=");
		sb.append(questionNoteThree);
		sb.append(", questionNoteFour=");
		sb.append(questionNoteFour);
		sb.append(", questionNoteFive=");
		sb.append(questionNoteFive);
		sb.append(", questionNoteSix=");
		sb.append(questionNoteSix);
		sb.append(", questionNoteSeven=");
		sb.append(questionNoteSeven);
		sb.append(", questionVehicalOne=");
		sb.append(questionVehicalOne);
		sb.append(", questionVehicalTwo=");
		sb.append(questionVehicalTwo);
		sb.append(", questionVehicalThree=");
		sb.append(questionVehicalThree);
		sb.append(", questionVehicalFour=");
		sb.append(questionVehicalFour);
		sb.append(", questionVehicalFive=");
		sb.append(questionVehicalFive);
		sb.append(", questionVehicalSix=");
		sb.append(questionVehicalSix);
		sb.append(", questionVehicalSeven=");
		sb.append(questionVehicalSeven);
		sb.append(", questionVehicalNoteOne=");
		sb.append(questionVehicalNoteOne);
		sb.append(", questionVehicalNoteTwo=");
		sb.append(questionVehicalNoteTwo);
		sb.append(", questionVehicalNoteThree=");
		sb.append(questionVehicalNoteThree);
		sb.append(", questionVehicalNoteFour=");
		sb.append(questionVehicalNoteFour);
		sb.append(", questionVehicalNoteFive=");
		sb.append(questionVehicalNoteFive);
		sb.append(", questionVehicalNoteSix=");
		sb.append(questionVehicalNoteSix);
		sb.append(", questionVehicalNoteSeven=");
		sb.append(questionVehicalNoteSeven);
		sb.append(", questionManageOne=");
		sb.append(questionManageOne);
		sb.append(", questionManageTwo=");
		sb.append(questionManageTwo);
		sb.append(", questionManageThree=");
		sb.append(questionManageThree);
		sb.append(", questionManageFour=");
		sb.append(questionManageFour);
		sb.append(", questionManageFive=");
		sb.append(questionManageFive);
		sb.append(", questionManageSix=");
		sb.append(questionManageSix);
		sb.append(", questionManageSeven=");
		sb.append(questionManageSeven);
		sb.append(", questionManageNoteOne=");
		sb.append(questionManageNoteOne);
		sb.append(", questionManageNoteTwo=");
		sb.append(questionManageNoteTwo);
		sb.append(", questionManageNoteThree=");
		sb.append(questionManageNoteThree);
		sb.append(", questionManageNoteFour=");
		sb.append(questionManageNoteFour);
		sb.append(", questionManageNoteFive=");
		sb.append(questionManageNoteFive);
		sb.append(", questionManageNoteSix=");
		sb.append(questionManageNoteSix);
		sb.append(", questionRecordsOne=");
		sb.append(questionRecordsOne);
		sb.append(", questionRecordsTwo=");
		sb.append(questionRecordsTwo);
		sb.append(", questionRecordsThree=");
		sb.append(questionRecordsThree);
		sb.append(", questionRecordsNoteOne=");
		sb.append(questionRecordsNoteOne);
		sb.append(", questionRecordsNoteTwo=");
		sb.append(questionRecordsNoteTwo);
		sb.append(", questionRecordsNoteThree=");
		sb.append(questionRecordsNoteThree);
		sb.append(", questionReskOne=");
		sb.append(questionReskOne);
		sb.append(", questionReskTwo=");
		sb.append(questionReskTwo);
		sb.append(", questionReskThree=");
		sb.append(questionReskThree);
		sb.append(", questionReskFour=");
		sb.append(questionReskFour);
		sb.append(", questionReskFive=");
		sb.append(questionReskFive);
		sb.append(", questionReskSix=");
		sb.append(questionReskSix);
		sb.append(", questionReskSeven=");
		sb.append(questionReskSeven);
		sb.append(", questionReskEight=");
		sb.append(questionReskEight);
		sb.append(", questionReskNoteOne=");
		sb.append(questionReskNoteOne);
		sb.append(", questionReskNoteTwo=");
		sb.append(questionReskNoteTwo);
		sb.append(", questionReskNoteThree=");
		sb.append(questionReskNoteThree);
		sb.append(", questionReskNoteFour=");
		sb.append(questionReskNoteFour);
		sb.append(", questionReskNoteFive=");
		sb.append(questionReskNoteFive);
		sb.append(", questionReskNoteSix=");
		sb.append(questionReskNoteSix);
		sb.append(", questionReskNoteSeven=");
		sb.append(questionReskNoteSeven);
		sb.append(", questionReskNoteEight=");
		sb.append(questionReskNoteEight);
		sb.append(", notcomplied=");
		sb.append(notcomplied);
		sb.append(", record=");
		sb.append(record);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public CompilanceCheck toEntityModel() {
		CompilanceCheckImpl compilanceCheckImpl = new CompilanceCheckImpl();

		compilanceCheckImpl.setCompilanceCheckid(compilanceCheckid);
		compilanceCheckImpl.setAditid(aditid);

		if (company == null) {
			compilanceCheckImpl.setCompany(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setCompany(company);
		}

		if (audidate == null) {
			compilanceCheckImpl.setAudidate(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setAudidate(audidate);
		}

		if (completedStatus == null) {
			compilanceCheckImpl.setCompletedStatus(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setCompletedStatus(completedStatus);
		}

		if (auditPercentage == null) {
			compilanceCheckImpl.setAuditPercentage(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setAuditPercentage(auditPercentage);
		}

		if (questionSafetyOne == null) {
			compilanceCheckImpl.setQuestionSafetyOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetyOne(questionSafetyOne);
		}

		if (questionSafetyTwo == null) {
			compilanceCheckImpl.setQuestionSafetyTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetyTwo(questionSafetyTwo);
		}

		if (questionSafetyThree == null) {
			compilanceCheckImpl.setQuestionSafetyThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetyThree(questionSafetyThree);
		}

		if (questionSafetFour == null) {
			compilanceCheckImpl.setQuestionSafetFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetFour(questionSafetFour);
		}

		if (questionSafetFive == null) {
			compilanceCheckImpl.setQuestionSafetFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetFive(questionSafetFive);
		}

		if (questionSafetSix == null) {
			compilanceCheckImpl.setQuestionSafetSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetSix(questionSafetSix);
		}

		if (questionSafetySeven == null) {
			compilanceCheckImpl.setQuestionSafetySeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionSafetySeven(questionSafetySeven);
		}

		if (questionNoteOne == null) {
			compilanceCheckImpl.setQuestionNoteOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteOne(questionNoteOne);
		}

		if (questionNoteTwo == null) {
			compilanceCheckImpl.setQuestionNoteTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteTwo(questionNoteTwo);
		}

		if (questionNoteThree == null) {
			compilanceCheckImpl.setQuestionNoteThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteThree(questionNoteThree);
		}

		if (questionNoteFour == null) {
			compilanceCheckImpl.setQuestionNoteFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteFour(questionNoteFour);
		}

		if (questionNoteFive == null) {
			compilanceCheckImpl.setQuestionNoteFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteFive(questionNoteFive);
		}

		if (questionNoteSix == null) {
			compilanceCheckImpl.setQuestionNoteSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteSix(questionNoteSix);
		}

		if (questionNoteSeven == null) {
			compilanceCheckImpl.setQuestionNoteSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionNoteSeven(questionNoteSeven);
		}

		if (questionVehicalOne == null) {
			compilanceCheckImpl.setQuestionVehicalOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalOne(questionVehicalOne);
		}

		if (questionVehicalTwo == null) {
			compilanceCheckImpl.setQuestionVehicalTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalTwo(questionVehicalTwo);
		}

		if (questionVehicalThree == null) {
			compilanceCheckImpl.setQuestionVehicalThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalThree(questionVehicalThree);
		}

		if (questionVehicalFour == null) {
			compilanceCheckImpl.setQuestionVehicalFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalFour(questionVehicalFour);
		}

		if (questionVehicalFive == null) {
			compilanceCheckImpl.setQuestionVehicalFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalFive(questionVehicalFive);
		}

		if (questionVehicalSix == null) {
			compilanceCheckImpl.setQuestionVehicalSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalSix(questionVehicalSix);
		}

		if (questionVehicalSeven == null) {
			compilanceCheckImpl.setQuestionVehicalSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalSeven(questionVehicalSeven);
		}

		if (questionVehicalNoteOne == null) {
			compilanceCheckImpl.setQuestionVehicalNoteOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteOne(questionVehicalNoteOne);
		}

		if (questionVehicalNoteTwo == null) {
			compilanceCheckImpl.setQuestionVehicalNoteTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
		}

		if (questionVehicalNoteThree == null) {
			compilanceCheckImpl.setQuestionVehicalNoteThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteThree(questionVehicalNoteThree);
		}

		if (questionVehicalNoteFour == null) {
			compilanceCheckImpl.setQuestionVehicalNoteFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteFour(questionVehicalNoteFour);
		}

		if (questionVehicalNoteFive == null) {
			compilanceCheckImpl.setQuestionVehicalNoteFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteFive(questionVehicalNoteFive);
		}

		if (questionVehicalNoteSix == null) {
			compilanceCheckImpl.setQuestionVehicalNoteSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteSix(questionVehicalNoteSix);
		}

		if (questionVehicalNoteSeven == null) {
			compilanceCheckImpl.setQuestionVehicalNoteSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionVehicalNoteSeven(questionVehicalNoteSeven);
		}

		if (questionManageOne == null) {
			compilanceCheckImpl.setQuestionManageOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageOne(questionManageOne);
		}

		if (questionManageTwo == null) {
			compilanceCheckImpl.setQuestionManageTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageTwo(questionManageTwo);
		}

		if (questionManageThree == null) {
			compilanceCheckImpl.setQuestionManageThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageThree(questionManageThree);
		}

		if (questionManageFour == null) {
			compilanceCheckImpl.setQuestionManageFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageFour(questionManageFour);
		}

		if (questionManageFive == null) {
			compilanceCheckImpl.setQuestionManageFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageFive(questionManageFive);
		}

		if (questionManageSix == null) {
			compilanceCheckImpl.setQuestionManageSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageSix(questionManageSix);
		}

		if (questionManageSeven == null) {
			compilanceCheckImpl.setQuestionManageSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageSeven(questionManageSeven);
		}

		if (questionManageNoteOne == null) {
			compilanceCheckImpl.setQuestionManageNoteOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteOne(questionManageNoteOne);
		}

		if (questionManageNoteTwo == null) {
			compilanceCheckImpl.setQuestionManageNoteTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteTwo(questionManageNoteTwo);
		}

		if (questionManageNoteThree == null) {
			compilanceCheckImpl.setQuestionManageNoteThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteThree(questionManageNoteThree);
		}

		if (questionManageNoteFour == null) {
			compilanceCheckImpl.setQuestionManageNoteFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteFour(questionManageNoteFour);
		}

		if (questionManageNoteFive == null) {
			compilanceCheckImpl.setQuestionManageNoteFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteFive(questionManageNoteFive);
		}

		if (questionManageNoteSix == null) {
			compilanceCheckImpl.setQuestionManageNoteSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionManageNoteSix(questionManageNoteSix);
		}

		if (questionRecordsOne == null) {
			compilanceCheckImpl.setQuestionRecordsOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsOne(questionRecordsOne);
		}

		if (questionRecordsTwo == null) {
			compilanceCheckImpl.setQuestionRecordsTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsTwo(questionRecordsTwo);
		}

		if (questionRecordsThree == null) {
			compilanceCheckImpl.setQuestionRecordsThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsThree(questionRecordsThree);
		}

		if (questionRecordsNoteOne == null) {
			compilanceCheckImpl.setQuestionRecordsNoteOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsNoteOne(questionRecordsNoteOne);
		}

		if (questionRecordsNoteTwo == null) {
			compilanceCheckImpl.setQuestionRecordsNoteTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
		}

		if (questionRecordsNoteThree == null) {
			compilanceCheckImpl.setQuestionRecordsNoteThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionRecordsNoteThree(questionRecordsNoteThree);
		}

		if (questionReskOne == null) {
			compilanceCheckImpl.setQuestionReskOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskOne(questionReskOne);
		}

		if (questionReskTwo == null) {
			compilanceCheckImpl.setQuestionReskTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskTwo(questionReskTwo);
		}

		if (questionReskThree == null) {
			compilanceCheckImpl.setQuestionReskThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskThree(questionReskThree);
		}

		if (questionReskFour == null) {
			compilanceCheckImpl.setQuestionReskFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskFour(questionReskFour);
		}

		if (questionReskFive == null) {
			compilanceCheckImpl.setQuestionReskFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskFive(questionReskFive);
		}

		if (questionReskSix == null) {
			compilanceCheckImpl.setQuestionReskSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskSix(questionReskSix);
		}

		if (questionReskSeven == null) {
			compilanceCheckImpl.setQuestionReskSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskSeven(questionReskSeven);
		}

		if (questionReskEight == null) {
			compilanceCheckImpl.setQuestionReskEight(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskEight(questionReskEight);
		}

		if (questionReskNoteOne == null) {
			compilanceCheckImpl.setQuestionReskNoteOne(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteOne(questionReskNoteOne);
		}

		if (questionReskNoteTwo == null) {
			compilanceCheckImpl.setQuestionReskNoteTwo(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteTwo(questionReskNoteTwo);
		}

		if (questionReskNoteThree == null) {
			compilanceCheckImpl.setQuestionReskNoteThree(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteThree(questionReskNoteThree);
		}

		if (questionReskNoteFour == null) {
			compilanceCheckImpl.setQuestionReskNoteFour(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteFour(questionReskNoteFour);
		}

		if (questionReskNoteFive == null) {
			compilanceCheckImpl.setQuestionReskNoteFive(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteFive(questionReskNoteFive);
		}

		if (questionReskNoteSix == null) {
			compilanceCheckImpl.setQuestionReskNoteSix(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteSix(questionReskNoteSix);
		}

		if (questionReskNoteSeven == null) {
			compilanceCheckImpl.setQuestionReskNoteSeven(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteSeven(questionReskNoteSeven);
		}

		if (questionReskNoteEight == null) {
			compilanceCheckImpl.setQuestionReskNoteEight(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setQuestionReskNoteEight(questionReskNoteEight);
		}

		if (notcomplied == null) {
			compilanceCheckImpl.setNotcomplied(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setNotcomplied(notcomplied);
		}

		if (record == null) {
			compilanceCheckImpl.setRecord(StringPool.BLANK);
		}
		else {
			compilanceCheckImpl.setRecord(record);
		}

		compilanceCheckImpl.resetOriginalValues();

		return compilanceCheckImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		compilanceCheckid = objectInput.readLong();
		aditid = objectInput.readLong();
		company = objectInput.readUTF();
		audidate = objectInput.readUTF();
		completedStatus = objectInput.readUTF();
		auditPercentage = objectInput.readUTF();
		questionSafetyOne = objectInput.readUTF();
		questionSafetyTwo = objectInput.readUTF();
		questionSafetyThree = objectInput.readUTF();
		questionSafetFour = objectInput.readUTF();
		questionSafetFive = objectInput.readUTF();
		questionSafetSix = objectInput.readUTF();
		questionSafetySeven = objectInput.readUTF();
		questionNoteOne = objectInput.readUTF();
		questionNoteTwo = objectInput.readUTF();
		questionNoteThree = objectInput.readUTF();
		questionNoteFour = objectInput.readUTF();
		questionNoteFive = objectInput.readUTF();
		questionNoteSix = objectInput.readUTF();
		questionNoteSeven = objectInput.readUTF();
		questionVehicalOne = objectInput.readUTF();
		questionVehicalTwo = objectInput.readUTF();
		questionVehicalThree = objectInput.readUTF();
		questionVehicalFour = objectInput.readUTF();
		questionVehicalFive = objectInput.readUTF();
		questionVehicalSix = objectInput.readUTF();
		questionVehicalSeven = objectInput.readUTF();
		questionVehicalNoteOne = objectInput.readUTF();
		questionVehicalNoteTwo = objectInput.readUTF();
		questionVehicalNoteThree = objectInput.readUTF();
		questionVehicalNoteFour = objectInput.readUTF();
		questionVehicalNoteFive = objectInput.readUTF();
		questionVehicalNoteSix = objectInput.readUTF();
		questionVehicalNoteSeven = objectInput.readUTF();
		questionManageOne = objectInput.readUTF();
		questionManageTwo = objectInput.readUTF();
		questionManageThree = objectInput.readUTF();
		questionManageFour = objectInput.readUTF();
		questionManageFive = objectInput.readUTF();
		questionManageSix = objectInput.readUTF();
		questionManageSeven = objectInput.readUTF();
		questionManageNoteOne = objectInput.readUTF();
		questionManageNoteTwo = objectInput.readUTF();
		questionManageNoteThree = objectInput.readUTF();
		questionManageNoteFour = objectInput.readUTF();
		questionManageNoteFive = objectInput.readUTF();
		questionManageNoteSix = objectInput.readUTF();
		questionRecordsOne = objectInput.readUTF();
		questionRecordsTwo = objectInput.readUTF();
		questionRecordsThree = objectInput.readUTF();
		questionRecordsNoteOne = objectInput.readUTF();
		questionRecordsNoteTwo = objectInput.readUTF();
		questionRecordsNoteThree = objectInput.readUTF();
		questionReskOne = objectInput.readUTF();
		questionReskTwo = objectInput.readUTF();
		questionReskThree = objectInput.readUTF();
		questionReskFour = objectInput.readUTF();
		questionReskFive = objectInput.readUTF();
		questionReskSix = objectInput.readUTF();
		questionReskSeven = objectInput.readUTF();
		questionReskEight = objectInput.readUTF();
		questionReskNoteOne = objectInput.readUTF();
		questionReskNoteTwo = objectInput.readUTF();
		questionReskNoteThree = objectInput.readUTF();
		questionReskNoteFour = objectInput.readUTF();
		questionReskNoteFive = objectInput.readUTF();
		questionReskNoteSix = objectInput.readUTF();
		questionReskNoteSeven = objectInput.readUTF();
		questionReskNoteEight = objectInput.readUTF();
		notcomplied = objectInput.readUTF();
		record = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(compilanceCheckid);
		objectOutput.writeLong(aditid);

		if (company == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(company);
		}

		if (audidate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(audidate);
		}

		if (completedStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(completedStatus);
		}

		if (auditPercentage == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditPercentage);
		}

		if (questionSafetyOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetyOne);
		}

		if (questionSafetyTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetyTwo);
		}

		if (questionSafetyThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetyThree);
		}

		if (questionSafetFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetFour);
		}

		if (questionSafetFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetFive);
		}

		if (questionSafetSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetSix);
		}

		if (questionSafetySeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionSafetySeven);
		}

		if (questionNoteOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteOne);
		}

		if (questionNoteTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteTwo);
		}

		if (questionNoteThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteThree);
		}

		if (questionNoteFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteFour);
		}

		if (questionNoteFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteFive);
		}

		if (questionNoteSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteSix);
		}

		if (questionNoteSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionNoteSeven);
		}

		if (questionVehicalOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalOne);
		}

		if (questionVehicalTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalTwo);
		}

		if (questionVehicalThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalThree);
		}

		if (questionVehicalFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalFour);
		}

		if (questionVehicalFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalFive);
		}

		if (questionVehicalSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalSix);
		}

		if (questionVehicalSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalSeven);
		}

		if (questionVehicalNoteOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteOne);
		}

		if (questionVehicalNoteTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteTwo);
		}

		if (questionVehicalNoteThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteThree);
		}

		if (questionVehicalNoteFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteFour);
		}

		if (questionVehicalNoteFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteFive);
		}

		if (questionVehicalNoteSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteSix);
		}

		if (questionVehicalNoteSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionVehicalNoteSeven);
		}

		if (questionManageOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageOne);
		}

		if (questionManageTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageTwo);
		}

		if (questionManageThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageThree);
		}

		if (questionManageFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageFour);
		}

		if (questionManageFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageFive);
		}

		if (questionManageSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageSix);
		}

		if (questionManageSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageSeven);
		}

		if (questionManageNoteOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteOne);
		}

		if (questionManageNoteTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteTwo);
		}

		if (questionManageNoteThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteThree);
		}

		if (questionManageNoteFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteFour);
		}

		if (questionManageNoteFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteFive);
		}

		if (questionManageNoteSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionManageNoteSix);
		}

		if (questionRecordsOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsOne);
		}

		if (questionRecordsTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsTwo);
		}

		if (questionRecordsThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsThree);
		}

		if (questionRecordsNoteOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsNoteOne);
		}

		if (questionRecordsNoteTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsNoteTwo);
		}

		if (questionRecordsNoteThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionRecordsNoteThree);
		}

		if (questionReskOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskOne);
		}

		if (questionReskTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskTwo);
		}

		if (questionReskThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskThree);
		}

		if (questionReskFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskFour);
		}

		if (questionReskFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskFive);
		}

		if (questionReskSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskSix);
		}

		if (questionReskSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskSeven);
		}

		if (questionReskEight == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskEight);
		}

		if (questionReskNoteOne == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteOne);
		}

		if (questionReskNoteTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteTwo);
		}

		if (questionReskNoteThree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteThree);
		}

		if (questionReskNoteFour == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteFour);
		}

		if (questionReskNoteFive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteFive);
		}

		if (questionReskNoteSix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteSix);
		}

		if (questionReskNoteSeven == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteSeven);
		}

		if (questionReskNoteEight == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(questionReskNoteEight);
		}

		if (notcomplied == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(notcomplied);
		}

		if (record == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(record);
		}
	}

	public long compilanceCheckid;
	public long aditid;
	public String company;
	public String audidate;
	public String completedStatus;
	public String auditPercentage;
	public String questionSafetyOne;
	public String questionSafetyTwo;
	public String questionSafetyThree;
	public String questionSafetFour;
	public String questionSafetFive;
	public String questionSafetSix;
	public String questionSafetySeven;
	public String questionNoteOne;
	public String questionNoteTwo;
	public String questionNoteThree;
	public String questionNoteFour;
	public String questionNoteFive;
	public String questionNoteSix;
	public String questionNoteSeven;
	public String questionVehicalOne;
	public String questionVehicalTwo;
	public String questionVehicalThree;
	public String questionVehicalFour;
	public String questionVehicalFive;
	public String questionVehicalSix;
	public String questionVehicalSeven;
	public String questionVehicalNoteOne;
	public String questionVehicalNoteTwo;
	public String questionVehicalNoteThree;
	public String questionVehicalNoteFour;
	public String questionVehicalNoteFive;
	public String questionVehicalNoteSix;
	public String questionVehicalNoteSeven;
	public String questionManageOne;
	public String questionManageTwo;
	public String questionManageThree;
	public String questionManageFour;
	public String questionManageFive;
	public String questionManageSix;
	public String questionManageSeven;
	public String questionManageNoteOne;
	public String questionManageNoteTwo;
	public String questionManageNoteThree;
	public String questionManageNoteFour;
	public String questionManageNoteFive;
	public String questionManageNoteSix;
	public String questionRecordsOne;
	public String questionRecordsTwo;
	public String questionRecordsThree;
	public String questionRecordsNoteOne;
	public String questionRecordsNoteTwo;
	public String questionRecordsNoteThree;
	public String questionReskOne;
	public String questionReskTwo;
	public String questionReskThree;
	public String questionReskFour;
	public String questionReskFive;
	public String questionReskSix;
	public String questionReskSeven;
	public String questionReskEight;
	public String questionReskNoteOne;
	public String questionReskNoteTwo;
	public String questionReskNoteThree;
	public String questionReskNoteFour;
	public String questionReskNoteFive;
	public String questionReskNoteSix;
	public String questionReskNoteSeven;
	public String questionReskNoteEight;
	public String notcomplied;
	public String record;
}