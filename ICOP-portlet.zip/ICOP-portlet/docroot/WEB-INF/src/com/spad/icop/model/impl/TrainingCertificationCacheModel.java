/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.TrainingCertification;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing TrainingCertification in entity cache.
 *
 * @author reeshu
 * @see TrainingCertification
 * @generated
 */
public class TrainingCertificationCacheModel implements CacheModel<TrainingCertification>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{trainingCertifiId=");
		sb.append(trainingCertifiId);
		sb.append(", aditid=");
		sb.append(aditid);
		sb.append(", trainingDates=");
		sb.append(trainingDates);
		sb.append(", exerciseName=");
		sb.append(exerciseName);
		sb.append(", pointsExercise=");
		sb.append(pointsExercise);
		sb.append(", nameOfficer=");
		sb.append(nameOfficer);
		sb.append(", number=");
		sb.append(number);
		sb.append(", statusExercise=");
		sb.append(statusExercise);
		sb.append(", statusMoulds=");
		sb.append(statusMoulds);
		sb.append(", companyName=");
		sb.append(companyName);
		sb.append(", address=");
		sb.append(address);
		sb.append(", email=");
		sb.append(email);
		sb.append(", operatorName=");
		sb.append(operatorName);
		sb.append(", typeVehicle=");
		sb.append(typeVehicle);
		sb.append(", noVehicles=");
		sb.append(noVehicles);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public TrainingCertification toEntityModel() {
		TrainingCertificationImpl trainingCertificationImpl = new TrainingCertificationImpl();

		trainingCertificationImpl.setTrainingCertifiId(trainingCertifiId);
		trainingCertificationImpl.setAditid(aditid);

		if (trainingDates == null) {
			trainingCertificationImpl.setTrainingDates(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setTrainingDates(trainingDates);
		}

		if (exerciseName == null) {
			trainingCertificationImpl.setExerciseName(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setExerciseName(exerciseName);
		}

		if (pointsExercise == null) {
			trainingCertificationImpl.setPointsExercise(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setPointsExercise(pointsExercise);
		}

		if (nameOfficer == null) {
			trainingCertificationImpl.setNameOfficer(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setNameOfficer(nameOfficer);
		}

		if (number == null) {
			trainingCertificationImpl.setNumber(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setNumber(number);
		}

		if (statusExercise == null) {
			trainingCertificationImpl.setStatusExercise(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setStatusExercise(statusExercise);
		}

		if (statusMoulds == null) {
			trainingCertificationImpl.setStatusMoulds(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setStatusMoulds(statusMoulds);
		}

		if (companyName == null) {
			trainingCertificationImpl.setCompanyName(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setCompanyName(companyName);
		}

		if (address == null) {
			trainingCertificationImpl.setAddress(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setAddress(address);
		}

		if (email == null) {
			trainingCertificationImpl.setEmail(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setEmail(email);
		}

		if (operatorName == null) {
			trainingCertificationImpl.setOperatorName(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setOperatorName(operatorName);
		}

		if (typeVehicle == null) {
			trainingCertificationImpl.setTypeVehicle(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setTypeVehicle(typeVehicle);
		}

		if (noVehicles == null) {
			trainingCertificationImpl.setNoVehicles(StringPool.BLANK);
		}
		else {
			trainingCertificationImpl.setNoVehicles(noVehicles);
		}

		trainingCertificationImpl.resetOriginalValues();

		return trainingCertificationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		trainingCertifiId = objectInput.readLong();
		aditid = objectInput.readLong();
		trainingDates = objectInput.readUTF();
		exerciseName = objectInput.readUTF();
		pointsExercise = objectInput.readUTF();
		nameOfficer = objectInput.readUTF();
		number = objectInput.readUTF();
		statusExercise = objectInput.readUTF();
		statusMoulds = objectInput.readUTF();
		companyName = objectInput.readUTF();
		address = objectInput.readUTF();
		email = objectInput.readUTF();
		operatorName = objectInput.readUTF();
		typeVehicle = objectInput.readUTF();
		noVehicles = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(trainingCertifiId);
		objectOutput.writeLong(aditid);

		if (trainingDates == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingDates);
		}

		if (exerciseName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(exerciseName);
		}

		if (pointsExercise == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(pointsExercise);
		}

		if (nameOfficer == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameOfficer);
		}

		if (number == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(number);
		}

		if (statusExercise == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusExercise);
		}

		if (statusMoulds == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusMoulds);
		}

		if (companyName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyName);
		}

		if (address == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (operatorName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(operatorName);
		}

		if (typeVehicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeVehicle);
		}

		if (noVehicles == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(noVehicles);
		}
	}

	public long trainingCertifiId;
	public long aditid;
	public String trainingDates;
	public String exerciseName;
	public String pointsExercise;
	public String nameOfficer;
	public String number;
	public String statusExercise;
	public String statusMoulds;
	public String companyName;
	public String address;
	public String email;
	public String operatorName;
	public String typeVehicle;
	public String noVehicles;
}