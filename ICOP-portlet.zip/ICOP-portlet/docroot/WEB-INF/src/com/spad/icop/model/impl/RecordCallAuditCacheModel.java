/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.RecordCallAudit;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RecordCallAudit in entity cache.
 *
 * @author reeshu
 * @see RecordCallAudit
 * @generated
 */
public class RecordCallAuditCacheModel implements CacheModel<RecordCallAudit>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{recordcallid=");
		sb.append(recordcallid);
		sb.append(", aditid=");
		sb.append(aditid);
		sb.append(", dateonroadsafty=");
		sb.append(dateonroadsafty);
		sb.append(", investigationtitle=");
		sb.append(investigationtitle);
		sb.append(", company=");
		sb.append(company);
		sb.append(", statusverification=");
		sb.append(statusverification);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RecordCallAudit toEntityModel() {
		RecordCallAuditImpl recordCallAuditImpl = new RecordCallAuditImpl();

		if (recordcallid == null) {
			recordCallAuditImpl.setRecordcallid(StringPool.BLANK);
		}
		else {
			recordCallAuditImpl.setRecordcallid(recordcallid);
		}

		recordCallAuditImpl.setAditid(aditid);

		if (dateonroadsafty == null) {
			recordCallAuditImpl.setDateonroadsafty(StringPool.BLANK);
		}
		else {
			recordCallAuditImpl.setDateonroadsafty(dateonroadsafty);
		}

		if (investigationtitle == null) {
			recordCallAuditImpl.setInvestigationtitle(StringPool.BLANK);
		}
		else {
			recordCallAuditImpl.setInvestigationtitle(investigationtitle);
		}

		if (company == null) {
			recordCallAuditImpl.setCompany(StringPool.BLANK);
		}
		else {
			recordCallAuditImpl.setCompany(company);
		}

		if (statusverification == null) {
			recordCallAuditImpl.setStatusverification(StringPool.BLANK);
		}
		else {
			recordCallAuditImpl.setStatusverification(statusverification);
		}

		recordCallAuditImpl.resetOriginalValues();

		return recordCallAuditImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		recordcallid = objectInput.readUTF();
		aditid = objectInput.readLong();
		dateonroadsafty = objectInput.readUTF();
		investigationtitle = objectInput.readUTF();
		company = objectInput.readUTF();
		statusverification = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (recordcallid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recordcallid);
		}

		objectOutput.writeLong(aditid);

		if (dateonroadsafty == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateonroadsafty);
		}

		if (investigationtitle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigationtitle);
		}

		if (company == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(company);
		}

		if (statusverification == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusverification);
		}
	}

	public String recordcallid;
	public long aditid;
	public String dateonroadsafty;
	public String investigationtitle;
	public String company;
	public String statusverification;
}