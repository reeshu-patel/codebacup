/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.AppointmentCall;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing AppointmentCall in entity cache.
 *
 * @author reeshu
 * @see AppointmentCall
 * @generated
 */
public class AppointmentCallCacheModel implements CacheModel<AppointmentCall>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{recordcallid=");
		sb.append(recordcallid);
		sb.append(", aditid=");
		sb.append(aditid);
		sb.append(", dateonroadsafty=");
		sb.append(dateonroadsafty);
		sb.append(", time=");
		sb.append(time);
		sb.append(", investigationtitle=");
		sb.append(investigationtitle);
		sb.append(", location=");
		sb.append(location);
		sb.append(", company=");
		sb.append(company);
		sb.append(", statusverification=");
		sb.append(statusverification);
		sb.append(", operatorname=");
		sb.append(operatorname);
		sb.append(", nameofOfficer=");
		sb.append(nameofOfficer);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public AppointmentCall toEntityModel() {
		AppointmentCallImpl appointmentCallImpl = new AppointmentCallImpl();

		appointmentCallImpl.setRecordcallid(recordcallid);
		appointmentCallImpl.setAditid(aditid);

		if (dateonroadsafty == null) {
			appointmentCallImpl.setDateonroadsafty(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setDateonroadsafty(dateonroadsafty);
		}

		if (time == null) {
			appointmentCallImpl.setTime(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setTime(time);
		}

		if (investigationtitle == null) {
			appointmentCallImpl.setInvestigationtitle(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setInvestigationtitle(investigationtitle);
		}

		if (location == null) {
			appointmentCallImpl.setLocation(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setLocation(location);
		}

		if (company == null) {
			appointmentCallImpl.setCompany(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setCompany(company);
		}

		if (statusverification == null) {
			appointmentCallImpl.setStatusverification(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setStatusverification(statusverification);
		}

		if (operatorname == null) {
			appointmentCallImpl.setOperatorname(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setOperatorname(operatorname);
		}

		if (nameofOfficer == null) {
			appointmentCallImpl.setNameofOfficer(StringPool.BLANK);
		}
		else {
			appointmentCallImpl.setNameofOfficer(nameofOfficer);
		}

		appointmentCallImpl.resetOriginalValues();

		return appointmentCallImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		recordcallid = objectInput.readLong();
		aditid = objectInput.readLong();
		dateonroadsafty = objectInput.readUTF();
		time = objectInput.readUTF();
		investigationtitle = objectInput.readUTF();
		location = objectInput.readUTF();
		company = objectInput.readUTF();
		statusverification = objectInput.readUTF();
		operatorname = objectInput.readUTF();
		nameofOfficer = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(recordcallid);
		objectOutput.writeLong(aditid);

		if (dateonroadsafty == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateonroadsafty);
		}

		if (time == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(time);
		}

		if (investigationtitle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigationtitle);
		}

		if (location == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(location);
		}

		if (company == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(company);
		}

		if (statusverification == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusverification);
		}

		if (operatorname == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(operatorname);
		}

		if (nameofOfficer == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameofOfficer);
		}
	}

	public long recordcallid;
	public long aditid;
	public String dateonroadsafty;
	public String time;
	public String investigationtitle;
	public String location;
	public String company;
	public String statusverification;
	public String operatorname;
	public String nameofOfficer;
}