/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.spad.icop.NoSuchComplainCheckAuditException;
import com.spad.icop.model.ComplainCheckAudit;
import com.spad.icop.model.impl.ComplainCheckAuditImpl;
import com.spad.icop.model.impl.ComplainCheckAuditModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the complain check audit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see ComplainCheckAuditPersistence
 * @see ComplainCheckAuditUtil
 * @generated
 */
public class ComplainCheckAuditPersistenceImpl extends BasePersistenceImpl<ComplainCheckAudit>
	implements ComplainCheckAuditPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link ComplainCheckAuditUtil} to access the complain check audit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = ComplainCheckAuditImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ADITID = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByaditid",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADITID =
		new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByaditid",
			new String[] { Long.class.getName() },
			ComplainCheckAuditModelImpl.ADITID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ADITID = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByaditid",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the complain check audits where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @return the matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findByaditid(long aditid)
		throws SystemException {
		return findByaditid(aditid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the complain check audits where aditid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param aditid the aditid
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @return the range of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findByaditid(long aditid, int start, int end)
		throws SystemException {
		return findByaditid(aditid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the complain check audits where aditid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param aditid the aditid
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findByaditid(long aditid, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADITID;
			finderArgs = new Object[] { aditid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ADITID;
			finderArgs = new Object[] { aditid, start, end, orderByComparator };
		}

		List<ComplainCheckAudit> list = (List<ComplainCheckAudit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (ComplainCheckAudit complainCheckAudit : list) {
				if ((aditid != complainCheckAudit.getAditid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_COMPLAINCHECKAUDIT_WHERE);

			query.append(_FINDER_COLUMN_ADITID_ADITID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(ComplainCheckAuditModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(aditid);

				if (!pagination) {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<ComplainCheckAudit>(list);
				}
				else {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first complain check audit in the ordered set where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findByaditid_First(long aditid,
		OrderByComparator orderByComparator)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = fetchByaditid_First(aditid,
				orderByComparator);

		if (complainCheckAudit != null) {
			return complainCheckAudit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("aditid=");
		msg.append(aditid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchComplainCheckAuditException(msg.toString());
	}

	/**
	 * Returns the first complain check audit in the ordered set where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchByaditid_First(long aditid,
		OrderByComparator orderByComparator) throws SystemException {
		List<ComplainCheckAudit> list = findByaditid(aditid, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last complain check audit in the ordered set where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findByaditid_Last(long aditid,
		OrderByComparator orderByComparator)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = fetchByaditid_Last(aditid,
				orderByComparator);

		if (complainCheckAudit != null) {
			return complainCheckAudit;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("aditid=");
		msg.append(aditid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchComplainCheckAuditException(msg.toString());
	}

	/**
	 * Returns the last complain check audit in the ordered set where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchByaditid_Last(long aditid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByaditid(aditid);

		if (count == 0) {
			return null;
		}

		List<ComplainCheckAudit> list = findByaditid(aditid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the complain check audits before and after the current complain check audit in the ordered set where aditid = &#63;.
	 *
	 * @param matterId the primary key of the current complain check audit
	 * @param aditid the aditid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit[] findByaditid_PrevAndNext(long matterId,
		long aditid, OrderByComparator orderByComparator)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = findByPrimaryKey(matterId);

		Session session = null;

		try {
			session = openSession();

			ComplainCheckAudit[] array = new ComplainCheckAuditImpl[3];

			array[0] = getByaditid_PrevAndNext(session, complainCheckAudit,
					aditid, orderByComparator, true);

			array[1] = complainCheckAudit;

			array[2] = getByaditid_PrevAndNext(session, complainCheckAudit,
					aditid, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected ComplainCheckAudit getByaditid_PrevAndNext(Session session,
		ComplainCheckAudit complainCheckAudit, long aditid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_COMPLAINCHECKAUDIT_WHERE);

		query.append(_FINDER_COLUMN_ADITID_ADITID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(ComplainCheckAuditModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(aditid);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(complainCheckAudit);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<ComplainCheckAudit> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the complain check audits where aditid = &#63; from the database.
	 *
	 * @param aditid the aditid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByaditid(long aditid) throws SystemException {
		for (ComplainCheckAudit complainCheckAudit : findByaditid(aditid,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(complainCheckAudit);
		}
	}

	/**
	 * Returns the number of complain check audits where aditid = &#63;.
	 *
	 * @param aditid the aditid
	 * @return the number of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByaditid(long aditid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ADITID;

		Object[] finderArgs = new Object[] { aditid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_COMPLAINCHECKAUDIT_WHERE);

			query.append(_FINDER_COLUMN_ADITID_ADITID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(aditid);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ADITID_ADITID_2 = "complainCheckAudit.aditid = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_METTERAUDIT =
		new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBymetterAudit",
			new String[] {
				Long.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_METTERAUDIT =
		new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED,
			ComplainCheckAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBymetterAudit",
			new String[] { Long.class.getName(), Long.class.getName() },
			ComplainCheckAuditModelImpl.ADITID_COLUMN_BITMASK |
			ComplainCheckAuditModelImpl.MATTERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_METTERAUDIT = new FinderPath(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBymetterAudit",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns all the complain check audits where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @return the matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findBymetterAudit(long aditid, long matterId)
		throws SystemException {
		return findBymetterAudit(aditid, matterId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the complain check audits where aditid = &#63; and matterId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @return the range of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findBymetterAudit(long aditid,
		long matterId, int start, int end) throws SystemException {
		return findBymetterAudit(aditid, matterId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the complain check audits where aditid = &#63; and matterId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findBymetterAudit(long aditid,
		long matterId, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_METTERAUDIT;
			finderArgs = new Object[] { aditid, matterId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_METTERAUDIT;
			finderArgs = new Object[] {
					aditid, matterId,
					
					start, end, orderByComparator
				};
		}

		List<ComplainCheckAudit> list = (List<ComplainCheckAudit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (ComplainCheckAudit complainCheckAudit : list) {
				if ((aditid != complainCheckAudit.getAditid()) ||
						(matterId != complainCheckAudit.getMatterId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_COMPLAINCHECKAUDIT_WHERE);

			query.append(_FINDER_COLUMN_METTERAUDIT_ADITID_2);

			query.append(_FINDER_COLUMN_METTERAUDIT_MATTERID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(ComplainCheckAuditModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(aditid);

				qPos.add(matterId);

				if (!pagination) {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<ComplainCheckAudit>(list);
				}
				else {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findBymetterAudit_First(long aditid,
		long matterId, OrderByComparator orderByComparator)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = fetchBymetterAudit_First(aditid,
				matterId, orderByComparator);

		if (complainCheckAudit != null) {
			return complainCheckAudit;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("aditid=");
		msg.append(aditid);

		msg.append(", matterId=");
		msg.append(matterId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchComplainCheckAuditException(msg.toString());
	}

	/**
	 * Returns the first complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchBymetterAudit_First(long aditid,
		long matterId, OrderByComparator orderByComparator)
		throws SystemException {
		List<ComplainCheckAudit> list = findBymetterAudit(aditid, matterId, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findBymetterAudit_Last(long aditid,
		long matterId, OrderByComparator orderByComparator)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = fetchBymetterAudit_Last(aditid,
				matterId, orderByComparator);

		if (complainCheckAudit != null) {
			return complainCheckAudit;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("aditid=");
		msg.append(aditid);

		msg.append(", matterId=");
		msg.append(matterId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchComplainCheckAuditException(msg.toString());
	}

	/**
	 * Returns the last complain check audit in the ordered set where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching complain check audit, or <code>null</code> if a matching complain check audit could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchBymetterAudit_Last(long aditid,
		long matterId, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countBymetterAudit(aditid, matterId);

		if (count == 0) {
			return null;
		}

		List<ComplainCheckAudit> list = findBymetterAudit(aditid, matterId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the complain check audits where aditid = &#63; and matterId = &#63; from the database.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBymetterAudit(long aditid, long matterId)
		throws SystemException {
		for (ComplainCheckAudit complainCheckAudit : findBymetterAudit(aditid,
				matterId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(complainCheckAudit);
		}
	}

	/**
	 * Returns the number of complain check audits where aditid = &#63; and matterId = &#63;.
	 *
	 * @param aditid the aditid
	 * @param matterId the matter ID
	 * @return the number of matching complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBymetterAudit(long aditid, long matterId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_METTERAUDIT;

		Object[] finderArgs = new Object[] { aditid, matterId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_COMPLAINCHECKAUDIT_WHERE);

			query.append(_FINDER_COLUMN_METTERAUDIT_ADITID_2);

			query.append(_FINDER_COLUMN_METTERAUDIT_MATTERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(aditid);

				qPos.add(matterId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_METTERAUDIT_ADITID_2 = "complainCheckAudit.aditid = ? AND ";
	private static final String _FINDER_COLUMN_METTERAUDIT_MATTERID_2 = "complainCheckAudit.matterId = ?";

	public ComplainCheckAuditPersistenceImpl() {
		setModelClass(ComplainCheckAudit.class);
	}

	/**
	 * Caches the complain check audit in the entity cache if it is enabled.
	 *
	 * @param complainCheckAudit the complain check audit
	 */
	@Override
	public void cacheResult(ComplainCheckAudit complainCheckAudit) {
		EntityCacheUtil.putResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditImpl.class, complainCheckAudit.getPrimaryKey(),
			complainCheckAudit);

		complainCheckAudit.resetOriginalValues();
	}

	/**
	 * Caches the complain check audits in the entity cache if it is enabled.
	 *
	 * @param complainCheckAudits the complain check audits
	 */
	@Override
	public void cacheResult(List<ComplainCheckAudit> complainCheckAudits) {
		for (ComplainCheckAudit complainCheckAudit : complainCheckAudits) {
			if (EntityCacheUtil.getResult(
						ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
						ComplainCheckAuditImpl.class,
						complainCheckAudit.getPrimaryKey()) == null) {
				cacheResult(complainCheckAudit);
			}
			else {
				complainCheckAudit.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all complain check audits.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(ComplainCheckAuditImpl.class.getName());
		}

		EntityCacheUtil.clearCache(ComplainCheckAuditImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the complain check audit.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(ComplainCheckAudit complainCheckAudit) {
		EntityCacheUtil.removeResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditImpl.class, complainCheckAudit.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<ComplainCheckAudit> complainCheckAudits) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (ComplainCheckAudit complainCheckAudit : complainCheckAudits) {
			EntityCacheUtil.removeResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
				ComplainCheckAuditImpl.class, complainCheckAudit.getPrimaryKey());
		}
	}

	/**
	 * Creates a new complain check audit with the primary key. Does not add the complain check audit to the database.
	 *
	 * @param matterId the primary key for the new complain check audit
	 * @return the new complain check audit
	 */
	@Override
	public ComplainCheckAudit create(long matterId) {
		ComplainCheckAudit complainCheckAudit = new ComplainCheckAuditImpl();

		complainCheckAudit.setNew(true);
		complainCheckAudit.setPrimaryKey(matterId);

		return complainCheckAudit;
	}

	/**
	 * Removes the complain check audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param matterId the primary key of the complain check audit
	 * @return the complain check audit that was removed
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit remove(long matterId)
		throws NoSuchComplainCheckAuditException, SystemException {
		return remove((Serializable)matterId);
	}

	/**
	 * Removes the complain check audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the complain check audit
	 * @return the complain check audit that was removed
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit remove(Serializable primaryKey)
		throws NoSuchComplainCheckAuditException, SystemException {
		Session session = null;

		try {
			session = openSession();

			ComplainCheckAudit complainCheckAudit = (ComplainCheckAudit)session.get(ComplainCheckAuditImpl.class,
					primaryKey);

			if (complainCheckAudit == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchComplainCheckAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(complainCheckAudit);
		}
		catch (NoSuchComplainCheckAuditException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected ComplainCheckAudit removeImpl(
		ComplainCheckAudit complainCheckAudit) throws SystemException {
		complainCheckAudit = toUnwrappedModel(complainCheckAudit);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(complainCheckAudit)) {
				complainCheckAudit = (ComplainCheckAudit)session.get(ComplainCheckAuditImpl.class,
						complainCheckAudit.getPrimaryKeyObj());
			}

			if (complainCheckAudit != null) {
				session.delete(complainCheckAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (complainCheckAudit != null) {
			clearCache(complainCheckAudit);
		}

		return complainCheckAudit;
	}

	@Override
	public ComplainCheckAudit updateImpl(
		com.spad.icop.model.ComplainCheckAudit complainCheckAudit)
		throws SystemException {
		complainCheckAudit = toUnwrappedModel(complainCheckAudit);

		boolean isNew = complainCheckAudit.isNew();

		ComplainCheckAuditModelImpl complainCheckAuditModelImpl = (ComplainCheckAuditModelImpl)complainCheckAudit;

		Session session = null;

		try {
			session = openSession();

			if (complainCheckAudit.isNew()) {
				session.save(complainCheckAudit);

				complainCheckAudit.setNew(false);
			}
			else {
				session.merge(complainCheckAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !ComplainCheckAuditModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((complainCheckAuditModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADITID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						complainCheckAuditModelImpl.getOriginalAditid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ADITID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADITID,
					args);

				args = new Object[] { complainCheckAuditModelImpl.getAditid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ADITID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ADITID,
					args);
			}

			if ((complainCheckAuditModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_METTERAUDIT.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						complainCheckAuditModelImpl.getOriginalAditid(),
						complainCheckAuditModelImpl.getOriginalMatterId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_METTERAUDIT,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_METTERAUDIT,
					args);

				args = new Object[] {
						complainCheckAuditModelImpl.getAditid(),
						complainCheckAuditModelImpl.getMatterId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_METTERAUDIT,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_METTERAUDIT,
					args);
			}
		}

		EntityCacheUtil.putResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
			ComplainCheckAuditImpl.class, complainCheckAudit.getPrimaryKey(),
			complainCheckAudit);

		return complainCheckAudit;
	}

	protected ComplainCheckAudit toUnwrappedModel(
		ComplainCheckAudit complainCheckAudit) {
		if (complainCheckAudit instanceof ComplainCheckAuditImpl) {
			return complainCheckAudit;
		}

		ComplainCheckAuditImpl complainCheckAuditImpl = new ComplainCheckAuditImpl();

		complainCheckAuditImpl.setNew(complainCheckAudit.isNew());
		complainCheckAuditImpl.setPrimaryKey(complainCheckAudit.getPrimaryKey());

		complainCheckAuditImpl.setMatterId(complainCheckAudit.getMatterId());
		complainCheckAuditImpl.setAditid(complainCheckAudit.getAditid());
		complainCheckAuditImpl.setAuditdate1_1(complainCheckAudit.getAuditdate1_1());
		complainCheckAuditImpl.setAuditdateNote1_1(complainCheckAudit.getAuditdateNote1_1());
		complainCheckAuditImpl.setAuditdate1_2(complainCheckAudit.getAuditdate1_2());
		complainCheckAuditImpl.setAuditdateNote1_2(complainCheckAudit.getAuditdateNote1_2());
		complainCheckAuditImpl.setAuditdate1_3(complainCheckAudit.getAuditdate1_3());
		complainCheckAuditImpl.setAuditdateNote1_3(complainCheckAudit.getAuditdateNote1_3());
		complainCheckAuditImpl.setAuditdate1_4(complainCheckAudit.getAuditdate1_4());
		complainCheckAuditImpl.setAuditdateNote1_4(complainCheckAudit.getAuditdateNote1_4());
		complainCheckAuditImpl.setAuditdate1_5(complainCheckAudit.getAuditdate1_5());
		complainCheckAuditImpl.setAuditdateNote1_5(complainCheckAudit.getAuditdateNote1_5());
		complainCheckAuditImpl.setAuditdate1_6(complainCheckAudit.getAuditdate1_6());
		complainCheckAuditImpl.setAuditdateNote1_6(complainCheckAudit.getAuditdateNote1_6());
		complainCheckAuditImpl.setAuditdate1_7(complainCheckAudit.getAuditdate1_7());
		complainCheckAuditImpl.setAuditdateNote1_7(complainCheckAudit.getAuditdateNote1_7());
		complainCheckAuditImpl.setAuditdate2_1(complainCheckAudit.getAuditdate2_1());
		complainCheckAuditImpl.setAuditdateNote2_1(complainCheckAudit.getAuditdateNote2_1());
		complainCheckAuditImpl.setAuditdate2_2(complainCheckAudit.getAuditdate2_2());
		complainCheckAuditImpl.setAuditdateNote2_2(complainCheckAudit.getAuditdateNote2_2());
		complainCheckAuditImpl.setAuditdate2_3(complainCheckAudit.getAuditdate2_3());
		complainCheckAuditImpl.setAuditdateNote2_3(complainCheckAudit.getAuditdateNote2_3());
		complainCheckAuditImpl.setAuditdate2_4(complainCheckAudit.getAuditdate2_4());
		complainCheckAuditImpl.setAuditdateNote2_4(complainCheckAudit.getAuditdateNote2_4());
		complainCheckAuditImpl.setAuditdate2_4_1(complainCheckAudit.getAuditdate2_4_1());
		complainCheckAuditImpl.setAuditdateNote2_4_1(complainCheckAudit.getAuditdateNote2_4_1());
		complainCheckAuditImpl.setAuditdate2_4_2(complainCheckAudit.getAuditdate2_4_2());
		complainCheckAuditImpl.setAuditdateNote2_4_2(complainCheckAudit.getAuditdateNote2_4_2());
		complainCheckAuditImpl.setAuditdate2_4_3(complainCheckAudit.getAuditdate2_4_3());
		complainCheckAuditImpl.setAuditdateNote2_4_3(complainCheckAudit.getAuditdateNote2_4_3());
		complainCheckAuditImpl.setAuditdate2_4_4(complainCheckAudit.getAuditdate2_4_4());
		complainCheckAuditImpl.setAuditdateNote2_4_4(complainCheckAudit.getAuditdateNote2_4_4());
		complainCheckAuditImpl.setAuditdate2_4_5(complainCheckAudit.getAuditdate2_4_5());
		complainCheckAuditImpl.setAuditdateNote2_4_5(complainCheckAudit.getAuditdateNote2_4_5());
		complainCheckAuditImpl.setAuditdate2_4_6(complainCheckAudit.getAuditdate2_4_6());
		complainCheckAuditImpl.setAuditdateNote2_4_6(complainCheckAudit.getAuditdateNote2_4_6());
		complainCheckAuditImpl.setAuditdate3_1(complainCheckAudit.getAuditdate3_1());
		complainCheckAuditImpl.setAuditdate3_2(complainCheckAudit.getAuditdate3_2());
		complainCheckAuditImpl.setAuditdate3_3(complainCheckAudit.getAuditdate3_3());
		complainCheckAuditImpl.setAuditdate3_4(complainCheckAudit.getAuditdate3_4());
		complainCheckAuditImpl.setAuditdate3_5(complainCheckAudit.getAuditdate3_5());
		complainCheckAuditImpl.setAuditdate3_6(complainCheckAudit.getAuditdate3_6());
		complainCheckAuditImpl.setAuditdateNote3_1(complainCheckAudit.getAuditdateNote3_1());
		complainCheckAuditImpl.setAuditdateNote3_2(complainCheckAudit.getAuditdateNote3_2());
		complainCheckAuditImpl.setAuditdateNote3_3(complainCheckAudit.getAuditdateNote3_3());
		complainCheckAuditImpl.setAuditdateNote3_4(complainCheckAudit.getAuditdateNote3_4());
		complainCheckAuditImpl.setAuditdateNote3_5(complainCheckAudit.getAuditdateNote3_5());
		complainCheckAuditImpl.setAuditdateNote3_6(complainCheckAudit.getAuditdateNote3_6());
		complainCheckAuditImpl.setAuditdate4_1(complainCheckAudit.getAuditdate4_1());
		complainCheckAuditImpl.setAuditdate4_2(complainCheckAudit.getAuditdate4_2());
		complainCheckAuditImpl.setAuditdate4_3(complainCheckAudit.getAuditdate4_3());
		complainCheckAuditImpl.setAuditdateNote4_1(complainCheckAudit.getAuditdateNote4_1());
		complainCheckAuditImpl.setAuditdateNote4_2(complainCheckAudit.getAuditdateNote4_2());
		complainCheckAuditImpl.setAuditdateNote4_3(complainCheckAudit.getAuditdateNote4_3());
		complainCheckAuditImpl.setAuditdate5_1(complainCheckAudit.getAuditdate5_1());
		complainCheckAuditImpl.setAuditdate5_2(complainCheckAudit.getAuditdate5_2());
		complainCheckAuditImpl.setAuditdate5_3(complainCheckAudit.getAuditdate5_3());
		complainCheckAuditImpl.setAuditdate5_4(complainCheckAudit.getAuditdate5_4());
		complainCheckAuditImpl.setAuditdate5_5(complainCheckAudit.getAuditdate5_5());
		complainCheckAuditImpl.setAuditdate5_6(complainCheckAudit.getAuditdate5_6());
		complainCheckAuditImpl.setAuditdate5_7(complainCheckAudit.getAuditdate5_7());
		complainCheckAuditImpl.setAuditdate5_8(complainCheckAudit.getAuditdate5_8());
		complainCheckAuditImpl.setAuditdateNote5_1(complainCheckAudit.getAuditdateNote5_1());
		complainCheckAuditImpl.setAuditdateNote5_2(complainCheckAudit.getAuditdateNote5_2());
		complainCheckAuditImpl.setAuditdateNote5_3(complainCheckAudit.getAuditdateNote5_3());
		complainCheckAuditImpl.setAuditdateNote5_4(complainCheckAudit.getAuditdateNote5_4());
		complainCheckAuditImpl.setAuditdateNote5_5(complainCheckAudit.getAuditdateNote5_5());
		complainCheckAuditImpl.setAuditdateNote5_6(complainCheckAudit.getAuditdateNote5_6());
		complainCheckAuditImpl.setAuditdateNote5_7(complainCheckAudit.getAuditdateNote5_7());
		complainCheckAuditImpl.setAuditdateNote5_8(complainCheckAudit.getAuditdateNote5_8());

		return complainCheckAuditImpl;
	}

	/**
	 * Returns the complain check audit with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the complain check audit
	 * @return the complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findByPrimaryKey(Serializable primaryKey)
		throws NoSuchComplainCheckAuditException, SystemException {
		ComplainCheckAudit complainCheckAudit = fetchByPrimaryKey(primaryKey);

		if (complainCheckAudit == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchComplainCheckAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return complainCheckAudit;
	}

	/**
	 * Returns the complain check audit with the primary key or throws a {@link com.spad.icop.NoSuchComplainCheckAuditException} if it could not be found.
	 *
	 * @param matterId the primary key of the complain check audit
	 * @return the complain check audit
	 * @throws com.spad.icop.NoSuchComplainCheckAuditException if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit findByPrimaryKey(long matterId)
		throws NoSuchComplainCheckAuditException, SystemException {
		return findByPrimaryKey((Serializable)matterId);
	}

	/**
	 * Returns the complain check audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the complain check audit
	 * @return the complain check audit, or <code>null</code> if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		ComplainCheckAudit complainCheckAudit = (ComplainCheckAudit)EntityCacheUtil.getResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
				ComplainCheckAuditImpl.class, primaryKey);

		if (complainCheckAudit == _nullComplainCheckAudit) {
			return null;
		}

		if (complainCheckAudit == null) {
			Session session = null;

			try {
				session = openSession();

				complainCheckAudit = (ComplainCheckAudit)session.get(ComplainCheckAuditImpl.class,
						primaryKey);

				if (complainCheckAudit != null) {
					cacheResult(complainCheckAudit);
				}
				else {
					EntityCacheUtil.putResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
						ComplainCheckAuditImpl.class, primaryKey,
						_nullComplainCheckAudit);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(ComplainCheckAuditModelImpl.ENTITY_CACHE_ENABLED,
					ComplainCheckAuditImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return complainCheckAudit;
	}

	/**
	 * Returns the complain check audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param matterId the primary key of the complain check audit
	 * @return the complain check audit, or <code>null</code> if a complain check audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ComplainCheckAudit fetchByPrimaryKey(long matterId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)matterId);
	}

	/**
	 * Returns all the complain check audits.
	 *
	 * @return the complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the complain check audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @return the range of complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the complain check audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.ComplainCheckAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of complain check audits
	 * @param end the upper bound of the range of complain check audits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ComplainCheckAudit> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<ComplainCheckAudit> list = (List<ComplainCheckAudit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_COMPLAINCHECKAUDIT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_COMPLAINCHECKAUDIT;

				if (pagination) {
					sql = sql.concat(ComplainCheckAuditModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<ComplainCheckAudit>(list);
				}
				else {
					list = (List<ComplainCheckAudit>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the complain check audits from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (ComplainCheckAudit complainCheckAudit : findAll()) {
			remove(complainCheckAudit);
		}
	}

	/**
	 * Returns the number of complain check audits.
	 *
	 * @return the number of complain check audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_COMPLAINCHECKAUDIT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the complain check audit persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.spad.icop.model.ComplainCheckAudit")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<ComplainCheckAudit>> listenersList = new ArrayList<ModelListener<ComplainCheckAudit>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<ComplainCheckAudit>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(ComplainCheckAuditImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_COMPLAINCHECKAUDIT = "SELECT complainCheckAudit FROM ComplainCheckAudit complainCheckAudit";
	private static final String _SQL_SELECT_COMPLAINCHECKAUDIT_WHERE = "SELECT complainCheckAudit FROM ComplainCheckAudit complainCheckAudit WHERE ";
	private static final String _SQL_COUNT_COMPLAINCHECKAUDIT = "SELECT COUNT(complainCheckAudit) FROM ComplainCheckAudit complainCheckAudit";
	private static final String _SQL_COUNT_COMPLAINCHECKAUDIT_WHERE = "SELECT COUNT(complainCheckAudit) FROM ComplainCheckAudit complainCheckAudit WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "complainCheckAudit.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ComplainCheckAudit exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ComplainCheckAudit exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(ComplainCheckAuditPersistenceImpl.class);
	private static ComplainCheckAudit _nullComplainCheckAudit = new ComplainCheckAuditImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<ComplainCheckAudit> toCacheModel() {
				return _nullComplainCheckAuditCacheModel;
			}
		};

	private static CacheModel<ComplainCheckAudit> _nullComplainCheckAuditCacheModel =
		new CacheModel<ComplainCheckAudit>() {
			@Override
			public ComplainCheckAudit toEntityModel() {
				return _nullComplainCheckAudit;
			}
		};
}