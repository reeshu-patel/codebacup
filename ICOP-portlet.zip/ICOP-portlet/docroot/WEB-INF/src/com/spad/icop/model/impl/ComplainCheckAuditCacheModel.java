/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.ComplainCheckAudit;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing ComplainCheckAudit in entity cache.
 *
 * @author reeshu
 * @see ComplainCheckAudit
 * @generated
 */
public class ComplainCheckAuditCacheModel implements CacheModel<ComplainCheckAudit>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(141);

		sb.append("{matterId=");
		sb.append(matterId);
		sb.append(", aditid=");
		sb.append(aditid);
		sb.append(", auditdate1_1=");
		sb.append(auditdate1_1);
		sb.append(", auditdateNote1_1=");
		sb.append(auditdateNote1_1);
		sb.append(", auditdate1_2=");
		sb.append(auditdate1_2);
		sb.append(", auditdateNote1_2=");
		sb.append(auditdateNote1_2);
		sb.append(", auditdate1_3=");
		sb.append(auditdate1_3);
		sb.append(", auditdateNote1_3=");
		sb.append(auditdateNote1_3);
		sb.append(", auditdate1_4=");
		sb.append(auditdate1_4);
		sb.append(", auditdateNote1_4=");
		sb.append(auditdateNote1_4);
		sb.append(", auditdate1_5=");
		sb.append(auditdate1_5);
		sb.append(", auditdateNote1_5=");
		sb.append(auditdateNote1_5);
		sb.append(", auditdate1_6=");
		sb.append(auditdate1_6);
		sb.append(", auditdateNote1_6=");
		sb.append(auditdateNote1_6);
		sb.append(", auditdate1_7=");
		sb.append(auditdate1_7);
		sb.append(", auditdateNote1_7=");
		sb.append(auditdateNote1_7);
		sb.append(", auditdate2_1=");
		sb.append(auditdate2_1);
		sb.append(", auditdateNote2_1=");
		sb.append(auditdateNote2_1);
		sb.append(", auditdate2_2=");
		sb.append(auditdate2_2);
		sb.append(", auditdateNote2_2=");
		sb.append(auditdateNote2_2);
		sb.append(", auditdate2_3=");
		sb.append(auditdate2_3);
		sb.append(", auditdateNote2_3=");
		sb.append(auditdateNote2_3);
		sb.append(", auditdate2_4=");
		sb.append(auditdate2_4);
		sb.append(", auditdateNote2_4=");
		sb.append(auditdateNote2_4);
		sb.append(", auditdate2_4_1=");
		sb.append(auditdate2_4_1);
		sb.append(", auditdateNote2_4_1=");
		sb.append(auditdateNote2_4_1);
		sb.append(", auditdate2_4_2=");
		sb.append(auditdate2_4_2);
		sb.append(", auditdateNote2_4_2=");
		sb.append(auditdateNote2_4_2);
		sb.append(", auditdate2_4_3=");
		sb.append(auditdate2_4_3);
		sb.append(", auditdateNote2_4_3=");
		sb.append(auditdateNote2_4_3);
		sb.append(", auditdate2_4_4=");
		sb.append(auditdate2_4_4);
		sb.append(", auditdateNote2_4_4=");
		sb.append(auditdateNote2_4_4);
		sb.append(", auditdate2_4_5=");
		sb.append(auditdate2_4_5);
		sb.append(", auditdateNote2_4_5=");
		sb.append(auditdateNote2_4_5);
		sb.append(", auditdate2_4_6=");
		sb.append(auditdate2_4_6);
		sb.append(", auditdateNote2_4_6=");
		sb.append(auditdateNote2_4_6);
		sb.append(", auditdate3_1=");
		sb.append(auditdate3_1);
		sb.append(", auditdate3_2=");
		sb.append(auditdate3_2);
		sb.append(", auditdate3_3=");
		sb.append(auditdate3_3);
		sb.append(", auditdate3_4=");
		sb.append(auditdate3_4);
		sb.append(", auditdate3_5=");
		sb.append(auditdate3_5);
		sb.append(", auditdate3_6=");
		sb.append(auditdate3_6);
		sb.append(", auditdateNote3_1=");
		sb.append(auditdateNote3_1);
		sb.append(", auditdateNote3_2=");
		sb.append(auditdateNote3_2);
		sb.append(", auditdateNote3_3=");
		sb.append(auditdateNote3_3);
		sb.append(", auditdateNote3_4=");
		sb.append(auditdateNote3_4);
		sb.append(", auditdateNote3_5=");
		sb.append(auditdateNote3_5);
		sb.append(", auditdateNote3_6=");
		sb.append(auditdateNote3_6);
		sb.append(", auditdate4_1=");
		sb.append(auditdate4_1);
		sb.append(", auditdate4_2=");
		sb.append(auditdate4_2);
		sb.append(", auditdate4_3=");
		sb.append(auditdate4_3);
		sb.append(", auditdateNote4_1=");
		sb.append(auditdateNote4_1);
		sb.append(", auditdateNote4_2=");
		sb.append(auditdateNote4_2);
		sb.append(", auditdateNote4_3=");
		sb.append(auditdateNote4_3);
		sb.append(", auditdate5_1=");
		sb.append(auditdate5_1);
		sb.append(", auditdate5_2=");
		sb.append(auditdate5_2);
		sb.append(", auditdate5_3=");
		sb.append(auditdate5_3);
		sb.append(", auditdate5_4=");
		sb.append(auditdate5_4);
		sb.append(", auditdate5_5=");
		sb.append(auditdate5_5);
		sb.append(", auditdate5_6=");
		sb.append(auditdate5_6);
		sb.append(", auditdate5_7=");
		sb.append(auditdate5_7);
		sb.append(", auditdate5_8=");
		sb.append(auditdate5_8);
		sb.append(", auditdateNote5_1=");
		sb.append(auditdateNote5_1);
		sb.append(", auditdateNote5_2=");
		sb.append(auditdateNote5_2);
		sb.append(", auditdateNote5_3=");
		sb.append(auditdateNote5_3);
		sb.append(", auditdateNote5_4=");
		sb.append(auditdateNote5_4);
		sb.append(", auditdateNote5_5=");
		sb.append(auditdateNote5_5);
		sb.append(", auditdateNote5_6=");
		sb.append(auditdateNote5_6);
		sb.append(", auditdateNote5_7=");
		sb.append(auditdateNote5_7);
		sb.append(", auditdateNote5_8=");
		sb.append(auditdateNote5_8);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ComplainCheckAudit toEntityModel() {
		ComplainCheckAuditImpl complainCheckAuditImpl = new ComplainCheckAuditImpl();

		complainCheckAuditImpl.setMatterId(matterId);
		complainCheckAuditImpl.setAditid(aditid);

		if (auditdate1_1 == null) {
			complainCheckAuditImpl.setAuditdate1_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_1(auditdate1_1);
		}

		if (auditdateNote1_1 == null) {
			complainCheckAuditImpl.setAuditdateNote1_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_1(auditdateNote1_1);
		}

		if (auditdate1_2 == null) {
			complainCheckAuditImpl.setAuditdate1_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_2(auditdate1_2);
		}

		if (auditdateNote1_2 == null) {
			complainCheckAuditImpl.setAuditdateNote1_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_2(auditdateNote1_2);
		}

		if (auditdate1_3 == null) {
			complainCheckAuditImpl.setAuditdate1_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_3(auditdate1_3);
		}

		if (auditdateNote1_3 == null) {
			complainCheckAuditImpl.setAuditdateNote1_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_3(auditdateNote1_3);
		}

		if (auditdate1_4 == null) {
			complainCheckAuditImpl.setAuditdate1_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_4(auditdate1_4);
		}

		if (auditdateNote1_4 == null) {
			complainCheckAuditImpl.setAuditdateNote1_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_4(auditdateNote1_4);
		}

		if (auditdate1_5 == null) {
			complainCheckAuditImpl.setAuditdate1_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_5(auditdate1_5);
		}

		if (auditdateNote1_5 == null) {
			complainCheckAuditImpl.setAuditdateNote1_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_5(auditdateNote1_5);
		}

		if (auditdate1_6 == null) {
			complainCheckAuditImpl.setAuditdate1_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_6(auditdate1_6);
		}

		if (auditdateNote1_6 == null) {
			complainCheckAuditImpl.setAuditdateNote1_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_6(auditdateNote1_6);
		}

		if (auditdate1_7 == null) {
			complainCheckAuditImpl.setAuditdate1_7(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate1_7(auditdate1_7);
		}

		if (auditdateNote1_7 == null) {
			complainCheckAuditImpl.setAuditdateNote1_7(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote1_7(auditdateNote1_7);
		}

		if (auditdate2_1 == null) {
			complainCheckAuditImpl.setAuditdate2_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_1(auditdate2_1);
		}

		if (auditdateNote2_1 == null) {
			complainCheckAuditImpl.setAuditdateNote2_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_1(auditdateNote2_1);
		}

		if (auditdate2_2 == null) {
			complainCheckAuditImpl.setAuditdate2_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_2(auditdate2_2);
		}

		if (auditdateNote2_2 == null) {
			complainCheckAuditImpl.setAuditdateNote2_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_2(auditdateNote2_2);
		}

		if (auditdate2_3 == null) {
			complainCheckAuditImpl.setAuditdate2_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_3(auditdate2_3);
		}

		if (auditdateNote2_3 == null) {
			complainCheckAuditImpl.setAuditdateNote2_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_3(auditdateNote2_3);
		}

		if (auditdate2_4 == null) {
			complainCheckAuditImpl.setAuditdate2_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4(auditdate2_4);
		}

		if (auditdateNote2_4 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4(auditdateNote2_4);
		}

		if (auditdate2_4_1 == null) {
			complainCheckAuditImpl.setAuditdate2_4_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_1(auditdate2_4_1);
		}

		if (auditdateNote2_4_1 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_1(auditdateNote2_4_1);
		}

		if (auditdate2_4_2 == null) {
			complainCheckAuditImpl.setAuditdate2_4_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_2(auditdate2_4_2);
		}

		if (auditdateNote2_4_2 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_2(auditdateNote2_4_2);
		}

		if (auditdate2_4_3 == null) {
			complainCheckAuditImpl.setAuditdate2_4_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_3(auditdate2_4_3);
		}

		if (auditdateNote2_4_3 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_3(auditdateNote2_4_3);
		}

		if (auditdate2_4_4 == null) {
			complainCheckAuditImpl.setAuditdate2_4_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_4(auditdate2_4_4);
		}

		if (auditdateNote2_4_4 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_4(auditdateNote2_4_4);
		}

		if (auditdate2_4_5 == null) {
			complainCheckAuditImpl.setAuditdate2_4_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_5(auditdate2_4_5);
		}

		if (auditdateNote2_4_5 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_5(auditdateNote2_4_5);
		}

		if (auditdate2_4_6 == null) {
			complainCheckAuditImpl.setAuditdate2_4_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate2_4_6(auditdate2_4_6);
		}

		if (auditdateNote2_4_6 == null) {
			complainCheckAuditImpl.setAuditdateNote2_4_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote2_4_6(auditdateNote2_4_6);
		}

		if (auditdate3_1 == null) {
			complainCheckAuditImpl.setAuditdate3_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_1(auditdate3_1);
		}

		if (auditdate3_2 == null) {
			complainCheckAuditImpl.setAuditdate3_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_2(auditdate3_2);
		}

		if (auditdate3_3 == null) {
			complainCheckAuditImpl.setAuditdate3_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_3(auditdate3_3);
		}

		if (auditdate3_4 == null) {
			complainCheckAuditImpl.setAuditdate3_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_4(auditdate3_4);
		}

		if (auditdate3_5 == null) {
			complainCheckAuditImpl.setAuditdate3_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_5(auditdate3_5);
		}

		if (auditdate3_6 == null) {
			complainCheckAuditImpl.setAuditdate3_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate3_6(auditdate3_6);
		}

		if (auditdateNote3_1 == null) {
			complainCheckAuditImpl.setAuditdateNote3_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_1(auditdateNote3_1);
		}

		if (auditdateNote3_2 == null) {
			complainCheckAuditImpl.setAuditdateNote3_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_2(auditdateNote3_2);
		}

		if (auditdateNote3_3 == null) {
			complainCheckAuditImpl.setAuditdateNote3_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_3(auditdateNote3_3);
		}

		if (auditdateNote3_4 == null) {
			complainCheckAuditImpl.setAuditdateNote3_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_4(auditdateNote3_4);
		}

		if (auditdateNote3_5 == null) {
			complainCheckAuditImpl.setAuditdateNote3_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_5(auditdateNote3_5);
		}

		if (auditdateNote3_6 == null) {
			complainCheckAuditImpl.setAuditdateNote3_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote3_6(auditdateNote3_6);
		}

		if (auditdate4_1 == null) {
			complainCheckAuditImpl.setAuditdate4_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate4_1(auditdate4_1);
		}

		if (auditdate4_2 == null) {
			complainCheckAuditImpl.setAuditdate4_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate4_2(auditdate4_2);
		}

		if (auditdate4_3 == null) {
			complainCheckAuditImpl.setAuditdate4_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate4_3(auditdate4_3);
		}

		if (auditdateNote4_1 == null) {
			complainCheckAuditImpl.setAuditdateNote4_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote4_1(auditdateNote4_1);
		}

		if (auditdateNote4_2 == null) {
			complainCheckAuditImpl.setAuditdateNote4_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote4_2(auditdateNote4_2);
		}

		if (auditdateNote4_3 == null) {
			complainCheckAuditImpl.setAuditdateNote4_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote4_3(auditdateNote4_3);
		}

		if (auditdate5_1 == null) {
			complainCheckAuditImpl.setAuditdate5_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_1(auditdate5_1);
		}

		if (auditdate5_2 == null) {
			complainCheckAuditImpl.setAuditdate5_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_2(auditdate5_2);
		}

		if (auditdate5_3 == null) {
			complainCheckAuditImpl.setAuditdate5_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_3(auditdate5_3);
		}

		if (auditdate5_4 == null) {
			complainCheckAuditImpl.setAuditdate5_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_4(auditdate5_4);
		}

		if (auditdate5_5 == null) {
			complainCheckAuditImpl.setAuditdate5_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_5(auditdate5_5);
		}

		if (auditdate5_6 == null) {
			complainCheckAuditImpl.setAuditdate5_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_6(auditdate5_6);
		}

		if (auditdate5_7 == null) {
			complainCheckAuditImpl.setAuditdate5_7(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_7(auditdate5_7);
		}

		if (auditdate5_8 == null) {
			complainCheckAuditImpl.setAuditdate5_8(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdate5_8(auditdate5_8);
		}

		if (auditdateNote5_1 == null) {
			complainCheckAuditImpl.setAuditdateNote5_1(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_1(auditdateNote5_1);
		}

		if (auditdateNote5_2 == null) {
			complainCheckAuditImpl.setAuditdateNote5_2(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_2(auditdateNote5_2);
		}

		if (auditdateNote5_3 == null) {
			complainCheckAuditImpl.setAuditdateNote5_3(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_3(auditdateNote5_3);
		}

		if (auditdateNote5_4 == null) {
			complainCheckAuditImpl.setAuditdateNote5_4(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_4(auditdateNote5_4);
		}

		if (auditdateNote5_5 == null) {
			complainCheckAuditImpl.setAuditdateNote5_5(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_5(auditdateNote5_5);
		}

		if (auditdateNote5_6 == null) {
			complainCheckAuditImpl.setAuditdateNote5_6(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_6(auditdateNote5_6);
		}

		if (auditdateNote5_7 == null) {
			complainCheckAuditImpl.setAuditdateNote5_7(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_7(auditdateNote5_7);
		}

		if (auditdateNote5_8 == null) {
			complainCheckAuditImpl.setAuditdateNote5_8(StringPool.BLANK);
		}
		else {
			complainCheckAuditImpl.setAuditdateNote5_8(auditdateNote5_8);
		}

		complainCheckAuditImpl.resetOriginalValues();

		return complainCheckAuditImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		matterId = objectInput.readLong();
		aditid = objectInput.readLong();
		auditdate1_1 = objectInput.readUTF();
		auditdateNote1_1 = objectInput.readUTF();
		auditdate1_2 = objectInput.readUTF();
		auditdateNote1_2 = objectInput.readUTF();
		auditdate1_3 = objectInput.readUTF();
		auditdateNote1_3 = objectInput.readUTF();
		auditdate1_4 = objectInput.readUTF();
		auditdateNote1_4 = objectInput.readUTF();
		auditdate1_5 = objectInput.readUTF();
		auditdateNote1_5 = objectInput.readUTF();
		auditdate1_6 = objectInput.readUTF();
		auditdateNote1_6 = objectInput.readUTF();
		auditdate1_7 = objectInput.readUTF();
		auditdateNote1_7 = objectInput.readUTF();
		auditdate2_1 = objectInput.readUTF();
		auditdateNote2_1 = objectInput.readUTF();
		auditdate2_2 = objectInput.readUTF();
		auditdateNote2_2 = objectInput.readUTF();
		auditdate2_3 = objectInput.readUTF();
		auditdateNote2_3 = objectInput.readUTF();
		auditdate2_4 = objectInput.readUTF();
		auditdateNote2_4 = objectInput.readUTF();
		auditdate2_4_1 = objectInput.readUTF();
		auditdateNote2_4_1 = objectInput.readUTF();
		auditdate2_4_2 = objectInput.readUTF();
		auditdateNote2_4_2 = objectInput.readUTF();
		auditdate2_4_3 = objectInput.readUTF();
		auditdateNote2_4_3 = objectInput.readUTF();
		auditdate2_4_4 = objectInput.readUTF();
		auditdateNote2_4_4 = objectInput.readUTF();
		auditdate2_4_5 = objectInput.readUTF();
		auditdateNote2_4_5 = objectInput.readUTF();
		auditdate2_4_6 = objectInput.readUTF();
		auditdateNote2_4_6 = objectInput.readUTF();
		auditdate3_1 = objectInput.readUTF();
		auditdate3_2 = objectInput.readUTF();
		auditdate3_3 = objectInput.readUTF();
		auditdate3_4 = objectInput.readUTF();
		auditdate3_5 = objectInput.readUTF();
		auditdate3_6 = objectInput.readUTF();
		auditdateNote3_1 = objectInput.readUTF();
		auditdateNote3_2 = objectInput.readUTF();
		auditdateNote3_3 = objectInput.readUTF();
		auditdateNote3_4 = objectInput.readUTF();
		auditdateNote3_5 = objectInput.readUTF();
		auditdateNote3_6 = objectInput.readUTF();
		auditdate4_1 = objectInput.readUTF();
		auditdate4_2 = objectInput.readUTF();
		auditdate4_3 = objectInput.readUTF();
		auditdateNote4_1 = objectInput.readUTF();
		auditdateNote4_2 = objectInput.readUTF();
		auditdateNote4_3 = objectInput.readUTF();
		auditdate5_1 = objectInput.readUTF();
		auditdate5_2 = objectInput.readUTF();
		auditdate5_3 = objectInput.readUTF();
		auditdate5_4 = objectInput.readUTF();
		auditdate5_5 = objectInput.readUTF();
		auditdate5_6 = objectInput.readUTF();
		auditdate5_7 = objectInput.readUTF();
		auditdate5_8 = objectInput.readUTF();
		auditdateNote5_1 = objectInput.readUTF();
		auditdateNote5_2 = objectInput.readUTF();
		auditdateNote5_3 = objectInput.readUTF();
		auditdateNote5_4 = objectInput.readUTF();
		auditdateNote5_5 = objectInput.readUTF();
		auditdateNote5_6 = objectInput.readUTF();
		auditdateNote5_7 = objectInput.readUTF();
		auditdateNote5_8 = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(matterId);
		objectOutput.writeLong(aditid);

		if (auditdate1_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_1);
		}

		if (auditdateNote1_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_1);
		}

		if (auditdate1_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_2);
		}

		if (auditdateNote1_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_2);
		}

		if (auditdate1_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_3);
		}

		if (auditdateNote1_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_3);
		}

		if (auditdate1_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_4);
		}

		if (auditdateNote1_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_4);
		}

		if (auditdate1_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_5);
		}

		if (auditdateNote1_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_5);
		}

		if (auditdate1_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_6);
		}

		if (auditdateNote1_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_6);
		}

		if (auditdate1_7 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate1_7);
		}

		if (auditdateNote1_7 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote1_7);
		}

		if (auditdate2_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_1);
		}

		if (auditdateNote2_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_1);
		}

		if (auditdate2_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_2);
		}

		if (auditdateNote2_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_2);
		}

		if (auditdate2_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_3);
		}

		if (auditdateNote2_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_3);
		}

		if (auditdate2_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4);
		}

		if (auditdateNote2_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4);
		}

		if (auditdate2_4_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_1);
		}

		if (auditdateNote2_4_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_1);
		}

		if (auditdate2_4_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_2);
		}

		if (auditdateNote2_4_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_2);
		}

		if (auditdate2_4_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_3);
		}

		if (auditdateNote2_4_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_3);
		}

		if (auditdate2_4_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_4);
		}

		if (auditdateNote2_4_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_4);
		}

		if (auditdate2_4_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_5);
		}

		if (auditdateNote2_4_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_5);
		}

		if (auditdate2_4_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate2_4_6);
		}

		if (auditdateNote2_4_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote2_4_6);
		}

		if (auditdate3_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_1);
		}

		if (auditdate3_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_2);
		}

		if (auditdate3_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_3);
		}

		if (auditdate3_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_4);
		}

		if (auditdate3_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_5);
		}

		if (auditdate3_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate3_6);
		}

		if (auditdateNote3_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_1);
		}

		if (auditdateNote3_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_2);
		}

		if (auditdateNote3_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_3);
		}

		if (auditdateNote3_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_4);
		}

		if (auditdateNote3_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_5);
		}

		if (auditdateNote3_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote3_6);
		}

		if (auditdate4_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate4_1);
		}

		if (auditdate4_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate4_2);
		}

		if (auditdate4_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate4_3);
		}

		if (auditdateNote4_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote4_1);
		}

		if (auditdateNote4_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote4_2);
		}

		if (auditdateNote4_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote4_3);
		}

		if (auditdate5_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_1);
		}

		if (auditdate5_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_2);
		}

		if (auditdate5_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_3);
		}

		if (auditdate5_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_4);
		}

		if (auditdate5_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_5);
		}

		if (auditdate5_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_6);
		}

		if (auditdate5_7 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_7);
		}

		if (auditdate5_8 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdate5_8);
		}

		if (auditdateNote5_1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_1);
		}

		if (auditdateNote5_2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_2);
		}

		if (auditdateNote5_3 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_3);
		}

		if (auditdateNote5_4 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_4);
		}

		if (auditdateNote5_5 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_5);
		}

		if (auditdateNote5_6 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_6);
		}

		if (auditdateNote5_7 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_7);
		}

		if (auditdateNote5_8 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditdateNote5_8);
		}
	}

	public long matterId;
	public long aditid;
	public String auditdate1_1;
	public String auditdateNote1_1;
	public String auditdate1_2;
	public String auditdateNote1_2;
	public String auditdate1_3;
	public String auditdateNote1_3;
	public String auditdate1_4;
	public String auditdateNote1_4;
	public String auditdate1_5;
	public String auditdateNote1_5;
	public String auditdate1_6;
	public String auditdateNote1_6;
	public String auditdate1_7;
	public String auditdateNote1_7;
	public String auditdate2_1;
	public String auditdateNote2_1;
	public String auditdate2_2;
	public String auditdateNote2_2;
	public String auditdate2_3;
	public String auditdateNote2_3;
	public String auditdate2_4;
	public String auditdateNote2_4;
	public String auditdate2_4_1;
	public String auditdateNote2_4_1;
	public String auditdate2_4_2;
	public String auditdateNote2_4_2;
	public String auditdate2_4_3;
	public String auditdateNote2_4_3;
	public String auditdate2_4_4;
	public String auditdateNote2_4_4;
	public String auditdate2_4_5;
	public String auditdateNote2_4_5;
	public String auditdate2_4_6;
	public String auditdateNote2_4_6;
	public String auditdate3_1;
	public String auditdate3_2;
	public String auditdate3_3;
	public String auditdate3_4;
	public String auditdate3_5;
	public String auditdate3_6;
	public String auditdateNote3_1;
	public String auditdateNote3_2;
	public String auditdateNote3_3;
	public String auditdateNote3_4;
	public String auditdateNote3_5;
	public String auditdateNote3_6;
	public String auditdate4_1;
	public String auditdate4_2;
	public String auditdate4_3;
	public String auditdateNote4_1;
	public String auditdateNote4_2;
	public String auditdateNote4_3;
	public String auditdate5_1;
	public String auditdate5_2;
	public String auditdate5_3;
	public String auditdate5_4;
	public String auditdate5_5;
	public String auditdate5_6;
	public String auditdate5_7;
	public String auditdate5_8;
	public String auditdateNote5_1;
	public String auditdateNote5_2;
	public String auditdateNote5_3;
	public String auditdateNote5_4;
	public String auditdateNote5_5;
	public String auditdateNote5_6;
	public String auditdateNote5_7;
	public String auditdateNote5_8;
}