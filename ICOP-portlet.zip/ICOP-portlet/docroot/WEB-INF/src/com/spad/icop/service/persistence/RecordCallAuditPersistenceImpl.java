/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.spad.icop.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.spad.icop.NoSuchRecordCallAuditException;
import com.spad.icop.model.RecordCallAudit;
import com.spad.icop.model.impl.RecordCallAuditImpl;
import com.spad.icop.model.impl.RecordCallAuditModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the record call audit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see RecordCallAuditPersistence
 * @see RecordCallAuditUtil
 * @generated
 */
public class RecordCallAuditPersistenceImpl extends BasePersistenceImpl<RecordCallAudit>
	implements RecordCallAuditPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link RecordCallAuditUtil} to access the record call audit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = RecordCallAuditImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditModelImpl.FINDER_CACHE_ENABLED,
			RecordCallAuditImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditModelImpl.FINDER_CACHE_ENABLED,
			RecordCallAuditImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public RecordCallAuditPersistenceImpl() {
		setModelClass(RecordCallAudit.class);
	}

	/**
	 * Caches the record call audit in the entity cache if it is enabled.
	 *
	 * @param recordCallAudit the record call audit
	 */
	@Override
	public void cacheResult(RecordCallAudit recordCallAudit) {
		EntityCacheUtil.putResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditImpl.class, recordCallAudit.getPrimaryKey(),
			recordCallAudit);

		recordCallAudit.resetOriginalValues();
	}

	/**
	 * Caches the record call audits in the entity cache if it is enabled.
	 *
	 * @param recordCallAudits the record call audits
	 */
	@Override
	public void cacheResult(List<RecordCallAudit> recordCallAudits) {
		for (RecordCallAudit recordCallAudit : recordCallAudits) {
			if (EntityCacheUtil.getResult(
						RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
						RecordCallAuditImpl.class,
						recordCallAudit.getPrimaryKey()) == null) {
				cacheResult(recordCallAudit);
			}
			else {
				recordCallAudit.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all record call audits.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(RecordCallAuditImpl.class.getName());
		}

		EntityCacheUtil.clearCache(RecordCallAuditImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the record call audit.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(RecordCallAudit recordCallAudit) {
		EntityCacheUtil.removeResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditImpl.class, recordCallAudit.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<RecordCallAudit> recordCallAudits) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (RecordCallAudit recordCallAudit : recordCallAudits) {
			EntityCacheUtil.removeResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
				RecordCallAuditImpl.class, recordCallAudit.getPrimaryKey());
		}
	}

	/**
	 * Creates a new record call audit with the primary key. Does not add the record call audit to the database.
	 *
	 * @param aditid the primary key for the new record call audit
	 * @return the new record call audit
	 */
	@Override
	public RecordCallAudit create(long aditid) {
		RecordCallAudit recordCallAudit = new RecordCallAuditImpl();

		recordCallAudit.setNew(true);
		recordCallAudit.setPrimaryKey(aditid);

		return recordCallAudit;
	}

	/**
	 * Removes the record call audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param aditid the primary key of the record call audit
	 * @return the record call audit that was removed
	 * @throws com.spad.icop.NoSuchRecordCallAuditException if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit remove(long aditid)
		throws NoSuchRecordCallAuditException, SystemException {
		return remove((Serializable)aditid);
	}

	/**
	 * Removes the record call audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the record call audit
	 * @return the record call audit that was removed
	 * @throws com.spad.icop.NoSuchRecordCallAuditException if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit remove(Serializable primaryKey)
		throws NoSuchRecordCallAuditException, SystemException {
		Session session = null;

		try {
			session = openSession();

			RecordCallAudit recordCallAudit = (RecordCallAudit)session.get(RecordCallAuditImpl.class,
					primaryKey);

			if (recordCallAudit == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchRecordCallAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(recordCallAudit);
		}
		catch (NoSuchRecordCallAuditException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected RecordCallAudit removeImpl(RecordCallAudit recordCallAudit)
		throws SystemException {
		recordCallAudit = toUnwrappedModel(recordCallAudit);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(recordCallAudit)) {
				recordCallAudit = (RecordCallAudit)session.get(RecordCallAuditImpl.class,
						recordCallAudit.getPrimaryKeyObj());
			}

			if (recordCallAudit != null) {
				session.delete(recordCallAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (recordCallAudit != null) {
			clearCache(recordCallAudit);
		}

		return recordCallAudit;
	}

	@Override
	public RecordCallAudit updateImpl(
		com.spad.icop.model.RecordCallAudit recordCallAudit)
		throws SystemException {
		recordCallAudit = toUnwrappedModel(recordCallAudit);

		boolean isNew = recordCallAudit.isNew();

		Session session = null;

		try {
			session = openSession();

			if (recordCallAudit.isNew()) {
				session.save(recordCallAudit);

				recordCallAudit.setNew(false);
			}
			else {
				session.merge(recordCallAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
			RecordCallAuditImpl.class, recordCallAudit.getPrimaryKey(),
			recordCallAudit);

		return recordCallAudit;
	}

	protected RecordCallAudit toUnwrappedModel(RecordCallAudit recordCallAudit) {
		if (recordCallAudit instanceof RecordCallAuditImpl) {
			return recordCallAudit;
		}

		RecordCallAuditImpl recordCallAuditImpl = new RecordCallAuditImpl();

		recordCallAuditImpl.setNew(recordCallAudit.isNew());
		recordCallAuditImpl.setPrimaryKey(recordCallAudit.getPrimaryKey());

		recordCallAuditImpl.setRecordcallid(recordCallAudit.getRecordcallid());
		recordCallAuditImpl.setAditid(recordCallAudit.getAditid());
		recordCallAuditImpl.setDateonroadsafty(recordCallAudit.getDateonroadsafty());
		recordCallAuditImpl.setInvestigationtitle(recordCallAudit.getInvestigationtitle());
		recordCallAuditImpl.setCompany(recordCallAudit.getCompany());
		recordCallAuditImpl.setStatusverification(recordCallAudit.getStatusverification());

		return recordCallAuditImpl;
	}

	/**
	 * Returns the record call audit with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the record call audit
	 * @return the record call audit
	 * @throws com.spad.icop.NoSuchRecordCallAuditException if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit findByPrimaryKey(Serializable primaryKey)
		throws NoSuchRecordCallAuditException, SystemException {
		RecordCallAudit recordCallAudit = fetchByPrimaryKey(primaryKey);

		if (recordCallAudit == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchRecordCallAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return recordCallAudit;
	}

	/**
	 * Returns the record call audit with the primary key or throws a {@link com.spad.icop.NoSuchRecordCallAuditException} if it could not be found.
	 *
	 * @param aditid the primary key of the record call audit
	 * @return the record call audit
	 * @throws com.spad.icop.NoSuchRecordCallAuditException if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit findByPrimaryKey(long aditid)
		throws NoSuchRecordCallAuditException, SystemException {
		return findByPrimaryKey((Serializable)aditid);
	}

	/**
	 * Returns the record call audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the record call audit
	 * @return the record call audit, or <code>null</code> if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		RecordCallAudit recordCallAudit = (RecordCallAudit)EntityCacheUtil.getResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
				RecordCallAuditImpl.class, primaryKey);

		if (recordCallAudit == _nullRecordCallAudit) {
			return null;
		}

		if (recordCallAudit == null) {
			Session session = null;

			try {
				session = openSession();

				recordCallAudit = (RecordCallAudit)session.get(RecordCallAuditImpl.class,
						primaryKey);

				if (recordCallAudit != null) {
					cacheResult(recordCallAudit);
				}
				else {
					EntityCacheUtil.putResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
						RecordCallAuditImpl.class, primaryKey,
						_nullRecordCallAudit);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(RecordCallAuditModelImpl.ENTITY_CACHE_ENABLED,
					RecordCallAuditImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return recordCallAudit;
	}

	/**
	 * Returns the record call audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param aditid the primary key of the record call audit
	 * @return the record call audit, or <code>null</code> if a record call audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecordCallAudit fetchByPrimaryKey(long aditid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)aditid);
	}

	/**
	 * Returns all the record call audits.
	 *
	 * @return the record call audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecordCallAudit> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the record call audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.RecordCallAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of record call audits
	 * @param end the upper bound of the range of record call audits (not inclusive)
	 * @return the range of record call audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecordCallAudit> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the record call audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.RecordCallAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of record call audits
	 * @param end the upper bound of the range of record call audits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of record call audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecordCallAudit> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<RecordCallAudit> list = (List<RecordCallAudit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_RECORDCALLAUDIT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_RECORDCALLAUDIT;

				if (pagination) {
					sql = sql.concat(RecordCallAuditModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<RecordCallAudit>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RecordCallAudit>(list);
				}
				else {
					list = (List<RecordCallAudit>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the record call audits from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (RecordCallAudit recordCallAudit : findAll()) {
			remove(recordCallAudit);
		}
	}

	/**
	 * Returns the number of record call audits.
	 *
	 * @return the number of record call audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_RECORDCALLAUDIT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the record call audit persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.spad.icop.model.RecordCallAudit")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<RecordCallAudit>> listenersList = new ArrayList<ModelListener<RecordCallAudit>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<RecordCallAudit>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(RecordCallAuditImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_RECORDCALLAUDIT = "SELECT recordCallAudit FROM RecordCallAudit recordCallAudit";
	private static final String _SQL_COUNT_RECORDCALLAUDIT = "SELECT COUNT(recordCallAudit) FROM RecordCallAudit recordCallAudit";
	private static final String _ORDER_BY_ENTITY_ALIAS = "recordCallAudit.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No RecordCallAudit exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(RecordCallAuditPersistenceImpl.class);
	private static RecordCallAudit _nullRecordCallAudit = new RecordCallAuditImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<RecordCallAudit> toCacheModel() {
				return _nullRecordCallAuditCacheModel;
			}
		};

	private static CacheModel<RecordCallAudit> _nullRecordCallAuditCacheModel = new CacheModel<RecordCallAudit>() {
			@Override
			public RecordCallAudit toEntityModel() {
				return _nullRecordCallAudit;
			}
		};
}