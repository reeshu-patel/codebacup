/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.LogWork;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing LogWork in entity cache.
 *
 * @author reeshu
 * @see LogWork
 * @generated
 */
public class LogWorkCacheModel implements CacheModel<LogWork>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{logworkId=");
		sb.append(logworkId);
		sb.append(", user=");
		sb.append(user);
		sb.append(", time=");
		sb.append(time);
		sb.append(", detail=");
		sb.append(detail);
		sb.append(", chronicle=");
		sb.append(chronicle);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public LogWork toEntityModel() {
		LogWorkImpl logWorkImpl = new LogWorkImpl();

		logWorkImpl.setLogworkId(logworkId);

		if (user == null) {
			logWorkImpl.setUser(StringPool.BLANK);
		}
		else {
			logWorkImpl.setUser(user);
		}

		if (time == null) {
			logWorkImpl.setTime(StringPool.BLANK);
		}
		else {
			logWorkImpl.setTime(time);
		}

		if (detail == null) {
			logWorkImpl.setDetail(StringPool.BLANK);
		}
		else {
			logWorkImpl.setDetail(detail);
		}

		if (chronicle == null) {
			logWorkImpl.setChronicle(StringPool.BLANK);
		}
		else {
			logWorkImpl.setChronicle(chronicle);
		}

		logWorkImpl.resetOriginalValues();

		return logWorkImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		logworkId = objectInput.readLong();
		user = objectInput.readUTF();
		time = objectInput.readUTF();
		detail = objectInput.readUTF();
		chronicle = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(logworkId);

		if (user == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(user);
		}

		if (time == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(time);
		}

		if (detail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(detail);
		}

		if (chronicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(chronicle);
		}
	}

	public long logworkId;
	public String user;
	public String time;
	public String detail;
	public String chronicle;
}