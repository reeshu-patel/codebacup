/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.spad.icop.model.ComplainCheckAudit;
import com.spad.icop.service.base.ComplainCheckAuditLocalServiceBaseImpl;

/**
 * The implementation of the complain check audit local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.spad.icop.service.ComplainCheckAuditLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author reeshu
 * @see com.spad.icop.service.base.ComplainCheckAuditLocalServiceBaseImpl
 * @see com.spad.icop.service.ComplainCheckAuditLocalServiceUtil
 */
public class ComplainCheckAuditLocalServiceImpl
	extends ComplainCheckAuditLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.spad.icop.service.ComplainCheckAuditLocalServiceUtil} to access the complain check audit local service.
	 */
	
	public List<ComplainCheckAudit> getsByAduit(long aditid) throws SystemException, PortalException {

		   List<ComplainCheckAudit> bill = complainCheckAuditPersistence.findByaditid(aditid);

		    return bill;
		}
	
	
	public List<ComplainCheckAudit> getsByMatterAduit(long aditid,long matterId) throws SystemException, PortalException {

		   List<ComplainCheckAudit> bill = complainCheckAuditPersistence.findBymetterAudit(aditid, matterId);

		    return bill;
		}
}