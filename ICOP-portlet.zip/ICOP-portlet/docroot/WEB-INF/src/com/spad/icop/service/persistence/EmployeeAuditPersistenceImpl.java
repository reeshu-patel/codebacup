/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.spad.icop.NoSuchEmployeeAuditException;
import com.spad.icop.model.EmployeeAudit;
import com.spad.icop.model.impl.EmployeeAuditImpl;
import com.spad.icop.model.impl.EmployeeAuditModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the employee audit service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see EmployeeAuditPersistence
 * @see EmployeeAuditUtil
 * @generated
 */
public class EmployeeAuditPersistenceImpl extends BasePersistenceImpl<EmployeeAudit>
	implements EmployeeAuditPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link EmployeeAuditUtil} to access the employee audit persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = EmployeeAuditImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditModelImpl.FINDER_CACHE_ENABLED,
			EmployeeAuditImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditModelImpl.FINDER_CACHE_ENABLED,
			EmployeeAuditImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public EmployeeAuditPersistenceImpl() {
		setModelClass(EmployeeAudit.class);
	}

	/**
	 * Caches the employee audit in the entity cache if it is enabled.
	 *
	 * @param employeeAudit the employee audit
	 */
	@Override
	public void cacheResult(EmployeeAudit employeeAudit) {
		EntityCacheUtil.putResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditImpl.class, employeeAudit.getPrimaryKey(),
			employeeAudit);

		employeeAudit.resetOriginalValues();
	}

	/**
	 * Caches the employee audits in the entity cache if it is enabled.
	 *
	 * @param employeeAudits the employee audits
	 */
	@Override
	public void cacheResult(List<EmployeeAudit> employeeAudits) {
		for (EmployeeAudit employeeAudit : employeeAudits) {
			if (EntityCacheUtil.getResult(
						EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
						EmployeeAuditImpl.class, employeeAudit.getPrimaryKey()) == null) {
				cacheResult(employeeAudit);
			}
			else {
				employeeAudit.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all employee audits.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(EmployeeAuditImpl.class.getName());
		}

		EntityCacheUtil.clearCache(EmployeeAuditImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the employee audit.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EmployeeAudit employeeAudit) {
		EntityCacheUtil.removeResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditImpl.class, employeeAudit.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<EmployeeAudit> employeeAudits) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (EmployeeAudit employeeAudit : employeeAudits) {
			EntityCacheUtil.removeResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
				EmployeeAuditImpl.class, employeeAudit.getPrimaryKey());
		}
	}

	/**
	 * Creates a new employee audit with the primary key. Does not add the employee audit to the database.
	 *
	 * @param aditid the primary key for the new employee audit
	 * @return the new employee audit
	 */
	@Override
	public EmployeeAudit create(long aditid) {
		EmployeeAudit employeeAudit = new EmployeeAuditImpl();

		employeeAudit.setNew(true);
		employeeAudit.setPrimaryKey(aditid);

		return employeeAudit;
	}

	/**
	 * Removes the employee audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param aditid the primary key of the employee audit
	 * @return the employee audit that was removed
	 * @throws com.spad.icop.NoSuchEmployeeAuditException if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit remove(long aditid)
		throws NoSuchEmployeeAuditException, SystemException {
		return remove((Serializable)aditid);
	}

	/**
	 * Removes the employee audit with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the employee audit
	 * @return the employee audit that was removed
	 * @throws com.spad.icop.NoSuchEmployeeAuditException if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit remove(Serializable primaryKey)
		throws NoSuchEmployeeAuditException, SystemException {
		Session session = null;

		try {
			session = openSession();

			EmployeeAudit employeeAudit = (EmployeeAudit)session.get(EmployeeAuditImpl.class,
					primaryKey);

			if (employeeAudit == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEmployeeAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(employeeAudit);
		}
		catch (NoSuchEmployeeAuditException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EmployeeAudit removeImpl(EmployeeAudit employeeAudit)
		throws SystemException {
		employeeAudit = toUnwrappedModel(employeeAudit);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(employeeAudit)) {
				employeeAudit = (EmployeeAudit)session.get(EmployeeAuditImpl.class,
						employeeAudit.getPrimaryKeyObj());
			}

			if (employeeAudit != null) {
				session.delete(employeeAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (employeeAudit != null) {
			clearCache(employeeAudit);
		}

		return employeeAudit;
	}

	@Override
	public EmployeeAudit updateImpl(
		com.spad.icop.model.EmployeeAudit employeeAudit)
		throws SystemException {
		employeeAudit = toUnwrappedModel(employeeAudit);

		boolean isNew = employeeAudit.isNew();

		Session session = null;

		try {
			session = openSession();

			if (employeeAudit.isNew()) {
				session.save(employeeAudit);

				employeeAudit.setNew(false);
			}
			else {
				session.merge(employeeAudit);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
			EmployeeAuditImpl.class, employeeAudit.getPrimaryKey(),
			employeeAudit);

		return employeeAudit;
	}

	protected EmployeeAudit toUnwrappedModel(EmployeeAudit employeeAudit) {
		if (employeeAudit instanceof EmployeeAuditImpl) {
			return employeeAudit;
		}

		EmployeeAuditImpl employeeAuditImpl = new EmployeeAuditImpl();

		employeeAuditImpl.setNew(employeeAudit.isNew());
		employeeAuditImpl.setPrimaryKey(employeeAudit.getPrimaryKey());

		employeeAuditImpl.setAditid(employeeAudit.getAditid());
		employeeAuditImpl.setDateonroad(employeeAudit.getDateonroad());
		employeeAuditImpl.setDateofincident(employeeAudit.getDateofincident());
		employeeAuditImpl.setTimeevent(employeeAudit.getTimeevent());
		employeeAuditImpl.setTitleinvestigation(employeeAudit.getTitleinvestigation());
		employeeAuditImpl.setTypeofvehicle(employeeAudit.getTypeofvehicle());
		employeeAuditImpl.setNoregistration(employeeAudit.getNoregistration());
		employeeAuditImpl.setCompany(employeeAudit.getCompany());
		employeeAuditImpl.setReportsKjr(employeeAudit.getReportsKjr());
		employeeAuditImpl.setReportscmd(employeeAudit.getReportscmd());
		employeeAuditImpl.setSrustatus(employeeAudit.getSrustatus());
		employeeAuditImpl.setCompletedStatus(employeeAudit.getCompletedStatus());
		employeeAuditImpl.setAudidate(employeeAudit.getAudidate());
		employeeAuditImpl.setAuditime(employeeAudit.getAuditime());
		employeeAuditImpl.setStatusofadudit(employeeAudit.getStatusofadudit());
		employeeAuditImpl.setCompleteddate(employeeAudit.getCompleteddate());
		employeeAuditImpl.setAddresss(employeeAudit.getAddresss());
		employeeAuditImpl.setLocationofincident(employeeAudit.getLocationofincident());
		employeeAuditImpl.setTrainingattendance(employeeAudit.getTrainingattendance());
		employeeAuditImpl.setAuditaccidents(employeeAudit.getAuditaccidents());
		employeeAuditImpl.setTypecertificate(employeeAudit.getTypecertificate());
		employeeAuditImpl.setDateofregistration(employeeAudit.getDateofregistration());
		employeeAuditImpl.setTrainingdates(employeeAudit.getTrainingdates());
		employeeAuditImpl.setEnddate(employeeAudit.getEnddate());
		employeeAuditImpl.setTypemod(employeeAudit.getTypemod());
		employeeAuditImpl.setTypeoflicens(employeeAudit.getTypeoflicens());
		employeeAuditImpl.setTypeofcompany(employeeAudit.getTypeofcompany());
		employeeAuditImpl.setPhoneno(employeeAudit.getPhoneno());
		employeeAuditImpl.setStatus(employeeAudit.getStatus());
		employeeAuditImpl.setAppendixg(employeeAudit.getAppendixg());
		employeeAuditImpl.setDateCaseSrU(employeeAudit.getDateCaseSrU());
		employeeAuditImpl.setActionSru(employeeAudit.getActionSru());
		employeeAuditImpl.setOfficerName(employeeAudit.getOfficerName());
		employeeAuditImpl.setVehiclesNo(employeeAudit.getVehiclesNo());
		employeeAuditImpl.setCompanyEmail(employeeAudit.getCompanyEmail());
		employeeAuditImpl.setRepresentativeName(employeeAudit.getRepresentativeName());
		employeeAuditImpl.setCompanieListNumber(employeeAudit.getCompanieListNumber());

		return employeeAuditImpl;
	}

	/**
	 * Returns the employee audit with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the employee audit
	 * @return the employee audit
	 * @throws com.spad.icop.NoSuchEmployeeAuditException if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEmployeeAuditException, SystemException {
		EmployeeAudit employeeAudit = fetchByPrimaryKey(primaryKey);

		if (employeeAudit == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEmployeeAuditException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return employeeAudit;
	}

	/**
	 * Returns the employee audit with the primary key or throws a {@link com.spad.icop.NoSuchEmployeeAuditException} if it could not be found.
	 *
	 * @param aditid the primary key of the employee audit
	 * @return the employee audit
	 * @throws com.spad.icop.NoSuchEmployeeAuditException if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit findByPrimaryKey(long aditid)
		throws NoSuchEmployeeAuditException, SystemException {
		return findByPrimaryKey((Serializable)aditid);
	}

	/**
	 * Returns the employee audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the employee audit
	 * @return the employee audit, or <code>null</code> if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		EmployeeAudit employeeAudit = (EmployeeAudit)EntityCacheUtil.getResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
				EmployeeAuditImpl.class, primaryKey);

		if (employeeAudit == _nullEmployeeAudit) {
			return null;
		}

		if (employeeAudit == null) {
			Session session = null;

			try {
				session = openSession();

				employeeAudit = (EmployeeAudit)session.get(EmployeeAuditImpl.class,
						primaryKey);

				if (employeeAudit != null) {
					cacheResult(employeeAudit);
				}
				else {
					EntityCacheUtil.putResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
						EmployeeAuditImpl.class, primaryKey, _nullEmployeeAudit);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(EmployeeAuditModelImpl.ENTITY_CACHE_ENABLED,
					EmployeeAuditImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return employeeAudit;
	}

	/**
	 * Returns the employee audit with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param aditid the primary key of the employee audit
	 * @return the employee audit, or <code>null</code> if a employee audit with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EmployeeAudit fetchByPrimaryKey(long aditid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)aditid);
	}

	/**
	 * Returns all the employee audits.
	 *
	 * @return the employee audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EmployeeAudit> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the employee audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.EmployeeAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of employee audits
	 * @param end the upper bound of the range of employee audits (not inclusive)
	 * @return the range of employee audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EmployeeAudit> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the employee audits.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.spad.icop.model.impl.EmployeeAuditModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of employee audits
	 * @param end the upper bound of the range of employee audits (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of employee audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EmployeeAudit> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<EmployeeAudit> list = (List<EmployeeAudit>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_EMPLOYEEAUDIT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_EMPLOYEEAUDIT;

				if (pagination) {
					sql = sql.concat(EmployeeAuditModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<EmployeeAudit>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EmployeeAudit>(list);
				}
				else {
					list = (List<EmployeeAudit>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the employee audits from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (EmployeeAudit employeeAudit : findAll()) {
			remove(employeeAudit);
		}
	}

	/**
	 * Returns the number of employee audits.
	 *
	 * @return the number of employee audits
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_EMPLOYEEAUDIT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the employee audit persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.spad.icop.model.EmployeeAudit")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<EmployeeAudit>> listenersList = new ArrayList<ModelListener<EmployeeAudit>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<EmployeeAudit>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(EmployeeAuditImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_EMPLOYEEAUDIT = "SELECT employeeAudit FROM EmployeeAudit employeeAudit";
	private static final String _SQL_COUNT_EMPLOYEEAUDIT = "SELECT COUNT(employeeAudit) FROM EmployeeAudit employeeAudit";
	private static final String _ORDER_BY_ENTITY_ALIAS = "employeeAudit.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No EmployeeAudit exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(EmployeeAuditPersistenceImpl.class);
	private static EmployeeAudit _nullEmployeeAudit = new EmployeeAuditImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<EmployeeAudit> toCacheModel() {
				return _nullEmployeeAuditCacheModel;
			}
		};

	private static CacheModel<EmployeeAudit> _nullEmployeeAuditCacheModel = new CacheModel<EmployeeAudit>() {
			@Override
			public EmployeeAudit toEntityModel() {
				return _nullEmployeeAudit;
			}
		};
}