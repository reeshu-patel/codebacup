package com.spad.icop;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

@Controller
@RequestMapping(value = "VIEW")
public class Iocp {

	private static final String DEFAULT_VIEW="view";
	
	 /*
	 * This is the default render method
	 * which will execute very first time when page will load
	 */
	
	@RenderMapping
	public String defaultRenderMethod(RenderRequest request,RenderResponse response){
		
	
		  
	return DEFAULT_VIEW;
	}
	
	
}