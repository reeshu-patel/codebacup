/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.spad.icop.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.jsonwebservice.JSONWebService;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.security.ac.AccessControlled;

import com.spad.icop.model.AppointmentCall;
import com.spad.icop.model.CompilanceCheck;
import com.spad.icop.model.ComplainCheckAudit;
import com.spad.icop.model.EmployeeAudit;
import com.spad.icop.model.LogWork;
import com.spad.icop.model.TrainingCertification;
import com.spad.icop.model.impl.AppointmentCallImpl;
import com.spad.icop.model.impl.CompilanceCheckImpl;
import com.spad.icop.model.impl.ComplainCheckAuditImpl;
import com.spad.icop.model.impl.EmployeeAuditImpl;
import com.spad.icop.service.AppointmentCallLocalServiceUtil;
import com.spad.icop.service.CompilanceCheckLocalServiceUtil;
import com.spad.icop.service.ComplainCheckAuditLocalServiceUtil;
import com.spad.icop.service.EmployeeAuditLocalServiceUtil;
import com.spad.icop.service.LogWorkLocalServiceUtil;
import com.spad.icop.service.TrainingCertificationLocalServiceUtil;
import com.spad.icop.service.base.EmployeeAuditServiceBaseImpl;

/**
 * 
 * The implementation of the employee audit remote service.
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.spad.icop.service.EmployeeAuditService} interface.
 * 
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *  
 *  
 * @see com.spad.icop.service.base.EmployeeAuditServiceBaseImpl
 * @see com.spad.icop.service.EmployeeAuditServiceUtil
 */

public class EmployeeAuditServiceImpl extends EmployeeAuditServiceBaseImpl {
	
	 /*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.spad.icop.service.EmployeeAuditServiceUtil} to access the employee audit remote service.
	 */
	
	public long addEmployeeAudit(String dateonRoad, String dateofIncident, String timeEvent, String locationofIncident, String Company, String trainingAttendance, String auditAccidents, String statusSRU)
	 {
		long aditID=0;
		try{
			aditID = CounterLocalServiceUtil.increment(EmployeeAuditServiceImpl.class.getName());
		}catch(SystemException e){
			//System.out.println(e.getMessage());
		}
		EmployeeAudit emp=null;
		emp = new EmployeeAuditImpl();
		emp = EmployeeAuditLocalServiceUtil.createEmployeeAudit(aditID);
		emp.setDateofincident(dateofIncident);
		emp.setDateonroad(dateonRoad);
		emp.setTimeevent(timeEvent);
		emp.setTrainingattendance(trainingAttendance);
		emp.setAuditaccidents(auditAccidents);
		emp.setSrustatus(statusSRU);
		try{
			EmployeeAuditLocalServiceUtil.addEmployeeAudit(emp);
		}catch(SystemException e){
			//System.out.println(e.getMessage());
		}
		return aditID;
	}
		@JSONWebService(value = "EMPLOYEE_ICOPE_AUDIT_LIST", method = "GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject EmployeeAudit()  throws PortalException, SystemException, IOException
		 {	
		JSONObject employeeICOP = JSONFactoryUtil.createJSONObject();
		JSONObject employeeFinalObject = JSONFactoryUtil.createJSONObject();
		JSONObject employeeIcoObject = JSONFactoryUtil.createJSONObject();
		JSONArray employeeArray = JSONFactoryUtil.createJSONArray();
		JSONObject appendexObject = JSONFactoryUtil.createJSONObject();
		JSONArray   SelfAssesmentArray= JSONFactoryUtil.createJSONArray();

		
		List<EmployeeAudit> emplouauditDetails = EmployeeAuditLocalServiceUtil.getEmployeeAudits(-1, -1);
		
		for(EmployeeAudit audit:emplouauditDetails){
			
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			doc.put("aditid", audit.getAditid());
			doc.put("dateonroad", audit.getDateonroad());
			doc.put("dateofincident", audit.getDateofincident());
			doc.put("timeevent", audit.getTimeevent());
			doc.put("titleinvestigation", audit.getTitleinvestigation());
			doc.put("typeofvehicle", audit.getTypeofvehicle());
			doc.put("noregistration", audit.getNoregistration());
			doc.put("company", audit.getCompany());
			doc.put("reportsKjr", audit.getReportsKjr());
			doc.put("reportscmd", audit.getReportscmd());
			doc.put("srustatus", audit.getSrustatus());
			doc.put("completedStatus", audit.getCompletedStatus());
			doc.put("audidate", audit.getAudidate());
			
			doc.put("auditime", audit.getAuditime());
			doc.put("statusofadudit", audit.getStatusofadudit());
			doc.put("completeddate", audit.getCompleteddate());
			doc.put("addresss", audit.getAddresss());
			doc.put("locationofincident", audit.getLocationofincident());
			doc.put("trainingattendance", audit.getTrainingattendance());
			doc.put("auditaccidents", audit.getAuditaccidents());
			employeeArray.put(doc);
			
		}
		
		employeeFinalObject.put("MainPage", employeeArray);
		
		JSONArray appoinmentArray = JSONFactoryUtil.createJSONArray();
		JSONArray recordCallArray = JSONFactoryUtil.createJSONArray();
		
		for(EmployeeAudit recordCall:emplouauditDetails) {
			
			JSONObject recordCalldoc = JSONFactoryUtil.createJSONObject();
			recordCalldoc.put("dateofincident", recordCall.getDateofincident());
			recordCalldoc.put("timeevent", recordCall.getTimeevent());
			recordCalldoc.put("location", recordCall.getLocationofincident());
			recordCalldoc.put("typeofvehicle", recordCall.getTypeofvehicle());
			recordCalldoc.put("noregistration", recordCall.getNoregistration());
			recordCalldoc.put("company", recordCall.getCompany());
			recordCallArray.put(recordCalldoc);
			
		}
		
		List<AppointmentCall>  appointmentCalls= AppointmentCallLocalServiceUtil.getAppointmentCalls(-1, -1);
		for(AppointmentCall recordCall:appointmentCalls){
			
			JSONObject appoinmentldoc = JSONFactoryUtil.createJSONObject();
			appoinmentldoc.put("Adit_Id", recordCall.getAditid());
			appoinmentldoc.put("Record_call_id", recordCall.getRecordcallid());
			appoinmentldoc.put("Date_Road_Safety", recordCall.getDateonroadsafty());
			appoinmentldoc.put("Time_Event", recordCall.getTime());
			appoinmentldoc.put("Location", recordCall.getLocation());
			appoinmentldoc.put("Investigation_Title", recordCall.getInvestigationtitle());
			appoinmentldoc.put("Company", recordCall.getCompany());
			appoinmentldoc.put("Status", recordCall.getStatusverification());
			appoinmentArray.put(appoinmentldoc);	
			
			employeeFinalObject.put("NOTICE_DIRECTION_MANAGEMENT_AUDIT", appoinmentArray);
			
		}
		
		for(EmployeeAudit audit:emplouauditDetails){
			String sruStatus = audit.getSrustatus();
			if("accepted".equals(sruStatus)){
			 JSONObject accepteddoc = JSONFactoryUtil.createJSONObject();
			 JSONArray sruArray = JSONFactoryUtil.createJSONArray();	
			 accepteddoc.put("aditid", audit.getAditid());
			 accepteddoc.put("dateonroad", audit.getDateonroad());
			 accepteddoc.put("dateofincident", audit.getDateofincident());
			 accepteddoc.put("timeevent", audit.getTimeevent());
			 accepteddoc.put("titleinvestigation", audit.getTitleinvestigation());
			 accepteddoc.put("typeofvehicle", audit.getTypeofvehicle());
			 accepteddoc.put("noregistration", audit.getNoregistration());
			 accepteddoc.put("company", audit.getCompany());
			 accepteddoc.put("reportsKjr", audit.getReportsKjr());
			 accepteddoc.put("reportscmd", audit.getReportscmd());
			 accepteddoc.put("srustatus", audit.getSrustatus());
			 accepteddoc.put("completedStatus", audit.getCompletedStatus());
			 accepteddoc.put("audidate", audit.getAudidate());
			 accepteddoc.put("auditime", audit.getAuditime());
			 accepteddoc.put("statusofadudit", audit.getStatusofadudit());
			 accepteddoc.put("completeddate", audit.getCompleteddate());
			 accepteddoc.put("addresss", audit.getAddresss());
			 accepteddoc.put("locationofincident", audit.getLocationofincident());
			 accepteddoc.put("trainingattendance", audit.getTrainingattendance());
			 accepteddoc.put("auditaccidents", audit.getAuditaccidents());
			 sruArray.put(accepteddoc);
			 employeeFinalObject.put("AuditSubmissionStatus", sruArray);
			}
			if("In the process".equals(sruStatus)){
				
				 JSONObject procesdoc = JSONFactoryUtil.createJSONObject();
				 JSONArray processArray = JSONFactoryUtil.createJSONArray();	
					
				 procesdoc.put("aditid", audit.getAditid());
				 procesdoc.put("dateonroad", audit.getDateonroad());
				 procesdoc.put("dateofincident", audit.getDateofincident());
				 procesdoc.put("timeevent", audit.getTimeevent());
				 procesdoc.put("titleinvestigation", audit.getTitleinvestigation());
				 procesdoc.put("typeofvehicle", audit.getTypeofvehicle());
				 procesdoc.put("noregistration", audit.getNoregistration());
				 procesdoc.put("company", audit.getCompany());
				 procesdoc.put("reportsKjr", audit.getReportsKjr());
				 procesdoc.put("reportscmd", audit.getReportscmd());
				 procesdoc.put("srustatus", audit.getSrustatus());
				 procesdoc.put("completedStatus", audit.getCompletedStatus());
				 procesdoc.put("audidate", audit.getAudidate());
					
				 procesdoc.put("auditime", audit.getAuditime());
					
				 procesdoc.put("statusofadudit", audit.getStatusofadudit());
				 procesdoc.put("completeddate", audit.getCompleteddate());
				 procesdoc.put("addresss", audit.getAddresss());
				 procesdoc.put("locationofincident", audit.getLocationofincident());
				 procesdoc.put("trainingattendance", audit.getTrainingattendance());
				 procesdoc.put("auditaccidents", audit.getAuditaccidents());
				 procesdoc.put("complianceInspections", "Audit");
				 procesdoc.put("completionStatus", "Validation");
				 processArray.put(procesdoc);
				 
				 employeeFinalObject.put("ComplianceInspections", processArray);
				
				
			}
			
			/* EXERCISE TAB---------------------	*  */	
		    
			String Status = audit.getStatus();
			if("attend".equals(Status)){
			JSONObject exerciesdoc = JSONFactoryUtil.createJSONObject();
			JSONArray exerciesArray = JSONFactoryUtil.createJSONArray();

			exerciesdoc.put("aditid", audit.getAditid());
			exerciesdoc.put("certificateType", audit.getTypecertificate());
			exerciesdoc.put("CompanyType", audit.getTypeofcompany());
			exerciesdoc.put("Company", audit.getCompany());
			exerciesdoc.put("CompanyAdress", audit.getAddresss());
			exerciesdoc.put("noregistration", audit.getNoregistration());
			exerciesdoc.put("dateofregistration", audit.getDateofregistration());
			exerciesdoc.put("trainingdates", audit.getTrainingdates());
			exerciesdoc.put("enddate", audit.getEnddate());
			exerciesdoc.put("typemod", audit.getTypemod());
			exerciesdoc.put("typeoflicens", audit.getTypeoflicens());
			exerciesdoc.put("WellPhone", audit.getPhoneno());
			exerciesdoc.put("status", audit.getStatus());
			exerciesArray.put(exerciesdoc);
			
			employeeIcoObject.put("EXERCISE", exerciesArray);
			//exrciseMainArray.put(exerciesObject);
				
			}
			
		}
		
		/* INQUERY TAB  */	
		
		List<EmployeeAudit> indexDetails = EmployeeAuditLocalServiceUtil.getEmployeeAudits(-1, -1);
		JSONArray appendexArray = JSONFactoryUtil.createJSONArray();
		JSONArray AppendixKJArray = JSONFactoryUtil.createJSONArray();
		JSONArray AuditReportSRUArray = JSONFactoryUtil.createJSONArray();
		JSONArray logWorkArray = JSONFactoryUtil.createJSONArray();

		for(EmployeeAudit audit:indexDetails){
			
			//Appendix_G			
			
			JSONObject appendexdoc = JSONFactoryUtil.createJSONObject();
		
			appendexdoc.put("aditid", audit.getAditid());
			appendexdoc.put("chronicle", audit.getDateofregistration());
			appendexdoc.put("company", audit.getCompany());
			appendexdoc.put("representativeName", audit.getRepresentativeName());
			appendexdoc.put("phoneno", audit.getPhoneno());
			appendexdoc.put("status", audit.getStatus());
			appendexdoc.put("appendixg", audit.getAppendixg());
			appendexdoc.put("reportscmd", audit.getReportscmd());
			
			appendexArray.put(appendexdoc);
			
			
			//Appendix_KJR	
		
			JSONObject AppendixKJRdoc = JSONFactoryUtil.createJSONObject();
			AppendixKJRdoc.put("aditid", audit.getAditid());
			AppendixKJRdoc.put("chronicle", audit.getDateofregistration());
			AppendixKJRdoc.put("company", audit.getCompany());
			AppendixKJRdoc.put("representativeName", audit.getRepresentativeName());
			AppendixKJRdoc.put("phoneno", audit.getPhoneno());
			AppendixKJRdoc.put("status", "Set Appointment");
			AppendixKJRdoc.put("AppendixG", "View | Download");
			AppendixKJRdoc.put("reportsKJR", "View | Download");
			AppendixKJRdoc.put("reportscmd", audit.getReportscmd());
			
			AppendixKJArray.put(AppendixKJRdoc);
			
			//Audit Report SRU
			
			JSONObject AuditReportSRUdoc = JSONFactoryUtil.createJSONObject();
			
			AuditReportSRUdoc.put("aditid", audit.getAditid());
			AuditReportSRUdoc.put("dateonroad", audit.getDateonroad());
			AuditReportSRUdoc.put("Date_of_incident", audit.getDateofincident());
			
			
			AuditReportSRUdoc.put("timeevent", audit.getTimeevent());
			AuditReportSRUdoc.put("locationofincident", audit.getLocationofincident());
			
			AuditReportSRUdoc.put("Company_name", audit.getCompany());
			
			AuditReportSRUdoc.put("Training_attendance", audit.getStatus());
			
			AuditReportSRUdoc.put("Post_Crash_Audit", audit.getAudidate());
			AuditReportSRUdoc.put("Compliance_Audit_Date", audit.getAudidate());
			AuditReportSRUdoc.put("Date_Case_SRU", audit.getDateCaseSrU());
			AuditReportSRUdoc.put("Action_SRU", audit.getActionSru());
			
			AuditReportSRUArray.put(AuditReportSRUdoc);
			
			// SELF ASSESSMENT	
			
			JSONObject SelfAssesmentDoc = JSONFactoryUtil.createJSONObject();
			
			SelfAssesmentDoc.put("aditid", audit.getAditid());
			SelfAssesmentDoc.put("AuditDate", audit.getAudidate());
			SelfAssesmentDoc.put("No_List", "1");
			SelfAssesmentDoc.put("Company_name", audit.getCompany());
			SelfAssesmentDoc.put("Audit_Persentage", "100%");
			SelfAssesmentDoc.put("Completion_Status", audit.getCompletedStatus());
			SelfAssesmentDoc.put("Name_officer",audit.getOfficerName() );
			SelfAssesmentDoc.put("Note_Overall", "Good");
			SelfAssesmentArray.put(SelfAssesmentDoc);
			
			

		}	
		
		//LOG WORK
		List<LogWork> logWorks = LogWorkLocalServiceUtil.getLogWorks(-1, -1);
		JSONObject logWorkDoc = JSONFactoryUtil.createJSONObject();
		for(LogWork logdet:logWorks){
		logWorkDoc.put("chronicle",logdet.getLogworkId());
		logWorkDoc.put("time", logdet.getUser());
		logWorkDoc.put("users", logdet.getChronicle());
		logWorkDoc.put("Detail", logdet.getDetail());
		logWorkDoc.put("User", logdet.getUser());
		logWorkArray.put(logWorkDoc);
		}
		appendexObject.put("AppendixG", appendexArray);
		appendexObject.put("Audit_Report_SRU", AuditReportSRUArray);
		appendexObject.put("Appendix_KJR", AppendixKJArray);
		employeeIcoObject.put("INQUIRY", appendexObject);
		employeeIcoObject.put("SELF_ASSESSMENT", SelfAssesmentArray);
		employeeFinalObject.put("APPOINTMENT_CALL_RECORDS", recordCallArray);	
		employeeIcoObject.put("Audit", employeeFinalObject);
		employeeIcoObject.put("LOG_WORK", logWorkArray);
		
		employeeICOP.put("EmplaoyeeICOP", employeeIcoObject);
		
		return employeeICOP;
	 
	 }
		
	    @JSONWebService(value = "Record_Call_Apointment_POST", method = "POST")
		@AccessControlled(guestAccessEnabled = true)
		public AppointmentCall RecordCallApointmentAudit(long aditid,String dateonroadsafty,String time,String investigationtitle
				,String company,String statusverification,String operatorname,String nameofOfficer,String location)  throws PortalException, SystemException, IOException
		 {	
	

		long appointmentId = CounterLocalServiceUtil.increment(AppointmentCallServiceImpl.class.getName());
		
		AppointmentCall appointment=null;
		appointment = new AppointmentCallImpl();
		
		appointment.setRecordcallid(appointmentId);
		appointment.setAditid(aditid);
		appointment.setDateonroadsafty(dateonroadsafty);
		appointment.setLocation(location);
		appointment.setTime(time);
		appointment.setInvestigationtitle(investigationtitle);
		appointment.setCompany(company);
		appointment.setStatusverification(statusverification);
		appointment.setOperatorname(operatorname);
		appointment.setNameofOfficer(nameofOfficer);
		
		
		return AppointmentCallLocalServiceUtil.addAppointmentCall(appointment);
	
		 }
		
		@JSONWebService(value ="Exercise_Index_Dropdown_List", method ="GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject IndexDropDown()  throws PortalException, SystemException, IOException
		 {	
			
			JSONObject IndexDropdown = JSONFactoryUtil.createJSONObject();
			JSONObject StatusObject = JSONFactoryUtil.createJSONObject();
		    JSONObject TypeOfVehicalObject = JSONFactoryUtil.createJSONObject();
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			JSONObject StatusExerciseObject = JSONFactoryUtil.createJSONObject();
			
			JSONArray vehicalArray = JSONFactoryUtil.createJSONArray();

			doc.put("TypeOfVehicale1", "Low");
			doc.put("TypeOfVehicale2", "Lori");
			doc.put("TypeOfVehicale3", "school bus");
			TypeOfVehicalObject.put("Type_Of_Vehicale", doc);
			vehicalArray.put(TypeOfVehicalObject);
			

			StatusExerciseObject.put("Status1", "attend");
			StatusExerciseObject.put("Status2", "Not present");
			StatusObject.put("Status_Exercise", StatusExerciseObject);
			vehicalArray.put(StatusObject);
			IndexDropdown.put("IndexDropdown", vehicalArray);
			
			
		 
		
		return IndexDropdown;
		
		}
		
		@JSONWebService(value = "Registation_Status_of_Training", method = "GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject RegistationStatus(String vehicletype,String vehicalNo,String companyName,String statusExercise)  throws PortalException, SystemException, IOException
		 {	
			
			//JSONObject RegistationStatus = JSONFactoryUtil.createJSONObject();
			
			
			List<TrainingCertification> list = new ArrayList<TrainingCertification>();
			
			List<TrainingCertification> trainingCertifications = null;
			try {
				trainingCertifications = TrainingCertificationLocalServiceUtil.getTrainingCertifications(-1, -1);
			} catch (SystemException e1) {
				//TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			DynamicQuery dynamicQuery =null;
			boolean setFlag = true;
			boolean setFlagand = true;
			
			try{
			ClassLoader loader=(ClassLoader)PortletBeanLocatorUtil.locate(com.spad.icop.service.ClpSerializer.getServletContextName(),"portletClassLoader");
			dynamicQuery = DynamicQueryFactoryUtil.forClass(TrainingCertification.class, loader);
			
			Criterion criterion = null;
			
			if(!vehicletype.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("typeVehicle", vehicletype);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("typeVehicle",vehicletype));
				setFlagand = false;
			}
			
			if(!vehicalNo.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("noVehicles", vehicalNo);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("noVehicles",vehicalNo));
				setFlagand = false;
			}
			if(!companyName.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("companyName", StringPool.PERCENT+companyName+StringPool.PERCENT );
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("companyName", StringPool.PERCENT+companyName+StringPool.PERCENT));
				setFlagand = false;
			}
			
			if(!statusExercise.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("statusExercise", statusExercise);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("statusExercise",statusExercise));
				setFlagand = false;
			}
			
			dynamicQuery.add(criterion);
			List<TrainingCertification> gallryIds =null;
			try {
				gallryIds = TrainingCertificationLocalServiceUtil.dynamicQuery(dynamicQuery);
				for(TrainingCertification gall:gallryIds ){
					list.add(gall);

				}
				
			} catch (SystemException e) {
				e.printStackTrace();
			}
		 
		
		 }catch(Exception e){}
			JSONArray TrainingNumArray = JSONFactoryUtil.createJSONArray();
			JSONObject registationStatus = JSONFactoryUtil.createJSONObject();
			
			 if(Validator.isNotNull(list) && list.size() > 0 ){
				for(TrainingCertification listindex:list)
				{
					JSONObject TrainingNum = JSONFactoryUtil.createJSONObject();
					JSONObject TrainingNumCer = JSONFactoryUtil.createJSONObject();
					
					JSONObject ExiercisNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNumCer = JSONFactoryUtil.createJSONObject();
					
					TrainingNum.put("trainingCertificationId",listindex.getTrainingCertifiId());
					TrainingNum.put("TrainingDates",listindex.getTrainingDates());
					TrainingNum.put("exerciseName",listindex.getExerciseName());
					TrainingNum.put("pointsExercise",listindex.getPointsExercise());
					TrainingNum.put("nameOfficer",listindex.getNameOfficer());
					TrainingNum.put("number",listindex.getNumber());
					TrainingNum.put("statusExercise",listindex.getStatusExercise());
					TrainingNum.put("statusMoulds",listindex.getStatusMoulds());
					TrainingNumCer.put("RegistationStatus", TrainingNum);
					//TrainingNumArray.put(TrainingNumCer);
					
					ExiercisNum.put("trainingCertificationId",listindex.getTrainingCertifiId());
					ExiercisNum.put("trainingDates",listindex.getTrainingDates());
					ExiercisNum.put("companyName",listindex.getCompanyName());
					ExiercisNum.put("Address",listindex.getAddress());
					ExiercisNum.put("Email",listindex.getEmail());
					ExiercisNum.put("operatorName",listindex.getOperatorName());
					ExiercisNum.put("typeVehicle",listindex.getTypeVehicle());
					ExiercisNum.put("noVehicles",listindex.getNoVehicles());
					ExiercisNum.put("statusExercise",listindex.getStatusExercise());
					
					TrainingNumCer.put("Exercise_name", ExiercisNum);
					TrainingNumArray.put(TrainingNumCer);
					
			}
			registationStatus.put("Reistation_Status_Certificat", TrainingNumArray);
			
			}else if(setFlag == true && setFlagand == true){
				for(TrainingCertification listindex:trainingCertifications)
				{
					JSONObject TrainingNum = JSONFactoryUtil.createJSONObject();
					JSONObject TrainingNumCer = JSONFactoryUtil.createJSONObject();
					
					JSONObject ExiercisNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNumCer = JSONFactoryUtil.createJSONObject();
					
					TrainingNum.put("trainingCertificationId",listindex.getTrainingCertifiId());
					TrainingNum.put("TrainingDates",listindex.getTrainingDates());
					TrainingNum.put("exerciseName",listindex.getExerciseName());
					TrainingNum.put("pointsExercise",listindex.getPointsExercise());
					TrainingNum.put("nameOfficer",listindex.getNameOfficer());
					TrainingNum.put("number",listindex.getNumber());
					TrainingNum.put("statusExercise",listindex.getStatusExercise());
					TrainingNum.put("statusMoulds",listindex.getStatusMoulds());
					TrainingNumCer.put("RegistationStatus", TrainingNum);
					//TrainingNumArray.put(TrainingNumCer);
					
					ExiercisNum.put("trainingCertificationId",listindex.getTrainingCertifiId());
					ExiercisNum.put("trainingDates",listindex.getTrainingDates());
					ExiercisNum.put("companyName",listindex.getCompanyName());
					ExiercisNum.put("Address",listindex.getAddress());
					ExiercisNum.put("Email",listindex.getEmail());
					ExiercisNum.put("operatorName",listindex.getOperatorName());
					ExiercisNum.put("typeVehicle",listindex.getTypeVehicle());
					ExiercisNum.put("noVehicles",listindex.getNoVehicles());
					ExiercisNum.put("statusExercise",listindex.getStatusExercise());
					TrainingNumCer.put("Exercise_name", ExiercisNum);
					TrainingNumArray.put(TrainingNumCer);
					
				}
				registationStatus.put("Reistation_Status_Certificat", TrainingNumArray);
			}	
				
		return registationStatus;
		
		}
		
		@JSONWebService(value ="SelfAssesment_Compilance_View_POST", method = "POST")
		@AccessControlled(guestAccessEnabled = true)
		public CompilanceCheck CompilanceCheckPost(long compilanceCheckid,long aditid,String company,String audidate,String completedStatus,String auditPercentage,String questionSafetyOne,String questionSafetyTwo,String questionSafetyThree,String questionSafetFour,String questionSafetFive,
				String questionSafetSix,String questionSafetySeven,String questionNoteOne,String questionNoteTwo,String questionNoteThree,String questionNoteFour,String questionNoteFive,String questionNoteSix,String questionNoteSeven,
				String questionVehicalOne,String questionVehicalTwo,String questionVehicalThree,String questionVehicalFour,String questionVehicalFive,String questionVehicalSix,
				String questionVehicalSeven,String questionVehicalNoteOne,String questionVehicalNoteTwo,String questionVehicalNoteThree,String questionVehicalNoteFour,String questionVehicalNoteFive,String questionVehicalNoteSix,
				String vehicleRegistrationNo,String model,String color,String dateofVehicles,String investigatorname,
				String questionVehicalNoteSeven,String questionManageOne,String questionManageTwo,String questionManageThree,String questionManageFour,String questionManageFive,String questionManageSix,String questionManageSeven,
				String questionManageNoteOne,String questionManageNoteTwo,String questionManageNoteThree,String questionManageNoteFour,String questionManageNoteFive,String questionManageNoteSix,String questionRecordsOne,String questionRecordsTwo,String questionRecordsThree,String questionRecordsNoteOne,String questionRecordsNoteTwo,String questionRecordsNoteThree,String questionReskOne,
				String questionReskTwo,String questionReskThree,String questionReskFour,String questionReskFive,String questionReskSix,String questionReskSeven,String questionReskEight,String questionReskNoteOne,String questionReskNoteTwo,String questionReskNoteThree,String questionReskNoteFour,
				String questionReskNoteFive,String questionReskNoteSix,String questionReskNoteSeven,String questionReskNoteEight,String notcomplied,String record)  throws PortalException, SystemException, IOException
		 {
			if(compilanceCheckid !=0){
				CompilanceCheck visual =CompilanceCheckLocalServiceUtil.getCompilanceCheck(compilanceCheckid);
				
				visual.setAditid(aditid);
				
				visual.setCompany(company);
				
				visual.setAudidate(audidate);
				visual.setCompletedStatus(completedStatus);
				visual.setAuditPercentage(auditPercentage);
				visual.setQuestionSafetyOne(questionSafetyOne);
				visual.setQuestionSafetyTwo(questionSafetyTwo);
				visual.setQuestionSafetyThree(questionSafetyThree);
				visual.setQuestionSafetFour(questionSafetFour);
				visual.setQuestionSafetFive(questionSafetFive);
				visual.setQuestionSafetSix(questionSafetSix);
				visual.setQuestionSafetySeven(questionSafetySeven);
				visual.setQuestionNoteOne(questionNoteOne);
				visual.setQuestionNoteTwo(questionNoteTwo);
				visual.setQuestionNoteThree(questionNoteThree);
				visual.setQuestionNoteFour(questionNoteFour);
				visual.setQuestionNoteFive(questionNoteFive);
				visual.setQuestionNoteSix(questionNoteSix);
				visual.setQuestionNoteSeven(questionNoteSeven);
				
				visual.setQuestionVehicalOne(questionVehicalOne);
				visual.setQuestionVehicalTwo(questionVehicalTwo);
				visual.setQuestionVehicalThree(questionVehicalThree);
				visual.setQuestionVehicalFour(questionVehicalFour);
				visual.setQuestionVehicalFive(questionVehicalFive);
				visual.setQuestionVehicalSix(questionVehicalSix);
				visual.setQuestionVehicalSeven(questionVehicalSeven);
				
				visual.setQuestionVehicalNoteOne(questionVehicalNoteOne);
				visual.setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
				visual.setQuestionVehicalNoteThree(questionVehicalNoteThree);
				visual.setQuestionVehicalNoteFour(questionVehicalNoteFour);
				visual.setQuestionVehicalNoteFive(questionVehicalNoteFive);
				visual.setQuestionVehicalNoteSix(questionVehicalNoteSix);
				visual.setQuestionVehicalSeven(questionVehicalSeven);
				
				visual.setQuestionManageOne(questionManageOne);
				visual.setQuestionManageTwo(questionManageTwo);
				visual.setQuestionManageThree(questionManageThree);
				visual.setQuestionManageNoteFour(questionManageNoteFour);
				visual.setQuestionManageFive(questionManageFive);
				visual.setQuestionManageSix(questionManageSix);
				
				visual.setQuestionManageNoteOne(questionManageNoteOne);
				visual.setQuestionManageNoteTwo(questionManageNoteTwo);
				visual.setQuestionManageNoteThree(questionManageNoteThree);
				visual.setQuestionManageNoteFour(questionManageNoteFour);
				visual.setQuestionManageNoteFive(questionManageNoteFive);
				visual.setQuestionManageNoteSix(questionManageNoteSix);
				
				visual.setQuestionRecordsOne(questionRecordsOne);
				visual.setQuestionRecordsTwo(questionRecordsTwo);
				visual.setQuestionRecordsThree(questionRecordsThree);
				
				visual.setQuestionRecordsNoteOne(questionRecordsNoteOne);
				visual.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
				visual.setQuestionRecordsNoteThree(questionRecordsNoteThree);
				
				visual.setQuestionReskOne(questionReskOne);
				visual.setQuestionReskTwo(questionReskTwo);
				visual.setQuestionReskThree(questionReskThree);
				visual.setQuestionReskFour(questionReskFour);
				visual.setQuestionReskFive(questionReskFive);
				visual.setQuestionReskSix(questionReskSix);
				visual.setQuestionReskSeven(questionReskSeven);
				visual.setQuestionReskEight(questionReskEight);
				
				visual.setQuestionRecordsNoteOne(questionRecordsNoteOne);
				visual.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
				visual.setQuestionReskNoteThree(questionReskNoteThree);
				visual.setQuestionReskNoteFour(questionReskNoteFour);
				visual.setQuestionReskNoteFive(questionReskNoteFive);
				visual.setQuestionReskNoteSix(questionReskNoteSix);
				visual.setQuestionReskNoteSeven(questionReskNoteSeven);
				visual.setQuestionReskNoteEight(questionReskNoteEight);
				
				visual.setNotcomplied(notcomplied);
				
				visual.setRecord(record);
				
				return CompilanceCheckLocalServiceUtil.updateCompilanceCheck(visual);
				
			}else{
			    long checkmailId = CounterLocalServiceUtil.increment(CompilanceCheckServiceImpl.class.getName());
				
			    CompilanceCheck visual=null;
				visual = new CompilanceCheckImpl();
				//visual = visualchecklistLocalServiceUtil.createvisualchecklist(checkId);
				visual.setCompilanceCheckid(checkmailId);
				visual.setAditid(aditid);
				
				visual.setCompany(company);
				visual.setAudidate(audidate);
				visual.setCompletedStatus(completedStatus);
				visual.setAuditPercentage(auditPercentage);
				visual.setQuestionSafetyOne(questionSafetyOne);
				visual.setQuestionSafetyTwo(questionSafetyTwo);
				visual.setQuestionSafetyThree(questionSafetyThree);
				visual.setQuestionSafetFour(questionSafetFour);
				visual.setQuestionSafetFive(questionSafetFive);
				visual.setQuestionSafetSix(questionSafetSix);
				visual.setQuestionSafetySeven(questionSafetySeven);
				visual.setQuestionNoteOne(questionNoteOne);
				visual.setQuestionNoteTwo(questionNoteTwo);
				visual.setQuestionNoteThree(questionNoteThree);
				visual.setQuestionNoteFour(questionNoteFour);
				visual.setQuestionNoteFive(questionNoteFive);
				visual.setQuestionNoteSix(questionNoteSix);
				visual.setQuestionNoteSeven(questionNoteSeven);
				
				visual.setQuestionVehicalOne(questionVehicalOne);
				visual.setQuestionVehicalTwo(questionVehicalTwo);
				visual.setQuestionVehicalThree(questionVehicalThree);
				visual.setQuestionVehicalFour(questionVehicalFour);
				visual.setQuestionVehicalFive(questionVehicalFive);
				visual.setQuestionVehicalSix(questionVehicalSix);
				visual.setQuestionVehicalSeven(questionVehicalSeven);
				
				visual.setQuestionVehicalNoteOne(questionVehicalNoteOne);
				visual.setQuestionVehicalNoteTwo(questionVehicalNoteTwo);
				visual.setQuestionVehicalNoteThree(questionVehicalNoteThree);
				visual.setQuestionVehicalNoteFour(questionVehicalNoteFour);
				visual.setQuestionVehicalNoteFive(questionVehicalNoteFive);
				visual.setQuestionVehicalNoteSix(questionVehicalNoteSix);
				visual.setQuestionVehicalSeven(questionVehicalSeven);
				
				visual.setQuestionManageOne(questionManageOne);
				visual.setQuestionManageTwo(questionManageTwo);
				visual.setQuestionManageThree(questionManageThree);
				visual.setQuestionManageNoteFour(questionManageNoteFour);
				visual.setQuestionManageFive(questionManageFive);
				visual.setQuestionManageSix(questionManageSix);
				
				visual.setQuestionManageNoteOne(questionManageNoteOne);
				visual.setQuestionManageNoteTwo(questionManageNoteTwo);
				visual.setQuestionManageNoteThree(questionManageNoteThree);
				visual.setQuestionManageNoteFour(questionManageNoteFour);
				visual.setQuestionManageNoteFive(questionManageNoteFive);
				visual.setQuestionManageNoteSix(questionManageNoteSix);
				
				visual.setQuestionRecordsOne(questionRecordsOne);
				visual.setQuestionRecordsTwo(questionRecordsTwo);
				visual.setQuestionRecordsThree(questionRecordsThree);
				
				visual.setQuestionRecordsNoteOne(questionRecordsNoteOne);
				visual.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
				visual.setQuestionRecordsNoteThree(questionRecordsNoteThree);
				
				visual.setQuestionReskOne(questionReskOne);
				visual.setQuestionReskTwo(questionReskTwo);
				visual.setQuestionReskThree(questionReskThree);
				visual.setQuestionReskFour(questionReskFour);
				visual.setQuestionReskFive(questionReskFive);
				visual.setQuestionReskSix(questionReskSix);
				visual.setQuestionReskSeven(questionReskSeven);
				visual.setQuestionReskEight(questionReskEight);
				
				visual.setQuestionRecordsNoteOne(questionRecordsNoteOne);
				visual.setQuestionRecordsNoteTwo(questionRecordsNoteTwo);
				visual.setQuestionReskNoteThree(questionReskNoteThree);
				visual.setQuestionReskNoteFour(questionReskNoteFour);
				visual.setQuestionReskNoteFive(questionReskNoteFive);
				visual.setQuestionReskNoteSix(questionReskNoteSix);
				visual.setQuestionReskNoteSeven(questionReskNoteSeven);
				visual.setQuestionReskNoteEight(questionReskNoteEight);
				
				visual.setNotcomplied(notcomplied);
				
				visual.setRecord(record);
					
				return CompilanceCheckLocalServiceUtil.addCompilanceCheck(visual);

				
				}
			
			
		 }
		
		@JSONWebService(value = "SelfAssesment_Compilance_View_GET", method = "GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject CompilanceCheck(long compilanceCheckid)  throws PortalException, SystemException, IOException
		 {
			JSONObject VisualInspectionReturn = JSONFactoryUtil.createJSONObject();
			
			JSONObject VisualMainReturn = JSONFactoryUtil.createJSONObject();
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			JSONObject VisualDetaildoc = JSONFactoryUtil.createJSONObject();
			
			//JSONObject VisualInspecterdoc = JSONFactoryUtil.createJSONObject();
			
				CompilanceCheck visual = CompilanceCheckLocalServiceUtil.getCompilanceCheck(compilanceCheckid);
			
				VisualDetaildoc.put("checkmailId", visual.getCompilanceCheckid());
				VisualDetaildoc.put("aditid", visual.getAditid());
				VisualDetaildoc.put("company", visual.getCompany());
				VisualDetaildoc.put("audidate", visual.getAudidate());
				VisualDetaildoc.put("completedStatus", visual.getCompletedStatus());
				VisualDetaildoc.put("auditPercentage", visual.getAuditPercentage());
				VisualDetaildoc.put("questionSafetyOne", visual.getQuestionSafetyOne());
				VisualDetaildoc.put("questionSafetyTwo", visual.getQuestionSafetyTwo());
				VisualDetaildoc.put("questionSafetyThree", visual.getQuestionSafetyThree());
				VisualDetaildoc.put("questionSafetFour", visual.getQuestionSafetFour());
				VisualDetaildoc.put("questionSafetFive", visual.getQuestionSafetFive());
				VisualDetaildoc.put("questionSafetSix", visual.getQuestionSafetSix());
				VisualDetaildoc.put("questionSafetySeven", visual.getQuestionSafetySeven());
				VisualDetaildoc.put("questionNoteOne", visual.getQuestionNoteOne());
				VisualDetaildoc.put("questionNoteTwo", visual.getQuestionNoteTwo());
				VisualDetaildoc.put("questionNoteThree", visual.getQuestionNoteThree());
				VisualDetaildoc.put("questionNoteFour", visual.getQuestionNoteFour());
				VisualDetaildoc.put("questionNoteFive", visual.getQuestionNoteFive());
				VisualDetaildoc.put("questionNoteSix", visual.getQuestionNoteSix());
				VisualDetaildoc.put("questionNoteSeven",visual.getQuestionNoteSeven());
				//VisualDetailArray.put(VisualDetaildoc);
				VisualDetaildoc.put("questionVehicalOne",visual.getQuestionVehicalOne());
				VisualDetaildoc.put("questionVehicalTwo",visual.getQuestionVehicalTwo());
				
				VisualDetaildoc.put("questionVehicalThree",visual.getQuestionVehicalThree());
				VisualDetaildoc.put("questionVehicalFour",visual.getQuestionVehicalFour());
				VisualDetaildoc.put("questionVehicalFive",visual.getQuestionVehicalFive());
				VisualDetaildoc.put("questionVehicalSix",visual.getQuestionVehicalSix());
				VisualDetaildoc.put("questionVehicalSeven",visual.getQuestionVehicalSeven());
				VisualDetaildoc.put("questionVehicalNoteOne",visual.getQuestionVehicalNoteOne());
				VisualDetaildoc.put("questionVehicalNoteTwo",visual.getQuestionVehicalNoteTwo());
				VisualDetaildoc.put("questionVehicalNoteThree",visual.getQuestionVehicalNoteThree());
				VisualDetaildoc.put("questionVehicalNoteFour",visual.getQuestionVehicalNoteFour());
				VisualDetaildoc.put("questionVehicalNoteFive",visual.getQuestionVehicalNoteFive());
				VisualDetaildoc.put("questionVehicalNoteSix",visual.getQuestionVehicalNoteSix());
				VisualDetaildoc.put("questionVehicalSeven",visual.getQuestionVehicalSeven());
				
				
				VisualDetaildoc.put("questionManageOne",visual.getQuestionManageOne());
				VisualDetaildoc.put("questionManageTwo",visual.getQuestionManageTwo());
				VisualDetaildoc.put("questionManageThree",visual.getQuestionManageThree());
				VisualDetaildoc.put("questionManageNoteFour",visual.getQuestionManageNoteFour());
				VisualDetaildoc.put("questionManageFive",visual.getQuestionManageFive());
				VisualDetaildoc.put("questionManageSix",visual.getQuestionManageSix());
				
				VisualDetaildoc.put("questionManageNoteOne",visual.getQuestionManageNoteOne());
				VisualDetaildoc.put("questionManageNoteTwo",visual.getQuestionManageNoteTwo());
				VisualDetaildoc.put("questionManageNoteThree",visual.getQuestionManageNoteThree());
				VisualDetaildoc.put("questionManageNoteFour",visual.getQuestionManageNoteFour());
				VisualDetaildoc.put("questionManageNoteFive",visual.getQuestionManageNoteFive());
				VisualDetaildoc.put("questionManageNoteSix",visual.getQuestionManageNoteSix());
				
				VisualDetaildoc.put("questionRecordsOne",visual.getQuestionRecordsOne());
				VisualDetaildoc.put("questionRecordsTwo",visual.getQuestionRecordsTwo());
				VisualDetaildoc.put("questionRecordsThree",visual.getQuestionRecordsThree());
				
				VisualDetaildoc.put("questionRecordsNoteOne",visual.getQuestionRecordsNoteOne());
				VisualDetaildoc.put("questionRecordsNoteTwo",visual.getQuestionRecordsNoteTwo());
				VisualDetaildoc.put("questionRecordsNoteThree",visual.getQuestionRecordsNoteThree());
				
				VisualDetaildoc.put("questionReskOne",visual.getQuestionReskOne());
				VisualDetaildoc.put("questionReskTwo",visual.getQuestionReskTwo());
				VisualDetaildoc.put("questionReskThree",visual.getQuestionReskThree());
				VisualDetaildoc.put("questionReskFour",visual.getQuestionReskFour());
				VisualDetaildoc.put("questionReskFive",visual.getQuestionReskFive());
				VisualDetaildoc.put("questionReskSix",visual.getQuestionReskSix());
				VisualDetaildoc.put("questionReskSeven",visual.getQuestionReskSeven());
				VisualDetaildoc.put("questionReskEight",visual.getQuestionReskEight());
				
				VisualDetaildoc.put("questionRecordsNoteOne",visual.getQuestionRecordsNoteOne());
				VisualDetaildoc.put("questionRecordsNoteTwo",visual.getQuestionRecordsNoteTwo());
				VisualDetaildoc.put("questionReskNoteThree",visual.getQuestionReskNoteThree());
				VisualDetaildoc.put("questionReskNoteFour",visual.getQuestionReskNoteFour());
				VisualDetaildoc.put("questionReskNoteFive",visual.getQuestionReskNoteFive());
				VisualDetaildoc.put("questionReskNoteSix",visual.getQuestionReskNoteSix());
				VisualDetaildoc.put("questionReskNoteSeven",visual.getQuestionReskNoteSeven());
				VisualDetaildoc.put("questionReskNoteEight",visual.getQuestionReskNoteEight());
				
				VisualDetaildoc.put("notcomplied",visual.getNotcomplied());
				VisualDetaildoc.put("record",visual.getRecord());
				
				VisualInspectionReturn.put("Compilance_Check", VisualDetaildoc);
				
				//VisualreturnArray.put(VisualInspectionReturn);
		     			
			VisualMainReturn.put("Compilance_Check_Detail", VisualInspectionReturn);
			
			return VisualMainReturn;
		 }
	
		@JSONWebService(value = "CHIEF_ICOP_LIST", method = "GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject ChiefIcopAudit()  throws PortalException, SystemException, IOException
		 {	
		JSONObject ChifIcop = JSONFactoryUtil.createJSONObject();
		JSONObject AuditChiefIcop = JSONFactoryUtil.createJSONObject();
		JSONObject employeeIcoObject = JSONFactoryUtil.createJSONObject();
		
		JSONObject exceriseObject = JSONFactoryUtil.createJSONObject();
		
		//JSONObject employeeFinalObject = JSONFactoryUtil.createJSONObject();
		//JSONArray employeeArray = JSONFactoryUtil.createJSONArray();
		//JSONObject appendexObject = JSONFactoryUtil.createJSONObject();
		
		JSONArray   appoinmentArray= JSONFactoryUtil.createJSONArray();
		JSONArray   exceriseArray= JSONFactoryUtil.createJSONArray();

		
		List<AppointmentCall>  appointmentCalls= AppointmentCallLocalServiceUtil.getAppointmentCalls(-1, -1);
		for(AppointmentCall recordCall:appointmentCalls){
			
			JSONObject appoinmentldoc = JSONFactoryUtil.createJSONObject();
			appoinmentldoc.put("Adit_Id", recordCall.getAditid());
			appoinmentldoc.put("Record_call_id", recordCall.getRecordcallid());
			appoinmentldoc.put("Date_Road_Safety", recordCall.getDateonroadsafty());
			appoinmentldoc.put("Time_Event", recordCall.getTime());
			appoinmentldoc.put("Location", recordCall.getLocation());
			appoinmentldoc.put("Investigation_Title", recordCall.getInvestigationtitle());
			appoinmentldoc.put("Company", recordCall.getCompany());
			appoinmentldoc.put("Status", recordCall.getStatusverification());
			appoinmentArray.put(appoinmentldoc);	
			
			employeeIcoObject.put("NOTICE_DIRECTION_MANAGEMENT_AUDIT", appoinmentArray);
			
		}
		
/* INQUERY TAB  */	
		
		List<EmployeeAudit> indexDetails = EmployeeAuditLocalServiceUtil.getEmployeeAudits(-1, -1);
		JSONArray appendexArray = JSONFactoryUtil.createJSONArray();
		JSONArray AppendixKJArray = JSONFactoryUtil.createJSONArray();
		JSONArray AuditReportArray = JSONFactoryUtil.createJSONArray();
		JSONObject appendexObject = JSONFactoryUtil.createJSONObject();
		for(EmployeeAudit audit:indexDetails){
			
//Appendix_G			
			
			JSONObject appendexdoc = JSONFactoryUtil.createJSONObject();
		
			appendexdoc.put("aditid", audit.getAditid());
			appendexdoc.put("chronicle", audit.getDateofregistration());
			appendexdoc.put("company", audit.getCompany());
			appendexdoc.put("representativeName", audit.getRepresentativeName());
			appendexdoc.put("phoneno", audit.getPhoneno());
			appendexdoc.put("status", audit.getStatus());
			appendexdoc.put("appendixg", audit.getAppendixg());
			appendexdoc.put("reportscmd", audit.getReportscmd());
			
			appendexArray.put(appendexdoc);
			
			
//Appendix_KJR	
		
			JSONObject AppendixKJRdoc = JSONFactoryUtil.createJSONObject();
			AppendixKJRdoc.put("aditid", audit.getAditid());
			AppendixKJRdoc.put("chronicle", audit.getDateofregistration());
			AppendixKJRdoc.put("company", audit.getCompany());
			AppendixKJRdoc.put("representativeName", audit.getRepresentativeName());
			AppendixKJRdoc.put("phoneno", audit.getPhoneno());
			AppendixKJRdoc.put("status", "Set Appointment");
			AppendixKJRdoc.put("AppendixG", "View | Download");
			AppendixKJRdoc.put("reportsKJR", "View | Download");
			AppendixKJRdoc.put("reportscmd", audit.getReportscmd());
			
			AppendixKJArray.put(AppendixKJRdoc);
			
//Audit Report SRU
			
			JSONObject AuditReportdoc = JSONFactoryUtil.createJSONObject();
			
			AuditReportdoc.put("aditid", audit.getAditid());
			AuditReportdoc.put("dateonroad", audit.getDateonroad());
			AuditReportdoc.put("Dateofincident", audit.getDateofincident());
			
			
			AuditReportdoc.put("timeevent", audit.getTimeevent());
			AuditReportdoc.put("locationofincident", audit.getLocationofincident());
			
			AuditReportdoc.put("Companyname", audit.getCompany());
			
			AuditReportdoc.put("TrainingAttendance", audit.getStatus());
			
			AuditReportdoc.put("PostCrashAudit", audit.getAudidate());
			AuditReportdoc.put("ComplianceAuditDate", audit.getAudidate());
			AuditReportdoc.put("DateCaseSRU", audit.getDateCaseSrU());
			AuditReportdoc.put("ActionSRU", audit.getActionSru());
			
			AuditReportArray.put(AuditReportdoc);
			

		}
		
		exceriseObject.put("REGISTRATION STATUS", "Use -Registation_Status_of_Training- Web Service");
		
		appendexObject.put("Appendix_G", appendexArray);
		appendexObject.put("Audit_Report", AuditReportArray);
		appendexObject.put("Appendix_KJR", AppendixKJArray);
		
		AuditChiefIcop.put("INDEXING", appendexObject);
		AuditChiefIcop.put("AUDIT", employeeIcoObject);
		AuditChiefIcop.put("EXERCISE", exceriseObject);
		
		ChifIcop.put("CHIEF_ICOP", AuditChiefIcop);
		
		
		return ChifIcop;
		 
	}	
		
		@JSONWebService(value = "Operators_List", method = "GET")
		@AccessControlled(guestAccessEnabled = true)
		public JSONObject OperatorsList(String vehicletype,String vehicalNo,String companyName,String statusExercise)  throws PortalException, SystemException, IOException
		 {	
			
			//JSONObject RegistationStatus = JSONFactoryUtil.createJSONObject();
			
			List<EmployeeAudit> list = new ArrayList<EmployeeAudit>();
			
			List<EmployeeAudit> employeeAudits = null;
			try {
				employeeAudits = EmployeeAuditLocalServiceUtil.getEmployeeAudits(-1, -1);
			} catch (SystemException e1) {
				//TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			DynamicQuery dynamicQuery =null;
			boolean setFlag = true;
			boolean setFlagand = true;
			
			try{
			ClassLoader loader=(ClassLoader)PortletBeanLocatorUtil.locate(com.spad.icop.service.ClpSerializer.getServletContextName(),"portletClassLoader");
			dynamicQuery = DynamicQueryFactoryUtil.forClass(EmployeeAudit.class, loader);
			
			Criterion criterion = null;
			
			if(!vehicletype.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("typeofvehicle", vehicletype);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("typeofvehicle",vehicletype));
				setFlagand = false;
			}
			
			if(!vehicalNo.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("vehiclesNo", vehicalNo);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("vehiclesNo",vehicalNo));
				setFlagand = false;
			}
			if(!companyName.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("company", StringPool.PERCENT+companyName+StringPool.PERCENT );
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("company", StringPool.PERCENT+companyName+StringPool.PERCENT));
				setFlagand = false;
			}
			
			if(!statusExercise.equals(StringPool.BLANK)){
				if(setFlag){
					criterion = RestrictionsFactoryUtil.like("status", statusExercise);
					setFlag = false;
				}
				criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("status",statusExercise));
				setFlagand = false;
			}
			
			dynamicQuery.add(criterion);
			List<EmployeeAudit> gallryIds =null;
			try {
				gallryIds = EmployeeAuditLocalServiceUtil.dynamicQuery(dynamicQuery);
				for(EmployeeAudit gall:gallryIds ){
					list.add(gall);

				}
				
			} catch (SystemException e) {
				e.printStackTrace();
			}
		 
		
		 }catch(Exception e){}
			JSONArray TrainingNumArray = JSONFactoryUtil.createJSONArray();
			JSONObject registationStatus = JSONFactoryUtil.createJSONObject();
			JSONObject TrainingNumCer = JSONFactoryUtil.createJSONObject();

			 if(Validator.isNotNull(list) && list.size() > 0 ){
				for(EmployeeAudit listindex:list)
				{
					JSONObject TrainingNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNumCer = JSONFactoryUtil.createJSONObject();
					
					TrainingNum.put("Aditid",listindex.getAditid());
					TrainingNum.put("List_Companies_No",listindex.getCompanieListNumber());
					TrainingNum.put("CompanyName",listindex.getCompany());

					TrainingNum.put("TypeofCompany",listindex.getTypeofcompany());
					TrainingNum.put("Address",listindex.getAddresss());
					TrainingNum.put("Email",listindex.getCompanyEmail());
					TrainingNum.put("Typeofvehicle",listindex.getTypeofvehicle());
					TrainingNum.put("Novehicles",listindex.getVehiclesNo());
					TrainingNum.put("StatusExercise",listindex.getStatus());
					
					TrainingNumArray.put(TrainingNum);
					
					TrainingNumCer.put("OPERATORS_LIST", TrainingNumArray);
					
			}
			registationStatus.put("OPERATORS_LIST_MAIN", TrainingNumCer);
			
			}else if(setFlag == true && setFlagand == true){
				for(EmployeeAudit listindex:employeeAudits)
				{
					JSONObject TrainingNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNum = JSONFactoryUtil.createJSONObject();
					//JSONObject ExiercisNumCer = JSONFactoryUtil.createJSONObject();
					
					TrainingNum.put("Aditid",listindex.getAditid());
					TrainingNum.put("List_Companies_No",listindex.getCompanieListNumber());
					TrainingNum.put("CompanyName",listindex.getCompany());
					TrainingNum.put("TypeofCompany",listindex.getTypeofcompany());
					TrainingNum.put("Address",listindex.getAddresss());
					TrainingNum.put("Email",listindex.getCompanyEmail());
					TrainingNum.put("Typeofvehicle",listindex.getTypeofvehicle());
					TrainingNum.put("Novehicles",listindex.getVehiclesNo());
					TrainingNum.put("StatusExercise",listindex.getStatus());
					//TrainingNumArray.put(TrainingNumCer);
					TrainingNumArray.put(TrainingNum);
				    TrainingNumCer.put("OPERATORS_LIST", TrainingNumArray);
				  
				}
				
			  registationStatus.put("OPERATORS_LIST_MAIN", TrainingNumCer);
			}	
				
		return registationStatus;
		
		}
		
		 @JSONWebService(value = "Complain_Check_Audit_POST", method = "POST")
			@AccessControlled(guestAccessEnabled = true)
			public ComplainCheckAudit COMPLIANCE_CHECKAUDIT(long aditid,String auditdate1_1,String auditdate1_2,String auditdate1_3
					,String auditdate1_4,String auditdate1_5,String auditdate1_6,String auditdate1_7,String auditdateNote1_1,String auditdateNote1_2,String auditdateNote1_3,String auditdateNote1_4,String auditdateNote1_5,String auditdateNote1_6,String auditdateNote1_7,
					String auditdate2_1,String auditdate2_2,String auditdate2_3,String auditdate2_4,String auditdateNote2_1,String auditdateNote2_2,String auditdateNote2_3,String auditdateNote2_4,
					String auditdate2_4_1,String auditdate2_4_2,String auditdate2_4_3,String auditdate2_4_4,String auditdateNote2_4_1,String auditdateNote2_4_2,String auditdateNote2_4_3,String auditdateNote2_4_4,
					String auditdate3_1,String auditdate3_2,String auditdate3_3,String auditdate3_4,String auditdate3_5,String auditdate3_6,String auditdateNote3_1,String auditdateNote3_2,String auditdateNote3_3,String auditdateNote3_4,String auditdateNote3_5,String auditdateNote3_6,
					String auditdate4_1,String auditdate4_2,String auditdate4_3,String auditdateNote4_1,String auditdateNote4_2,String auditdateNote4_3,String auditdate5_1,String auditdate5_2,String auditdate5_3,String auditdate5_4,String auditdate5_5,String auditdate5_6,String auditdate5_7,String auditdate5_8,
					String auditdateNote5_1,String auditdateNote5_2,String auditdateNote5_3,String auditdateNote5_4,String auditdateNote5_5,String auditdateNote5_6,String auditdateNote5_7,String auditdateNote5_8)  throws PortalException, SystemException, IOException
			 {	
		

			long appointmentId = CounterLocalServiceUtil.increment(ComplainCheckAudit.class.getName());
			
			ComplainCheckAudit appointment=null;
			appointment = new ComplainCheckAuditImpl();
			
			appointment.setMatterId(appointmentId);
			appointment.setAditid(aditid);
			appointment.setAuditdate1_1(auditdate1_1);
			appointment.setAuditdate1_2(auditdate1_2);
			appointment.setAuditdate1_3(auditdate1_3);
			appointment.setAuditdate1_4(auditdate1_4);
			appointment.setAuditdate1_5(auditdate1_5);
			appointment.setAuditdate1_6(auditdate1_6);
			appointment.setAuditdate1_7(auditdate1_7);
			
			appointment.setAuditdateNote1_1(auditdateNote1_1);
			appointment.setAuditdateNote1_2(auditdateNote1_2);
			appointment.setAuditdateNote1_3(auditdateNote1_3);
			appointment.setAuditdateNote1_4(auditdateNote1_4);
			appointment.setAuditdateNote1_5(auditdateNote1_5);
			appointment.setAuditdateNote1_6(auditdateNote1_6);
			appointment.setAuditdateNote1_7(auditdateNote1_7);
			
			
			appointment.setAuditdate2_1(auditdate2_1);
			appointment.setAuditdate2_2(auditdate2_2);
			appointment.setAuditdate2_3(auditdate2_3);
			appointment.setAuditdate2_4(auditdate2_4);
			appointment.setAuditdateNote2_1(auditdateNote2_1);
			appointment.setAuditdateNote2_2(auditdateNote2_2);
			appointment.setAuditdateNote2_3(auditdateNote2_3);
			appointment.setAuditdateNote2_4(auditdateNote2_4);
			
			appointment.setAuditdate2_4_1(auditdate2_4_1);
			appointment.setAuditdate2_4_2(auditdate2_4_2);
			appointment.setAuditdate2_4_3(auditdate2_4_3);
			appointment.setAuditdate2_4_4(auditdate2_4_4);
			appointment.setAuditdateNote2_4_1(auditdateNote2_4_1);
			appointment.setAuditdateNote2_4_2(auditdateNote2_4_2);
			appointment.setAuditdateNote2_4_3(auditdateNote2_4_3);
			appointment.setAuditdateNote2_4_4(auditdateNote2_4_4);
			
			appointment.setAuditdate3_1(auditdate3_1);
			appointment.setAuditdate3_2(auditdate3_2);
			appointment.setAuditdate3_3(auditdate3_3);
			appointment.setAuditdate3_4(auditdate3_4);
			appointment.setAuditdate3_5(auditdate3_5);
			appointment.setAuditdate3_6(auditdate3_6);
			appointment.setAuditdateNote3_1(auditdateNote3_1);
			appointment.setAuditdateNote3_2(auditdateNote3_2);
			appointment.setAuditdateNote3_3(auditdateNote3_3);
			appointment.setAuditdateNote3_4(auditdateNote3_4);
			appointment.setAuditdateNote3_5(auditdateNote3_5);
			appointment.setAuditdateNote3_6(auditdateNote3_6);
			
			appointment.setAuditdate4_1(auditdate4_1);
			appointment.setAuditdate4_2(auditdate4_2);
			appointment.setAuditdate4_3(auditdate4_3);
			appointment.setAuditdateNote4_1(auditdateNote4_1);
			appointment.setAuditdateNote4_2(auditdateNote4_2);
			appointment.setAuditdateNote4_3(auditdateNote4_3);
			
			appointment.setAuditdate5_1(auditdate5_1);
			appointment.setAuditdate5_2(auditdate5_2);
			appointment.setAuditdate5_3(auditdate5_3);
			appointment.setAuditdate5_4(auditdate5_4);
			appointment.setAuditdate5_5(auditdate5_5);
			appointment.setAuditdate5_6(auditdate5_6);
			appointment.setAuditdate5_7(auditdate5_7);
			appointment.setAuditdate5_8(auditdate5_8);
			
			appointment.setAuditdateNote5_1(auditdateNote5_1);
			appointment.setAuditdateNote5_2(auditdateNote5_2);
			appointment.setAuditdateNote5_3(auditdateNote5_3);
			appointment.setAuditdateNote5_4(auditdateNote5_4);
			appointment.setAuditdateNote5_5(auditdateNote5_5);
			appointment.setAuditdateNote5_6(auditdateNote5_6);
			appointment.setAuditdateNote5_7(auditdateNote5_7);
			
			return ComplainCheckAuditLocalServiceUtil.addComplainCheckAudit(appointment);
			
		}
		  	
		    @JSONWebService(value = "Complain_Check_Validation_Get", method = "GET")
			@AccessControlled(guestAccessEnabled = true)
			public JSONObject ComplainChekValidation(long matterId,long aditid)  throws PortalException, SystemException, IOException
			 {
			 JSONObject complainObject= JSONFactoryUtil.createJSONObject();
			  List<ComplainCheckAudit> ComplainCheckAudit = ComplainCheckAuditLocalServiceUtil.getsByMatterAduit(aditid, matterId);
			  for(ComplainCheckAudit complain:ComplainCheckAudit){
				 
				 JSONObject complainvalidate = JSONFactoryUtil.createJSONObject();
				 complainvalidate.put("matterId", complain.getMatterId());
				 complainvalidate.put("aditid", complain.getAditid());
				 complainvalidate.put("auditdate1_1", complain.getAuditdate1_1());
				 complainvalidate.put("auditdate1_2", complain.getAuditdate1_2());
				 complainvalidate.put("auditdate1_3", complain.getAuditdate1_3());
				 complainvalidate.put("auditdate1_4", complain.getAuditdate1_4());
				 complainvalidate.put("auditdate1_5", complain.getAuditdate1_5());
				 complainvalidate.put("auditdate1_6", complain.getAuditdate1_6());
				 complainvalidate.put("auditdate1_7", complain.getAuditdate1_7());
				 
				 complainvalidate.put("auditdateNote1_1", complain.getAuditdateNote1_1());
				 complainvalidate.put("auditdateNote1_2", complain.getAuditdateNote1_2());
				 complainvalidate.put("auditdateNote1_3", complain.getAuditdateNote1_3());
				 complainvalidate.put("auditdateNote1_4", complain.getAuditdateNote1_4());
				 complainvalidate.put("auditdateNote1_5", complain.getAuditdateNote1_5());
				 complainvalidate.put("auditdateNote1_6", complain.getAuditdateNote1_6());
				 complainvalidate.put("auditdateNote1_7", complain.getAuditdateNote1_7());
				 complainObject.put("ComplainAuditValidate", complainvalidate);
				 
			 }
			 
				return complainObject;	
			 
			 }
		 
		 
	}