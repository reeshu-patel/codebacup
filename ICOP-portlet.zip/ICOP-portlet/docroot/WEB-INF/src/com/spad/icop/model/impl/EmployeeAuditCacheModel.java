/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.spad.icop.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.spad.icop.model.EmployeeAudit;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing EmployeeAudit in entity cache.
 *
 * @author reeshu
 * @see EmployeeAudit
 * @generated
 */
public class EmployeeAuditCacheModel implements CacheModel<EmployeeAudit>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(75);

		sb.append("{aditid=");
		sb.append(aditid);
		sb.append(", dateonroad=");
		sb.append(dateonroad);
		sb.append(", dateofincident=");
		sb.append(dateofincident);
		sb.append(", timeevent=");
		sb.append(timeevent);
		sb.append(", titleinvestigation=");
		sb.append(titleinvestigation);
		sb.append(", typeofvehicle=");
		sb.append(typeofvehicle);
		sb.append(", noregistration=");
		sb.append(noregistration);
		sb.append(", company=");
		sb.append(company);
		sb.append(", reportsKjr=");
		sb.append(reportsKjr);
		sb.append(", reportscmd=");
		sb.append(reportscmd);
		sb.append(", srustatus=");
		sb.append(srustatus);
		sb.append(", completedStatus=");
		sb.append(completedStatus);
		sb.append(", audidate=");
		sb.append(audidate);
		sb.append(", auditime=");
		sb.append(auditime);
		sb.append(", statusofadudit=");
		sb.append(statusofadudit);
		sb.append(", completeddate=");
		sb.append(completeddate);
		sb.append(", addresss=");
		sb.append(addresss);
		sb.append(", locationofincident=");
		sb.append(locationofincident);
		sb.append(", trainingattendance=");
		sb.append(trainingattendance);
		sb.append(", auditaccidents=");
		sb.append(auditaccidents);
		sb.append(", typecertificate=");
		sb.append(typecertificate);
		sb.append(", dateofregistration=");
		sb.append(dateofregistration);
		sb.append(", trainingdates=");
		sb.append(trainingdates);
		sb.append(", enddate=");
		sb.append(enddate);
		sb.append(", typemod=");
		sb.append(typemod);
		sb.append(", typeoflicens=");
		sb.append(typeoflicens);
		sb.append(", typeofcompany=");
		sb.append(typeofcompany);
		sb.append(", phoneno=");
		sb.append(phoneno);
		sb.append(", status=");
		sb.append(status);
		sb.append(", appendixg=");
		sb.append(appendixg);
		sb.append(", dateCaseSrU=");
		sb.append(dateCaseSrU);
		sb.append(", actionSru=");
		sb.append(actionSru);
		sb.append(", officerName=");
		sb.append(officerName);
		sb.append(", vehiclesNo=");
		sb.append(vehiclesNo);
		sb.append(", companyEmail=");
		sb.append(companyEmail);
		sb.append(", representativeName=");
		sb.append(representativeName);
		sb.append(", companieListNumber=");
		sb.append(companieListNumber);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EmployeeAudit toEntityModel() {
		EmployeeAuditImpl employeeAuditImpl = new EmployeeAuditImpl();

		employeeAuditImpl.setAditid(aditid);

		if (dateonroad == null) {
			employeeAuditImpl.setDateonroad(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setDateonroad(dateonroad);
		}

		if (dateofincident == null) {
			employeeAuditImpl.setDateofincident(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setDateofincident(dateofincident);
		}

		if (timeevent == null) {
			employeeAuditImpl.setTimeevent(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTimeevent(timeevent);
		}

		if (titleinvestigation == null) {
			employeeAuditImpl.setTitleinvestigation(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTitleinvestigation(titleinvestigation);
		}

		if (typeofvehicle == null) {
			employeeAuditImpl.setTypeofvehicle(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTypeofvehicle(typeofvehicle);
		}

		if (noregistration == null) {
			employeeAuditImpl.setNoregistration(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setNoregistration(noregistration);
		}

		if (company == null) {
			employeeAuditImpl.setCompany(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setCompany(company);
		}

		if (reportsKjr == null) {
			employeeAuditImpl.setReportsKjr(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setReportsKjr(reportsKjr);
		}

		if (reportscmd == null) {
			employeeAuditImpl.setReportscmd(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setReportscmd(reportscmd);
		}

		if (srustatus == null) {
			employeeAuditImpl.setSrustatus(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setSrustatus(srustatus);
		}

		if (completedStatus == null) {
			employeeAuditImpl.setCompletedStatus(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setCompletedStatus(completedStatus);
		}

		if (audidate == null) {
			employeeAuditImpl.setAudidate(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setAudidate(audidate);
		}

		if (auditime == null) {
			employeeAuditImpl.setAuditime(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setAuditime(auditime);
		}

		if (statusofadudit == null) {
			employeeAuditImpl.setStatusofadudit(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setStatusofadudit(statusofadudit);
		}

		if (completeddate == null) {
			employeeAuditImpl.setCompleteddate(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setCompleteddate(completeddate);
		}

		if (addresss == null) {
			employeeAuditImpl.setAddresss(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setAddresss(addresss);
		}

		if (locationofincident == null) {
			employeeAuditImpl.setLocationofincident(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setLocationofincident(locationofincident);
		}

		if (trainingattendance == null) {
			employeeAuditImpl.setTrainingattendance(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTrainingattendance(trainingattendance);
		}

		if (auditaccidents == null) {
			employeeAuditImpl.setAuditaccidents(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setAuditaccidents(auditaccidents);
		}

		if (typecertificate == null) {
			employeeAuditImpl.setTypecertificate(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTypecertificate(typecertificate);
		}

		if (dateofregistration == null) {
			employeeAuditImpl.setDateofregistration(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setDateofregistration(dateofregistration);
		}

		if (trainingdates == null) {
			employeeAuditImpl.setTrainingdates(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTrainingdates(trainingdates);
		}

		if (enddate == null) {
			employeeAuditImpl.setEnddate(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setEnddate(enddate);
		}

		if (typemod == null) {
			employeeAuditImpl.setTypemod(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTypemod(typemod);
		}

		if (typeoflicens == null) {
			employeeAuditImpl.setTypeoflicens(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTypeoflicens(typeoflicens);
		}

		if (typeofcompany == null) {
			employeeAuditImpl.setTypeofcompany(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setTypeofcompany(typeofcompany);
		}

		if (phoneno == null) {
			employeeAuditImpl.setPhoneno(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setPhoneno(phoneno);
		}

		if (status == null) {
			employeeAuditImpl.setStatus(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setStatus(status);
		}

		if (appendixg == null) {
			employeeAuditImpl.setAppendixg(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setAppendixg(appendixg);
		}

		if (dateCaseSrU == null) {
			employeeAuditImpl.setDateCaseSrU(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setDateCaseSrU(dateCaseSrU);
		}

		if (actionSru == null) {
			employeeAuditImpl.setActionSru(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setActionSru(actionSru);
		}

		if (officerName == null) {
			employeeAuditImpl.setOfficerName(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setOfficerName(officerName);
		}

		if (vehiclesNo == null) {
			employeeAuditImpl.setVehiclesNo(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setVehiclesNo(vehiclesNo);
		}

		if (companyEmail == null) {
			employeeAuditImpl.setCompanyEmail(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setCompanyEmail(companyEmail);
		}

		if (representativeName == null) {
			employeeAuditImpl.setRepresentativeName(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setRepresentativeName(representativeName);
		}

		if (companieListNumber == null) {
			employeeAuditImpl.setCompanieListNumber(StringPool.BLANK);
		}
		else {
			employeeAuditImpl.setCompanieListNumber(companieListNumber);
		}

		employeeAuditImpl.resetOriginalValues();

		return employeeAuditImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		aditid = objectInput.readLong();
		dateonroad = objectInput.readUTF();
		dateofincident = objectInput.readUTF();
		timeevent = objectInput.readUTF();
		titleinvestigation = objectInput.readUTF();
		typeofvehicle = objectInput.readUTF();
		noregistration = objectInput.readUTF();
		company = objectInput.readUTF();
		reportsKjr = objectInput.readUTF();
		reportscmd = objectInput.readUTF();
		srustatus = objectInput.readUTF();
		completedStatus = objectInput.readUTF();
		audidate = objectInput.readUTF();
		auditime = objectInput.readUTF();
		statusofadudit = objectInput.readUTF();
		completeddate = objectInput.readUTF();
		addresss = objectInput.readUTF();
		locationofincident = objectInput.readUTF();
		trainingattendance = objectInput.readUTF();
		auditaccidents = objectInput.readUTF();
		typecertificate = objectInput.readUTF();
		dateofregistration = objectInput.readUTF();
		trainingdates = objectInput.readUTF();
		enddate = objectInput.readUTF();
		typemod = objectInput.readUTF();
		typeoflicens = objectInput.readUTF();
		typeofcompany = objectInput.readUTF();
		phoneno = objectInput.readUTF();
		status = objectInput.readUTF();
		appendixg = objectInput.readUTF();
		dateCaseSrU = objectInput.readUTF();
		actionSru = objectInput.readUTF();
		officerName = objectInput.readUTF();
		vehiclesNo = objectInput.readUTF();
		companyEmail = objectInput.readUTF();
		representativeName = objectInput.readUTF();
		companieListNumber = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(aditid);

		if (dateonroad == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateonroad);
		}

		if (dateofincident == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofincident);
		}

		if (timeevent == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(timeevent);
		}

		if (titleinvestigation == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(titleinvestigation);
		}

		if (typeofvehicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeofvehicle);
		}

		if (noregistration == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(noregistration);
		}

		if (company == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(company);
		}

		if (reportsKjr == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(reportsKjr);
		}

		if (reportscmd == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(reportscmd);
		}

		if (srustatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(srustatus);
		}

		if (completedStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(completedStatus);
		}

		if (audidate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(audidate);
		}

		if (auditime == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditime);
		}

		if (statusofadudit == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusofadudit);
		}

		if (completeddate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(completeddate);
		}

		if (addresss == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(addresss);
		}

		if (locationofincident == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(locationofincident);
		}

		if (trainingattendance == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingattendance);
		}

		if (auditaccidents == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(auditaccidents);
		}

		if (typecertificate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typecertificate);
		}

		if (dateofregistration == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofregistration);
		}

		if (trainingdates == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingdates);
		}

		if (enddate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(enddate);
		}

		if (typemod == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typemod);
		}

		if (typeoflicens == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeoflicens);
		}

		if (typeofcompany == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeofcompany);
		}

		if (phoneno == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(phoneno);
		}

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (appendixg == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(appendixg);
		}

		if (dateCaseSrU == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateCaseSrU);
		}

		if (actionSru == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(actionSru);
		}

		if (officerName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(officerName);
		}

		if (vehiclesNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehiclesNo);
		}

		if (companyEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyEmail);
		}

		if (representativeName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(representativeName);
		}

		if (companieListNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companieListNumber);
		}
	}

	public long aditid;
	public String dateonroad;
	public String dateofincident;
	public String timeevent;
	public String titleinvestigation;
	public String typeofvehicle;
	public String noregistration;
	public String company;
	public String reportsKjr;
	public String reportscmd;
	public String srustatus;
	public String completedStatus;
	public String audidate;
	public String auditime;
	public String statusofadudit;
	public String completeddate;
	public String addresss;
	public String locationofincident;
	public String trainingattendance;
	public String auditaccidents;
	public String typecertificate;
	public String dateofregistration;
	public String trainingdates;
	public String enddate;
	public String typemod;
	public String typeoflicens;
	public String typeofcompany;
	public String phoneno;
	public String status;
	public String appendixg;
	public String dateCaseSrU;
	public String actionSru;
	public String officerName;
	public String vehiclesNo;
	public String companyEmail;
	public String representativeName;
	public String companieListNumber;
}