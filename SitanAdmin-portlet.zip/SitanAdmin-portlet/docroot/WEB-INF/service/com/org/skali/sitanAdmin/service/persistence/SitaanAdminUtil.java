/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.org.skali.sitanAdmin.model.SitaanAdmin;

import java.util.List;

/**
 * The persistence utility for the sitaan admin service. This utility wraps {@link SitaanAdminPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see SitaanAdminPersistence
 * @see SitaanAdminPersistenceImpl
 * @generated
 */
public class SitaanAdminUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(SitaanAdmin sitaanAdmin) {
		getPersistence().clearCache(sitaanAdmin);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<SitaanAdmin> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<SitaanAdmin> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<SitaanAdmin> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static SitaanAdmin update(SitaanAdmin sitaanAdmin)
		throws SystemException {
		return getPersistence().update(sitaanAdmin);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static SitaanAdmin update(SitaanAdmin sitaanAdmin,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(sitaanAdmin, serviceContext);
	}

	/**
	* Returns all the sitaan admins where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId);
	}

	/**
	* Returns a range of all the sitaan admins where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBybilId(bilId);
	}

	/**
	* Returns the number of sitaan admins where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBybilId(bilId);
	}

	/**
	* Returns all the sitaan admins where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBydateSeized(dateSeized);
	}

	/**
	* Returns a range of all the sitaan admins where dateSeized = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dateSeized the date seized
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBydateSeized(dateSeized, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where dateSeized = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dateSeized the date seized
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBydateSeized(dateSeized, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBydateSeized_First(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBydateSeized_First(dateSeized, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBydateSeized_First(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBydateSeized_First(dateSeized, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBydateSeized_Last(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBydateSeized_Last(dateSeized, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBydateSeized_Last(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBydateSeized_Last(dateSeized, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBydateSeized_PrevAndNext(
		long bilId, java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBydateSeized_PrevAndNext(bilId, dateSeized,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where dateSeized = &#63; from the database.
	*
	* @param dateSeized the date seized
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBydateSeized(java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBydateSeized(dateSeized);
	}

	/**
	* Returns the number of sitaan admins where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBydateSeized(java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBydateSeized(dateSeized);
	}

	/**
	* Returns all the sitaan admins where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycheckSitesSita(checkSitesSita);
	}

	/**
	* Returns a range of all the sitaan admins where checkSitesSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesSita the check sites sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycheckSitesSita(checkSitesSita, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where checkSitesSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesSita the check sites sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycheckSitesSita(checkSitesSita, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBycheckSitesSita_First(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBycheckSitesSita_First(checkSitesSita, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBycheckSitesSita_First(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycheckSitesSita_First(checkSitesSita,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBycheckSitesSita_Last(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBycheckSitesSita_Last(checkSitesSita, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBycheckSitesSita_Last(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycheckSitesSita_Last(checkSitesSita, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBycheckSitesSita_PrevAndNext(
		long bilId, java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBycheckSitesSita_PrevAndNext(bilId, checkSitesSita,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where checkSitesSita = &#63; from the database.
	*
	* @param checkSitesSita the check sites sita
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycheckSitesSita(java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycheckSitesSita(checkSitesSita);
	}

	/**
	* Returns the number of sitaan admins where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycheckSitesSita(java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycheckSitesSita(checkSitesSita);
	}

	/**
	* Returns all the sitaan admins where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByreferenceEffective(referenceEffective);
	}

	/**
	* Returns a range of all the sitaan admins where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByreferenceEffective(referenceEffective, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByreferenceEffective(referenceEffective, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByreferenceEffective_First(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByreferenceEffective_First(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByreferenceEffective_Last(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByreferenceEffective_Last(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByreferenceEffective_PrevAndNext(
		long bilId, java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByreferenceEffective_PrevAndNext(bilId,
			referenceEffective, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where referenceEffective = &#63; from the database.
	*
	* @param referenceEffective the reference effective
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByreferenceEffective(referenceEffective);
	}

	/**
	* Returns the number of sitaan admins where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByreferenceEffective(referenceEffective);
	}

	/**
	* Returns all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByconfiscatedPeriod(confiscatedPeriod);
	}

	/**
	* Returns a range of all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param confiscatedPeriod the confiscated period
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByconfiscatedPeriod(confiscatedPeriod, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param confiscatedPeriod the confiscated period
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByconfiscatedPeriod(confiscatedPeriod, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByconfiscatedPeriod_First(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByconfiscatedPeriod_First(confiscatedPeriod,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByconfiscatedPeriod_First(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByconfiscatedPeriod_First(confiscatedPeriod,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByconfiscatedPeriod_Last(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByconfiscatedPeriod_Last(confiscatedPeriod,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByconfiscatedPeriod_Last(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByconfiscatedPeriod_Last(confiscatedPeriod,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByconfiscatedPeriod_PrevAndNext(
		long bilId, java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByconfiscatedPeriod_PrevAndNext(bilId,
			confiscatedPeriod, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where confiscatedPeriod = &#63; from the database.
	*
	* @param confiscatedPeriod the confiscated period
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByconfiscatedPeriod(
		java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByconfiscatedPeriod(confiscatedPeriod);
	}

	/**
	* Returns the number of sitaan admins where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByconfiscatedPeriod(
		java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByconfiscatedPeriod(confiscatedPeriod);
	}

	/**
	* Returns all the sitaan admins where source = &#63;.
	*
	* @param source the source
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysource(source);
	}

	/**
	* Returns a range of all the sitaan admins where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysource(source, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBysource(source, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBysource_First(source, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysource_First(source, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBysource_Last(source, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysource_Last(source, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBysource_PrevAndNext(
		long bilId, java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBysource_PrevAndNext(bilId, source, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where source = &#63; from the database.
	*
	* @param source the source
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBysource(source);
	}

	/**
	* Returns the number of sitaan admins where source = &#63;.
	*
	* @param source the source
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBysource(source);
	}

	/**
	* Returns all the sitaan admins where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByownerName(ownerName);
	}

	/**
	* Returns a range of all the sitaan admins where ownerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ownerName the owner name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByownerName(ownerName, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where ownerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ownerName the owner name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByownerName(ownerName, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByownerName_First(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByownerName_First(ownerName, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByownerName_First(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByownerName_First(ownerName, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByownerName_Last(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByownerName_Last(ownerName, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByownerName_Last(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByownerName_Last(ownerName, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByownerName_PrevAndNext(
		long bilId, java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByownerName_PrevAndNext(bilId, ownerName,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where ownerName = &#63; from the database.
	*
	* @param ownerName the owner name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByownerName(java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByownerName(ownerName);
	}

	/**
	* Returns the number of sitaan admins where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByownerName(java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByownerName(ownerName);
	}

	/**
	* Returns all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByvehicleRegistrationNo(vehicleRegistrationNo);
	}

	/**
	* Returns a range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByvehicleRegistrationNo(vehicleRegistrationNo, start,
			end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByvehicleRegistrationNo(vehicleRegistrationNo, start,
			end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByvehicleRegistrationNo_First(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByvehicleRegistrationNo_First(vehicleRegistrationNo,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByvehicleRegistrationNo_First(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByvehicleRegistrationNo_First(vehicleRegistrationNo,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByvehicleRegistrationNo_Last(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByvehicleRegistrationNo_Last(vehicleRegistrationNo,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByvehicleRegistrationNo_Last(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByvehicleRegistrationNo_Last(vehicleRegistrationNo,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByvehicleRegistrationNo_PrevAndNext(
		long bilId, java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByvehicleRegistrationNo_PrevAndNext(bilId,
			vehicleRegistrationNo, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where vehicleRegistrationNo = &#63; from the database.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByvehicleRegistrationNo(vehicleRegistrationNo);
	}

	/**
	* Returns the number of sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByvehicleRegistrationNo(vehicleRegistrationNo);
	}

	/**
	* Returns all the sitaan admins where territory = &#63;.
	*
	* @param territory the territory
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByterritory(territory);
	}

	/**
	* Returns a range of all the sitaan admins where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByterritory(territory, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByterritory(territory, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByterritory_First(territory, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByterritory_First(territory, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByterritory_Last(territory, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByterritory_Last(territory, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where territory = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByterritory_PrevAndNext(
		long bilId, java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByterritory_PrevAndNext(bilId, territory,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where territory = &#63; from the database.
	*
	* @param territory the territory
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByterritory(territory);
	}

	/**
	* Returns the number of sitaan admins where territory = &#63;.
	*
	* @param territory the territory
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByterritory(territory);
	}

	/**
	* Returns all the sitaan admins where state = &#63;.
	*
	* @param state the state
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state);
	}

	/**
	* Returns a range of all the sitaan admins where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBystate_First(state, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystate_First(state, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findBystate_Last(state, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystate_Last(state, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where state = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBystate_PrevAndNext(
		long bilId, java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBystate_PrevAndNext(bilId, state, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where state = &#63; from the database.
	*
	* @param state the state
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystate(state);
	}

	/**
	* Returns the number of sitaan admins where state = &#63;.
	*
	* @param state the state
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystate(state);
	}

	/**
	* Returns all the sitaan admins where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylocationCageSita(locationCageSita);
	}

	/**
	* Returns a range of all the sitaan admins where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylocationCageSita(locationCageSita, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylocationCageSita(locationCageSita, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBylocationCageSita_First(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylocationCageSita_First(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBylocationCageSita_Last(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylocationCageSita_Last(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBylocationCageSita_PrevAndNext(
		long bilId, java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBylocationCageSita_PrevAndNext(bilId, locationCageSita,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where locationCageSita = &#63; from the database.
	*
	* @param locationCageSita the location cage sita
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylocationCageSita(locationCageSita);
	}

	/**
	* Returns the number of sitaan admins where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylocationCageSita(java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylocationCageSita(locationCageSita);
	}

	/**
	* Returns all the sitaan admins where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns a range of all the sitaan admins where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByforeclosureStatus(foreclosureStatus, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByforeclosureStatus(foreclosureStatus, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByforeclosureStatus_First(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByforeclosureStatus_First(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByforeclosureStatus_Last(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByforeclosureStatus_Last(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByforeclosureStatus_PrevAndNext(
		long bilId, java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByforeclosureStatus_PrevAndNext(bilId,
			foreclosureStatus, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where foreclosureStatus = &#63; from the database.
	*
	* @param foreclosureStatus the foreclosure status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns the number of sitaan admins where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns all the sitaan admins where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByresultsforeclosure(resultsforeclosure);
	}

	/**
	* Returns a range of all the sitaan admins where resultsforeclosure = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByresultsforeclosure(resultsforeclosure, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where resultsforeclosure = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByresultsforeclosure(resultsforeclosure, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByresultsforeclosure_First(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByresultsforeclosure_First(resultsforeclosure,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByresultsforeclosure_First(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByresultsforeclosure_First(resultsforeclosure,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByresultsforeclosure_Last(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByresultsforeclosure_Last(resultsforeclosure,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByresultsforeclosure_Last(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByresultsforeclosure_Last(resultsforeclosure,
			orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByresultsforeclosure_PrevAndNext(
		long bilId, java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByresultsforeclosure_PrevAndNext(bilId,
			resultsforeclosure, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where resultsforeclosure = &#63; from the database.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByresultsforeclosure(
		java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByresultsforeclosure(resultsforeclosure);
	}

	/**
	* Returns the number of sitaan admins where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByresultsforeclosure(
		java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByresultsforeclosure(resultsforeclosure);
	}

	/**
	* Returns all the sitaan admins where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBypaymentStatus(paymentStatus);
	}

	/**
	* Returns a range of all the sitaan admins where paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBypaymentStatus(paymentStatus, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBypaymentStatus(paymentStatus, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBypaymentStatus_First(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBypaymentStatus_First(paymentStatus, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBypaymentStatus_First(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBypaymentStatus_First(paymentStatus, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findBypaymentStatus_Last(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBypaymentStatus_Last(paymentStatus, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchBypaymentStatus_Last(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBypaymentStatus_Last(paymentStatus, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findBypaymentStatus_PrevAndNext(
		long bilId, boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findBypaymentStatus_PrevAndNext(bilId, paymentStatus,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where paymentStatus = &#63; from the database.
	*
	* @param paymentStatus the payment status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBypaymentStatus(boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBypaymentStatus(paymentStatus);
	}

	/**
	* Returns the number of sitaan admins where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countBypaymentStatus(boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBypaymentStatus(paymentStatus);
	}

	/**
	* Returns all the sitaan admins where officerName = &#63;.
	*
	* @param officerName the officer name
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByofficerName(officerName);
	}

	/**
	* Returns a range of all the sitaan admins where officerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerName the officer name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByofficerName(officerName, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where officerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerName the officer name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByofficerName(officerName, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByofficerName_First(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByofficerName_First(officerName, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByofficerName_First(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByofficerName_First(officerName, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByofficerName_Last(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByofficerName_Last(officerName, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByofficerName_Last(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByofficerName_Last(officerName, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByofficerName_PrevAndNext(
		long bilId, java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByofficerName_PrevAndNext(bilId, officerName,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where officerName = &#63; from the database.
	*
	* @param officerName the officer name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByofficerName(java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByofficerName(officerName);
	}

	/**
	* Returns the number of sitaan admins where officerName = &#63;.
	*
	* @param officerName the officer name
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByofficerName(java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByofficerName(officerName);
	}

	/**
	* Returns all the sitaan admins where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrightsReleased(rightsReleased);
	}

	/**
	* Returns a range of all the sitaan admins where rightsReleased = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param rightsReleased the rights released
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrightsReleased(rightsReleased, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where rightsReleased = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param rightsReleased the rights released
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByrightsReleased(rightsReleased, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByrightsReleased_First(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByrightsReleased_First(rightsReleased, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByrightsReleased_First(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrightsReleased_First(rightsReleased,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByrightsReleased_Last(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByrightsReleased_Last(rightsReleased, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByrightsReleased_Last(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrightsReleased_Last(rightsReleased, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByrightsReleased_PrevAndNext(
		long bilId, java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByrightsReleased_PrevAndNext(bilId, rightsReleased,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where rightsReleased = &#63; from the database.
	*
	* @param rightsReleased the rights released
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByrightsReleased(java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByrightsReleased(rightsReleased);
	}

	/**
	* Returns the number of sitaan admins where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByrightsReleased(java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByrightsReleased(rightsReleased);
	}

	/**
	* Returns all the sitaan admins where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByacceptancedate(acceptancedate);
	}

	/**
	* Returns a range of all the sitaan admins where acceptancedate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param acceptancedate the acceptancedate
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByacceptancedate(acceptancedate, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where acceptancedate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param acceptancedate the acceptancedate
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByacceptancedate(acceptancedate, start, end,
			orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByacceptancedate_First(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByacceptancedate_First(acceptancedate, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByacceptancedate_First(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByacceptancedate_First(acceptancedate,
			orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByacceptancedate_Last(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByacceptancedate_Last(acceptancedate, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByacceptancedate_Last(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByacceptancedate_Last(acceptancedate, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByacceptancedate_PrevAndNext(
		long bilId, java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByacceptancedate_PrevAndNext(bilId, acceptancedate,
			orderByComparator);
	}

	/**
	* Removes all the sitaan admins where acceptancedate = &#63; from the database.
	*
	* @param acceptancedate the acceptancedate
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByacceptancedate(java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByacceptancedate(acceptancedate);
	}

	/**
	* Returns the number of sitaan admins where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByacceptancedate(java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByacceptancedate(acceptancedate);
	}

	/**
	* Returns all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus);
	}

	/**
	* Returns a range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, start, end, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByFinedByColumn_First(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByFinedByColumn_First(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, orderByComparator);
	}

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByFinedByColumn_First(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByFinedByColumn_First(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByFinedByColumn_Last(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByFinedByColumn_Last(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, orderByComparator);
	}

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByFinedByColumn_Last(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByFinedByColumn_Last(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, orderByComparator);
	}

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin[] findByFinedByColumn_PrevAndNext(
		long bilId, java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence()
				   .findByFinedByColumn_PrevAndNext(bilId, source, ownerName,
			territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, orderByComparator);
	}

	/**
	* Removes all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63; from the database.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByFinedByColumn(java.lang.String source,
		java.lang.String ownerName, java.lang.String territory,
		java.lang.String vehicleRegistrationNo, java.lang.String dateSeized,
		java.lang.String checkSitesSita, java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence()
			.removeByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus);
	}

	/**
	* Returns the number of sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countByFinedByColumn(java.lang.String source,
		java.lang.String ownerName, java.lang.String territory,
		java.lang.String vehicleRegistrationNo, java.lang.String dateSeized,
		java.lang.String checkSitesSita, java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus);
	}

	/**
	* Caches the sitaan admin in the entity cache if it is enabled.
	*
	* @param sitaanAdmin the sitaan admin
	*/
	public static void cacheResult(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin) {
		getPersistence().cacheResult(sitaanAdmin);
	}

	/**
	* Caches the sitaan admins in the entity cache if it is enabled.
	*
	* @param sitaanAdmins the sitaan admins
	*/
	public static void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> sitaanAdmins) {
		getPersistence().cacheResult(sitaanAdmins);
	}

	/**
	* Creates a new sitaan admin with the primary key. Does not add the sitaan admin to the database.
	*
	* @param bilId the primary key for the new sitaan admin
	* @return the new sitaan admin
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin create(long bilId) {
		return getPersistence().create(bilId);
	}

	/**
	* Removes the sitaan admin with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin remove(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().remove(bilId);
	}

	public static com.org.skali.sitanAdmin.model.SitaanAdmin updateImpl(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(sitaanAdmin);
	}

	/**
	* Returns the sitaan admin with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchSitaanAdminException} if it could not be found.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin findByPrimaryKey(
		long bilId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException {
		return getPersistence().findByPrimaryKey(bilId);
	}

	/**
	* Returns the sitaan admin with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin, or <code>null</code> if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.SitaanAdmin fetchByPrimaryKey(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(bilId);
	}

	/**
	* Returns all the sitaan admins.
	*
	* @return the sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the sitaan admins.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the sitaan admins.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the sitaan admins from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of sitaan admins.
	*
	* @return the number of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static SitaanAdminPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (SitaanAdminPersistence)PortletBeanLocatorUtil.locate(com.org.skali.sitanAdmin.service.ClpSerializer.getServletContextName(),
					SitaanAdminPersistence.class.getName());

			ReferenceRegistry.registerReference(SitaanAdminUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(SitaanAdminPersistence persistence) {
	}

	private static SitaanAdminPersistence _persistence;
}