/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ErrortypesSourceLocalService}.
 *
 * @author reeshu
 * @see ErrortypesSourceLocalService
 * @generated
 */
public class ErrortypesSourceLocalServiceWrapper
	implements ErrortypesSourceLocalService,
		ServiceWrapper<ErrortypesSourceLocalService> {
	public ErrortypesSourceLocalServiceWrapper(
		ErrortypesSourceLocalService errortypesSourceLocalService) {
		_errortypesSourceLocalService = errortypesSourceLocalService;
	}

	/**
	* Adds the errortypes source to the database. Also notifies the appropriate model listeners.
	*
	* @param errortypesSource the errortypes source
	* @return the errortypes source that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource addErrortypesSource(
		com.org.skali.sitanAdmin.model.ErrortypesSource errortypesSource)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.addErrortypesSource(errortypesSource);
	}

	/**
	* Creates a new errortypes source with the primary key. Does not add the errortypes source to the database.
	*
	* @param errortypeid the primary key for the new errortypes source
	* @return the new errortypes source
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource createErrortypesSource(
		long errortypeid) {
		return _errortypesSourceLocalService.createErrortypesSource(errortypeid);
	}

	/**
	* Deletes the errortypes source with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param errortypeid the primary key of the errortypes source
	* @return the errortypes source that was removed
	* @throws PortalException if a errortypes source with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource deleteErrortypesSource(
		long errortypeid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.deleteErrortypesSource(errortypeid);
	}

	/**
	* Deletes the errortypes source from the database. Also notifies the appropriate model listeners.
	*
	* @param errortypesSource the errortypes source
	* @return the errortypes source that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource deleteErrortypesSource(
		com.org.skali.sitanAdmin.model.ErrortypesSource errortypesSource)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.deleteErrortypesSource(errortypesSource);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _errortypesSourceLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesSourceModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.dynamicQuery(dynamicQuery, start,
			end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesSourceModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.dynamicQuery(dynamicQuery, start,
			end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource fetchErrortypesSource(
		long errortypeid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.fetchErrortypesSource(errortypeid);
	}

	/**
	* Returns the errortypes source with the primary key.
	*
	* @param errortypeid the primary key of the errortypes source
	* @return the errortypes source
	* @throws PortalException if a errortypes source with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource getErrortypesSource(
		long errortypeid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.getErrortypesSource(errortypeid);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the errortypes sources.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesSourceModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of errortypes sources
	* @param end the upper bound of the range of errortypes sources (not inclusive)
	* @return the range of errortypes sources
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.ErrortypesSource> getErrortypesSources(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.getErrortypesSources(start, end);
	}

	/**
	* Returns the number of errortypes sources.
	*
	* @return the number of errortypes sources
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getErrortypesSourcesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.getErrortypesSourcesCount();
	}

	/**
	* Updates the errortypes source in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param errortypesSource the errortypes source
	* @return the errortypes source that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.ErrortypesSource updateErrortypesSource(
		com.org.skali.sitanAdmin.model.ErrortypesSource errortypesSource)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _errortypesSourceLocalService.updateErrortypesSource(errortypesSource);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _errortypesSourceLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_errortypesSourceLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _errortypesSourceLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public ErrortypesSourceLocalService getWrappedErrortypesSourceLocalService() {
		return _errortypesSourceLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedErrortypesSourceLocalService(
		ErrortypesSourceLocalService errortypesSourceLocalService) {
		_errortypesSourceLocalService = errortypesSourceLocalService;
	}

	@Override
	public ErrortypesSourceLocalService getWrappedService() {
		return _errortypesSourceLocalService;
	}

	@Override
	public void setWrappedService(
		ErrortypesSourceLocalService errortypesSourceLocalService) {
		_errortypesSourceLocalService = errortypesSourceLocalService;
	}

	private ErrortypesSourceLocalService _errortypesSourceLocalService;
}