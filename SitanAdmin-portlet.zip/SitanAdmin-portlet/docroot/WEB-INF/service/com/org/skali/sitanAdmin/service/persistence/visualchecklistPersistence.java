/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.org.skali.sitanAdmin.model.visualchecklist;

/**
 * The persistence interface for the visualchecklist service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see visualchecklistPersistenceImpl
 * @see visualchecklistUtil
 * @generated
 */
public interface visualchecklistPersistence extends BasePersistence<visualchecklist> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link visualchecklistUtil} to access the visualchecklist persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the visualchecklists where checkId = &#63;.
	*
	* @param checkId the check ID
	* @return the matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBycheckId(
		long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the visualchecklists where checkId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkId the check ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @return the range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBycheckId(
		long checkId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the visualchecklists where checkId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkId the check ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBycheckId(
		long checkId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first visualchecklist in the ordered set where checkId = &#63;.
	*
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findBycheckId_First(
		long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the first visualchecklist in the ordered set where checkId = &#63;.
	*
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchBycheckId_First(
		long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last visualchecklist in the ordered set where checkId = &#63;.
	*
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findBycheckId_Last(
		long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the last visualchecklist in the ordered set where checkId = &#63;.
	*
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchBycheckId_Last(
		long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the visualchecklists where checkId = &#63; from the database.
	*
	* @param checkId the check ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycheckId(long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of visualchecklists where checkId = &#63;.
	*
	* @param checkId the check ID
	* @return the number of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public int countBycheckId(long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the visualchecklists where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the visualchecklists where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @return the range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the visualchecklists where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first visualchecklist in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the first visualchecklist in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last visualchecklist in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the last visualchecklist in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the visualchecklists before and after the current visualchecklist in the ordered set where bilId = &#63;.
	*
	* @param checkId the primary key of the current visualchecklist
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist[] findBybilId_PrevAndNext(
		long checkId, long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Removes all the visualchecklists where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of visualchecklists where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the visualchecklists where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @return the matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findByBillChek(
		long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the visualchecklists where bilId = &#63; and checkId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @return the range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findByBillChek(
		long bilId, long checkId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the visualchecklists where bilId = &#63; and checkId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findByBillChek(
		long bilId, long checkId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findByBillChek_First(
		long bilId, long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the first visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchByBillChek_First(
		long bilId, long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findByBillChek_Last(
		long bilId, long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the last visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchByBillChek_Last(
		long bilId, long checkId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the visualchecklists where bilId = &#63; and checkId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByBillChek(long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of visualchecklists where bilId = &#63; and checkId = &#63;.
	*
	* @param bilId the bil ID
	* @param checkId the check ID
	* @return the number of matching visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public int countByBillChek(long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the visualchecklist in the entity cache if it is enabled.
	*
	* @param visualchecklist the visualchecklist
	*/
	public void cacheResult(
		com.org.skali.sitanAdmin.model.visualchecklist visualchecklist);

	/**
	* Caches the visualchecklists in the entity cache if it is enabled.
	*
	* @param visualchecklists the visualchecklists
	*/
	public void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> visualchecklists);

	/**
	* Creates a new visualchecklist with the primary key. Does not add the visualchecklist to the database.
	*
	* @param checkId the primary key for the new visualchecklist
	* @return the new visualchecklist
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist create(long checkId);

	/**
	* Removes the visualchecklist with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param checkId the primary key of the visualchecklist
	* @return the visualchecklist that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist remove(long checkId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	public com.org.skali.sitanAdmin.model.visualchecklist updateImpl(
		com.org.skali.sitanAdmin.model.visualchecklist visualchecklist)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the visualchecklist with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchvisualchecklistException} if it could not be found.
	*
	* @param checkId the primary key of the visualchecklist
	* @return the visualchecklist
	* @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist findByPrimaryKey(
		long checkId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvisualchecklistException;

	/**
	* Returns the visualchecklist with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param checkId the primary key of the visualchecklist
	* @return the visualchecklist, or <code>null</code> if a visualchecklist with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.visualchecklist fetchByPrimaryKey(
		long checkId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the visualchecklists.
	*
	* @return the visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the visualchecklists.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @return the range of visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the visualchecklists.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of visualchecklists
	* @param end the upper bound of the range of visualchecklists (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.visualchecklist> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the visualchecklists from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of visualchecklists.
	*
	* @return the number of visualchecklists
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}