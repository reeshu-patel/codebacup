/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.LicensesStatusServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.LicensesStatusServiceSoap
 * @generated
 */
public class LicensesStatusSoap implements Serializable {
	public static LicensesStatusSoap toSoapModel(LicensesStatus model) {
		LicensesStatusSoap soapModel = new LicensesStatusSoap();

		soapModel.setLicensesstatusid(model.getLicensesstatusid());
		soapModel.setBilId(model.getBilId());
		soapModel.setActive(model.getActive());
		soapModel.setNoActive(model.getNoActive());
		soapModel.setMoreoverHadAge(model.getMoreoverHadAge());
		soapModel.setFinishedWithin(model.getFinishedWithin());

		return soapModel;
	}

	public static LicensesStatusSoap[] toSoapModels(LicensesStatus[] models) {
		LicensesStatusSoap[] soapModels = new LicensesStatusSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LicensesStatusSoap[][] toSoapModels(LicensesStatus[][] models) {
		LicensesStatusSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LicensesStatusSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LicensesStatusSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LicensesStatusSoap[] toSoapModels(List<LicensesStatus> models) {
		List<LicensesStatusSoap> soapModels = new ArrayList<LicensesStatusSoap>(models.size());

		for (LicensesStatus model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LicensesStatusSoap[soapModels.size()]);
	}

	public LicensesStatusSoap() {
	}

	public long getPrimaryKey() {
		return _licensesstatusid;
	}

	public void setPrimaryKey(long pk) {
		setLicensesstatusid(pk);
	}

	public long getLicensesstatusid() {
		return _licensesstatusid;
	}

	public void setLicensesstatusid(long licensesstatusid) {
		_licensesstatusid = licensesstatusid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getActive() {
		return _active;
	}

	public void setActive(String active) {
		_active = active;
	}

	public String getNoActive() {
		return _noActive;
	}

	public void setNoActive(String noActive) {
		_noActive = noActive;
	}

	public String getMoreoverHadAge() {
		return _moreoverHadAge;
	}

	public void setMoreoverHadAge(String moreoverHadAge) {
		_moreoverHadAge = moreoverHadAge;
	}

	public String getFinishedWithin() {
		return _finishedWithin;
	}

	public void setFinishedWithin(String finishedWithin) {
		_finishedWithin = finishedWithin;
	}

	private long _licensesstatusid;
	private long _bilId;
	private String _active;
	private String _noActive;
	private String _moreoverHadAge;
	private String _finishedWithin;
}