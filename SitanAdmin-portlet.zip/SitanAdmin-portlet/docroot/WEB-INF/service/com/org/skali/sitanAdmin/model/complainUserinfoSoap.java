/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.complainUserinfoServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.complainUserinfoServiceSoap
 * @generated
 */
public class complainUserinfoSoap implements Serializable {
	public static complainUserinfoSoap toSoapModel(complainUserinfo model) {
		complainUserinfoSoap soapModel = new complainUserinfoSoap();

		soapModel.setComplainUserId(model.getComplainUserId());
		soapModel.setBilId(model.getBilId());
		soapModel.setPrefix(model.getPrefix());
		soapModel.setName(model.getName());
		soapModel.setIdentificationnumber(model.getIdentificationnumber());
		soapModel.setPassport(model.getPassport());
		soapModel.setCitizen(model.getCitizen());
		soapModel.setNation(model.getNation());
		soapModel.setGender(model.getGender());
		soapModel.setAge(model.getAge());
		soapModel.setPhoneNo(model.getPhoneNo());
		soapModel.setCellPhones(model.getCellPhones());
		soapModel.setAddress(model.getAddress());
		soapModel.setEmail(model.getEmail());
		soapModel.setState(model.getState());
		soapModel.setDName(model.getDName());
		soapModel.setDidentificationnumber(model.getDidentificationnumber());
		soapModel.setDateofbirth(model.getDateofbirth());
		soapModel.setDcitizen(model.getDcitizen());
		soapModel.setDriverNation(model.getDriverNation());
		soapModel.setDrivergender(model.getDrivergender());
		soapModel.setDriverAge(model.getDriverAge());
		soapModel.setRetirees(model.getRetirees());
		soapModel.setStatusReadPSV(model.getStatusReadPSV());
		soapModel.setDriverLicense(model.getDriverLicense());
		soapModel.setDphone(model.getDphone());
		soapModel.setDphoneTwo(model.getDphoneTwo());
		soapModel.setDaddress(model.getDaddress());

		return soapModel;
	}

	public static complainUserinfoSoap[] toSoapModels(complainUserinfo[] models) {
		complainUserinfoSoap[] soapModels = new complainUserinfoSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static complainUserinfoSoap[][] toSoapModels(
		complainUserinfo[][] models) {
		complainUserinfoSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new complainUserinfoSoap[models.length][models[0].length];
		}
		else {
			soapModels = new complainUserinfoSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static complainUserinfoSoap[] toSoapModels(
		List<complainUserinfo> models) {
		List<complainUserinfoSoap> soapModels = new ArrayList<complainUserinfoSoap>(models.size());

		for (complainUserinfo model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new complainUserinfoSoap[soapModels.size()]);
	}

	public complainUserinfoSoap() {
	}

	public long getPrimaryKey() {
		return _complainUserId;
	}

	public void setPrimaryKey(long pk) {
		setComplainUserId(pk);
	}

	public long getComplainUserId() {
		return _complainUserId;
	}

	public void setComplainUserId(long complainUserId) {
		_complainUserId = complainUserId;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getPrefix() {
		return _prefix;
	}

	public void setPrefix(String prefix) {
		_prefix = prefix;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public String getIdentificationnumber() {
		return _identificationnumber;
	}

	public void setIdentificationnumber(String identificationnumber) {
		_identificationnumber = identificationnumber;
	}

	public String getPassport() {
		return _passport;
	}

	public void setPassport(String passport) {
		_passport = passport;
	}

	public String getCitizen() {
		return _citizen;
	}

	public void setCitizen(String citizen) {
		_citizen = citizen;
	}

	public String getNation() {
		return _nation;
	}

	public void setNation(String nation) {
		_nation = nation;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public long getAge() {
		return _age;
	}

	public void setAge(long age) {
		_age = age;
	}

	public String getPhoneNo() {
		return _phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		_phoneNo = phoneNo;
	}

	public String getCellPhones() {
		return _cellPhones;
	}

	public void setCellPhones(String cellPhones) {
		_cellPhones = cellPhones;
	}

	public String getAddress() {
		return _address;
	}

	public void setAddress(String address) {
		_address = address;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getState() {
		return _state;
	}

	public void setState(String state) {
		_state = state;
	}

	public String getDName() {
		return _dName;
	}

	public void setDName(String dName) {
		_dName = dName;
	}

	public String getDidentificationnumber() {
		return _didentificationnumber;
	}

	public void setDidentificationnumber(String didentificationnumber) {
		_didentificationnumber = didentificationnumber;
	}

	public String getDateofbirth() {
		return _dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		_dateofbirth = dateofbirth;
	}

	public String getDcitizen() {
		return _dcitizen;
	}

	public void setDcitizen(String dcitizen) {
		_dcitizen = dcitizen;
	}

	public String getDriverNation() {
		return _driverNation;
	}

	public void setDriverNation(String driverNation) {
		_driverNation = driverNation;
	}

	public String getDrivergender() {
		return _drivergender;
	}

	public void setDrivergender(String drivergender) {
		_drivergender = drivergender;
	}

	public long getDriverAge() {
		return _driverAge;
	}

	public void setDriverAge(long driverAge) {
		_driverAge = driverAge;
	}

	public String getRetirees() {
		return _retirees;
	}

	public void setRetirees(String retirees) {
		_retirees = retirees;
	}

	public long getStatusReadPSV() {
		return _statusReadPSV;
	}

	public void setStatusReadPSV(long statusReadPSV) {
		_statusReadPSV = statusReadPSV;
	}

	public String getDriverLicense() {
		return _driverLicense;
	}

	public void setDriverLicense(String driverLicense) {
		_driverLicense = driverLicense;
	}

	public String getDphone() {
		return _dphone;
	}

	public void setDphone(String dphone) {
		_dphone = dphone;
	}

	public String getDphoneTwo() {
		return _dphoneTwo;
	}

	public void setDphoneTwo(String dphoneTwo) {
		_dphoneTwo = dphoneTwo;
	}

	public String getDaddress() {
		return _daddress;
	}

	public void setDaddress(String daddress) {
		_daddress = daddress;
	}

	private long _complainUserId;
	private long _bilId;
	private String _prefix;
	private String _name;
	private String _identificationnumber;
	private String _passport;
	private String _citizen;
	private String _nation;
	private String _gender;
	private long _age;
	private String _phoneNo;
	private String _cellPhones;
	private String _address;
	private String _email;
	private String _state;
	private String _dName;
	private String _didentificationnumber;
	private String _dateofbirth;
	private String _dcitizen;
	private String _driverNation;
	private String _drivergender;
	private long _driverAge;
	private String _retirees;
	private long _statusReadPSV;
	private String _driverLicense;
	private String _dphone;
	private String _dphoneTwo;
	private String _daddress;
}