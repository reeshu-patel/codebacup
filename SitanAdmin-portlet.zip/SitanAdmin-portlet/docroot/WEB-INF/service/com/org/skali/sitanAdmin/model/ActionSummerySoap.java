/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.ActionSummeryServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.ActionSummeryServiceSoap
 * @generated
 */
public class ActionSummerySoap implements Serializable {
	public static ActionSummerySoap toSoapModel(ActionSummery model) {
		ActionSummerySoap soapModel = new ActionSummerySoap();

		soapModel.setActionsummeryid(model.getActionsummeryid());
		soapModel.setBilId(model.getBilId());
		soapModel.setDateTime(model.getDateTime());
		soapModel.setStatus(model.getStatus());
		soapModel.setAction(model.getAction());
		soapModel.setActionBy(model.getActionBy());

		return soapModel;
	}

	public static ActionSummerySoap[] toSoapModels(ActionSummery[] models) {
		ActionSummerySoap[] soapModels = new ActionSummerySoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ActionSummerySoap[][] toSoapModels(ActionSummery[][] models) {
		ActionSummerySoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ActionSummerySoap[models.length][models[0].length];
		}
		else {
			soapModels = new ActionSummerySoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ActionSummerySoap[] toSoapModels(List<ActionSummery> models) {
		List<ActionSummerySoap> soapModels = new ArrayList<ActionSummerySoap>(models.size());

		for (ActionSummery model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ActionSummerySoap[soapModels.size()]);
	}

	public ActionSummerySoap() {
	}

	public long getPrimaryKey() {
		return _actionsummeryid;
	}

	public void setPrimaryKey(long pk) {
		setActionsummeryid(pk);
	}

	public long getActionsummeryid() {
		return _actionsummeryid;
	}

	public void setActionsummeryid(long actionsummeryid) {
		_actionsummeryid = actionsummeryid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getDateTime() {
		return _dateTime;
	}

	public void setDateTime(String dateTime) {
		_dateTime = dateTime;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public String getAction() {
		return _action;
	}

	public void setAction(String action) {
		_action = action;
	}

	public String getActionBy() {
		return _actionBy;
	}

	public void setActionBy(String actionBy) {
		_actionBy = actionBy;
	}

	private long _actionsummeryid;
	private long _bilId;
	private String _dateTime;
	private String _status;
	private String _action;
	private String _actionBy;
}