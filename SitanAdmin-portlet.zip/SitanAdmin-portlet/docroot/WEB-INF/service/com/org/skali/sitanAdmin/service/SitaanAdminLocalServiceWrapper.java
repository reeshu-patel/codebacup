/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link SitaanAdminLocalService}.
 *
 * @author reeshu
 * @see SitaanAdminLocalService
 * @generated
 */
public class SitaanAdminLocalServiceWrapper implements SitaanAdminLocalService,
	ServiceWrapper<SitaanAdminLocalService> {
	public SitaanAdminLocalServiceWrapper(
		SitaanAdminLocalService sitaanAdminLocalService) {
		_sitaanAdminLocalService = sitaanAdminLocalService;
	}

	/**
	* Adds the sitaan admin to the database. Also notifies the appropriate model listeners.
	*
	* @param sitaanAdmin the sitaan admin
	* @return the sitaan admin that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin addSitaanAdmin(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.addSitaanAdmin(sitaanAdmin);
	}

	/**
	* Creates a new sitaan admin with the primary key. Does not add the sitaan admin to the database.
	*
	* @param bilId the primary key for the new sitaan admin
	* @return the new sitaan admin
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin createSitaanAdmin(
		long bilId) {
		return _sitaanAdminLocalService.createSitaanAdmin(bilId);
	}

	/**
	* Deletes the sitaan admin with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin that was removed
	* @throws PortalException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin deleteSitaanAdmin(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.deleteSitaanAdmin(bilId);
	}

	/**
	* Deletes the sitaan admin from the database. Also notifies the appropriate model listeners.
	*
	* @param sitaanAdmin the sitaan admin
	* @return the sitaan admin that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin deleteSitaanAdmin(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.deleteSitaanAdmin(sitaanAdmin);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _sitaanAdminLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchSitaanAdmin(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.fetchSitaanAdmin(bilId);
	}

	/**
	* Returns the sitaan admin with the primary key.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin
	* @throws PortalException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin getSitaanAdmin(long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getSitaanAdmin(bilId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the sitaan admins.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getSitaanAdmins(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getSitaanAdmins(start, end);
	}

	/**
	* Returns the number of sitaan admins.
	*
	* @return the number of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getSitaanAdminsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getSitaanAdminsCount();
	}

	/**
	* Updates the sitaan admin in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param sitaanAdmin the sitaan admin
	* @return the sitaan admin that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.org.skali.sitanAdmin.model.SitaanAdmin updateSitaanAdmin(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.updateSitaanAdmin(sitaanAdmin);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _sitaanAdminLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_sitaanAdminLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _sitaanAdminLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByBilId(
		long billid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByBilId(billid);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByDateSeized(
		java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByDateSeized(dateSeized);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByCheckSitesSita(
		java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByCheckSitesSita(checkSitesSita);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByReferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByReferenceEffective(referenceEffective);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByConfiscatedPeriod(
		java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByConfiscatedPeriod(confiscatedPeriod);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsBySource(
		java.lang.String source)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsBySource(source);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByOwnerName(
		java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByOwnerName(ownerName);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByVehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByVehicleRegistrationNo(vehicleRegistrationNo);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByTerritory(
		java.lang.String territory)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByTerritory(territory);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByState(
		java.lang.String state)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByState(state);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByLocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByLocationCageSita(locationCageSita);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByForeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByForeclosureStatus(foreclosureStatus);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByResultsforeclosure(
		java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByResultsforeclosure(resultsforeclosure);
	}

	@Override
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> getsByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminLocalService.getsByFinedByColumn(source, ownerName,
			territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public SitaanAdminLocalService getWrappedSitaanAdminLocalService() {
		return _sitaanAdminLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedSitaanAdminLocalService(
		SitaanAdminLocalService sitaanAdminLocalService) {
		_sitaanAdminLocalService = sitaanAdminLocalService;
	}

	@Override
	public SitaanAdminLocalService getWrappedService() {
		return _sitaanAdminLocalService;
	}

	@Override
	public void setWrappedService(
		SitaanAdminLocalService sitaanAdminLocalService) {
		_sitaanAdminLocalService = sitaanAdminLocalService;
	}

	private SitaanAdminLocalService _sitaanAdminLocalService;
}