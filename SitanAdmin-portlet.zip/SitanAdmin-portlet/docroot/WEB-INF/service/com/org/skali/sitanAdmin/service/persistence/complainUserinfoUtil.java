/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.org.skali.sitanAdmin.model.complainUserinfo;

import java.util.List;

/**
 * The persistence utility for the complain userinfo service. This utility wraps {@link complainUserinfoPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see complainUserinfoPersistence
 * @see complainUserinfoPersistenceImpl
 * @generated
 */
public class complainUserinfoUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(complainUserinfo complainUserinfo) {
		getPersistence().clearCache(complainUserinfo);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<complainUserinfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<complainUserinfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<complainUserinfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static complainUserinfo update(complainUserinfo complainUserinfo)
		throws SystemException {
		return getPersistence().update(complainUserinfo);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static complainUserinfo update(complainUserinfo complainUserinfo,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(complainUserinfo, serviceContext);
	}

	/**
	* Returns all the complain userinfos where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId);
	}

	/**
	* Returns a range of all the complain userinfos where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of complain userinfos
	* @param end the upper bound of the range of complain userinfos (not inclusive)
	* @return the range of matching complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end);
	}

	/**
	* Returns an ordered range of all the complain userinfos where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of complain userinfos
	* @param end the upper bound of the range of complain userinfos (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end, orderByComparator);
	}

	/**
	* Returns the first complain userinfo in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain userinfo
	* @throws com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException if a matching complain userinfo could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException {
		return getPersistence().findBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the first complain userinfo in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching complain userinfo, or <code>null</code> if a matching complain userinfo could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the last complain userinfo in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain userinfo
	* @throws com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException if a matching complain userinfo could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException {
		return getPersistence().findBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Returns the last complain userinfo in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching complain userinfo, or <code>null</code> if a matching complain userinfo could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Returns the complain userinfos before and after the current complain userinfo in the ordered set where bilId = &#63;.
	*
	* @param complainUserId the primary key of the current complain userinfo
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next complain userinfo
	* @throws com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo[] findBybilId_PrevAndNext(
		long complainUserId, long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException {
		return getPersistence()
				   .findBybilId_PrevAndNext(complainUserId, bilId,
			orderByComparator);
	}

	/**
	* Removes all the complain userinfos where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBybilId(bilId);
	}

	/**
	* Returns the number of complain userinfos where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBybilId(bilId);
	}

	/**
	* Caches the complain userinfo in the entity cache if it is enabled.
	*
	* @param complainUserinfo the complain userinfo
	*/
	public static void cacheResult(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo) {
		getPersistence().cacheResult(complainUserinfo);
	}

	/**
	* Caches the complain userinfos in the entity cache if it is enabled.
	*
	* @param complainUserinfos the complain userinfos
	*/
	public static void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> complainUserinfos) {
		getPersistence().cacheResult(complainUserinfos);
	}

	/**
	* Creates a new complain userinfo with the primary key. Does not add the complain userinfo to the database.
	*
	* @param complainUserId the primary key for the new complain userinfo
	* @return the new complain userinfo
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo create(
		long complainUserId) {
		return getPersistence().create(complainUserId);
	}

	/**
	* Removes the complain userinfo with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param complainUserId the primary key of the complain userinfo
	* @return the complain userinfo that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo remove(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException {
		return getPersistence().remove(complainUserId);
	}

	public static com.org.skali.sitanAdmin.model.complainUserinfo updateImpl(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(complainUserinfo);
	}

	/**
	* Returns the complain userinfo with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException} if it could not be found.
	*
	* @param complainUserId the primary key of the complain userinfo
	* @return the complain userinfo
	* @throws com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo findByPrimaryKey(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException {
		return getPersistence().findByPrimaryKey(complainUserId);
	}

	/**
	* Returns the complain userinfo with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param complainUserId the primary key of the complain userinfo
	* @return the complain userinfo, or <code>null</code> if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo fetchByPrimaryKey(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(complainUserId);
	}

	/**
	* Returns all the complain userinfos.
	*
	* @return the complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the complain userinfos.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of complain userinfos
	* @param end the upper bound of the range of complain userinfos (not inclusive)
	* @return the range of complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the complain userinfos.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of complain userinfos
	* @param end the upper bound of the range of complain userinfos (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the complain userinfos from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of complain userinfos.
	*
	* @return the number of complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static complainUserinfoPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (complainUserinfoPersistence)PortletBeanLocatorUtil.locate(com.org.skali.sitanAdmin.service.ClpSerializer.getServletContextName(),
					complainUserinfoPersistence.class.getName());

			ReferenceRegistry.registerReference(complainUserinfoUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(complainUserinfoPersistence persistence) {
	}

	private static complainUserinfoPersistence _persistence;
}