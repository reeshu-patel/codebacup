/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link complainUserinfo}.
 * </p>
 *
 * @author reeshu
 * @see complainUserinfo
 * @generated
 */
public class complainUserinfoWrapper implements complainUserinfo,
	ModelWrapper<complainUserinfo> {
	public complainUserinfoWrapper(complainUserinfo complainUserinfo) {
		_complainUserinfo = complainUserinfo;
	}

	@Override
	public Class<?> getModelClass() {
		return complainUserinfo.class;
	}

	@Override
	public String getModelClassName() {
		return complainUserinfo.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("complainUserId", getComplainUserId());
		attributes.put("bilId", getBilId());
		attributes.put("prefix", getPrefix());
		attributes.put("name", getName());
		attributes.put("identificationnumber", getIdentificationnumber());
		attributes.put("passport", getPassport());
		attributes.put("citizen", getCitizen());
		attributes.put("nation", getNation());
		attributes.put("gender", getGender());
		attributes.put("age", getAge());
		attributes.put("phoneNo", getPhoneNo());
		attributes.put("cellPhones", getCellPhones());
		attributes.put("address", getAddress());
		attributes.put("email", getEmail());
		attributes.put("state", getState());
		attributes.put("dName", getDName());
		attributes.put("didentificationnumber", getDidentificationnumber());
		attributes.put("dateofbirth", getDateofbirth());
		attributes.put("dcitizen", getDcitizen());
		attributes.put("driverNation", getDriverNation());
		attributes.put("drivergender", getDrivergender());
		attributes.put("driverAge", getDriverAge());
		attributes.put("retirees", getRetirees());
		attributes.put("statusReadPSV", getStatusReadPSV());
		attributes.put("driverLicense", getDriverLicense());
		attributes.put("dphone", getDphone());
		attributes.put("dphoneTwo", getDphoneTwo());
		attributes.put("daddress", getDaddress());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long complainUserId = (Long)attributes.get("complainUserId");

		if (complainUserId != null) {
			setComplainUserId(complainUserId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String prefix = (String)attributes.get("prefix");

		if (prefix != null) {
			setPrefix(prefix);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String identificationnumber = (String)attributes.get(
				"identificationnumber");

		if (identificationnumber != null) {
			setIdentificationnumber(identificationnumber);
		}

		String passport = (String)attributes.get("passport");

		if (passport != null) {
			setPassport(passport);
		}

		String citizen = (String)attributes.get("citizen");

		if (citizen != null) {
			setCitizen(citizen);
		}

		String nation = (String)attributes.get("nation");

		if (nation != null) {
			setNation(nation);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		Long age = (Long)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String phoneNo = (String)attributes.get("phoneNo");

		if (phoneNo != null) {
			setPhoneNo(phoneNo);
		}

		String cellPhones = (String)attributes.get("cellPhones");

		if (cellPhones != null) {
			setCellPhones(cellPhones);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String dName = (String)attributes.get("dName");

		if (dName != null) {
			setDName(dName);
		}

		String didentificationnumber = (String)attributes.get(
				"didentificationnumber");

		if (didentificationnumber != null) {
			setDidentificationnumber(didentificationnumber);
		}

		String dateofbirth = (String)attributes.get("dateofbirth");

		if (dateofbirth != null) {
			setDateofbirth(dateofbirth);
		}

		String dcitizen = (String)attributes.get("dcitizen");

		if (dcitizen != null) {
			setDcitizen(dcitizen);
		}

		String driverNation = (String)attributes.get("driverNation");

		if (driverNation != null) {
			setDriverNation(driverNation);
		}

		String drivergender = (String)attributes.get("drivergender");

		if (drivergender != null) {
			setDrivergender(drivergender);
		}

		Long driverAge = (Long)attributes.get("driverAge");

		if (driverAge != null) {
			setDriverAge(driverAge);
		}

		String retirees = (String)attributes.get("retirees");

		if (retirees != null) {
			setRetirees(retirees);
		}

		Long statusReadPSV = (Long)attributes.get("statusReadPSV");

		if (statusReadPSV != null) {
			setStatusReadPSV(statusReadPSV);
		}

		String driverLicense = (String)attributes.get("driverLicense");

		if (driverLicense != null) {
			setDriverLicense(driverLicense);
		}

		String dphone = (String)attributes.get("dphone");

		if (dphone != null) {
			setDphone(dphone);
		}

		String dphoneTwo = (String)attributes.get("dphoneTwo");

		if (dphoneTwo != null) {
			setDphoneTwo(dphoneTwo);
		}

		String daddress = (String)attributes.get("daddress");

		if (daddress != null) {
			setDaddress(daddress);
		}
	}

	/**
	* Returns the primary key of this complain userinfo.
	*
	* @return the primary key of this complain userinfo
	*/
	@Override
	public long getPrimaryKey() {
		return _complainUserinfo.getPrimaryKey();
	}

	/**
	* Sets the primary key of this complain userinfo.
	*
	* @param primaryKey the primary key of this complain userinfo
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_complainUserinfo.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the complain user ID of this complain userinfo.
	*
	* @return the complain user ID of this complain userinfo
	*/
	@Override
	public long getComplainUserId() {
		return _complainUserinfo.getComplainUserId();
	}

	/**
	* Sets the complain user ID of this complain userinfo.
	*
	* @param complainUserId the complain user ID of this complain userinfo
	*/
	@Override
	public void setComplainUserId(long complainUserId) {
		_complainUserinfo.setComplainUserId(complainUserId);
	}

	/**
	* Returns the complain user uuid of this complain userinfo.
	*
	* @return the complain user uuid of this complain userinfo
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getComplainUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _complainUserinfo.getComplainUserUuid();
	}

	/**
	* Sets the complain user uuid of this complain userinfo.
	*
	* @param complainUserUuid the complain user uuid of this complain userinfo
	*/
	@Override
	public void setComplainUserUuid(java.lang.String complainUserUuid) {
		_complainUserinfo.setComplainUserUuid(complainUserUuid);
	}

	/**
	* Returns the bil ID of this complain userinfo.
	*
	* @return the bil ID of this complain userinfo
	*/
	@Override
	public long getBilId() {
		return _complainUserinfo.getBilId();
	}

	/**
	* Sets the bil ID of this complain userinfo.
	*
	* @param bilId the bil ID of this complain userinfo
	*/
	@Override
	public void setBilId(long bilId) {
		_complainUserinfo.setBilId(bilId);
	}

	/**
	* Returns the prefix of this complain userinfo.
	*
	* @return the prefix of this complain userinfo
	*/
	@Override
	public java.lang.String getPrefix() {
		return _complainUserinfo.getPrefix();
	}

	/**
	* Sets the prefix of this complain userinfo.
	*
	* @param prefix the prefix of this complain userinfo
	*/
	@Override
	public void setPrefix(java.lang.String prefix) {
		_complainUserinfo.setPrefix(prefix);
	}

	/**
	* Returns the name of this complain userinfo.
	*
	* @return the name of this complain userinfo
	*/
	@Override
	public java.lang.String getName() {
		return _complainUserinfo.getName();
	}

	/**
	* Sets the name of this complain userinfo.
	*
	* @param name the name of this complain userinfo
	*/
	@Override
	public void setName(java.lang.String name) {
		_complainUserinfo.setName(name);
	}

	/**
	* Returns the identificationnumber of this complain userinfo.
	*
	* @return the identificationnumber of this complain userinfo
	*/
	@Override
	public java.lang.String getIdentificationnumber() {
		return _complainUserinfo.getIdentificationnumber();
	}

	/**
	* Sets the identificationnumber of this complain userinfo.
	*
	* @param identificationnumber the identificationnumber of this complain userinfo
	*/
	@Override
	public void setIdentificationnumber(java.lang.String identificationnumber) {
		_complainUserinfo.setIdentificationnumber(identificationnumber);
	}

	/**
	* Returns the passport of this complain userinfo.
	*
	* @return the passport of this complain userinfo
	*/
	@Override
	public java.lang.String getPassport() {
		return _complainUserinfo.getPassport();
	}

	/**
	* Sets the passport of this complain userinfo.
	*
	* @param passport the passport of this complain userinfo
	*/
	@Override
	public void setPassport(java.lang.String passport) {
		_complainUserinfo.setPassport(passport);
	}

	/**
	* Returns the citizen of this complain userinfo.
	*
	* @return the citizen of this complain userinfo
	*/
	@Override
	public java.lang.String getCitizen() {
		return _complainUserinfo.getCitizen();
	}

	/**
	* Sets the citizen of this complain userinfo.
	*
	* @param citizen the citizen of this complain userinfo
	*/
	@Override
	public void setCitizen(java.lang.String citizen) {
		_complainUserinfo.setCitizen(citizen);
	}

	/**
	* Returns the nation of this complain userinfo.
	*
	* @return the nation of this complain userinfo
	*/
	@Override
	public java.lang.String getNation() {
		return _complainUserinfo.getNation();
	}

	/**
	* Sets the nation of this complain userinfo.
	*
	* @param nation the nation of this complain userinfo
	*/
	@Override
	public void setNation(java.lang.String nation) {
		_complainUserinfo.setNation(nation);
	}

	/**
	* Returns the gender of this complain userinfo.
	*
	* @return the gender of this complain userinfo
	*/
	@Override
	public java.lang.String getGender() {
		return _complainUserinfo.getGender();
	}

	/**
	* Sets the gender of this complain userinfo.
	*
	* @param gender the gender of this complain userinfo
	*/
	@Override
	public void setGender(java.lang.String gender) {
		_complainUserinfo.setGender(gender);
	}

	/**
	* Returns the age of this complain userinfo.
	*
	* @return the age of this complain userinfo
	*/
	@Override
	public long getAge() {
		return _complainUserinfo.getAge();
	}

	/**
	* Sets the age of this complain userinfo.
	*
	* @param age the age of this complain userinfo
	*/
	@Override
	public void setAge(long age) {
		_complainUserinfo.setAge(age);
	}

	/**
	* Returns the phone no of this complain userinfo.
	*
	* @return the phone no of this complain userinfo
	*/
	@Override
	public java.lang.String getPhoneNo() {
		return _complainUserinfo.getPhoneNo();
	}

	/**
	* Sets the phone no of this complain userinfo.
	*
	* @param phoneNo the phone no of this complain userinfo
	*/
	@Override
	public void setPhoneNo(java.lang.String phoneNo) {
		_complainUserinfo.setPhoneNo(phoneNo);
	}

	/**
	* Returns the cell phones of this complain userinfo.
	*
	* @return the cell phones of this complain userinfo
	*/
	@Override
	public java.lang.String getCellPhones() {
		return _complainUserinfo.getCellPhones();
	}

	/**
	* Sets the cell phones of this complain userinfo.
	*
	* @param cellPhones the cell phones of this complain userinfo
	*/
	@Override
	public void setCellPhones(java.lang.String cellPhones) {
		_complainUserinfo.setCellPhones(cellPhones);
	}

	/**
	* Returns the address of this complain userinfo.
	*
	* @return the address of this complain userinfo
	*/
	@Override
	public java.lang.String getAddress() {
		return _complainUserinfo.getAddress();
	}

	/**
	* Sets the address of this complain userinfo.
	*
	* @param address the address of this complain userinfo
	*/
	@Override
	public void setAddress(java.lang.String address) {
		_complainUserinfo.setAddress(address);
	}

	/**
	* Returns the email of this complain userinfo.
	*
	* @return the email of this complain userinfo
	*/
	@Override
	public java.lang.String getEmail() {
		return _complainUserinfo.getEmail();
	}

	/**
	* Sets the email of this complain userinfo.
	*
	* @param email the email of this complain userinfo
	*/
	@Override
	public void setEmail(java.lang.String email) {
		_complainUserinfo.setEmail(email);
	}

	/**
	* Returns the state of this complain userinfo.
	*
	* @return the state of this complain userinfo
	*/
	@Override
	public java.lang.String getState() {
		return _complainUserinfo.getState();
	}

	/**
	* Sets the state of this complain userinfo.
	*
	* @param state the state of this complain userinfo
	*/
	@Override
	public void setState(java.lang.String state) {
		_complainUserinfo.setState(state);
	}

	/**
	* Returns the d name of this complain userinfo.
	*
	* @return the d name of this complain userinfo
	*/
	@Override
	public java.lang.String getDName() {
		return _complainUserinfo.getDName();
	}

	/**
	* Sets the d name of this complain userinfo.
	*
	* @param dName the d name of this complain userinfo
	*/
	@Override
	public void setDName(java.lang.String dName) {
		_complainUserinfo.setDName(dName);
	}

	/**
	* Returns the didentificationnumber of this complain userinfo.
	*
	* @return the didentificationnumber of this complain userinfo
	*/
	@Override
	public java.lang.String getDidentificationnumber() {
		return _complainUserinfo.getDidentificationnumber();
	}

	/**
	* Sets the didentificationnumber of this complain userinfo.
	*
	* @param didentificationnumber the didentificationnumber of this complain userinfo
	*/
	@Override
	public void setDidentificationnumber(java.lang.String didentificationnumber) {
		_complainUserinfo.setDidentificationnumber(didentificationnumber);
	}

	/**
	* Returns the dateofbirth of this complain userinfo.
	*
	* @return the dateofbirth of this complain userinfo
	*/
	@Override
	public java.lang.String getDateofbirth() {
		return _complainUserinfo.getDateofbirth();
	}

	/**
	* Sets the dateofbirth of this complain userinfo.
	*
	* @param dateofbirth the dateofbirth of this complain userinfo
	*/
	@Override
	public void setDateofbirth(java.lang.String dateofbirth) {
		_complainUserinfo.setDateofbirth(dateofbirth);
	}

	/**
	* Returns the dcitizen of this complain userinfo.
	*
	* @return the dcitizen of this complain userinfo
	*/
	@Override
	public java.lang.String getDcitizen() {
		return _complainUserinfo.getDcitizen();
	}

	/**
	* Sets the dcitizen of this complain userinfo.
	*
	* @param dcitizen the dcitizen of this complain userinfo
	*/
	@Override
	public void setDcitizen(java.lang.String dcitizen) {
		_complainUserinfo.setDcitizen(dcitizen);
	}

	/**
	* Returns the driver nation of this complain userinfo.
	*
	* @return the driver nation of this complain userinfo
	*/
	@Override
	public java.lang.String getDriverNation() {
		return _complainUserinfo.getDriverNation();
	}

	/**
	* Sets the driver nation of this complain userinfo.
	*
	* @param driverNation the driver nation of this complain userinfo
	*/
	@Override
	public void setDriverNation(java.lang.String driverNation) {
		_complainUserinfo.setDriverNation(driverNation);
	}

	/**
	* Returns the drivergender of this complain userinfo.
	*
	* @return the drivergender of this complain userinfo
	*/
	@Override
	public java.lang.String getDrivergender() {
		return _complainUserinfo.getDrivergender();
	}

	/**
	* Sets the drivergender of this complain userinfo.
	*
	* @param drivergender the drivergender of this complain userinfo
	*/
	@Override
	public void setDrivergender(java.lang.String drivergender) {
		_complainUserinfo.setDrivergender(drivergender);
	}

	/**
	* Returns the driver age of this complain userinfo.
	*
	* @return the driver age of this complain userinfo
	*/
	@Override
	public long getDriverAge() {
		return _complainUserinfo.getDriverAge();
	}

	/**
	* Sets the driver age of this complain userinfo.
	*
	* @param driverAge the driver age of this complain userinfo
	*/
	@Override
	public void setDriverAge(long driverAge) {
		_complainUserinfo.setDriverAge(driverAge);
	}

	/**
	* Returns the retirees of this complain userinfo.
	*
	* @return the retirees of this complain userinfo
	*/
	@Override
	public java.lang.String getRetirees() {
		return _complainUserinfo.getRetirees();
	}

	/**
	* Sets the retirees of this complain userinfo.
	*
	* @param retirees the retirees of this complain userinfo
	*/
	@Override
	public void setRetirees(java.lang.String retirees) {
		_complainUserinfo.setRetirees(retirees);
	}

	/**
	* Returns the status read p s v of this complain userinfo.
	*
	* @return the status read p s v of this complain userinfo
	*/
	@Override
	public long getStatusReadPSV() {
		return _complainUserinfo.getStatusReadPSV();
	}

	/**
	* Sets the status read p s v of this complain userinfo.
	*
	* @param statusReadPSV the status read p s v of this complain userinfo
	*/
	@Override
	public void setStatusReadPSV(long statusReadPSV) {
		_complainUserinfo.setStatusReadPSV(statusReadPSV);
	}

	/**
	* Returns the driver license of this complain userinfo.
	*
	* @return the driver license of this complain userinfo
	*/
	@Override
	public java.lang.String getDriverLicense() {
		return _complainUserinfo.getDriverLicense();
	}

	/**
	* Sets the driver license of this complain userinfo.
	*
	* @param driverLicense the driver license of this complain userinfo
	*/
	@Override
	public void setDriverLicense(java.lang.String driverLicense) {
		_complainUserinfo.setDriverLicense(driverLicense);
	}

	/**
	* Returns the dphone of this complain userinfo.
	*
	* @return the dphone of this complain userinfo
	*/
	@Override
	public java.lang.String getDphone() {
		return _complainUserinfo.getDphone();
	}

	/**
	* Sets the dphone of this complain userinfo.
	*
	* @param dphone the dphone of this complain userinfo
	*/
	@Override
	public void setDphone(java.lang.String dphone) {
		_complainUserinfo.setDphone(dphone);
	}

	/**
	* Returns the dphone two of this complain userinfo.
	*
	* @return the dphone two of this complain userinfo
	*/
	@Override
	public java.lang.String getDphoneTwo() {
		return _complainUserinfo.getDphoneTwo();
	}

	/**
	* Sets the dphone two of this complain userinfo.
	*
	* @param dphoneTwo the dphone two of this complain userinfo
	*/
	@Override
	public void setDphoneTwo(java.lang.String dphoneTwo) {
		_complainUserinfo.setDphoneTwo(dphoneTwo);
	}

	/**
	* Returns the daddress of this complain userinfo.
	*
	* @return the daddress of this complain userinfo
	*/
	@Override
	public java.lang.String getDaddress() {
		return _complainUserinfo.getDaddress();
	}

	/**
	* Sets the daddress of this complain userinfo.
	*
	* @param daddress the daddress of this complain userinfo
	*/
	@Override
	public void setDaddress(java.lang.String daddress) {
		_complainUserinfo.setDaddress(daddress);
	}

	@Override
	public boolean isNew() {
		return _complainUserinfo.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_complainUserinfo.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _complainUserinfo.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_complainUserinfo.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _complainUserinfo.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _complainUserinfo.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_complainUserinfo.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _complainUserinfo.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_complainUserinfo.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_complainUserinfo.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_complainUserinfo.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new complainUserinfoWrapper((complainUserinfo)_complainUserinfo.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo) {
		return _complainUserinfo.compareTo(complainUserinfo);
	}

	@Override
	public int hashCode() {
		return _complainUserinfo.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.complainUserinfo> toCacheModel() {
		return _complainUserinfo.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.complainUserinfo toEscapedModel() {
		return new complainUserinfoWrapper(_complainUserinfo.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.complainUserinfo toUnescapedModel() {
		return new complainUserinfoWrapper(_complainUserinfo.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _complainUserinfo.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _complainUserinfo.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_complainUserinfo.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof complainUserinfoWrapper)) {
			return false;
		}

		complainUserinfoWrapper complainUserinfoWrapper = (complainUserinfoWrapper)obj;

		if (Validator.equals(_complainUserinfo,
					complainUserinfoWrapper._complainUserinfo)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public complainUserinfo getWrappedcomplainUserinfo() {
		return _complainUserinfo;
	}

	@Override
	public complainUserinfo getWrappedModel() {
		return _complainUserinfo;
	}

	@Override
	public void resetOriginalValues() {
		_complainUserinfo.resetOriginalValues();
	}

	private complainUserinfo _complainUserinfo;
}