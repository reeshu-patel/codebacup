/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DocumentTree}.
 * </p>
 *
 * @author reeshu
 * @see DocumentTree
 * @generated
 */
public class DocumentTreeWrapper implements DocumentTree,
	ModelWrapper<DocumentTree> {
	public DocumentTreeWrapper(DocumentTree documentTree) {
		_documentTree = documentTree;
	}

	@Override
	public Class<?> getModelClass() {
		return DocumentTree.class;
	}

	@Override
	public String getModelClassName() {
		return DocumentTree.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("documenttreeid", getDocumenttreeid());
		attributes.put("bilId", getBilId());
		attributes.put("fileentryid", getFileentryid());
		attributes.put("folderid", getFolderid());
		attributes.put("foldername", getFoldername());
		attributes.put("title", getTitle());
		attributes.put("description", getDescription());
		attributes.put("leaf", getLeaf());
		attributes.put("type", getType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long documenttreeid = (Long)attributes.get("documenttreeid");

		if (documenttreeid != null) {
			setDocumenttreeid(documenttreeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		Long fileentryid = (Long)attributes.get("fileentryid");

		if (fileentryid != null) {
			setFileentryid(fileentryid);
		}

		Long folderid = (Long)attributes.get("folderid");

		if (folderid != null) {
			setFolderid(folderid);
		}

		String foldername = (String)attributes.get("foldername");

		if (foldername != null) {
			setFoldername(foldername);
		}

		String title = (String)attributes.get("title");

		if (title != null) {
			setTitle(title);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String leaf = (String)attributes.get("leaf");

		if (leaf != null) {
			setLeaf(leaf);
		}

		String type = (String)attributes.get("type");

		if (type != null) {
			setType(type);
		}
	}

	/**
	* Returns the primary key of this document tree.
	*
	* @return the primary key of this document tree
	*/
	@Override
	public long getPrimaryKey() {
		return _documentTree.getPrimaryKey();
	}

	/**
	* Sets the primary key of this document tree.
	*
	* @param primaryKey the primary key of this document tree
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_documentTree.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the documenttreeid of this document tree.
	*
	* @return the documenttreeid of this document tree
	*/
	@Override
	public long getDocumenttreeid() {
		return _documentTree.getDocumenttreeid();
	}

	/**
	* Sets the documenttreeid of this document tree.
	*
	* @param documenttreeid the documenttreeid of this document tree
	*/
	@Override
	public void setDocumenttreeid(long documenttreeid) {
		_documentTree.setDocumenttreeid(documenttreeid);
	}

	/**
	* Returns the bil ID of this document tree.
	*
	* @return the bil ID of this document tree
	*/
	@Override
	public long getBilId() {
		return _documentTree.getBilId();
	}

	/**
	* Sets the bil ID of this document tree.
	*
	* @param bilId the bil ID of this document tree
	*/
	@Override
	public void setBilId(long bilId) {
		_documentTree.setBilId(bilId);
	}

	/**
	* Returns the fileentryid of this document tree.
	*
	* @return the fileentryid of this document tree
	*/
	@Override
	public long getFileentryid() {
		return _documentTree.getFileentryid();
	}

	/**
	* Sets the fileentryid of this document tree.
	*
	* @param fileentryid the fileentryid of this document tree
	*/
	@Override
	public void setFileentryid(long fileentryid) {
		_documentTree.setFileentryid(fileentryid);
	}

	/**
	* Returns the folderid of this document tree.
	*
	* @return the folderid of this document tree
	*/
	@Override
	public long getFolderid() {
		return _documentTree.getFolderid();
	}

	/**
	* Sets the folderid of this document tree.
	*
	* @param folderid the folderid of this document tree
	*/
	@Override
	public void setFolderid(long folderid) {
		_documentTree.setFolderid(folderid);
	}

	/**
	* Returns the foldername of this document tree.
	*
	* @return the foldername of this document tree
	*/
	@Override
	public java.lang.String getFoldername() {
		return _documentTree.getFoldername();
	}

	/**
	* Sets the foldername of this document tree.
	*
	* @param foldername the foldername of this document tree
	*/
	@Override
	public void setFoldername(java.lang.String foldername) {
		_documentTree.setFoldername(foldername);
	}

	/**
	* Returns the title of this document tree.
	*
	* @return the title of this document tree
	*/
	@Override
	public java.lang.String getTitle() {
		return _documentTree.getTitle();
	}

	/**
	* Sets the title of this document tree.
	*
	* @param title the title of this document tree
	*/
	@Override
	public void setTitle(java.lang.String title) {
		_documentTree.setTitle(title);
	}

	/**
	* Returns the description of this document tree.
	*
	* @return the description of this document tree
	*/
	@Override
	public java.lang.String getDescription() {
		return _documentTree.getDescription();
	}

	/**
	* Sets the description of this document tree.
	*
	* @param description the description of this document tree
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_documentTree.setDescription(description);
	}

	/**
	* Returns the leaf of this document tree.
	*
	* @return the leaf of this document tree
	*/
	@Override
	public java.lang.String getLeaf() {
		return _documentTree.getLeaf();
	}

	/**
	* Sets the leaf of this document tree.
	*
	* @param leaf the leaf of this document tree
	*/
	@Override
	public void setLeaf(java.lang.String leaf) {
		_documentTree.setLeaf(leaf);
	}

	/**
	* Returns the type of this document tree.
	*
	* @return the type of this document tree
	*/
	@Override
	public java.lang.String getType() {
		return _documentTree.getType();
	}

	/**
	* Sets the type of this document tree.
	*
	* @param type the type of this document tree
	*/
	@Override
	public void setType(java.lang.String type) {
		_documentTree.setType(type);
	}

	@Override
	public boolean isNew() {
		return _documentTree.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_documentTree.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _documentTree.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_documentTree.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _documentTree.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _documentTree.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_documentTree.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _documentTree.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_documentTree.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_documentTree.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_documentTree.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DocumentTreeWrapper((DocumentTree)_documentTree.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.DocumentTree documentTree) {
		return _documentTree.compareTo(documentTree);
	}

	@Override
	public int hashCode() {
		return _documentTree.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.DocumentTree> toCacheModel() {
		return _documentTree.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.DocumentTree toEscapedModel() {
		return new DocumentTreeWrapper(_documentTree.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.DocumentTree toUnescapedModel() {
		return new DocumentTreeWrapper(_documentTree.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _documentTree.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _documentTree.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_documentTree.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DocumentTreeWrapper)) {
			return false;
		}

		DocumentTreeWrapper documentTreeWrapper = (DocumentTreeWrapper)obj;

		if (Validator.equals(_documentTree, documentTreeWrapper._documentTree)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DocumentTree getWrappedDocumentTree() {
		return _documentTree;
	}

	@Override
	public DocumentTree getWrappedModel() {
		return _documentTree;
	}

	@Override
	public void resetOriginalValues() {
		_documentTree.resetOriginalValues();
	}

	private DocumentTree _documentTree;
}