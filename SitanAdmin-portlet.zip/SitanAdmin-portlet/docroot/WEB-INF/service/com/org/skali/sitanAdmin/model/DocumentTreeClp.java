/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.DocumentTreeLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class DocumentTreeClp extends BaseModelImpl<DocumentTree>
	implements DocumentTree {
	public DocumentTreeClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DocumentTree.class;
	}

	@Override
	public String getModelClassName() {
		return DocumentTree.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _documenttreeid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDocumenttreeid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _documenttreeid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("documenttreeid", getDocumenttreeid());
		attributes.put("bilId", getBilId());
		attributes.put("fileentryid", getFileentryid());
		attributes.put("folderid", getFolderid());
		attributes.put("foldername", getFoldername());
		attributes.put("title", getTitle());
		attributes.put("description", getDescription());
		attributes.put("leaf", getLeaf());
		attributes.put("type", getType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long documenttreeid = (Long)attributes.get("documenttreeid");

		if (documenttreeid != null) {
			setDocumenttreeid(documenttreeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		Long fileentryid = (Long)attributes.get("fileentryid");

		if (fileentryid != null) {
			setFileentryid(fileentryid);
		}

		Long folderid = (Long)attributes.get("folderid");

		if (folderid != null) {
			setFolderid(folderid);
		}

		String foldername = (String)attributes.get("foldername");

		if (foldername != null) {
			setFoldername(foldername);
		}

		String title = (String)attributes.get("title");

		if (title != null) {
			setTitle(title);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String leaf = (String)attributes.get("leaf");

		if (leaf != null) {
			setLeaf(leaf);
		}

		String type = (String)attributes.get("type");

		if (type != null) {
			setType(type);
		}
	}

	@Override
	public long getDocumenttreeid() {
		return _documenttreeid;
	}

	@Override
	public void setDocumenttreeid(long documenttreeid) {
		_documenttreeid = documenttreeid;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setDocumenttreeid", long.class);

				method.invoke(_documentTreeRemoteModel, documenttreeid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_documentTreeRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getFileentryid() {
		return _fileentryid;
	}

	@Override
	public void setFileentryid(long fileentryid) {
		_fileentryid = fileentryid;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setFileentryid", long.class);

				method.invoke(_documentTreeRemoteModel, fileentryid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getFolderid() {
		return _folderid;
	}

	@Override
	public void setFolderid(long folderid) {
		_folderid = folderid;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setFolderid", long.class);

				method.invoke(_documentTreeRemoteModel, folderid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFoldername() {
		return _foldername;
	}

	@Override
	public void setFoldername(String foldername) {
		_foldername = foldername;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setFoldername", String.class);

				method.invoke(_documentTreeRemoteModel, foldername);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTitle() {
		return _title;
	}

	@Override
	public void setTitle(String title) {
		_title = title;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setTitle", String.class);

				method.invoke(_documentTreeRemoteModel, title);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_documentTreeRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLeaf() {
		return _leaf;
	}

	@Override
	public void setLeaf(String leaf) {
		_leaf = leaf;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setLeaf", String.class);

				method.invoke(_documentTreeRemoteModel, leaf);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getType() {
		return _type;
	}

	@Override
	public void setType(String type) {
		_type = type;

		if (_documentTreeRemoteModel != null) {
			try {
				Class<?> clazz = _documentTreeRemoteModel.getClass();

				Method method = clazz.getMethod("setType", String.class);

				method.invoke(_documentTreeRemoteModel, type);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getDocumentTreeRemoteModel() {
		return _documentTreeRemoteModel;
	}

	public void setDocumentTreeRemoteModel(BaseModel<?> documentTreeRemoteModel) {
		_documentTreeRemoteModel = documentTreeRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _documentTreeRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_documentTreeRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DocumentTreeLocalServiceUtil.addDocumentTree(this);
		}
		else {
			DocumentTreeLocalServiceUtil.updateDocumentTree(this);
		}
	}

	@Override
	public DocumentTree toEscapedModel() {
		return (DocumentTree)ProxyUtil.newProxyInstance(DocumentTree.class.getClassLoader(),
			new Class[] { DocumentTree.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DocumentTreeClp clone = new DocumentTreeClp();

		clone.setDocumenttreeid(getDocumenttreeid());
		clone.setBilId(getBilId());
		clone.setFileentryid(getFileentryid());
		clone.setFolderid(getFolderid());
		clone.setFoldername(getFoldername());
		clone.setTitle(getTitle());
		clone.setDescription(getDescription());
		clone.setLeaf(getLeaf());
		clone.setType(getType());

		return clone;
	}

	@Override
	public int compareTo(DocumentTree documentTree) {
		long primaryKey = documentTree.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DocumentTreeClp)) {
			return false;
		}

		DocumentTreeClp documentTree = (DocumentTreeClp)obj;

		long primaryKey = documentTree.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{documenttreeid=");
		sb.append(getDocumenttreeid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", fileentryid=");
		sb.append(getFileentryid());
		sb.append(", folderid=");
		sb.append(getFolderid());
		sb.append(", foldername=");
		sb.append(getFoldername());
		sb.append(", title=");
		sb.append(getTitle());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", leaf=");
		sb.append(getLeaf());
		sb.append(", type=");
		sb.append(getType());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(31);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.DocumentTree");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>documenttreeid</column-name><column-value><![CDATA[");
		sb.append(getDocumenttreeid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>fileentryid</column-name><column-value><![CDATA[");
		sb.append(getFileentryid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>folderid</column-name><column-value><![CDATA[");
		sb.append(getFolderid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>foldername</column-name><column-value><![CDATA[");
		sb.append(getFoldername());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>title</column-name><column-value><![CDATA[");
		sb.append(getTitle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>leaf</column-name><column-value><![CDATA[");
		sb.append(getLeaf());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>type</column-name><column-value><![CDATA[");
		sb.append(getType());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _documenttreeid;
	private long _bilId;
	private long _fileentryid;
	private long _folderid;
	private String _foldername;
	private String _title;
	private String _description;
	private String _leaf;
	private String _type;
	private BaseModel<?> _documentTreeRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}