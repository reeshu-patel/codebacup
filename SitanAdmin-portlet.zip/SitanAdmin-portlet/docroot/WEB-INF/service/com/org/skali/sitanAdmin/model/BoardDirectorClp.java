/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.BoardDirectorLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class BoardDirectorClp extends BaseModelImpl<BoardDirector>
	implements BoardDirector {
	public BoardDirectorClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return BoardDirector.class;
	}

	@Override
	public String getModelClassName() {
		return BoardDirector.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _boarddirectorid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setBoarddirectorid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _boarddirectorid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("boarddirectorid", getBoarddirectorid());
		attributes.put("bilId", getBilId());
		attributes.put("wealp", getWealp());
		attributes.put("kplama", getKplama());
		attributes.put("newKp", getNewKp());
		attributes.put("position", getPosition());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long boarddirectorid = (Long)attributes.get("boarddirectorid");

		if (boarddirectorid != null) {
			setBoarddirectorid(boarddirectorid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String wealp = (String)attributes.get("wealp");

		if (wealp != null) {
			setWealp(wealp);
		}

		String kplama = (String)attributes.get("kplama");

		if (kplama != null) {
			setKplama(kplama);
		}

		String newKp = (String)attributes.get("newKp");

		if (newKp != null) {
			setNewKp(newKp);
		}

		String position = (String)attributes.get("position");

		if (position != null) {
			setPosition(position);
		}
	}

	@Override
	public long getBoarddirectorid() {
		return _boarddirectorid;
	}

	@Override
	public void setBoarddirectorid(long boarddirectorid) {
		_boarddirectorid = boarddirectorid;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setBoarddirectorid", long.class);

				method.invoke(_boardDirectorRemoteModel, boarddirectorid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_boardDirectorRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWealp() {
		return _wealp;
	}

	@Override
	public void setWealp(String wealp) {
		_wealp = wealp;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setWealp", String.class);

				method.invoke(_boardDirectorRemoteModel, wealp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getKplama() {
		return _kplama;
	}

	@Override
	public void setKplama(String kplama) {
		_kplama = kplama;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setKplama", String.class);

				method.invoke(_boardDirectorRemoteModel, kplama);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNewKp() {
		return _newKp;
	}

	@Override
	public void setNewKp(String newKp) {
		_newKp = newKp;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setNewKp", String.class);

				method.invoke(_boardDirectorRemoteModel, newKp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPosition() {
		return _position;
	}

	@Override
	public void setPosition(String position) {
		_position = position;

		if (_boardDirectorRemoteModel != null) {
			try {
				Class<?> clazz = _boardDirectorRemoteModel.getClass();

				Method method = clazz.getMethod("setPosition", String.class);

				method.invoke(_boardDirectorRemoteModel, position);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getBoardDirectorRemoteModel() {
		return _boardDirectorRemoteModel;
	}

	public void setBoardDirectorRemoteModel(
		BaseModel<?> boardDirectorRemoteModel) {
		_boardDirectorRemoteModel = boardDirectorRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _boardDirectorRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_boardDirectorRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			BoardDirectorLocalServiceUtil.addBoardDirector(this);
		}
		else {
			BoardDirectorLocalServiceUtil.updateBoardDirector(this);
		}
	}

	@Override
	public BoardDirector toEscapedModel() {
		return (BoardDirector)ProxyUtil.newProxyInstance(BoardDirector.class.getClassLoader(),
			new Class[] { BoardDirector.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		BoardDirectorClp clone = new BoardDirectorClp();

		clone.setBoarddirectorid(getBoarddirectorid());
		clone.setBilId(getBilId());
		clone.setWealp(getWealp());
		clone.setKplama(getKplama());
		clone.setNewKp(getNewKp());
		clone.setPosition(getPosition());

		return clone;
	}

	@Override
	public int compareTo(BoardDirector boardDirector) {
		long primaryKey = boardDirector.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BoardDirectorClp)) {
			return false;
		}

		BoardDirectorClp boardDirector = (BoardDirectorClp)obj;

		long primaryKey = boardDirector.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{boarddirectorid=");
		sb.append(getBoarddirectorid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", wealp=");
		sb.append(getWealp());
		sb.append(", kplama=");
		sb.append(getKplama());
		sb.append(", newKp=");
		sb.append(getNewKp());
		sb.append(", position=");
		sb.append(getPosition());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.BoardDirector");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>boarddirectorid</column-name><column-value><![CDATA[");
		sb.append(getBoarddirectorid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>wealp</column-name><column-value><![CDATA[");
		sb.append(getWealp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>kplama</column-name><column-value><![CDATA[");
		sb.append(getKplama());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>newKp</column-name><column-value><![CDATA[");
		sb.append(getNewKp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>position</column-name><column-value><![CDATA[");
		sb.append(getPosition());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _boarddirectorid;
	private long _bilId;
	private String _wealp;
	private String _kplama;
	private String _newKp;
	private String _position;
	private BaseModel<?> _boardDirectorRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}