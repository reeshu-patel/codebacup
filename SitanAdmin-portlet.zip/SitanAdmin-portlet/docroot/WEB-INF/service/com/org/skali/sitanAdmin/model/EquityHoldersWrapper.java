/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EquityHolders}.
 * </p>
 *
 * @author reeshu
 * @see EquityHolders
 * @generated
 */
public class EquityHoldersWrapper implements EquityHolders,
	ModelWrapper<EquityHolders> {
	public EquityHoldersWrapper(EquityHolders equityHolders) {
		_equityHolders = equityHolders;
	}

	@Override
	public Class<?> getModelClass() {
		return EquityHolders.class;
	}

	@Override
	public String getModelClassName() {
		return EquityHolders.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("equityholdersid", getEquityholdersid());
		attributes.put("bilId", getBilId());
		attributes.put("name", getName());
		attributes.put("kpLama", getKpLama());
		attributes.put("newKp", getNewKp());
		attributes.put("value", getValue());
		attributes.put("percent", getPercent());
		attributes.put("gender", getGender());
		attributes.put("nation", getNation());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long equityholdersid = (Long)attributes.get("equityholdersid");

		if (equityholdersid != null) {
			setEquityholdersid(equityholdersid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String kpLama = (String)attributes.get("kpLama");

		if (kpLama != null) {
			setKpLama(kpLama);
		}

		String newKp = (String)attributes.get("newKp");

		if (newKp != null) {
			setNewKp(newKp);
		}

		String value = (String)attributes.get("value");

		if (value != null) {
			setValue(value);
		}

		String percent = (String)attributes.get("percent");

		if (percent != null) {
			setPercent(percent);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String nation = (String)attributes.get("nation");

		if (nation != null) {
			setNation(nation);
		}
	}

	/**
	* Returns the primary key of this equity holders.
	*
	* @return the primary key of this equity holders
	*/
	@Override
	public long getPrimaryKey() {
		return _equityHolders.getPrimaryKey();
	}

	/**
	* Sets the primary key of this equity holders.
	*
	* @param primaryKey the primary key of this equity holders
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_equityHolders.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the equityholdersid of this equity holders.
	*
	* @return the equityholdersid of this equity holders
	*/
	@Override
	public long getEquityholdersid() {
		return _equityHolders.getEquityholdersid();
	}

	/**
	* Sets the equityholdersid of this equity holders.
	*
	* @param equityholdersid the equityholdersid of this equity holders
	*/
	@Override
	public void setEquityholdersid(long equityholdersid) {
		_equityHolders.setEquityholdersid(equityholdersid);
	}

	/**
	* Returns the bil ID of this equity holders.
	*
	* @return the bil ID of this equity holders
	*/
	@Override
	public long getBilId() {
		return _equityHolders.getBilId();
	}

	/**
	* Sets the bil ID of this equity holders.
	*
	* @param bilId the bil ID of this equity holders
	*/
	@Override
	public void setBilId(long bilId) {
		_equityHolders.setBilId(bilId);
	}

	/**
	* Returns the name of this equity holders.
	*
	* @return the name of this equity holders
	*/
	@Override
	public java.lang.String getName() {
		return _equityHolders.getName();
	}

	/**
	* Sets the name of this equity holders.
	*
	* @param name the name of this equity holders
	*/
	@Override
	public void setName(java.lang.String name) {
		_equityHolders.setName(name);
	}

	/**
	* Returns the kp lama of this equity holders.
	*
	* @return the kp lama of this equity holders
	*/
	@Override
	public java.lang.String getKpLama() {
		return _equityHolders.getKpLama();
	}

	/**
	* Sets the kp lama of this equity holders.
	*
	* @param kpLama the kp lama of this equity holders
	*/
	@Override
	public void setKpLama(java.lang.String kpLama) {
		_equityHolders.setKpLama(kpLama);
	}

	/**
	* Returns the new kp of this equity holders.
	*
	* @return the new kp of this equity holders
	*/
	@Override
	public java.lang.String getNewKp() {
		return _equityHolders.getNewKp();
	}

	/**
	* Sets the new kp of this equity holders.
	*
	* @param newKp the new kp of this equity holders
	*/
	@Override
	public void setNewKp(java.lang.String newKp) {
		_equityHolders.setNewKp(newKp);
	}

	/**
	* Returns the value of this equity holders.
	*
	* @return the value of this equity holders
	*/
	@Override
	public java.lang.String getValue() {
		return _equityHolders.getValue();
	}

	/**
	* Sets the value of this equity holders.
	*
	* @param value the value of this equity holders
	*/
	@Override
	public void setValue(java.lang.String value) {
		_equityHolders.setValue(value);
	}

	/**
	* Returns the percent of this equity holders.
	*
	* @return the percent of this equity holders
	*/
	@Override
	public java.lang.String getPercent() {
		return _equityHolders.getPercent();
	}

	/**
	* Sets the percent of this equity holders.
	*
	* @param percent the percent of this equity holders
	*/
	@Override
	public void setPercent(java.lang.String percent) {
		_equityHolders.setPercent(percent);
	}

	/**
	* Returns the gender of this equity holders.
	*
	* @return the gender of this equity holders
	*/
	@Override
	public java.lang.String getGender() {
		return _equityHolders.getGender();
	}

	/**
	* Sets the gender of this equity holders.
	*
	* @param gender the gender of this equity holders
	*/
	@Override
	public void setGender(java.lang.String gender) {
		_equityHolders.setGender(gender);
	}

	/**
	* Returns the nation of this equity holders.
	*
	* @return the nation of this equity holders
	*/
	@Override
	public java.lang.String getNation() {
		return _equityHolders.getNation();
	}

	/**
	* Sets the nation of this equity holders.
	*
	* @param nation the nation of this equity holders
	*/
	@Override
	public void setNation(java.lang.String nation) {
		_equityHolders.setNation(nation);
	}

	@Override
	public boolean isNew() {
		return _equityHolders.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_equityHolders.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _equityHolders.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_equityHolders.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _equityHolders.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _equityHolders.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_equityHolders.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _equityHolders.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_equityHolders.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_equityHolders.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_equityHolders.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EquityHoldersWrapper((EquityHolders)_equityHolders.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.EquityHolders equityHolders) {
		return _equityHolders.compareTo(equityHolders);
	}

	@Override
	public int hashCode() {
		return _equityHolders.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.EquityHolders> toCacheModel() {
		return _equityHolders.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.EquityHolders toEscapedModel() {
		return new EquityHoldersWrapper(_equityHolders.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.EquityHolders toUnescapedModel() {
		return new EquityHoldersWrapper(_equityHolders.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _equityHolders.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _equityHolders.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_equityHolders.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EquityHoldersWrapper)) {
			return false;
		}

		EquityHoldersWrapper equityHoldersWrapper = (EquityHoldersWrapper)obj;

		if (Validator.equals(_equityHolders, equityHoldersWrapper._equityHolders)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public EquityHolders getWrappedEquityHolders() {
		return _equityHolders;
	}

	@Override
	public EquityHolders getWrappedModel() {
		return _equityHolders;
	}

	@Override
	public void resetOriginalValues() {
		_equityHolders.resetOriginalValues();
	}

	private EquityHolders _equityHolders;
}