/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.OfficerDetailServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.OfficerDetailServiceSoap
 * @generated
 */
public class OfficerDetailSoap implements Serializable {
	public static OfficerDetailSoap toSoapModel(OfficerDetail model) {
		OfficerDetailSoap soapModel = new OfficerDetailSoap();

		soapModel.setOfficerid(model.getOfficerid());
		soapModel.setOfficername(model.getOfficername());
		soapModel.setOfficertype(model.getOfficertype());
		soapModel.setOffice(model.getOffice());
		soapModel.setOfficerpower(model.getOfficerpower());
		soapModel.setDate(model.getDate());
		soapModel.setOfficerphone(model.getOfficerphone());
		soapModel.setOfficerEmail(model.getOfficerEmail());

		return soapModel;
	}

	public static OfficerDetailSoap[] toSoapModels(OfficerDetail[] models) {
		OfficerDetailSoap[] soapModels = new OfficerDetailSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static OfficerDetailSoap[][] toSoapModels(OfficerDetail[][] models) {
		OfficerDetailSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new OfficerDetailSoap[models.length][models[0].length];
		}
		else {
			soapModels = new OfficerDetailSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static OfficerDetailSoap[] toSoapModels(List<OfficerDetail> models) {
		List<OfficerDetailSoap> soapModels = new ArrayList<OfficerDetailSoap>(models.size());

		for (OfficerDetail model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new OfficerDetailSoap[soapModels.size()]);
	}

	public OfficerDetailSoap() {
	}

	public long getPrimaryKey() {
		return _officerid;
	}

	public void setPrimaryKey(long pk) {
		setOfficerid(pk);
	}

	public long getOfficerid() {
		return _officerid;
	}

	public void setOfficerid(long officerid) {
		_officerid = officerid;
	}

	public String getOfficername() {
		return _officername;
	}

	public void setOfficername(String officername) {
		_officername = officername;
	}

	public String getOfficertype() {
		return _officertype;
	}

	public void setOfficertype(String officertype) {
		_officertype = officertype;
	}

	public String getOffice() {
		return _office;
	}

	public void setOffice(String office) {
		_office = office;
	}

	public String getOfficerpower() {
		return _Officerpower;
	}

	public void setOfficerpower(String Officerpower) {
		_Officerpower = Officerpower;
	}

	public String getDate() {
		return _Date;
	}

	public void setDate(String Date) {
		_Date = Date;
	}

	public long getOfficerphone() {
		return _officerphone;
	}

	public void setOfficerphone(long officerphone) {
		_officerphone = officerphone;
	}

	public String getOfficerEmail() {
		return _officerEmail;
	}

	public void setOfficerEmail(String officerEmail) {
		_officerEmail = officerEmail;
	}

	private long _officerid;
	private String _officername;
	private String _officertype;
	private String _office;
	private String _Officerpower;
	private String _Date;
	private long _officerphone;
	private String _officerEmail;
}