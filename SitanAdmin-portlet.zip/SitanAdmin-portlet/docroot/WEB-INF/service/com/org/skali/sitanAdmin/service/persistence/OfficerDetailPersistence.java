/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.org.skali.sitanAdmin.model.OfficerDetail;

/**
 * The persistence interface for the officer detail service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see OfficerDetailPersistenceImpl
 * @see OfficerDetailUtil
 * @generated
 */
public interface OfficerDetailPersistence extends BasePersistence<OfficerDetail> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link OfficerDetailUtil} to access the officer detail persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the officer details where officerid = &#63;.
	*
	* @param officerid the officerid
	* @return the matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the officer details where officerid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerid the officerid
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @return the range of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the officer details where officerid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerid the officerid
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail findByofficerid_First(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException;

	/**
	* Returns the first officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching officer detail, or <code>null</code> if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail fetchByofficerid_First(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail findByofficerid_Last(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException;

	/**
	* Returns the last officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching officer detail, or <code>null</code> if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail fetchByofficerid_Last(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the officer details where officerid = &#63; from the database.
	*
	* @param officerid the officerid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByofficerid(long officerid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of officer details where officerid = &#63;.
	*
	* @param officerid the officerid
	* @return the number of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public int countByofficerid(long officerid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the officer detail in the entity cache if it is enabled.
	*
	* @param officerDetail the officer detail
	*/
	public void cacheResult(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail);

	/**
	* Caches the officer details in the entity cache if it is enabled.
	*
	* @param officerDetails the officer details
	*/
	public void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> officerDetails);

	/**
	* Creates a new officer detail with the primary key. Does not add the officer detail to the database.
	*
	* @param officerid the primary key for the new officer detail
	* @return the new officer detail
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail create(long officerid);

	/**
	* Removes the officer detail with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail remove(long officerid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException;

	public com.org.skali.sitanAdmin.model.OfficerDetail updateImpl(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the officer detail with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchOfficerDetailException} if it could not be found.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail findByPrimaryKey(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException;

	/**
	* Returns the officer detail with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail, or <code>null</code> if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.OfficerDetail fetchByPrimaryKey(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the officer details.
	*
	* @return the officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the officer details.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @return the range of officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the officer details.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of officer details
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the officer details from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of officer details.
	*
	* @return the number of officer details
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}