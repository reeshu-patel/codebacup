/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ActiveVehicleDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class ActiveVehicleDetailClp extends BaseModelImpl<ActiveVehicleDetail>
	implements ActiveVehicleDetail {
	public ActiveVehicleDetailClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return ActiveVehicleDetail.class;
	}

	@Override
	public String getModelClassName() {
		return ActiveVehicleDetail.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _vehicalid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setVehicalid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _vehicalid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("vehicalid", getVehicalid());
		attributes.put("bilId", getBilId());
		attributes.put("classcode", getClasscode());
		attributes.put("byVehicle", getByVehicle());
		attributes.put("withoutMotor", getWithoutMotor());
		attributes.put("commencement", getCommencement());
		attributes.put("ageLimit", getAgeLimit());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long vehicalid = (Long)attributes.get("vehicalid");

		if (vehicalid != null) {
			setVehicalid(vehicalid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String classcode = (String)attributes.get("classcode");

		if (classcode != null) {
			setClasscode(classcode);
		}

		String byVehicle = (String)attributes.get("byVehicle");

		if (byVehicle != null) {
			setByVehicle(byVehicle);
		}

		String withoutMotor = (String)attributes.get("withoutMotor");

		if (withoutMotor != null) {
			setWithoutMotor(withoutMotor);
		}

		String commencement = (String)attributes.get("commencement");

		if (commencement != null) {
			setCommencement(commencement);
		}

		String ageLimit = (String)attributes.get("ageLimit");

		if (ageLimit != null) {
			setAgeLimit(ageLimit);
		}
	}

	@Override
	public long getVehicalid() {
		return _vehicalid;
	}

	@Override
	public void setVehicalid(long vehicalid) {
		_vehicalid = vehicalid;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicalid", long.class);

				method.invoke(_activeVehicleDetailRemoteModel, vehicalid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_activeVehicleDetailRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getClasscode() {
		return _classcode;
	}

	@Override
	public void setClasscode(String classcode) {
		_classcode = classcode;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setClasscode", String.class);

				method.invoke(_activeVehicleDetailRemoteModel, classcode);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getByVehicle() {
		return _byVehicle;
	}

	@Override
	public void setByVehicle(String byVehicle) {
		_byVehicle = byVehicle;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setByVehicle", String.class);

				method.invoke(_activeVehicleDetailRemoteModel, byVehicle);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWithoutMotor() {
		return _withoutMotor;
	}

	@Override
	public void setWithoutMotor(String withoutMotor) {
		_withoutMotor = withoutMotor;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setWithoutMotor", String.class);

				method.invoke(_activeVehicleDetailRemoteModel, withoutMotor);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCommencement() {
		return _commencement;
	}

	@Override
	public void setCommencement(String commencement) {
		_commencement = commencement;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setCommencement", String.class);

				method.invoke(_activeVehicleDetailRemoteModel, commencement);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAgeLimit() {
		return _ageLimit;
	}

	@Override
	public void setAgeLimit(String ageLimit) {
		_ageLimit = ageLimit;

		if (_activeVehicleDetailRemoteModel != null) {
			try {
				Class<?> clazz = _activeVehicleDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setAgeLimit", String.class);

				method.invoke(_activeVehicleDetailRemoteModel, ageLimit);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getActiveVehicleDetailRemoteModel() {
		return _activeVehicleDetailRemoteModel;
	}

	public void setActiveVehicleDetailRemoteModel(
		BaseModel<?> activeVehicleDetailRemoteModel) {
		_activeVehicleDetailRemoteModel = activeVehicleDetailRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _activeVehicleDetailRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_activeVehicleDetailRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			ActiveVehicleDetailLocalServiceUtil.addActiveVehicleDetail(this);
		}
		else {
			ActiveVehicleDetailLocalServiceUtil.updateActiveVehicleDetail(this);
		}
	}

	@Override
	public ActiveVehicleDetail toEscapedModel() {
		return (ActiveVehicleDetail)ProxyUtil.newProxyInstance(ActiveVehicleDetail.class.getClassLoader(),
			new Class[] { ActiveVehicleDetail.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		ActiveVehicleDetailClp clone = new ActiveVehicleDetailClp();

		clone.setVehicalid(getVehicalid());
		clone.setBilId(getBilId());
		clone.setClasscode(getClasscode());
		clone.setByVehicle(getByVehicle());
		clone.setWithoutMotor(getWithoutMotor());
		clone.setCommencement(getCommencement());
		clone.setAgeLimit(getAgeLimit());

		return clone;
	}

	@Override
	public int compareTo(ActiveVehicleDetail activeVehicleDetail) {
		long primaryKey = activeVehicleDetail.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ActiveVehicleDetailClp)) {
			return false;
		}

		ActiveVehicleDetailClp activeVehicleDetail = (ActiveVehicleDetailClp)obj;

		long primaryKey = activeVehicleDetail.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{vehicalid=");
		sb.append(getVehicalid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", classcode=");
		sb.append(getClasscode());
		sb.append(", byVehicle=");
		sb.append(getByVehicle());
		sb.append(", withoutMotor=");
		sb.append(getWithoutMotor());
		sb.append(", commencement=");
		sb.append(getCommencement());
		sb.append(", ageLimit=");
		sb.append(getAgeLimit());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(25);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.ActiveVehicleDetail");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>vehicalid</column-name><column-value><![CDATA[");
		sb.append(getVehicalid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>classcode</column-name><column-value><![CDATA[");
		sb.append(getClasscode());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>byVehicle</column-name><column-value><![CDATA[");
		sb.append(getByVehicle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>withoutMotor</column-name><column-value><![CDATA[");
		sb.append(getWithoutMotor());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>commencement</column-name><column-value><![CDATA[");
		sb.append(getCommencement());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ageLimit</column-name><column-value><![CDATA[");
		sb.append(getAgeLimit());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _vehicalid;
	private long _bilId;
	private String _classcode;
	private String _byVehicle;
	private String _withoutMotor;
	private String _commencement;
	private String _ageLimit;
	private BaseModel<?> _activeVehicleDetailRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}