/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ErrorTypes}.
 * </p>
 *
 * @author reeshu
 * @see ErrorTypes
 * @generated
 */
public class ErrorTypesWrapper implements ErrorTypes, ModelWrapper<ErrorTypes> {
	public ErrorTypesWrapper(ErrorTypes errorTypes) {
		_errorTypes = errorTypes;
	}

	@Override
	public Class<?> getModelClass() {
		return ErrorTypes.class;
	}

	@Override
	public String getModelClassName() {
		return ErrorTypes.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("errortypeid", getErrortypeid());
		attributes.put("errortypes", getErrortypes());
		attributes.put("sourcetypes", getSourcetypes());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long errortypeid = (Long)attributes.get("errortypeid");

		if (errortypeid != null) {
			setErrortypeid(errortypeid);
		}

		String errortypes = (String)attributes.get("errortypes");

		if (errortypes != null) {
			setErrortypes(errortypes);
		}

		String sourcetypes = (String)attributes.get("sourcetypes");

		if (sourcetypes != null) {
			setSourcetypes(sourcetypes);
		}
	}

	/**
	* Returns the primary key of this error types.
	*
	* @return the primary key of this error types
	*/
	@Override
	public long getPrimaryKey() {
		return _errorTypes.getPrimaryKey();
	}

	/**
	* Sets the primary key of this error types.
	*
	* @param primaryKey the primary key of this error types
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_errorTypes.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the errortypeid of this error types.
	*
	* @return the errortypeid of this error types
	*/
	@Override
	public long getErrortypeid() {
		return _errorTypes.getErrortypeid();
	}

	/**
	* Sets the errortypeid of this error types.
	*
	* @param errortypeid the errortypeid of this error types
	*/
	@Override
	public void setErrortypeid(long errortypeid) {
		_errorTypes.setErrortypeid(errortypeid);
	}

	/**
	* Returns the errortypes of this error types.
	*
	* @return the errortypes of this error types
	*/
	@Override
	public java.lang.String getErrortypes() {
		return _errorTypes.getErrortypes();
	}

	/**
	* Sets the errortypes of this error types.
	*
	* @param errortypes the errortypes of this error types
	*/
	@Override
	public void setErrortypes(java.lang.String errortypes) {
		_errorTypes.setErrortypes(errortypes);
	}

	/**
	* Returns the sourcetypes of this error types.
	*
	* @return the sourcetypes of this error types
	*/
	@Override
	public java.lang.String getSourcetypes() {
		return _errorTypes.getSourcetypes();
	}

	/**
	* Sets the sourcetypes of this error types.
	*
	* @param sourcetypes the sourcetypes of this error types
	*/
	@Override
	public void setSourcetypes(java.lang.String sourcetypes) {
		_errorTypes.setSourcetypes(sourcetypes);
	}

	@Override
	public boolean isNew() {
		return _errorTypes.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_errorTypes.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _errorTypes.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_errorTypes.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _errorTypes.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _errorTypes.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_errorTypes.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _errorTypes.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_errorTypes.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_errorTypes.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_errorTypes.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ErrorTypesWrapper((ErrorTypes)_errorTypes.clone());
	}

	@Override
	public int compareTo(ErrorTypes errorTypes) {
		return _errorTypes.compareTo(errorTypes);
	}

	@Override
	public int hashCode() {
		return _errorTypes.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<ErrorTypes> toCacheModel() {
		return _errorTypes.toCacheModel();
	}

	@Override
	public ErrorTypes toEscapedModel() {
		return new ErrorTypesWrapper(_errorTypes.toEscapedModel());
	}

	@Override
	public ErrorTypes toUnescapedModel() {
		return new ErrorTypesWrapper(_errorTypes.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _errorTypes.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _errorTypes.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_errorTypes.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ErrorTypesWrapper)) {
			return false;
		}

		ErrorTypesWrapper errorTypesWrapper = (ErrorTypesWrapper)obj;

		if (Validator.equals(_errorTypes, errorTypesWrapper._errorTypes)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ErrorTypes getWrappedErrorTypes() {
		return _errorTypes;
	}

	@Override
	public ErrorTypes getWrappedModel() {
		return _errorTypes;
	}

	@Override
	public void resetOriginalValues() {
		_errorTypes.resetOriginalValues();
	}

	private ErrorTypes _errorTypes;
}