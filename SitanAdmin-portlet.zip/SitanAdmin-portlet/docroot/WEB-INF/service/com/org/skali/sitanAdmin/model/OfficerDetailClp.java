/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.OfficerDetailLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class OfficerDetailClp extends BaseModelImpl<OfficerDetail>
	implements OfficerDetail {
	public OfficerDetailClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return OfficerDetail.class;
	}

	@Override
	public String getModelClassName() {
		return OfficerDetail.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _officerid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setOfficerid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _officerid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("officerid", getOfficerid());
		attributes.put("officername", getOfficername());
		attributes.put("officertype", getOfficertype());
		attributes.put("office", getOffice());
		attributes.put("Officerpower", getOfficerpower());
		attributes.put("Date", getDate());
		attributes.put("officerphone", getOfficerphone());
		attributes.put("officerEmail", getOfficerEmail());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long officerid = (Long)attributes.get("officerid");

		if (officerid != null) {
			setOfficerid(officerid);
		}

		String officername = (String)attributes.get("officername");

		if (officername != null) {
			setOfficername(officername);
		}

		String officertype = (String)attributes.get("officertype");

		if (officertype != null) {
			setOfficertype(officertype);
		}

		String office = (String)attributes.get("office");

		if (office != null) {
			setOffice(office);
		}

		String Officerpower = (String)attributes.get("Officerpower");

		if (Officerpower != null) {
			setOfficerpower(Officerpower);
		}

		String Date = (String)attributes.get("Date");

		if (Date != null) {
			setDate(Date);
		}

		Long officerphone = (Long)attributes.get("officerphone");

		if (officerphone != null) {
			setOfficerphone(officerphone);
		}

		String officerEmail = (String)attributes.get("officerEmail");

		if (officerEmail != null) {
			setOfficerEmail(officerEmail);
		}
	}

	@Override
	public long getOfficerid() {
		return _officerid;
	}

	@Override
	public void setOfficerid(long officerid) {
		_officerid = officerid;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficerid", long.class);

				method.invoke(_officerDetailRemoteModel, officerid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOfficername() {
		return _officername;
	}

	@Override
	public void setOfficername(String officername) {
		_officername = officername;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficername", String.class);

				method.invoke(_officerDetailRemoteModel, officername);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOfficertype() {
		return _officertype;
	}

	@Override
	public void setOfficertype(String officertype) {
		_officertype = officertype;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficertype", String.class);

				method.invoke(_officerDetailRemoteModel, officertype);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOffice() {
		return _office;
	}

	@Override
	public void setOffice(String office) {
		_office = office;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOffice", String.class);

				method.invoke(_officerDetailRemoteModel, office);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOfficerpower() {
		return _Officerpower;
	}

	@Override
	public void setOfficerpower(String Officerpower) {
		_Officerpower = Officerpower;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficerpower", String.class);

				method.invoke(_officerDetailRemoteModel, Officerpower);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDate() {
		return _Date;
	}

	@Override
	public void setDate(String Date) {
		_Date = Date;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setDate", String.class);

				method.invoke(_officerDetailRemoteModel, Date);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getOfficerphone() {
		return _officerphone;
	}

	@Override
	public void setOfficerphone(long officerphone) {
		_officerphone = officerphone;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficerphone", long.class);

				method.invoke(_officerDetailRemoteModel, officerphone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOfficerEmail() {
		return _officerEmail;
	}

	@Override
	public void setOfficerEmail(String officerEmail) {
		_officerEmail = officerEmail;

		if (_officerDetailRemoteModel != null) {
			try {
				Class<?> clazz = _officerDetailRemoteModel.getClass();

				Method method = clazz.getMethod("setOfficerEmail", String.class);

				method.invoke(_officerDetailRemoteModel, officerEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getOfficerDetailRemoteModel() {
		return _officerDetailRemoteModel;
	}

	public void setOfficerDetailRemoteModel(
		BaseModel<?> officerDetailRemoteModel) {
		_officerDetailRemoteModel = officerDetailRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _officerDetailRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_officerDetailRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			OfficerDetailLocalServiceUtil.addOfficerDetail(this);
		}
		else {
			OfficerDetailLocalServiceUtil.updateOfficerDetail(this);
		}
	}

	@Override
	public OfficerDetail toEscapedModel() {
		return (OfficerDetail)ProxyUtil.newProxyInstance(OfficerDetail.class.getClassLoader(),
			new Class[] { OfficerDetail.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		OfficerDetailClp clone = new OfficerDetailClp();

		clone.setOfficerid(getOfficerid());
		clone.setOfficername(getOfficername());
		clone.setOfficertype(getOfficertype());
		clone.setOffice(getOffice());
		clone.setOfficerpower(getOfficerpower());
		clone.setDate(getDate());
		clone.setOfficerphone(getOfficerphone());
		clone.setOfficerEmail(getOfficerEmail());

		return clone;
	}

	@Override
	public int compareTo(OfficerDetail officerDetail) {
		long primaryKey = officerDetail.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OfficerDetailClp)) {
			return false;
		}

		OfficerDetailClp officerDetail = (OfficerDetailClp)obj;

		long primaryKey = officerDetail.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{officerid=");
		sb.append(getOfficerid());
		sb.append(", officername=");
		sb.append(getOfficername());
		sb.append(", officertype=");
		sb.append(getOfficertype());
		sb.append(", office=");
		sb.append(getOffice());
		sb.append(", Officerpower=");
		sb.append(getOfficerpower());
		sb.append(", Date=");
		sb.append(getDate());
		sb.append(", officerphone=");
		sb.append(getOfficerphone());
		sb.append(", officerEmail=");
		sb.append(getOfficerEmail());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.OfficerDetail");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>officerid</column-name><column-value><![CDATA[");
		sb.append(getOfficerid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>officername</column-name><column-value><![CDATA[");
		sb.append(getOfficername());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>officertype</column-name><column-value><![CDATA[");
		sb.append(getOfficertype());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>office</column-name><column-value><![CDATA[");
		sb.append(getOffice());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>Officerpower</column-name><column-value><![CDATA[");
		sb.append(getOfficerpower());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>Date</column-name><column-value><![CDATA[");
		sb.append(getDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>officerphone</column-name><column-value><![CDATA[");
		sb.append(getOfficerphone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>officerEmail</column-name><column-value><![CDATA[");
		sb.append(getOfficerEmail());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _officerid;
	private String _officername;
	private String _officertype;
	private String _office;
	private String _Officerpower;
	private String _Date;
	private long _officerphone;
	private String _officerEmail;
	private BaseModel<?> _officerDetailRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}