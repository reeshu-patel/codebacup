/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link detailoksboyds}.
 * </p>
 *
 * @author reeshu
 * @see detailoksboyds
 * @generated
 */
public class detailoksboydsWrapper implements detailoksboyds,
	ModelWrapper<detailoksboyds> {
	public detailoksboydsWrapper(detailoksboyds detailoksboyds) {
		_detailoksboyds = detailoksboyds;
	}

	@Override
	public Class<?> getModelClass() {
		return detailoksboyds.class;
	}

	@Override
	public String getModelClassName() {
		return detailoksboyds.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("boydssId", getBoydssId());
		attributes.put("bilId", getBilId());
		attributes.put("companyName", getCompanyName());
		attributes.put("classOperatorLicense", getClassOperatorLicense());
		attributes.put("listofCompanies", getListofCompanies());
		attributes.put("reRegistration", getReRegistration());
		attributes.put("email", getEmail());
		attributes.put("noReferenceFile", getNoReferenceFile());
		attributes.put("addressList", getAddressList());
		attributes.put("addressListRegistation", getAddressListRegistation());
		attributes.put("authorisedCapital", getAuthorisedCapital());
		attributes.put("accruedCapital", getAccruedCapital());
		attributes.put("capitalPaid", getCapitalPaid());
		attributes.put("ComRegNo", getComRegNo());
		attributes.put("nationOwner", getNationOwner());
		attributes.put("dateListofCompanies", getDateListofCompanies());
		attributes.put("activity", getActivity());
		attributes.put("phoneNo", getPhoneNo());
		attributes.put("faxNo", getFaxNo());
		attributes.put("lastUpdateDate", getLastUpdateDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long boydssId = (Long)attributes.get("boydssId");

		if (boydssId != null) {
			setBoydssId(boydssId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String classOperatorLicense = (String)attributes.get(
				"classOperatorLicense");

		if (classOperatorLicense != null) {
			setClassOperatorLicense(classOperatorLicense);
		}

		String listofCompanies = (String)attributes.get("listofCompanies");

		if (listofCompanies != null) {
			setListofCompanies(listofCompanies);
		}

		String reRegistration = (String)attributes.get("reRegistration");

		if (reRegistration != null) {
			setReRegistration(reRegistration);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String noReferenceFile = (String)attributes.get("noReferenceFile");

		if (noReferenceFile != null) {
			setNoReferenceFile(noReferenceFile);
		}

		String addressList = (String)attributes.get("addressList");

		if (addressList != null) {
			setAddressList(addressList);
		}

		String addressListRegistation = (String)attributes.get(
				"addressListRegistation");

		if (addressListRegistation != null) {
			setAddressListRegistation(addressListRegistation);
		}

		String authorisedCapital = (String)attributes.get("authorisedCapital");

		if (authorisedCapital != null) {
			setAuthorisedCapital(authorisedCapital);
		}

		Long accruedCapital = (Long)attributes.get("accruedCapital");

		if (accruedCapital != null) {
			setAccruedCapital(accruedCapital);
		}

		String capitalPaid = (String)attributes.get("capitalPaid");

		if (capitalPaid != null) {
			setCapitalPaid(capitalPaid);
		}

		Long ComRegNo = (Long)attributes.get("ComRegNo");

		if (ComRegNo != null) {
			setComRegNo(ComRegNo);
		}

		String nationOwner = (String)attributes.get("nationOwner");

		if (nationOwner != null) {
			setNationOwner(nationOwner);
		}

		String dateListofCompanies = (String)attributes.get(
				"dateListofCompanies");

		if (dateListofCompanies != null) {
			setDateListofCompanies(dateListofCompanies);
		}

		String activity = (String)attributes.get("activity");

		if (activity != null) {
			setActivity(activity);
		}

		String phoneNo = (String)attributes.get("phoneNo");

		if (phoneNo != null) {
			setPhoneNo(phoneNo);
		}

		String faxNo = (String)attributes.get("faxNo");

		if (faxNo != null) {
			setFaxNo(faxNo);
		}

		String lastUpdateDate = (String)attributes.get("lastUpdateDate");

		if (lastUpdateDate != null) {
			setLastUpdateDate(lastUpdateDate);
		}
	}

	/**
	* Returns the primary key of this detailoksboyds.
	*
	* @return the primary key of this detailoksboyds
	*/
	@Override
	public long getPrimaryKey() {
		return _detailoksboyds.getPrimaryKey();
	}

	/**
	* Sets the primary key of this detailoksboyds.
	*
	* @param primaryKey the primary key of this detailoksboyds
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_detailoksboyds.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the boydss ID of this detailoksboyds.
	*
	* @return the boydss ID of this detailoksboyds
	*/
	@Override
	public long getBoydssId() {
		return _detailoksboyds.getBoydssId();
	}

	/**
	* Sets the boydss ID of this detailoksboyds.
	*
	* @param boydssId the boydss ID of this detailoksboyds
	*/
	@Override
	public void setBoydssId(long boydssId) {
		_detailoksboyds.setBoydssId(boydssId);
	}

	/**
	* Returns the bil ID of this detailoksboyds.
	*
	* @return the bil ID of this detailoksboyds
	*/
	@Override
	public long getBilId() {
		return _detailoksboyds.getBilId();
	}

	/**
	* Sets the bil ID of this detailoksboyds.
	*
	* @param bilId the bil ID of this detailoksboyds
	*/
	@Override
	public void setBilId(long bilId) {
		_detailoksboyds.setBilId(bilId);
	}

	/**
	* Returns the company name of this detailoksboyds.
	*
	* @return the company name of this detailoksboyds
	*/
	@Override
	public java.lang.String getCompanyName() {
		return _detailoksboyds.getCompanyName();
	}

	/**
	* Sets the company name of this detailoksboyds.
	*
	* @param companyName the company name of this detailoksboyds
	*/
	@Override
	public void setCompanyName(java.lang.String companyName) {
		_detailoksboyds.setCompanyName(companyName);
	}

	/**
	* Returns the class operator license of this detailoksboyds.
	*
	* @return the class operator license of this detailoksboyds
	*/
	@Override
	public java.lang.String getClassOperatorLicense() {
		return _detailoksboyds.getClassOperatorLicense();
	}

	/**
	* Sets the class operator license of this detailoksboyds.
	*
	* @param classOperatorLicense the class operator license of this detailoksboyds
	*/
	@Override
	public void setClassOperatorLicense(java.lang.String classOperatorLicense) {
		_detailoksboyds.setClassOperatorLicense(classOperatorLicense);
	}

	/**
	* Returns the listof companies of this detailoksboyds.
	*
	* @return the listof companies of this detailoksboyds
	*/
	@Override
	public java.lang.String getListofCompanies() {
		return _detailoksboyds.getListofCompanies();
	}

	/**
	* Sets the listof companies of this detailoksboyds.
	*
	* @param listofCompanies the listof companies of this detailoksboyds
	*/
	@Override
	public void setListofCompanies(java.lang.String listofCompanies) {
		_detailoksboyds.setListofCompanies(listofCompanies);
	}

	/**
	* Returns the re registration of this detailoksboyds.
	*
	* @return the re registration of this detailoksboyds
	*/
	@Override
	public java.lang.String getReRegistration() {
		return _detailoksboyds.getReRegistration();
	}

	/**
	* Sets the re registration of this detailoksboyds.
	*
	* @param reRegistration the re registration of this detailoksboyds
	*/
	@Override
	public void setReRegistration(java.lang.String reRegistration) {
		_detailoksboyds.setReRegistration(reRegistration);
	}

	/**
	* Returns the email of this detailoksboyds.
	*
	* @return the email of this detailoksboyds
	*/
	@Override
	public java.lang.String getEmail() {
		return _detailoksboyds.getEmail();
	}

	/**
	* Sets the email of this detailoksboyds.
	*
	* @param email the email of this detailoksboyds
	*/
	@Override
	public void setEmail(java.lang.String email) {
		_detailoksboyds.setEmail(email);
	}

	/**
	* Returns the no reference file of this detailoksboyds.
	*
	* @return the no reference file of this detailoksboyds
	*/
	@Override
	public java.lang.String getNoReferenceFile() {
		return _detailoksboyds.getNoReferenceFile();
	}

	/**
	* Sets the no reference file of this detailoksboyds.
	*
	* @param noReferenceFile the no reference file of this detailoksboyds
	*/
	@Override
	public void setNoReferenceFile(java.lang.String noReferenceFile) {
		_detailoksboyds.setNoReferenceFile(noReferenceFile);
	}

	/**
	* Returns the address list of this detailoksboyds.
	*
	* @return the address list of this detailoksboyds
	*/
	@Override
	public java.lang.String getAddressList() {
		return _detailoksboyds.getAddressList();
	}

	/**
	* Sets the address list of this detailoksboyds.
	*
	* @param addressList the address list of this detailoksboyds
	*/
	@Override
	public void setAddressList(java.lang.String addressList) {
		_detailoksboyds.setAddressList(addressList);
	}

	/**
	* Returns the address list registation of this detailoksboyds.
	*
	* @return the address list registation of this detailoksboyds
	*/
	@Override
	public java.lang.String getAddressListRegistation() {
		return _detailoksboyds.getAddressListRegistation();
	}

	/**
	* Sets the address list registation of this detailoksboyds.
	*
	* @param addressListRegistation the address list registation of this detailoksboyds
	*/
	@Override
	public void setAddressListRegistation(
		java.lang.String addressListRegistation) {
		_detailoksboyds.setAddressListRegistation(addressListRegistation);
	}

	/**
	* Returns the authorised capital of this detailoksboyds.
	*
	* @return the authorised capital of this detailoksboyds
	*/
	@Override
	public java.lang.String getAuthorisedCapital() {
		return _detailoksboyds.getAuthorisedCapital();
	}

	/**
	* Sets the authorised capital of this detailoksboyds.
	*
	* @param authorisedCapital the authorised capital of this detailoksboyds
	*/
	@Override
	public void setAuthorisedCapital(java.lang.String authorisedCapital) {
		_detailoksboyds.setAuthorisedCapital(authorisedCapital);
	}

	/**
	* Returns the accrued capital of this detailoksboyds.
	*
	* @return the accrued capital of this detailoksboyds
	*/
	@Override
	public long getAccruedCapital() {
		return _detailoksboyds.getAccruedCapital();
	}

	/**
	* Sets the accrued capital of this detailoksboyds.
	*
	* @param accruedCapital the accrued capital of this detailoksboyds
	*/
	@Override
	public void setAccruedCapital(long accruedCapital) {
		_detailoksboyds.setAccruedCapital(accruedCapital);
	}

	/**
	* Returns the capital paid of this detailoksboyds.
	*
	* @return the capital paid of this detailoksboyds
	*/
	@Override
	public java.lang.String getCapitalPaid() {
		return _detailoksboyds.getCapitalPaid();
	}

	/**
	* Sets the capital paid of this detailoksboyds.
	*
	* @param capitalPaid the capital paid of this detailoksboyds
	*/
	@Override
	public void setCapitalPaid(java.lang.String capitalPaid) {
		_detailoksboyds.setCapitalPaid(capitalPaid);
	}

	/**
	* Returns the com reg no of this detailoksboyds.
	*
	* @return the com reg no of this detailoksboyds
	*/
	@Override
	public long getComRegNo() {
		return _detailoksboyds.getComRegNo();
	}

	/**
	* Sets the com reg no of this detailoksboyds.
	*
	* @param ComRegNo the com reg no of this detailoksboyds
	*/
	@Override
	public void setComRegNo(long ComRegNo) {
		_detailoksboyds.setComRegNo(ComRegNo);
	}

	/**
	* Returns the nation owner of this detailoksboyds.
	*
	* @return the nation owner of this detailoksboyds
	*/
	@Override
	public java.lang.String getNationOwner() {
		return _detailoksboyds.getNationOwner();
	}

	/**
	* Sets the nation owner of this detailoksboyds.
	*
	* @param nationOwner the nation owner of this detailoksboyds
	*/
	@Override
	public void setNationOwner(java.lang.String nationOwner) {
		_detailoksboyds.setNationOwner(nationOwner);
	}

	/**
	* Returns the date listof companies of this detailoksboyds.
	*
	* @return the date listof companies of this detailoksboyds
	*/
	@Override
	public java.lang.String getDateListofCompanies() {
		return _detailoksboyds.getDateListofCompanies();
	}

	/**
	* Sets the date listof companies of this detailoksboyds.
	*
	* @param dateListofCompanies the date listof companies of this detailoksboyds
	*/
	@Override
	public void setDateListofCompanies(java.lang.String dateListofCompanies) {
		_detailoksboyds.setDateListofCompanies(dateListofCompanies);
	}

	/**
	* Returns the activity of this detailoksboyds.
	*
	* @return the activity of this detailoksboyds
	*/
	@Override
	public java.lang.String getActivity() {
		return _detailoksboyds.getActivity();
	}

	/**
	* Sets the activity of this detailoksboyds.
	*
	* @param activity the activity of this detailoksboyds
	*/
	@Override
	public void setActivity(java.lang.String activity) {
		_detailoksboyds.setActivity(activity);
	}

	/**
	* Returns the phone no of this detailoksboyds.
	*
	* @return the phone no of this detailoksboyds
	*/
	@Override
	public java.lang.String getPhoneNo() {
		return _detailoksboyds.getPhoneNo();
	}

	/**
	* Sets the phone no of this detailoksboyds.
	*
	* @param phoneNo the phone no of this detailoksboyds
	*/
	@Override
	public void setPhoneNo(java.lang.String phoneNo) {
		_detailoksboyds.setPhoneNo(phoneNo);
	}

	/**
	* Returns the fax no of this detailoksboyds.
	*
	* @return the fax no of this detailoksboyds
	*/
	@Override
	public java.lang.String getFaxNo() {
		return _detailoksboyds.getFaxNo();
	}

	/**
	* Sets the fax no of this detailoksboyds.
	*
	* @param faxNo the fax no of this detailoksboyds
	*/
	@Override
	public void setFaxNo(java.lang.String faxNo) {
		_detailoksboyds.setFaxNo(faxNo);
	}

	/**
	* Returns the last update date of this detailoksboyds.
	*
	* @return the last update date of this detailoksboyds
	*/
	@Override
	public java.lang.String getLastUpdateDate() {
		return _detailoksboyds.getLastUpdateDate();
	}

	/**
	* Sets the last update date of this detailoksboyds.
	*
	* @param lastUpdateDate the last update date of this detailoksboyds
	*/
	@Override
	public void setLastUpdateDate(java.lang.String lastUpdateDate) {
		_detailoksboyds.setLastUpdateDate(lastUpdateDate);
	}

	@Override
	public boolean isNew() {
		return _detailoksboyds.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_detailoksboyds.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _detailoksboyds.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_detailoksboyds.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _detailoksboyds.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _detailoksboyds.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_detailoksboyds.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _detailoksboyds.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_detailoksboyds.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_detailoksboyds.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_detailoksboyds.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new detailoksboydsWrapper((detailoksboyds)_detailoksboyds.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.detailoksboyds detailoksboyds) {
		return _detailoksboyds.compareTo(detailoksboyds);
	}

	@Override
	public int hashCode() {
		return _detailoksboyds.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.detailoksboyds> toCacheModel() {
		return _detailoksboyds.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.detailoksboyds toEscapedModel() {
		return new detailoksboydsWrapper(_detailoksboyds.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.detailoksboyds toUnescapedModel() {
		return new detailoksboydsWrapper(_detailoksboyds.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _detailoksboyds.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _detailoksboyds.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_detailoksboyds.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof detailoksboydsWrapper)) {
			return false;
		}

		detailoksboydsWrapper detailoksboydsWrapper = (detailoksboydsWrapper)obj;

		if (Validator.equals(_detailoksboyds,
					detailoksboydsWrapper._detailoksboyds)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public detailoksboyds getWrappeddetailoksboyds() {
		return _detailoksboyds;
	}

	@Override
	public detailoksboyds getWrappedModel() {
		return _detailoksboyds;
	}

	@Override
	public void resetOriginalValues() {
		_detailoksboyds.resetOriginalValues();
	}

	private detailoksboyds _detailoksboyds;
}