/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.ErrortypesSourceServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.ErrortypesSourceServiceSoap
 * @generated
 */
public class ErrortypesSourceSoap implements Serializable {
	public static ErrortypesSourceSoap toSoapModel(ErrortypesSource model) {
		ErrortypesSourceSoap soapModel = new ErrortypesSourceSoap();

		soapModel.setErrortypeid(model.getErrortypeid());
		soapModel.setBilId(model.getBilId());
		soapModel.setErrortypes(model.getErrortypes());
		soapModel.setSourcetypes(model.getSourcetypes());

		return soapModel;
	}

	public static ErrortypesSourceSoap[] toSoapModels(ErrortypesSource[] models) {
		ErrortypesSourceSoap[] soapModels = new ErrortypesSourceSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ErrortypesSourceSoap[][] toSoapModels(
		ErrortypesSource[][] models) {
		ErrortypesSourceSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ErrortypesSourceSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ErrortypesSourceSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ErrortypesSourceSoap[] toSoapModels(
		List<ErrortypesSource> models) {
		List<ErrortypesSourceSoap> soapModels = new ArrayList<ErrortypesSourceSoap>(models.size());

		for (ErrortypesSource model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ErrortypesSourceSoap[soapModels.size()]);
	}

	public ErrortypesSourceSoap() {
	}

	public long getPrimaryKey() {
		return _errortypeid;
	}

	public void setPrimaryKey(long pk) {
		setErrortypeid(pk);
	}

	public long getErrortypeid() {
		return _errortypeid;
	}

	public void setErrortypeid(long errortypeid) {
		_errortypeid = errortypeid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getErrortypes() {
		return _errortypes;
	}

	public void setErrortypes(String errortypes) {
		_errortypes = errortypes;
	}

	public String getSourcetypes() {
		return _sourcetypes;
	}

	public void setSourcetypes(String sourcetypes) {
		_sourcetypes = sourcetypes;
	}

	private long _errortypeid;
	private long _bilId;
	private String _errortypes;
	private String _sourcetypes;
}