/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link InqueryService}.
 *
 * @author reeshu
 * @see InqueryService
 * @generated
 */
public class InqueryServiceWrapper implements InqueryService,
	ServiceWrapper<InqueryService> {
	public InqueryServiceWrapper(InqueryService inqueryService) {
		_inqueryService = inqueryService;
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _inqueryService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_inqueryService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _inqueryService.invokeMethod(name, parameterTypes, arguments);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject getInqueryData(
		java.lang.String datesize, java.lang.String checkSitesDate,
		java.lang.String referenceEffective, java.lang.String source,
		java.lang.String nameofowner, java.lang.String vehicleRegistration,
		java.lang.String territory, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String nameOfofficer) throws java.text.ParseException {
		return _inqueryService.getInqueryData(datesize, checkSitesDate,
			referenceEffective, source, nameofowner, vehicleRegistration,
			territory, state, locationCageSita, foreclosureStatus, nameOfofficer);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public InqueryService getWrappedInqueryService() {
		return _inqueryService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedInqueryService(InqueryService inqueryService) {
		_inqueryService = inqueryService;
	}

	@Override
	public InqueryService getWrappedService() {
		return _inqueryService;
	}

	@Override
	public void setWrappedService(InqueryService inqueryService) {
		_inqueryService = inqueryService;
	}

	private InqueryService _inqueryService;
}