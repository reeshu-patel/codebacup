/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.SourceTypesServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.SourceTypesServiceSoap
 * @generated
 */
public class SourceTypesSoap implements Serializable {
	public static SourceTypesSoap toSoapModel(SourceTypes model) {
		SourceTypesSoap soapModel = new SourceTypesSoap();

		soapModel.setSourcetypeid(model.getSourcetypeid());
		soapModel.setBilId(model.getBilId());
		soapModel.setErrortypes(model.getErrortypes());
		soapModel.setSourcetypes(model.getSourcetypes());

		return soapModel;
	}

	public static SourceTypesSoap[] toSoapModels(SourceTypes[] models) {
		SourceTypesSoap[] soapModels = new SourceTypesSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SourceTypesSoap[][] toSoapModels(SourceTypes[][] models) {
		SourceTypesSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SourceTypesSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SourceTypesSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SourceTypesSoap[] toSoapModels(List<SourceTypes> models) {
		List<SourceTypesSoap> soapModels = new ArrayList<SourceTypesSoap>(models.size());

		for (SourceTypes model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SourceTypesSoap[soapModels.size()]);
	}

	public SourceTypesSoap() {
	}

	public long getPrimaryKey() {
		return _sourcetypeid;
	}

	public void setPrimaryKey(long pk) {
		setSourcetypeid(pk);
	}

	public long getSourcetypeid() {
		return _sourcetypeid;
	}

	public void setSourcetypeid(long sourcetypeid) {
		_sourcetypeid = sourcetypeid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getErrortypes() {
		return _errortypes;
	}

	public void setErrortypes(String errortypes) {
		_errortypes = errortypes;
	}

	public String getSourcetypes() {
		return _sourcetypes;
	}

	public void setSourcetypes(String sourcetypes) {
		_sourcetypes = sourcetypes;
	}

	private long _sourcetypeid;
	private long _bilId;
	private String _errortypes;
	private String _sourcetypes;
}