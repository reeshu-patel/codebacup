/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.detailoksboydsLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class detailoksboydsClp extends BaseModelImpl<detailoksboyds>
	implements detailoksboyds {
	public detailoksboydsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return detailoksboyds.class;
	}

	@Override
	public String getModelClassName() {
		return detailoksboyds.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _boydssId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setBoydssId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _boydssId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("boydssId", getBoydssId());
		attributes.put("bilId", getBilId());
		attributes.put("companyName", getCompanyName());
		attributes.put("classOperatorLicense", getClassOperatorLicense());
		attributes.put("listofCompanies", getListofCompanies());
		attributes.put("reRegistration", getReRegistration());
		attributes.put("email", getEmail());
		attributes.put("noReferenceFile", getNoReferenceFile());
		attributes.put("addressList", getAddressList());
		attributes.put("addressListRegistation", getAddressListRegistation());
		attributes.put("authorisedCapital", getAuthorisedCapital());
		attributes.put("accruedCapital", getAccruedCapital());
		attributes.put("capitalPaid", getCapitalPaid());
		attributes.put("ComRegNo", getComRegNo());
		attributes.put("nationOwner", getNationOwner());
		attributes.put("dateListofCompanies", getDateListofCompanies());
		attributes.put("activity", getActivity());
		attributes.put("phoneNo", getPhoneNo());
		attributes.put("faxNo", getFaxNo());
		attributes.put("lastUpdateDate", getLastUpdateDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long boydssId = (Long)attributes.get("boydssId");

		if (boydssId != null) {
			setBoydssId(boydssId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String classOperatorLicense = (String)attributes.get(
				"classOperatorLicense");

		if (classOperatorLicense != null) {
			setClassOperatorLicense(classOperatorLicense);
		}

		String listofCompanies = (String)attributes.get("listofCompanies");

		if (listofCompanies != null) {
			setListofCompanies(listofCompanies);
		}

		String reRegistration = (String)attributes.get("reRegistration");

		if (reRegistration != null) {
			setReRegistration(reRegistration);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String noReferenceFile = (String)attributes.get("noReferenceFile");

		if (noReferenceFile != null) {
			setNoReferenceFile(noReferenceFile);
		}

		String addressList = (String)attributes.get("addressList");

		if (addressList != null) {
			setAddressList(addressList);
		}

		String addressListRegistation = (String)attributes.get(
				"addressListRegistation");

		if (addressListRegistation != null) {
			setAddressListRegistation(addressListRegistation);
		}

		String authorisedCapital = (String)attributes.get("authorisedCapital");

		if (authorisedCapital != null) {
			setAuthorisedCapital(authorisedCapital);
		}

		Long accruedCapital = (Long)attributes.get("accruedCapital");

		if (accruedCapital != null) {
			setAccruedCapital(accruedCapital);
		}

		String capitalPaid = (String)attributes.get("capitalPaid");

		if (capitalPaid != null) {
			setCapitalPaid(capitalPaid);
		}

		Long ComRegNo = (Long)attributes.get("ComRegNo");

		if (ComRegNo != null) {
			setComRegNo(ComRegNo);
		}

		String nationOwner = (String)attributes.get("nationOwner");

		if (nationOwner != null) {
			setNationOwner(nationOwner);
		}

		String dateListofCompanies = (String)attributes.get(
				"dateListofCompanies");

		if (dateListofCompanies != null) {
			setDateListofCompanies(dateListofCompanies);
		}

		String activity = (String)attributes.get("activity");

		if (activity != null) {
			setActivity(activity);
		}

		String phoneNo = (String)attributes.get("phoneNo");

		if (phoneNo != null) {
			setPhoneNo(phoneNo);
		}

		String faxNo = (String)attributes.get("faxNo");

		if (faxNo != null) {
			setFaxNo(faxNo);
		}

		String lastUpdateDate = (String)attributes.get("lastUpdateDate");

		if (lastUpdateDate != null) {
			setLastUpdateDate(lastUpdateDate);
		}
	}

	@Override
	public long getBoydssId() {
		return _boydssId;
	}

	@Override
	public void setBoydssId(long boydssId) {
		_boydssId = boydssId;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setBoydssId", long.class);

				method.invoke(_detailoksboydsRemoteModel, boydssId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_detailoksboydsRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompanyName() {
		return _companyName;
	}

	@Override
	public void setCompanyName(String companyName) {
		_companyName = companyName;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyName", String.class);

				method.invoke(_detailoksboydsRemoteModel, companyName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getClassOperatorLicense() {
		return _classOperatorLicense;
	}

	@Override
	public void setClassOperatorLicense(String classOperatorLicense) {
		_classOperatorLicense = classOperatorLicense;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setClassOperatorLicense",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, classOperatorLicense);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getListofCompanies() {
		return _listofCompanies;
	}

	@Override
	public void setListofCompanies(String listofCompanies) {
		_listofCompanies = listofCompanies;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setListofCompanies",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, listofCompanies);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getReRegistration() {
		return _reRegistration;
	}

	@Override
	public void setReRegistration(String reRegistration) {
		_reRegistration = reRegistration;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setReRegistration",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, reRegistration);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_detailoksboydsRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNoReferenceFile() {
		return _noReferenceFile;
	}

	@Override
	public void setNoReferenceFile(String noReferenceFile) {
		_noReferenceFile = noReferenceFile;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setNoReferenceFile",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, noReferenceFile);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddressList() {
		return _addressList;
	}

	@Override
	public void setAddressList(String addressList) {
		_addressList = addressList;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setAddressList", String.class);

				method.invoke(_detailoksboydsRemoteModel, addressList);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddressListRegistation() {
		return _addressListRegistation;
	}

	@Override
	public void setAddressListRegistation(String addressListRegistation) {
		_addressListRegistation = addressListRegistation;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setAddressListRegistation",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, addressListRegistation);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuthorisedCapital() {
		return _authorisedCapital;
	}

	@Override
	public void setAuthorisedCapital(String authorisedCapital) {
		_authorisedCapital = authorisedCapital;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setAuthorisedCapital",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, authorisedCapital);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAccruedCapital() {
		return _accruedCapital;
	}

	@Override
	public void setAccruedCapital(long accruedCapital) {
		_accruedCapital = accruedCapital;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setAccruedCapital", long.class);

				method.invoke(_detailoksboydsRemoteModel, accruedCapital);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCapitalPaid() {
		return _capitalPaid;
	}

	@Override
	public void setCapitalPaid(String capitalPaid) {
		_capitalPaid = capitalPaid;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setCapitalPaid", String.class);

				method.invoke(_detailoksboydsRemoteModel, capitalPaid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getComRegNo() {
		return _ComRegNo;
	}

	@Override
	public void setComRegNo(long ComRegNo) {
		_ComRegNo = ComRegNo;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setComRegNo", long.class);

				method.invoke(_detailoksboydsRemoteModel, ComRegNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNationOwner() {
		return _nationOwner;
	}

	@Override
	public void setNationOwner(String nationOwner) {
		_nationOwner = nationOwner;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setNationOwner", String.class);

				method.invoke(_detailoksboydsRemoteModel, nationOwner);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateListofCompanies() {
		return _dateListofCompanies;
	}

	@Override
	public void setDateListofCompanies(String dateListofCompanies) {
		_dateListofCompanies = dateListofCompanies;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setDateListofCompanies",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, dateListofCompanies);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getActivity() {
		return _activity;
	}

	@Override
	public void setActivity(String activity) {
		_activity = activity;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setActivity", String.class);

				method.invoke(_detailoksboydsRemoteModel, activity);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPhoneNo() {
		return _phoneNo;
	}

	@Override
	public void setPhoneNo(String phoneNo) {
		_phoneNo = phoneNo;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setPhoneNo", String.class);

				method.invoke(_detailoksboydsRemoteModel, phoneNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFaxNo() {
		return _faxNo;
	}

	@Override
	public void setFaxNo(String faxNo) {
		_faxNo = faxNo;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setFaxNo", String.class);

				method.invoke(_detailoksboydsRemoteModel, faxNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLastUpdateDate() {
		return _lastUpdateDate;
	}

	@Override
	public void setLastUpdateDate(String lastUpdateDate) {
		_lastUpdateDate = lastUpdateDate;

		if (_detailoksboydsRemoteModel != null) {
			try {
				Class<?> clazz = _detailoksboydsRemoteModel.getClass();

				Method method = clazz.getMethod("setLastUpdateDate",
						String.class);

				method.invoke(_detailoksboydsRemoteModel, lastUpdateDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getdetailoksboydsRemoteModel() {
		return _detailoksboydsRemoteModel;
	}

	public void setdetailoksboydsRemoteModel(
		BaseModel<?> detailoksboydsRemoteModel) {
		_detailoksboydsRemoteModel = detailoksboydsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _detailoksboydsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_detailoksboydsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			detailoksboydsLocalServiceUtil.adddetailoksboyds(this);
		}
		else {
			detailoksboydsLocalServiceUtil.updatedetailoksboyds(this);
		}
	}

	@Override
	public detailoksboyds toEscapedModel() {
		return (detailoksboyds)ProxyUtil.newProxyInstance(detailoksboyds.class.getClassLoader(),
			new Class[] { detailoksboyds.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		detailoksboydsClp clone = new detailoksboydsClp();

		clone.setBoydssId(getBoydssId());
		clone.setBilId(getBilId());
		clone.setCompanyName(getCompanyName());
		clone.setClassOperatorLicense(getClassOperatorLicense());
		clone.setListofCompanies(getListofCompanies());
		clone.setReRegistration(getReRegistration());
		clone.setEmail(getEmail());
		clone.setNoReferenceFile(getNoReferenceFile());
		clone.setAddressList(getAddressList());
		clone.setAddressListRegistation(getAddressListRegistation());
		clone.setAuthorisedCapital(getAuthorisedCapital());
		clone.setAccruedCapital(getAccruedCapital());
		clone.setCapitalPaid(getCapitalPaid());
		clone.setComRegNo(getComRegNo());
		clone.setNationOwner(getNationOwner());
		clone.setDateListofCompanies(getDateListofCompanies());
		clone.setActivity(getActivity());
		clone.setPhoneNo(getPhoneNo());
		clone.setFaxNo(getFaxNo());
		clone.setLastUpdateDate(getLastUpdateDate());

		return clone;
	}

	@Override
	public int compareTo(detailoksboyds detailoksboyds) {
		long primaryKey = detailoksboyds.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof detailoksboydsClp)) {
			return false;
		}

		detailoksboydsClp detailoksboyds = (detailoksboydsClp)obj;

		long primaryKey = detailoksboyds.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(41);

		sb.append("{boydssId=");
		sb.append(getBoydssId());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", companyName=");
		sb.append(getCompanyName());
		sb.append(", classOperatorLicense=");
		sb.append(getClassOperatorLicense());
		sb.append(", listofCompanies=");
		sb.append(getListofCompanies());
		sb.append(", reRegistration=");
		sb.append(getReRegistration());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", noReferenceFile=");
		sb.append(getNoReferenceFile());
		sb.append(", addressList=");
		sb.append(getAddressList());
		sb.append(", addressListRegistation=");
		sb.append(getAddressListRegistation());
		sb.append(", authorisedCapital=");
		sb.append(getAuthorisedCapital());
		sb.append(", accruedCapital=");
		sb.append(getAccruedCapital());
		sb.append(", capitalPaid=");
		sb.append(getCapitalPaid());
		sb.append(", ComRegNo=");
		sb.append(getComRegNo());
		sb.append(", nationOwner=");
		sb.append(getNationOwner());
		sb.append(", dateListofCompanies=");
		sb.append(getDateListofCompanies());
		sb.append(", activity=");
		sb.append(getActivity());
		sb.append(", phoneNo=");
		sb.append(getPhoneNo());
		sb.append(", faxNo=");
		sb.append(getFaxNo());
		sb.append(", lastUpdateDate=");
		sb.append(getLastUpdateDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(64);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.detailoksboyds");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>boydssId</column-name><column-value><![CDATA[");
		sb.append(getBoydssId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyName</column-name><column-value><![CDATA[");
		sb.append(getCompanyName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>classOperatorLicense</column-name><column-value><![CDATA[");
		sb.append(getClassOperatorLicense());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>listofCompanies</column-name><column-value><![CDATA[");
		sb.append(getListofCompanies());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>reRegistration</column-name><column-value><![CDATA[");
		sb.append(getReRegistration());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>noReferenceFile</column-name><column-value><![CDATA[");
		sb.append(getNoReferenceFile());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>addressList</column-name><column-value><![CDATA[");
		sb.append(getAddressList());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>addressListRegistation</column-name><column-value><![CDATA[");
		sb.append(getAddressListRegistation());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>authorisedCapital</column-name><column-value><![CDATA[");
		sb.append(getAuthorisedCapital());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>accruedCapital</column-name><column-value><![CDATA[");
		sb.append(getAccruedCapital());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>capitalPaid</column-name><column-value><![CDATA[");
		sb.append(getCapitalPaid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ComRegNo</column-name><column-value><![CDATA[");
		sb.append(getComRegNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nationOwner</column-name><column-value><![CDATA[");
		sb.append(getNationOwner());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateListofCompanies</column-name><column-value><![CDATA[");
		sb.append(getDateListofCompanies());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>activity</column-name><column-value><![CDATA[");
		sb.append(getActivity());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>phoneNo</column-name><column-value><![CDATA[");
		sb.append(getPhoneNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>faxNo</column-name><column-value><![CDATA[");
		sb.append(getFaxNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>lastUpdateDate</column-name><column-value><![CDATA[");
		sb.append(getLastUpdateDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _boydssId;
	private long _bilId;
	private String _companyName;
	private String _classOperatorLicense;
	private String _listofCompanies;
	private String _reRegistration;
	private String _email;
	private String _noReferenceFile;
	private String _addressList;
	private String _addressListRegistation;
	private String _authorisedCapital;
	private long _accruedCapital;
	private String _capitalPaid;
	private long _ComRegNo;
	private String _nationOwner;
	private String _dateListofCompanies;
	private String _activity;
	private String _phoneNo;
	private String _faxNo;
	private String _lastUpdateDate;
	private BaseModel<?> _detailoksboydsRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}