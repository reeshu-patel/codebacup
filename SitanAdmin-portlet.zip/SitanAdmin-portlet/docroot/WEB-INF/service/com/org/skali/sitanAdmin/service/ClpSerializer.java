/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayInputStream;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayOutputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ClassLoaderObjectInputStream;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import com.org.skali.sitanAdmin.model.AcceptanceVehicleDetailClp;
import com.org.skali.sitanAdmin.model.ActionSummeryClp;
import com.org.skali.sitanAdmin.model.ActiveVehicleDetailClp;
import com.org.skali.sitanAdmin.model.BillInqueryClp;
import com.org.skali.sitanAdmin.model.BoardDirectorClp;
import com.org.skali.sitanAdmin.model.DocumentTreeClp;
import com.org.skali.sitanAdmin.model.EquityHoldersClp;
import com.org.skali.sitanAdmin.model.InqueryClp;
import com.org.skali.sitanAdmin.model.LicensesStatusClp;
import com.org.skali.sitanAdmin.model.OfficerDetailClp;
import com.org.skali.sitanAdmin.model.RecoredComunicationClp;
import com.org.skali.sitanAdmin.model.SitaanAdminClp;
import com.org.skali.sitanAdmin.model.SourceTypesClp;
import com.org.skali.sitanAdmin.model.complainUserinfoClp;
import com.org.skali.sitanAdmin.model.detailoksboydsClp;
import com.org.skali.sitanAdmin.model.vehicalInfoClp;
import com.org.skali.sitanAdmin.model.visualchecklistClp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;

/**
 * @author reeshu
 */
public class ClpSerializer {
	public static String getServletContextName() {
		if (Validator.isNotNull(_servletContextName)) {
			return _servletContextName;
		}

		synchronized (ClpSerializer.class) {
			if (Validator.isNotNull(_servletContextName)) {
				return _servletContextName;
			}

			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Class<?> portletPropsClass = classLoader.loadClass(
						"com.liferay.util.portlet.PortletProps");

				Method getMethod = portletPropsClass.getMethod("get",
						new Class<?>[] { String.class });

				String portletPropsServletContextName = (String)getMethod.invoke(null,
						"SitanAdmin-portlet-deployment-context");

				if (Validator.isNotNull(portletPropsServletContextName)) {
					_servletContextName = portletPropsServletContextName;
				}
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info(
						"Unable to locate deployment context from portlet properties");
				}
			}

			if (Validator.isNull(_servletContextName)) {
				try {
					String propsUtilServletContextName = PropsUtil.get(
							"SitanAdmin-portlet-deployment-context");

					if (Validator.isNotNull(propsUtilServletContextName)) {
						_servletContextName = propsUtilServletContextName;
					}
				}
				catch (Throwable t) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Unable to locate deployment context from portal properties");
					}
				}
			}

			if (Validator.isNull(_servletContextName)) {
				_servletContextName = "SitanAdmin-portlet";
			}

			return _servletContextName;
		}
	}

	public static Object translateInput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(AcceptanceVehicleDetailClp.class.getName())) {
			return translateInputAcceptanceVehicleDetail(oldModel);
		}

		if (oldModelClassName.equals(ActionSummeryClp.class.getName())) {
			return translateInputActionSummery(oldModel);
		}

		if (oldModelClassName.equals(ActiveVehicleDetailClp.class.getName())) {
			return translateInputActiveVehicleDetail(oldModel);
		}

		if (oldModelClassName.equals(BillInqueryClp.class.getName())) {
			return translateInputBillInquery(oldModel);
		}

		if (oldModelClassName.equals(BoardDirectorClp.class.getName())) {
			return translateInputBoardDirector(oldModel);
		}

		if (oldModelClassName.equals(complainUserinfoClp.class.getName())) {
			return translateInputcomplainUserinfo(oldModel);
		}

		if (oldModelClassName.equals(detailoksboydsClp.class.getName())) {
			return translateInputdetailoksboyds(oldModel);
		}

		if (oldModelClassName.equals(DocumentTreeClp.class.getName())) {
			return translateInputDocumentTree(oldModel);
		}

		if (oldModelClassName.equals(EquityHoldersClp.class.getName())) {
			return translateInputEquityHolders(oldModel);
		}

		if (oldModelClassName.equals(InqueryClp.class.getName())) {
			return translateInputInquery(oldModel);
		}

		if (oldModelClassName.equals(LicensesStatusClp.class.getName())) {
			return translateInputLicensesStatus(oldModel);
		}

		if (oldModelClassName.equals(OfficerDetailClp.class.getName())) {
			return translateInputOfficerDetail(oldModel);
		}

		if (oldModelClassName.equals(RecoredComunicationClp.class.getName())) {
			return translateInputRecoredComunication(oldModel);
		}

		if (oldModelClassName.equals(SitaanAdminClp.class.getName())) {
			return translateInputSitaanAdmin(oldModel);
		}

		if (oldModelClassName.equals(SourceTypesClp.class.getName())) {
			return translateInputSourceTypes(oldModel);
		}

		if (oldModelClassName.equals(vehicalInfoClp.class.getName())) {
			return translateInputvehicalInfo(oldModel);
		}

		if (oldModelClassName.equals(visualchecklistClp.class.getName())) {
			return translateInputvisualchecklist(oldModel);
		}

		return oldModel;
	}

	public static Object translateInput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateInput(curObj));
		}

		return newList;
	}

	public static Object translateInputAcceptanceVehicleDetail(
		BaseModel<?> oldModel) {
		AcceptanceVehicleDetailClp oldClpModel = (AcceptanceVehicleDetailClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getAcceptanceVehicleDetailRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputActionSummery(BaseModel<?> oldModel) {
		ActionSummeryClp oldClpModel = (ActionSummeryClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getActionSummeryRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputActiveVehicleDetail(
		BaseModel<?> oldModel) {
		ActiveVehicleDetailClp oldClpModel = (ActiveVehicleDetailClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getActiveVehicleDetailRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputBillInquery(BaseModel<?> oldModel) {
		BillInqueryClp oldClpModel = (BillInqueryClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getBillInqueryRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputBoardDirector(BaseModel<?> oldModel) {
		BoardDirectorClp oldClpModel = (BoardDirectorClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getBoardDirectorRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputcomplainUserinfo(BaseModel<?> oldModel) {
		complainUserinfoClp oldClpModel = (complainUserinfoClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getcomplainUserinfoRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputdetailoksboyds(BaseModel<?> oldModel) {
		detailoksboydsClp oldClpModel = (detailoksboydsClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getdetailoksboydsRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputDocumentTree(BaseModel<?> oldModel) {
		DocumentTreeClp oldClpModel = (DocumentTreeClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getDocumentTreeRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEquityHolders(BaseModel<?> oldModel) {
		EquityHoldersClp oldClpModel = (EquityHoldersClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEquityHoldersRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputInquery(BaseModel<?> oldModel) {
		InqueryClp oldClpModel = (InqueryClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getInqueryRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLicensesStatus(BaseModel<?> oldModel) {
		LicensesStatusClp oldClpModel = (LicensesStatusClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLicensesStatusRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputOfficerDetail(BaseModel<?> oldModel) {
		OfficerDetailClp oldClpModel = (OfficerDetailClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getOfficerDetailRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRecoredComunication(
		BaseModel<?> oldModel) {
		RecoredComunicationClp oldClpModel = (RecoredComunicationClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRecoredComunicationRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputSitaanAdmin(BaseModel<?> oldModel) {
		SitaanAdminClp oldClpModel = (SitaanAdminClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getSitaanAdminRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputSourceTypes(BaseModel<?> oldModel) {
		SourceTypesClp oldClpModel = (SourceTypesClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getSourceTypesRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputvehicalInfo(BaseModel<?> oldModel) {
		vehicalInfoClp oldClpModel = (vehicalInfoClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getvehicalInfoRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputvisualchecklist(BaseModel<?> oldModel) {
		visualchecklistClp oldClpModel = (visualchecklistClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getvisualchecklistRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateInput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateInput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailImpl")) {
			return translateOutputAcceptanceVehicleDetail(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.ActionSummeryImpl")) {
			return translateOutputActionSummery(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailImpl")) {
			return translateOutputActiveVehicleDetail(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.BillInqueryImpl")) {
			return translateOutputBillInquery(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.BoardDirectorImpl")) {
			return translateOutputBoardDirector(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.complainUserinfoImpl")) {
			return translateOutputcomplainUserinfo(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.detailoksboydsImpl")) {
			return translateOutputdetailoksboyds(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.DocumentTreeImpl")) {
			return translateOutputDocumentTree(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.EquityHoldersImpl")) {
			return translateOutputEquityHolders(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.InqueryImpl")) {
			return translateOutputInquery(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.LicensesStatusImpl")) {
			return translateOutputLicensesStatus(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.OfficerDetailImpl")) {
			return translateOutputOfficerDetail(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.RecoredComunicationImpl")) {
			return translateOutputRecoredComunication(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.SitaanAdminImpl")) {
			return translateOutputSitaanAdmin(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.SourceTypesImpl")) {
			return translateOutputSourceTypes(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.vehicalInfoImpl")) {
			return translateOutputvehicalInfo(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.org.skali.sitanAdmin.model.impl.visualchecklistImpl")) {
			return translateOutputvisualchecklist(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		return oldModel;
	}

	public static Object translateOutput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateOutput(curObj));
		}

		return newList;
	}

	public static Object translateOutput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateOutput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateOutput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Throwable translateThrowable(Throwable throwable) {
		if (_useReflectionToTranslateThrowable) {
			try {
				UnsyncByteArrayOutputStream unsyncByteArrayOutputStream = new UnsyncByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(unsyncByteArrayOutputStream);

				objectOutputStream.writeObject(throwable);

				objectOutputStream.flush();
				objectOutputStream.close();

				UnsyncByteArrayInputStream unsyncByteArrayInputStream = new UnsyncByteArrayInputStream(unsyncByteArrayOutputStream.unsafeGetByteArray(),
						0, unsyncByteArrayOutputStream.size());

				Thread currentThread = Thread.currentThread();

				ClassLoader contextClassLoader = currentThread.getContextClassLoader();

				ObjectInputStream objectInputStream = new ClassLoaderObjectInputStream(unsyncByteArrayInputStream,
						contextClassLoader);

				throwable = (Throwable)objectInputStream.readObject();

				objectInputStream.close();

				return throwable;
			}
			catch (SecurityException se) {
				if (_log.isInfoEnabled()) {
					_log.info("Do not use reflection to translate throwable");
				}

				_useReflectionToTranslateThrowable = false;
			}
			catch (Throwable throwable2) {
				_log.error(throwable2, throwable2);

				return throwable2;
			}
		}

		Class<?> clazz = throwable.getClass();

		String className = clazz.getName();

		if (className.equals(PortalException.class.getName())) {
			return new PortalException();
		}

		if (className.equals(SystemException.class.getName())) {
			return new SystemException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException")) {
			return new com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchActionSummeryException")) {
			return new com.org.skali.sitanAdmin.NoSuchActionSummeryException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException")) {
			return new com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchBillInqueryException")) {
			return new com.org.skali.sitanAdmin.NoSuchBillInqueryException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchBoardDirectorException")) {
			return new com.org.skali.sitanAdmin.NoSuchBoardDirectorException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException")) {
			return new com.org.skali.sitanAdmin.NoSuchcomplainUserinfoException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchdetailoksboydsException")) {
			return new com.org.skali.sitanAdmin.NoSuchdetailoksboydsException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchDocumentTreeException")) {
			return new com.org.skali.sitanAdmin.NoSuchDocumentTreeException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchEquityHoldersException")) {
			return new com.org.skali.sitanAdmin.NoSuchEquityHoldersException();
		}

		if (className.equals("com.org.skali.sitanAdmin.NoSuchInqueryException")) {
			return new com.org.skali.sitanAdmin.NoSuchInqueryException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchLicensesStatusException")) {
			return new com.org.skali.sitanAdmin.NoSuchLicensesStatusException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchOfficerDetailException")) {
			return new com.org.skali.sitanAdmin.NoSuchOfficerDetailException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchRecoredComunicationException")) {
			return new com.org.skali.sitanAdmin.NoSuchRecoredComunicationException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchSitaanAdminException")) {
			return new com.org.skali.sitanAdmin.NoSuchSitaanAdminException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchSourceTypesException")) {
			return new com.org.skali.sitanAdmin.NoSuchSourceTypesException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchvehicalInfoException")) {
			return new com.org.skali.sitanAdmin.NoSuchvehicalInfoException();
		}

		if (className.equals(
					"com.org.skali.sitanAdmin.NoSuchvisualchecklistException")) {
			return new com.org.skali.sitanAdmin.NoSuchvisualchecklistException();
		}

		return throwable;
	}

	public static Object translateOutputAcceptanceVehicleDetail(
		BaseModel<?> oldModel) {
		AcceptanceVehicleDetailClp newModel = new AcceptanceVehicleDetailClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setAcceptanceVehicleDetailRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputActionSummery(BaseModel<?> oldModel) {
		ActionSummeryClp newModel = new ActionSummeryClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setActionSummeryRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputActiveVehicleDetail(
		BaseModel<?> oldModel) {
		ActiveVehicleDetailClp newModel = new ActiveVehicleDetailClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setActiveVehicleDetailRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputBillInquery(BaseModel<?> oldModel) {
		BillInqueryClp newModel = new BillInqueryClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setBillInqueryRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputBoardDirector(BaseModel<?> oldModel) {
		BoardDirectorClp newModel = new BoardDirectorClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setBoardDirectorRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputcomplainUserinfo(BaseModel<?> oldModel) {
		complainUserinfoClp newModel = new complainUserinfoClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setcomplainUserinfoRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputdetailoksboyds(BaseModel<?> oldModel) {
		detailoksboydsClp newModel = new detailoksboydsClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setdetailoksboydsRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputDocumentTree(BaseModel<?> oldModel) {
		DocumentTreeClp newModel = new DocumentTreeClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setDocumentTreeRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEquityHolders(BaseModel<?> oldModel) {
		EquityHoldersClp newModel = new EquityHoldersClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEquityHoldersRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputInquery(BaseModel<?> oldModel) {
		InqueryClp newModel = new InqueryClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setInqueryRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLicensesStatus(BaseModel<?> oldModel) {
		LicensesStatusClp newModel = new LicensesStatusClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLicensesStatusRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputOfficerDetail(BaseModel<?> oldModel) {
		OfficerDetailClp newModel = new OfficerDetailClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setOfficerDetailRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRecoredComunication(
		BaseModel<?> oldModel) {
		RecoredComunicationClp newModel = new RecoredComunicationClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRecoredComunicationRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputSitaanAdmin(BaseModel<?> oldModel) {
		SitaanAdminClp newModel = new SitaanAdminClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setSitaanAdminRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputSourceTypes(BaseModel<?> oldModel) {
		SourceTypesClp newModel = new SourceTypesClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setSourceTypesRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputvehicalInfo(BaseModel<?> oldModel) {
		vehicalInfoClp newModel = new vehicalInfoClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setvehicalInfoRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputvisualchecklist(BaseModel<?> oldModel) {
		visualchecklistClp newModel = new visualchecklistClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setvisualchecklistRemoteModel(oldModel);

		return newModel;
	}

	private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
	private static String _servletContextName;
	private static boolean _useReflectionToTranslateThrowable = true;
}