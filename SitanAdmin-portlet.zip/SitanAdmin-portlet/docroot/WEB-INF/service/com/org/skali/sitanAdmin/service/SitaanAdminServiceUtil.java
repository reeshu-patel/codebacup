/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for SitaanAdmin. This utility wraps
 * {@link com.org.skali.sitanAdmin.service.impl.SitaanAdminServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author reeshu
 * @see SitaanAdminService
 * @see com.org.skali.sitanAdmin.service.base.SitaanAdminServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.impl.SitaanAdminServiceImpl
 * @generated
 */
public class SitaanAdminServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.org.skali.sitanAdmin.service.impl.SitaanAdminServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static com.liferay.portal.kernel.json.JSONObject FinedByColumn(
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String state,
		java.lang.String vehicleRegistrationNo,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String locationCageSita,
		java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String action, java.lang.String paymentStatus)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .FinedByColumn(dateSeized, checkSitesSita, source,
			ownerName, territory, state, vehicleRegistrationNo,
			referenceEffective, confiscatedPeriod, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, action,
			paymentStatus);
	}

	public static com.liferay.portal.kernel.json.JSONObject FinedByBillId(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().FinedByBillId(bilId);
	}

	public static java.util.List<com.liferay.portal.model.User> geCMDUsers()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().geCMDUsers();
	}

	public static com.liferay.portal.kernel.json.JSONObject ActionCaseByBillId(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().ActionCaseByBillId(bilId);
	}

	public static com.liferay.portal.kernel.json.JSONObject UploadDocumentSearch(
		java.lang.String title)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().UploadDocumentSearch(title);
	}

	public static void Upload_Document(java.io.File file,
		java.lang.String fileName)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		getService().Upload_Document(file, fileName);
	}

	public static com.liferay.portal.kernel.json.JSONArray Document_Binding_Tree()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService().Document_Binding_Tree();
	}

	public static com.liferay.portal.kernel.json.JSONObject Officer_List()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService().Officer_List();
	}

	public static com.liferay.portal.kernel.json.JSONObject VisualInspection(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService().VisualInspection(bilId);
	}

	public static com.org.skali.sitanAdmin.model.visualchecklist VisualInspectionPost(
		long checkId, long bilId, java.lang.String numberplates,
		java.lang.String numberplatesNote, java.lang.String forwardlighting,
		java.lang.String forwardlightingNote, java.lang.String backlight,
		java.lang.String backlightNote, java.lang.String trafficLight,
		java.lang.String trafficLightNote, java.lang.String signallight,
		java.lang.String signallightNote, java.lang.String vehiclebody,
		java.lang.String vehiclebodyNote, java.lang.String vehicleAccessories,
		java.lang.String vehicleAccessoriesNote, java.lang.String windscreen,
		java.lang.String windscreenNote, java.lang.String rearMirror,
		java.lang.String rearMirrorNote, java.lang.String doormirror,
		java.lang.String doormirrorNote, java.lang.String vehicletires,
		java.lang.String vehicletiresNote, java.lang.String frontbumper,
		java.lang.String frontbumperNote, java.lang.String rearbumper,
		java.lang.String rearbumperNote, java.lang.String frontseat,
		java.lang.String frontseatNote, java.lang.String rearseats,
		java.lang.String rearseatsNote, java.lang.String note,
		java.lang.String investigatorname, java.lang.String investigatorEmail,
		java.lang.String investigatorphone)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService()
				   .VisualInspectionPost(checkId, bilId, numberplates,
			numberplatesNote, forwardlighting, forwardlightingNote, backlight,
			backlightNote, trafficLight, trafficLightNote, signallight,
			signallightNote, vehiclebody, vehiclebodyNote, vehicleAccessories,
			vehicleAccessoriesNote, windscreen, windscreenNote, rearMirror,
			rearMirrorNote, doormirror, doormirrorNote, vehicletires,
			vehicletiresNote, frontbumper, frontbumperNote, rearbumper,
			rearbumperNote, frontseat, frontseatNote, rearseats, rearseatsNote,
			note, investigatorname, investigatorEmail, investigatorphone);
	}

	public static com.liferay.portal.kernel.json.JSONObject SaveVisualInspection(
		long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService().SaveVisualInspection(bilId, checkId);
	}

	public static void Multiple_Upload_Document(java.io.File[] file)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		getService().Multiple_Upload_Document(file);
	}

	public static com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail AcceptaneceVehicalDetail(
		long vehicalid, long bilId, java.lang.String vehiNumberPlate,
		java.lang.String ownerName, java.lang.String companyRepresentative,
		java.lang.String kpNo, java.lang.String chronicle,
		java.lang.String Signature, java.lang.String accodocument,
		java.lang.String cardIdentity, java.lang.String drivingLicense,
		java.lang.String grantVehicle, java.lang.String attorney,
		java.lang.String numberPlateDetail)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService()
				   .AcceptaneceVehicalDetail(vehicalid, bilId, vehiNumberPlate,
			ownerName, companyRepresentative, kpNo, chronicle, Signature,
			accodocument, cardIdentity, drivingLicense, grantVehicle, attorney,
			numberPlateDetail);
	}

	public static com.liferay.portal.kernel.json.JSONObject FileAcceptaneceVehicalDetail(
		long vehicalid, long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return getService().FileAcceptaneceVehicalDetail(vehicalid, bilId);
	}

	public static void clearService() {
		_service = null;
	}

	public static SitaanAdminService getService() {
		if (_service == null) {
			InvokableService invokableService = (InvokableService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					SitaanAdminService.class.getName());

			if (invokableService instanceof SitaanAdminService) {
				_service = (SitaanAdminService)invokableService;
			}
			else {
				_service = new SitaanAdminServiceClp(invokableService);
			}

			ReferenceRegistry.registerReference(SitaanAdminServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(SitaanAdminService service) {
	}

	private static SitaanAdminService _service;
}