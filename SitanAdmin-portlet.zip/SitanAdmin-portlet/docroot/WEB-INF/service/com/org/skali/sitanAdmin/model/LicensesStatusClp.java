/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.LicensesStatusLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class LicensesStatusClp extends BaseModelImpl<LicensesStatus>
	implements LicensesStatus {
	public LicensesStatusClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return LicensesStatus.class;
	}

	@Override
	public String getModelClassName() {
		return LicensesStatus.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _licensesstatusid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setLicensesstatusid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _licensesstatusid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("licensesstatusid", getLicensesstatusid());
		attributes.put("bilId", getBilId());
		attributes.put("active", getActive());
		attributes.put("noActive", getNoActive());
		attributes.put("moreoverHadAge", getMoreoverHadAge());
		attributes.put("finishedWithin", getFinishedWithin());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long licensesstatusid = (Long)attributes.get("licensesstatusid");

		if (licensesstatusid != null) {
			setLicensesstatusid(licensesstatusid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String active = (String)attributes.get("active");

		if (active != null) {
			setActive(active);
		}

		String noActive = (String)attributes.get("noActive");

		if (noActive != null) {
			setNoActive(noActive);
		}

		String moreoverHadAge = (String)attributes.get("moreoverHadAge");

		if (moreoverHadAge != null) {
			setMoreoverHadAge(moreoverHadAge);
		}

		String finishedWithin = (String)attributes.get("finishedWithin");

		if (finishedWithin != null) {
			setFinishedWithin(finishedWithin);
		}
	}

	@Override
	public long getLicensesstatusid() {
		return _licensesstatusid;
	}

	@Override
	public void setLicensesstatusid(long licensesstatusid) {
		_licensesstatusid = licensesstatusid;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setLicensesstatusid",
						long.class);

				method.invoke(_licensesStatusRemoteModel, licensesstatusid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_licensesStatusRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getActive() {
		return _active;
	}

	@Override
	public void setActive(String active) {
		_active = active;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setActive", String.class);

				method.invoke(_licensesStatusRemoteModel, active);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNoActive() {
		return _noActive;
	}

	@Override
	public void setNoActive(String noActive) {
		_noActive = noActive;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setNoActive", String.class);

				method.invoke(_licensesStatusRemoteModel, noActive);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMoreoverHadAge() {
		return _moreoverHadAge;
	}

	@Override
	public void setMoreoverHadAge(String moreoverHadAge) {
		_moreoverHadAge = moreoverHadAge;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setMoreoverHadAge",
						String.class);

				method.invoke(_licensesStatusRemoteModel, moreoverHadAge);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFinishedWithin() {
		return _finishedWithin;
	}

	@Override
	public void setFinishedWithin(String finishedWithin) {
		_finishedWithin = finishedWithin;

		if (_licensesStatusRemoteModel != null) {
			try {
				Class<?> clazz = _licensesStatusRemoteModel.getClass();

				Method method = clazz.getMethod("setFinishedWithin",
						String.class);

				method.invoke(_licensesStatusRemoteModel, finishedWithin);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getLicensesStatusRemoteModel() {
		return _licensesStatusRemoteModel;
	}

	public void setLicensesStatusRemoteModel(
		BaseModel<?> licensesStatusRemoteModel) {
		_licensesStatusRemoteModel = licensesStatusRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _licensesStatusRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_licensesStatusRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			LicensesStatusLocalServiceUtil.addLicensesStatus(this);
		}
		else {
			LicensesStatusLocalServiceUtil.updateLicensesStatus(this);
		}
	}

	@Override
	public LicensesStatus toEscapedModel() {
		return (LicensesStatus)ProxyUtil.newProxyInstance(LicensesStatus.class.getClassLoader(),
			new Class[] { LicensesStatus.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		LicensesStatusClp clone = new LicensesStatusClp();

		clone.setLicensesstatusid(getLicensesstatusid());
		clone.setBilId(getBilId());
		clone.setActive(getActive());
		clone.setNoActive(getNoActive());
		clone.setMoreoverHadAge(getMoreoverHadAge());
		clone.setFinishedWithin(getFinishedWithin());

		return clone;
	}

	@Override
	public int compareTo(LicensesStatus licensesStatus) {
		long primaryKey = licensesStatus.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LicensesStatusClp)) {
			return false;
		}

		LicensesStatusClp licensesStatus = (LicensesStatusClp)obj;

		long primaryKey = licensesStatus.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{licensesstatusid=");
		sb.append(getLicensesstatusid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", active=");
		sb.append(getActive());
		sb.append(", noActive=");
		sb.append(getNoActive());
		sb.append(", moreoverHadAge=");
		sb.append(getMoreoverHadAge());
		sb.append(", finishedWithin=");
		sb.append(getFinishedWithin());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.LicensesStatus");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>licensesstatusid</column-name><column-value><![CDATA[");
		sb.append(getLicensesstatusid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>active</column-name><column-value><![CDATA[");
		sb.append(getActive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>noActive</column-name><column-value><![CDATA[");
		sb.append(getNoActive());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>moreoverHadAge</column-name><column-value><![CDATA[");
		sb.append(getMoreoverHadAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>finishedWithin</column-name><column-value><![CDATA[");
		sb.append(getFinishedWithin());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _licensesstatusid;
	private long _bilId;
	private String _active;
	private String _noActive;
	private String _moreoverHadAge;
	private String _finishedWithin;
	private BaseModel<?> _licensesStatusRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}