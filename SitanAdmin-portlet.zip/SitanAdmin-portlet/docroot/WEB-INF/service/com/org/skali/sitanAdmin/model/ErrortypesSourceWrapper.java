/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ErrortypesSource}.
 * </p>
 *
 * @author reeshu
 * @see ErrortypesSource
 * @generated
 */
public class ErrortypesSourceWrapper implements ErrortypesSource,
	ModelWrapper<ErrortypesSource> {
	public ErrortypesSourceWrapper(ErrortypesSource errortypesSource) {
		_errortypesSource = errortypesSource;
	}

	@Override
	public Class<?> getModelClass() {
		return ErrortypesSource.class;
	}

	@Override
	public String getModelClassName() {
		return ErrortypesSource.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("errortypeid", getErrortypeid());
		attributes.put("bilId", getBilId());
		attributes.put("errortypes", getErrortypes());
		attributes.put("sourcetypes", getSourcetypes());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long errortypeid = (Long)attributes.get("errortypeid");

		if (errortypeid != null) {
			setErrortypeid(errortypeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String errortypes = (String)attributes.get("errortypes");

		if (errortypes != null) {
			setErrortypes(errortypes);
		}

		String sourcetypes = (String)attributes.get("sourcetypes");

		if (sourcetypes != null) {
			setSourcetypes(sourcetypes);
		}
	}

	/**
	* Returns the primary key of this errortypes source.
	*
	* @return the primary key of this errortypes source
	*/
	@Override
	public long getPrimaryKey() {
		return _errortypesSource.getPrimaryKey();
	}

	/**
	* Sets the primary key of this errortypes source.
	*
	* @param primaryKey the primary key of this errortypes source
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_errortypesSource.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the errortypeid of this errortypes source.
	*
	* @return the errortypeid of this errortypes source
	*/
	@Override
	public long getErrortypeid() {
		return _errortypesSource.getErrortypeid();
	}

	/**
	* Sets the errortypeid of this errortypes source.
	*
	* @param errortypeid the errortypeid of this errortypes source
	*/
	@Override
	public void setErrortypeid(long errortypeid) {
		_errortypesSource.setErrortypeid(errortypeid);
	}

	/**
	* Returns the bil ID of this errortypes source.
	*
	* @return the bil ID of this errortypes source
	*/
	@Override
	public long getBilId() {
		return _errortypesSource.getBilId();
	}

	/**
	* Sets the bil ID of this errortypes source.
	*
	* @param bilId the bil ID of this errortypes source
	*/
	@Override
	public void setBilId(long bilId) {
		_errortypesSource.setBilId(bilId);
	}

	/**
	* Returns the errortypes of this errortypes source.
	*
	* @return the errortypes of this errortypes source
	*/
	@Override
	public java.lang.String getErrortypes() {
		return _errortypesSource.getErrortypes();
	}

	/**
	* Sets the errortypes of this errortypes source.
	*
	* @param errortypes the errortypes of this errortypes source
	*/
	@Override
	public void setErrortypes(java.lang.String errortypes) {
		_errortypesSource.setErrortypes(errortypes);
	}

	/**
	* Returns the sourcetypes of this errortypes source.
	*
	* @return the sourcetypes of this errortypes source
	*/
	@Override
	public java.lang.String getSourcetypes() {
		return _errortypesSource.getSourcetypes();
	}

	/**
	* Sets the sourcetypes of this errortypes source.
	*
	* @param sourcetypes the sourcetypes of this errortypes source
	*/
	@Override
	public void setSourcetypes(java.lang.String sourcetypes) {
		_errortypesSource.setSourcetypes(sourcetypes);
	}

	@Override
	public boolean isNew() {
		return _errortypesSource.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_errortypesSource.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _errortypesSource.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_errortypesSource.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _errortypesSource.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _errortypesSource.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_errortypesSource.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _errortypesSource.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_errortypesSource.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_errortypesSource.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_errortypesSource.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ErrortypesSourceWrapper((ErrortypesSource)_errortypesSource.clone());
	}

	@Override
	public int compareTo(ErrortypesSource errortypesSource) {
		return _errortypesSource.compareTo(errortypesSource);
	}

	@Override
	public int hashCode() {
		return _errortypesSource.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<ErrortypesSource> toCacheModel() {
		return _errortypesSource.toCacheModel();
	}

	@Override
	public ErrortypesSource toEscapedModel() {
		return new ErrortypesSourceWrapper(_errortypesSource.toEscapedModel());
	}

	@Override
	public ErrortypesSource toUnescapedModel() {
		return new ErrortypesSourceWrapper(_errortypesSource.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _errortypesSource.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _errortypesSource.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_errortypesSource.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ErrortypesSourceWrapper)) {
			return false;
		}

		ErrortypesSourceWrapper errortypesSourceWrapper = (ErrortypesSourceWrapper)obj;

		if (Validator.equals(_errortypesSource,
					errortypesSourceWrapper._errortypesSource)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ErrortypesSource getWrappedErrortypesSource() {
		return _errortypesSource;
	}

	@Override
	public ErrortypesSource getWrappedModel() {
		return _errortypesSource;
	}

	@Override
	public void resetOriginalValues() {
		_errortypesSource.resetOriginalValues();
	}

	private ErrortypesSource _errortypesSource;
}