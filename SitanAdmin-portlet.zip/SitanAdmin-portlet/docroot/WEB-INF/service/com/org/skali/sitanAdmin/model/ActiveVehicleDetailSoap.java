/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.ActiveVehicleDetailServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.ActiveVehicleDetailServiceSoap
 * @generated
 */
public class ActiveVehicleDetailSoap implements Serializable {
	public static ActiveVehicleDetailSoap toSoapModel(ActiveVehicleDetail model) {
		ActiveVehicleDetailSoap soapModel = new ActiveVehicleDetailSoap();

		soapModel.setVehicalid(model.getVehicalid());
		soapModel.setBilId(model.getBilId());
		soapModel.setClasscode(model.getClasscode());
		soapModel.setByVehicle(model.getByVehicle());
		soapModel.setWithoutMotor(model.getWithoutMotor());
		soapModel.setCommencement(model.getCommencement());
		soapModel.setAgeLimit(model.getAgeLimit());

		return soapModel;
	}

	public static ActiveVehicleDetailSoap[] toSoapModels(
		ActiveVehicleDetail[] models) {
		ActiveVehicleDetailSoap[] soapModels = new ActiveVehicleDetailSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ActiveVehicleDetailSoap[][] toSoapModels(
		ActiveVehicleDetail[][] models) {
		ActiveVehicleDetailSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ActiveVehicleDetailSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ActiveVehicleDetailSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ActiveVehicleDetailSoap[] toSoapModels(
		List<ActiveVehicleDetail> models) {
		List<ActiveVehicleDetailSoap> soapModels = new ArrayList<ActiveVehicleDetailSoap>(models.size());

		for (ActiveVehicleDetail model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ActiveVehicleDetailSoap[soapModels.size()]);
	}

	public ActiveVehicleDetailSoap() {
	}

	public long getPrimaryKey() {
		return _vehicalid;
	}

	public void setPrimaryKey(long pk) {
		setVehicalid(pk);
	}

	public long getVehicalid() {
		return _vehicalid;
	}

	public void setVehicalid(long vehicalid) {
		_vehicalid = vehicalid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getClasscode() {
		return _classcode;
	}

	public void setClasscode(String classcode) {
		_classcode = classcode;
	}

	public String getByVehicle() {
		return _byVehicle;
	}

	public void setByVehicle(String byVehicle) {
		_byVehicle = byVehicle;
	}

	public String getWithoutMotor() {
		return _withoutMotor;
	}

	public void setWithoutMotor(String withoutMotor) {
		_withoutMotor = withoutMotor;
	}

	public String getCommencement() {
		return _commencement;
	}

	public void setCommencement(String commencement) {
		_commencement = commencement;
	}

	public String getAgeLimit() {
		return _ageLimit;
	}

	public void setAgeLimit(String ageLimit) {
		_ageLimit = ageLimit;
	}

	private long _vehicalid;
	private long _bilId;
	private String _classcode;
	private String _byVehicle;
	private String _withoutMotor;
	private String _commencement;
	private String _ageLimit;
}