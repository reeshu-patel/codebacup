/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.complainUserinfoLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class complainUserinfoClp extends BaseModelImpl<complainUserinfo>
	implements complainUserinfo {
	public complainUserinfoClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return complainUserinfo.class;
	}

	@Override
	public String getModelClassName() {
		return complainUserinfo.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _complainUserId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setComplainUserId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _complainUserId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("complainUserId", getComplainUserId());
		attributes.put("bilId", getBilId());
		attributes.put("prefix", getPrefix());
		attributes.put("name", getName());
		attributes.put("identificationnumber", getIdentificationnumber());
		attributes.put("passport", getPassport());
		attributes.put("citizen", getCitizen());
		attributes.put("nation", getNation());
		attributes.put("gender", getGender());
		attributes.put("age", getAge());
		attributes.put("phoneNo", getPhoneNo());
		attributes.put("cellPhones", getCellPhones());
		attributes.put("address", getAddress());
		attributes.put("email", getEmail());
		attributes.put("state", getState());
		attributes.put("dName", getDName());
		attributes.put("didentificationnumber", getDidentificationnumber());
		attributes.put("dateofbirth", getDateofbirth());
		attributes.put("dcitizen", getDcitizen());
		attributes.put("driverNation", getDriverNation());
		attributes.put("drivergender", getDrivergender());
		attributes.put("driverAge", getDriverAge());
		attributes.put("retirees", getRetirees());
		attributes.put("statusReadPSV", getStatusReadPSV());
		attributes.put("driverLicense", getDriverLicense());
		attributes.put("dphone", getDphone());
		attributes.put("dphoneTwo", getDphoneTwo());
		attributes.put("daddress", getDaddress());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long complainUserId = (Long)attributes.get("complainUserId");

		if (complainUserId != null) {
			setComplainUserId(complainUserId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String prefix = (String)attributes.get("prefix");

		if (prefix != null) {
			setPrefix(prefix);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String identificationnumber = (String)attributes.get(
				"identificationnumber");

		if (identificationnumber != null) {
			setIdentificationnumber(identificationnumber);
		}

		String passport = (String)attributes.get("passport");

		if (passport != null) {
			setPassport(passport);
		}

		String citizen = (String)attributes.get("citizen");

		if (citizen != null) {
			setCitizen(citizen);
		}

		String nation = (String)attributes.get("nation");

		if (nation != null) {
			setNation(nation);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		Long age = (Long)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String phoneNo = (String)attributes.get("phoneNo");

		if (phoneNo != null) {
			setPhoneNo(phoneNo);
		}

		String cellPhones = (String)attributes.get("cellPhones");

		if (cellPhones != null) {
			setCellPhones(cellPhones);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String dName = (String)attributes.get("dName");

		if (dName != null) {
			setDName(dName);
		}

		String didentificationnumber = (String)attributes.get(
				"didentificationnumber");

		if (didentificationnumber != null) {
			setDidentificationnumber(didentificationnumber);
		}

		String dateofbirth = (String)attributes.get("dateofbirth");

		if (dateofbirth != null) {
			setDateofbirth(dateofbirth);
		}

		String dcitizen = (String)attributes.get("dcitizen");

		if (dcitizen != null) {
			setDcitizen(dcitizen);
		}

		String driverNation = (String)attributes.get("driverNation");

		if (driverNation != null) {
			setDriverNation(driverNation);
		}

		String drivergender = (String)attributes.get("drivergender");

		if (drivergender != null) {
			setDrivergender(drivergender);
		}

		Long driverAge = (Long)attributes.get("driverAge");

		if (driverAge != null) {
			setDriverAge(driverAge);
		}

		String retirees = (String)attributes.get("retirees");

		if (retirees != null) {
			setRetirees(retirees);
		}

		Long statusReadPSV = (Long)attributes.get("statusReadPSV");

		if (statusReadPSV != null) {
			setStatusReadPSV(statusReadPSV);
		}

		String driverLicense = (String)attributes.get("driverLicense");

		if (driverLicense != null) {
			setDriverLicense(driverLicense);
		}

		String dphone = (String)attributes.get("dphone");

		if (dphone != null) {
			setDphone(dphone);
		}

		String dphoneTwo = (String)attributes.get("dphoneTwo");

		if (dphoneTwo != null) {
			setDphoneTwo(dphoneTwo);
		}

		String daddress = (String)attributes.get("daddress");

		if (daddress != null) {
			setDaddress(daddress);
		}
	}

	@Override
	public long getComplainUserId() {
		return _complainUserId;
	}

	@Override
	public void setComplainUserId(long complainUserId) {
		_complainUserId = complainUserId;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setComplainUserId", long.class);

				method.invoke(_complainUserinfoRemoteModel, complainUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getComplainUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getComplainUserId(), "uuid",
			_complainUserUuid);
	}

	@Override
	public void setComplainUserUuid(String complainUserUuid) {
		_complainUserUuid = complainUserUuid;
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_complainUserinfoRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPrefix() {
		return _prefix;
	}

	@Override
	public void setPrefix(String prefix) {
		_prefix = prefix;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setPrefix", String.class);

				method.invoke(_complainUserinfoRemoteModel, prefix);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getName() {
		return _name;
	}

	@Override
	public void setName(String name) {
		_name = name;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setName", String.class);

				method.invoke(_complainUserinfoRemoteModel, name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getIdentificationnumber() {
		return _identificationnumber;
	}

	@Override
	public void setIdentificationnumber(String identificationnumber) {
		_identificationnumber = identificationnumber;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setIdentificationnumber",
						String.class);

				method.invoke(_complainUserinfoRemoteModel, identificationnumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPassport() {
		return _passport;
	}

	@Override
	public void setPassport(String passport) {
		_passport = passport;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setPassport", String.class);

				method.invoke(_complainUserinfoRemoteModel, passport);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCitizen() {
		return _citizen;
	}

	@Override
	public void setCitizen(String citizen) {
		_citizen = citizen;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setCitizen", String.class);

				method.invoke(_complainUserinfoRemoteModel, citizen);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNation() {
		return _nation;
	}

	@Override
	public void setNation(String nation) {
		_nation = nation;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setNation", String.class);

				method.invoke(_complainUserinfoRemoteModel, nation);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGender() {
		return _gender;
	}

	@Override
	public void setGender(String gender) {
		_gender = gender;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setGender", String.class);

				method.invoke(_complainUserinfoRemoteModel, gender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAge() {
		return _age;
	}

	@Override
	public void setAge(long age) {
		_age = age;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setAge", long.class);

				method.invoke(_complainUserinfoRemoteModel, age);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPhoneNo() {
		return _phoneNo;
	}

	@Override
	public void setPhoneNo(String phoneNo) {
		_phoneNo = phoneNo;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setPhoneNo", String.class);

				method.invoke(_complainUserinfoRemoteModel, phoneNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCellPhones() {
		return _cellPhones;
	}

	@Override
	public void setCellPhones(String cellPhones) {
		_cellPhones = cellPhones;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setCellPhones", String.class);

				method.invoke(_complainUserinfoRemoteModel, cellPhones);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAddress() {
		return _address;
	}

	@Override
	public void setAddress(String address) {
		_address = address;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setAddress", String.class);

				method.invoke(_complainUserinfoRemoteModel, address);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmail() {
		return _email;
	}

	@Override
	public void setEmail(String email) {
		_email = email;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setEmail", String.class);

				method.invoke(_complainUserinfoRemoteModel, email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getState() {
		return _state;
	}

	@Override
	public void setState(String state) {
		_state = state;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setState", String.class);

				method.invoke(_complainUserinfoRemoteModel, state);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDName() {
		return _dName;
	}

	@Override
	public void setDName(String dName) {
		_dName = dName;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDName", String.class);

				method.invoke(_complainUserinfoRemoteModel, dName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDidentificationnumber() {
		return _didentificationnumber;
	}

	@Override
	public void setDidentificationnumber(String didentificationnumber) {
		_didentificationnumber = didentificationnumber;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDidentificationnumber",
						String.class);

				method.invoke(_complainUserinfoRemoteModel,
					didentificationnumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateofbirth() {
		return _dateofbirth;
	}

	@Override
	public void setDateofbirth(String dateofbirth) {
		_dateofbirth = dateofbirth;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDateofbirth", String.class);

				method.invoke(_complainUserinfoRemoteModel, dateofbirth);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDcitizen() {
		return _dcitizen;
	}

	@Override
	public void setDcitizen(String dcitizen) {
		_dcitizen = dcitizen;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDcitizen", String.class);

				method.invoke(_complainUserinfoRemoteModel, dcitizen);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDriverNation() {
		return _driverNation;
	}

	@Override
	public void setDriverNation(String driverNation) {
		_driverNation = driverNation;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDriverNation", String.class);

				method.invoke(_complainUserinfoRemoteModel, driverNation);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDrivergender() {
		return _drivergender;
	}

	@Override
	public void setDrivergender(String drivergender) {
		_drivergender = drivergender;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDrivergender", String.class);

				method.invoke(_complainUserinfoRemoteModel, drivergender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getDriverAge() {
		return _driverAge;
	}

	@Override
	public void setDriverAge(long driverAge) {
		_driverAge = driverAge;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDriverAge", long.class);

				method.invoke(_complainUserinfoRemoteModel, driverAge);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRetirees() {
		return _retirees;
	}

	@Override
	public void setRetirees(String retirees) {
		_retirees = retirees;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setRetirees", String.class);

				method.invoke(_complainUserinfoRemoteModel, retirees);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStatusReadPSV() {
		return _statusReadPSV;
	}

	@Override
	public void setStatusReadPSV(long statusReadPSV) {
		_statusReadPSV = statusReadPSV;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusReadPSV", long.class);

				method.invoke(_complainUserinfoRemoteModel, statusReadPSV);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDriverLicense() {
		return _driverLicense;
	}

	@Override
	public void setDriverLicense(String driverLicense) {
		_driverLicense = driverLicense;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDriverLicense", String.class);

				method.invoke(_complainUserinfoRemoteModel, driverLicense);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDphone() {
		return _dphone;
	}

	@Override
	public void setDphone(String dphone) {
		_dphone = dphone;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDphone", String.class);

				method.invoke(_complainUserinfoRemoteModel, dphone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDphoneTwo() {
		return _dphoneTwo;
	}

	@Override
	public void setDphoneTwo(String dphoneTwo) {
		_dphoneTwo = dphoneTwo;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDphoneTwo", String.class);

				method.invoke(_complainUserinfoRemoteModel, dphoneTwo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDaddress() {
		return _daddress;
	}

	@Override
	public void setDaddress(String daddress) {
		_daddress = daddress;

		if (_complainUserinfoRemoteModel != null) {
			try {
				Class<?> clazz = _complainUserinfoRemoteModel.getClass();

				Method method = clazz.getMethod("setDaddress", String.class);

				method.invoke(_complainUserinfoRemoteModel, daddress);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getcomplainUserinfoRemoteModel() {
		return _complainUserinfoRemoteModel;
	}

	public void setcomplainUserinfoRemoteModel(
		BaseModel<?> complainUserinfoRemoteModel) {
		_complainUserinfoRemoteModel = complainUserinfoRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _complainUserinfoRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_complainUserinfoRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			complainUserinfoLocalServiceUtil.addcomplainUserinfo(this);
		}
		else {
			complainUserinfoLocalServiceUtil.updatecomplainUserinfo(this);
		}
	}

	@Override
	public complainUserinfo toEscapedModel() {
		return (complainUserinfo)ProxyUtil.newProxyInstance(complainUserinfo.class.getClassLoader(),
			new Class[] { complainUserinfo.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		complainUserinfoClp clone = new complainUserinfoClp();

		clone.setComplainUserId(getComplainUserId());
		clone.setBilId(getBilId());
		clone.setPrefix(getPrefix());
		clone.setName(getName());
		clone.setIdentificationnumber(getIdentificationnumber());
		clone.setPassport(getPassport());
		clone.setCitizen(getCitizen());
		clone.setNation(getNation());
		clone.setGender(getGender());
		clone.setAge(getAge());
		clone.setPhoneNo(getPhoneNo());
		clone.setCellPhones(getCellPhones());
		clone.setAddress(getAddress());
		clone.setEmail(getEmail());
		clone.setState(getState());
		clone.setDName(getDName());
		clone.setDidentificationnumber(getDidentificationnumber());
		clone.setDateofbirth(getDateofbirth());
		clone.setDcitizen(getDcitizen());
		clone.setDriverNation(getDriverNation());
		clone.setDrivergender(getDrivergender());
		clone.setDriverAge(getDriverAge());
		clone.setRetirees(getRetirees());
		clone.setStatusReadPSV(getStatusReadPSV());
		clone.setDriverLicense(getDriverLicense());
		clone.setDphone(getDphone());
		clone.setDphoneTwo(getDphoneTwo());
		clone.setDaddress(getDaddress());

		return clone;
	}

	@Override
	public int compareTo(complainUserinfo complainUserinfo) {
		long primaryKey = complainUserinfo.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof complainUserinfoClp)) {
			return false;
		}

		complainUserinfoClp complainUserinfo = (complainUserinfoClp)obj;

		long primaryKey = complainUserinfo.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(57);

		sb.append("{complainUserId=");
		sb.append(getComplainUserId());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", prefix=");
		sb.append(getPrefix());
		sb.append(", name=");
		sb.append(getName());
		sb.append(", identificationnumber=");
		sb.append(getIdentificationnumber());
		sb.append(", passport=");
		sb.append(getPassport());
		sb.append(", citizen=");
		sb.append(getCitizen());
		sb.append(", nation=");
		sb.append(getNation());
		sb.append(", gender=");
		sb.append(getGender());
		sb.append(", age=");
		sb.append(getAge());
		sb.append(", phoneNo=");
		sb.append(getPhoneNo());
		sb.append(", cellPhones=");
		sb.append(getCellPhones());
		sb.append(", address=");
		sb.append(getAddress());
		sb.append(", email=");
		sb.append(getEmail());
		sb.append(", state=");
		sb.append(getState());
		sb.append(", dName=");
		sb.append(getDName());
		sb.append(", didentificationnumber=");
		sb.append(getDidentificationnumber());
		sb.append(", dateofbirth=");
		sb.append(getDateofbirth());
		sb.append(", dcitizen=");
		sb.append(getDcitizen());
		sb.append(", driverNation=");
		sb.append(getDriverNation());
		sb.append(", drivergender=");
		sb.append(getDrivergender());
		sb.append(", driverAge=");
		sb.append(getDriverAge());
		sb.append(", retirees=");
		sb.append(getRetirees());
		sb.append(", statusReadPSV=");
		sb.append(getStatusReadPSV());
		sb.append(", driverLicense=");
		sb.append(getDriverLicense());
		sb.append(", dphone=");
		sb.append(getDphone());
		sb.append(", dphoneTwo=");
		sb.append(getDphoneTwo());
		sb.append(", daddress=");
		sb.append(getDaddress());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(88);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.complainUserinfo");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>complainUserId</column-name><column-value><![CDATA[");
		sb.append(getComplainUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>prefix</column-name><column-value><![CDATA[");
		sb.append(getPrefix());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>name</column-name><column-value><![CDATA[");
		sb.append(getName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>identificationnumber</column-name><column-value><![CDATA[");
		sb.append(getIdentificationnumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>passport</column-name><column-value><![CDATA[");
		sb.append(getPassport());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>citizen</column-name><column-value><![CDATA[");
		sb.append(getCitizen());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nation</column-name><column-value><![CDATA[");
		sb.append(getNation());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>gender</column-name><column-value><![CDATA[");
		sb.append(getGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>age</column-name><column-value><![CDATA[");
		sb.append(getAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>phoneNo</column-name><column-value><![CDATA[");
		sb.append(getPhoneNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>cellPhones</column-name><column-value><![CDATA[");
		sb.append(getCellPhones());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>address</column-name><column-value><![CDATA[");
		sb.append(getAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>email</column-name><column-value><![CDATA[");
		sb.append(getEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>state</column-name><column-value><![CDATA[");
		sb.append(getState());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dName</column-name><column-value><![CDATA[");
		sb.append(getDName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>didentificationnumber</column-name><column-value><![CDATA[");
		sb.append(getDidentificationnumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateofbirth</column-name><column-value><![CDATA[");
		sb.append(getDateofbirth());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dcitizen</column-name><column-value><![CDATA[");
		sb.append(getDcitizen());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>driverNation</column-name><column-value><![CDATA[");
		sb.append(getDriverNation());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>drivergender</column-name><column-value><![CDATA[");
		sb.append(getDrivergender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>driverAge</column-name><column-value><![CDATA[");
		sb.append(getDriverAge());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>retirees</column-name><column-value><![CDATA[");
		sb.append(getRetirees());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusReadPSV</column-name><column-value><![CDATA[");
		sb.append(getStatusReadPSV());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>driverLicense</column-name><column-value><![CDATA[");
		sb.append(getDriverLicense());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dphone</column-name><column-value><![CDATA[");
		sb.append(getDphone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dphoneTwo</column-name><column-value><![CDATA[");
		sb.append(getDphoneTwo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>daddress</column-name><column-value><![CDATA[");
		sb.append(getDaddress());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _complainUserId;
	private String _complainUserUuid;
	private long _bilId;
	private String _prefix;
	private String _name;
	private String _identificationnumber;
	private String _passport;
	private String _citizen;
	private String _nation;
	private String _gender;
	private long _age;
	private String _phoneNo;
	private String _cellPhones;
	private String _address;
	private String _email;
	private String _state;
	private String _dName;
	private String _didentificationnumber;
	private String _dateofbirth;
	private String _dcitizen;
	private String _driverNation;
	private String _drivergender;
	private long _driverAge;
	private String _retirees;
	private long _statusReadPSV;
	private String _driverLicense;
	private String _dphone;
	private String _dphoneTwo;
	private String _daddress;
	private BaseModel<?> _complainUserinfoRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}