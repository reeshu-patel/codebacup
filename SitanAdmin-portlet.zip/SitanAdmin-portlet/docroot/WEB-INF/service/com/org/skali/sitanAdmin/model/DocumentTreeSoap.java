/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.DocumentTreeServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.DocumentTreeServiceSoap
 * @generated
 */
public class DocumentTreeSoap implements Serializable {
	public static DocumentTreeSoap toSoapModel(DocumentTree model) {
		DocumentTreeSoap soapModel = new DocumentTreeSoap();

		soapModel.setDocumenttreeid(model.getDocumenttreeid());
		soapModel.setBilId(model.getBilId());
		soapModel.setFileentryid(model.getFileentryid());
		soapModel.setFolderid(model.getFolderid());
		soapModel.setFoldername(model.getFoldername());
		soapModel.setTitle(model.getTitle());
		soapModel.setDescription(model.getDescription());
		soapModel.setLeaf(model.getLeaf());
		soapModel.setType(model.getType());

		return soapModel;
	}

	public static DocumentTreeSoap[] toSoapModels(DocumentTree[] models) {
		DocumentTreeSoap[] soapModels = new DocumentTreeSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DocumentTreeSoap[][] toSoapModels(DocumentTree[][] models) {
		DocumentTreeSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DocumentTreeSoap[models.length][models[0].length];
		}
		else {
			soapModels = new DocumentTreeSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DocumentTreeSoap[] toSoapModels(List<DocumentTree> models) {
		List<DocumentTreeSoap> soapModels = new ArrayList<DocumentTreeSoap>(models.size());

		for (DocumentTree model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DocumentTreeSoap[soapModels.size()]);
	}

	public DocumentTreeSoap() {
	}

	public long getPrimaryKey() {
		return _documenttreeid;
	}

	public void setPrimaryKey(long pk) {
		setDocumenttreeid(pk);
	}

	public long getDocumenttreeid() {
		return _documenttreeid;
	}

	public void setDocumenttreeid(long documenttreeid) {
		_documenttreeid = documenttreeid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public long getFileentryid() {
		return _fileentryid;
	}

	public void setFileentryid(long fileentryid) {
		_fileentryid = fileentryid;
	}

	public long getFolderid() {
		return _folderid;
	}

	public void setFolderid(long folderid) {
		_folderid = folderid;
	}

	public String getFoldername() {
		return _foldername;
	}

	public void setFoldername(String foldername) {
		_foldername = foldername;
	}

	public String getTitle() {
		return _title;
	}

	public void setTitle(String title) {
		_title = title;
	}

	public String getDescription() {
		return _description;
	}

	public void setDescription(String description) {
		_description = description;
	}

	public String getLeaf() {
		return _leaf;
	}

	public void setLeaf(String leaf) {
		_leaf = leaf;
	}

	public String getType() {
		return _type;
	}

	public void setType(String type) {
		_type = type;
	}

	private long _documenttreeid;
	private long _bilId;
	private long _fileentryid;
	private long _folderid;
	private String _foldername;
	private String _title;
	private String _description;
	private String _leaf;
	private String _type;
}