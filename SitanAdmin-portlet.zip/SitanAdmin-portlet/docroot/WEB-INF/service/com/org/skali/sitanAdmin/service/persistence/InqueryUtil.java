/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.org.skali.sitanAdmin.model.Inquery;

import java.util.List;

/**
 * The persistence utility for the inquery service. This utility wraps {@link InqueryPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see InqueryPersistence
 * @see InqueryPersistenceImpl
 * @generated
 */
public class InqueryUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Inquery inquery) {
		getPersistence().clearCache(inquery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Inquery> findWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Inquery> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Inquery> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Inquery update(Inquery inquery) throws SystemException {
		return getPersistence().update(inquery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Inquery update(Inquery inquery, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(inquery, serviceContext);
	}

	/**
	* Returns all the inqueries where datesize = &#63;.
	*
	* @param datesize the datesize
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBydatesize(
		java.lang.String datesize)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBydatesize(datesize);
	}

	/**
	* Returns a range of all the inqueries where datesize = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param datesize the datesize
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBydatesize(
		java.lang.String datesize, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBydatesize(datesize, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where datesize = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param datesize the datesize
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBydatesize(
		java.lang.String datesize, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBydatesize(datesize, start, end, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where datesize = &#63;.
	*
	* @param datesize the datesize
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBydatesize_First(
		java.lang.String datesize,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBydatesize_First(datesize, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where datesize = &#63;.
	*
	* @param datesize the datesize
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBydatesize_First(
		java.lang.String datesize,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBydatesize_First(datesize, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where datesize = &#63;.
	*
	* @param datesize the datesize
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBydatesize_Last(
		java.lang.String datesize,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBydatesize_Last(datesize, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where datesize = &#63;.
	*
	* @param datesize the datesize
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBydatesize_Last(
		java.lang.String datesize,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBydatesize_Last(datesize, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where datesize = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param datesize the datesize
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBydatesize_PrevAndNext(
		long inqueryId, java.lang.String datesize,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBydatesize_PrevAndNext(inqueryId, datesize,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where datesize = &#63; from the database.
	*
	* @param datesize the datesize
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBydatesize(java.lang.String datesize)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBydatesize(datesize);
	}

	/**
	* Returns the number of inqueries where datesize = &#63;.
	*
	* @param datesize the datesize
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBydatesize(java.lang.String datesize)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBydatesize(datesize);
	}

	/**
	* Returns all the inqueries where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBycheckSitesDate(
		java.lang.String checkSitesDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycheckSitesDate(checkSitesDate);
	}

	/**
	* Returns a range of all the inqueries where checkSitesDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesDate the check sites date
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBycheckSitesDate(
		java.lang.String checkSitesDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycheckSitesDate(checkSitesDate, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where checkSitesDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesDate the check sites date
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBycheckSitesDate(
		java.lang.String checkSitesDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycheckSitesDate(checkSitesDate, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBycheckSitesDate_First(
		java.lang.String checkSitesDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBycheckSitesDate_First(checkSitesDate, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBycheckSitesDate_First(
		java.lang.String checkSitesDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycheckSitesDate_First(checkSitesDate,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBycheckSitesDate_Last(
		java.lang.String checkSitesDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBycheckSitesDate_Last(checkSitesDate, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBycheckSitesDate_Last(
		java.lang.String checkSitesDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycheckSitesDate_Last(checkSitesDate, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where checkSitesDate = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param checkSitesDate the check sites date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBycheckSitesDate_PrevAndNext(
		long inqueryId, java.lang.String checkSitesDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBycheckSitesDate_PrevAndNext(inqueryId, checkSitesDate,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where checkSitesDate = &#63; from the database.
	*
	* @param checkSitesDate the check sites date
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycheckSitesDate(java.lang.String checkSitesDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycheckSitesDate(checkSitesDate);
	}

	/**
	* Returns the number of inqueries where checkSitesDate = &#63;.
	*
	* @param checkSitesDate the check sites date
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycheckSitesDate(java.lang.String checkSitesDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycheckSitesDate(checkSitesDate);
	}

	/**
	* Returns all the inqueries where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByreferenceEffective(referenceEffective);
	}

	/**
	* Returns a range of all the inqueries where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByreferenceEffective(referenceEffective, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByreferenceEffective(referenceEffective, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByreferenceEffective_First(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByreferenceEffective_First(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByreferenceEffective_Last(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByreferenceEffective_Last(referenceEffective,
			orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where referenceEffective = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findByreferenceEffective_PrevAndNext(
		long inqueryId, java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByreferenceEffective_PrevAndNext(inqueryId,
			referenceEffective, orderByComparator);
	}

	/**
	* Removes all the inqueries where referenceEffective = &#63; from the database.
	*
	* @param referenceEffective the reference effective
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByreferenceEffective(referenceEffective);
	}

	/**
	* Returns the number of inqueries where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByreferenceEffective(referenceEffective);
	}

	/**
	* Returns all the inqueries where source = &#63;.
	*
	* @param source the source
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBysource(
		java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysource(source);
	}

	/**
	* Returns a range of all the inqueries where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBysource(
		java.lang.String source, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBysource(source, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBysource(
		java.lang.String source, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBysource(source, start, end, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBysource_First(source, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysource_First(source, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBysource_Last(source, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBysource_Last(source, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where source = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBysource_PrevAndNext(
		long inqueryId, java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBysource_PrevAndNext(inqueryId, source,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where source = &#63; from the database.
	*
	* @param source the source
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBysource(source);
	}

	/**
	* Returns the number of inqueries where source = &#63;.
	*
	* @param source the source
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBysource(source);
	}

	/**
	* Returns all the inqueries where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameofowner(
		java.lang.String nameofowner)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBynameofowner(nameofowner);
	}

	/**
	* Returns a range of all the inqueries where nameofowner = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameofowner the nameofowner
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameofowner(
		java.lang.String nameofowner, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBynameofowner(nameofowner, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where nameofowner = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameofowner the nameofowner
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameofowner(
		java.lang.String nameofowner, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBynameofowner(nameofowner, start, end, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBynameofowner_First(
		java.lang.String nameofowner,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameofowner_First(nameofowner, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBynameofowner_First(
		java.lang.String nameofowner,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBynameofowner_First(nameofowner, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBynameofowner_Last(
		java.lang.String nameofowner,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameofowner_Last(nameofowner, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBynameofowner_Last(
		java.lang.String nameofowner,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBynameofowner_Last(nameofowner, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where nameofowner = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param nameofowner the nameofowner
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBynameofowner_PrevAndNext(
		long inqueryId, java.lang.String nameofowner,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameofowner_PrevAndNext(inqueryId, nameofowner,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where nameofowner = &#63; from the database.
	*
	* @param nameofowner the nameofowner
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBynameofowner(java.lang.String nameofowner)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBynameofowner(nameofowner);
	}

	/**
	* Returns the number of inqueries where nameofowner = &#63;.
	*
	* @param nameofowner the nameofowner
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBynameofowner(java.lang.String nameofowner)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBynameofowner(nameofowner);
	}

	/**
	* Returns all the inqueries where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByvehicleRegistration(
		java.lang.String vehicleRegistration)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByvehicleRegistration(vehicleRegistration);
	}

	/**
	* Returns a range of all the inqueries where vehicleRegistration = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistration the vehicle registration
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByvehicleRegistration(
		java.lang.String vehicleRegistration, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByvehicleRegistration(vehicleRegistration, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where vehicleRegistration = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistration the vehicle registration
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByvehicleRegistration(
		java.lang.String vehicleRegistration, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByvehicleRegistration(vehicleRegistration, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByvehicleRegistration_First(
		java.lang.String vehicleRegistration,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByvehicleRegistration_First(vehicleRegistration,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByvehicleRegistration_First(
		java.lang.String vehicleRegistration,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByvehicleRegistration_First(vehicleRegistration,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByvehicleRegistration_Last(
		java.lang.String vehicleRegistration,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByvehicleRegistration_Last(vehicleRegistration,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByvehicleRegistration_Last(
		java.lang.String vehicleRegistration,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByvehicleRegistration_Last(vehicleRegistration,
			orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where vehicleRegistration = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param vehicleRegistration the vehicle registration
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findByvehicleRegistration_PrevAndNext(
		long inqueryId, java.lang.String vehicleRegistration,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByvehicleRegistration_PrevAndNext(inqueryId,
			vehicleRegistration, orderByComparator);
	}

	/**
	* Removes all the inqueries where vehicleRegistration = &#63; from the database.
	*
	* @param vehicleRegistration the vehicle registration
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByvehicleRegistration(
		java.lang.String vehicleRegistration)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByvehicleRegistration(vehicleRegistration);
	}

	/**
	* Returns the number of inqueries where vehicleRegistration = &#63;.
	*
	* @param vehicleRegistration the vehicle registration
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countByvehicleRegistration(
		java.lang.String vehicleRegistration)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByvehicleRegistration(vehicleRegistration);
	}

	/**
	* Returns all the inqueries where territory = &#63;.
	*
	* @param territory the territory
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByterritory(
		java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByterritory(territory);
	}

	/**
	* Returns a range of all the inqueries where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByterritory(
		java.lang.String territory, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByterritory(territory, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByterritory(
		java.lang.String territory, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByterritory(territory, start, end, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByterritory_First(territory, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByterritory_First(territory, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByterritory_Last(territory, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByterritory_Last(territory, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where territory = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findByterritory_PrevAndNext(
		long inqueryId, java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByterritory_PrevAndNext(inqueryId, territory,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where territory = &#63; from the database.
	*
	* @param territory the territory
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByterritory(territory);
	}

	/**
	* Returns the number of inqueries where territory = &#63;.
	*
	* @param territory the territory
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByterritory(territory);
	}

	/**
	* Returns all the inqueries where state = &#63;.
	*
	* @param state the state
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBystate(
		java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state);
	}

	/**
	* Returns a range of all the inqueries where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBystate(
		java.lang.String state, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBystate(
		java.lang.String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystate(state, start, end, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBystate_First(state, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystate_First(state, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findBystate_Last(state, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystate_Last(state, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where state = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBystate_PrevAndNext(
		long inqueryId, java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBystate_PrevAndNext(inqueryId, state, orderByComparator);
	}

	/**
	* Removes all the inqueries where state = &#63; from the database.
	*
	* @param state the state
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystate(state);
	}

	/**
	* Returns the number of inqueries where state = &#63;.
	*
	* @param state the state
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystate(state);
	}

	/**
	* Returns all the inqueries where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBylocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylocationCageSita(locationCageSita);
	}

	/**
	* Returns a range of all the inqueries where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylocationCageSita(locationCageSita, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylocationCageSita(locationCageSita, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBylocationCageSita_First(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylocationCageSita_First(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBylocationCageSita_Last(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylocationCageSita_Last(locationCageSita,
			orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where locationCageSita = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBylocationCageSita_PrevAndNext(
		long inqueryId, java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBylocationCageSita_PrevAndNext(inqueryId,
			locationCageSita, orderByComparator);
	}

	/**
	* Removes all the inqueries where locationCageSita = &#63; from the database.
	*
	* @param locationCageSita the location cage sita
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylocationCageSita(locationCageSita);
	}

	/**
	* Returns the number of inqueries where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylocationCageSita(java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylocationCageSita(locationCageSita);
	}

	/**
	* Returns all the inqueries where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns a range of all the inqueries where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByforeclosureStatus(foreclosureStatus, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByforeclosureStatus(foreclosureStatus, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByforeclosureStatus_First(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByforeclosureStatus_First(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByforeclosureStatus_Last(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByforeclosureStatus_Last(foreclosureStatus,
			orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where foreclosureStatus = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findByforeclosureStatus_PrevAndNext(
		long inqueryId, java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findByforeclosureStatus_PrevAndNext(inqueryId,
			foreclosureStatus, orderByComparator);
	}

	/**
	* Removes all the inqueries where foreclosureStatus = &#63; from the database.
	*
	* @param foreclosureStatus the foreclosure status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns the number of inqueries where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByforeclosureStatus(foreclosureStatus);
	}

	/**
	* Returns all the inqueries where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @return the matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameOfofficer(
		java.lang.String nameOfofficer)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBynameOfofficer(nameOfofficer);
	}

	/**
	* Returns a range of all the inqueries where nameOfofficer = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameOfofficer the name ofofficer
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameOfofficer(
		java.lang.String nameOfofficer, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBynameOfofficer(nameOfofficer, start, end);
	}

	/**
	* Returns an ordered range of all the inqueries where nameOfofficer = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameOfofficer the name ofofficer
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findBynameOfofficer(
		java.lang.String nameOfofficer, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBynameOfofficer(nameOfofficer, start, end,
			orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBynameOfofficer_First(
		java.lang.String nameOfofficer,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameOfofficer_First(nameOfofficer, orderByComparator);
	}

	/**
	* Returns the first inquery in the ordered set where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBynameOfofficer_First(
		java.lang.String nameOfofficer,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBynameOfofficer_First(nameOfofficer, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findBynameOfofficer_Last(
		java.lang.String nameOfofficer,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameOfofficer_Last(nameOfofficer, orderByComparator);
	}

	/**
	* Returns the last inquery in the ordered set where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchBynameOfofficer_Last(
		java.lang.String nameOfofficer,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBynameOfofficer_Last(nameOfofficer, orderByComparator);
	}

	/**
	* Returns the inqueries before and after the current inquery in the ordered set where nameOfofficer = &#63;.
	*
	* @param inqueryId the primary key of the current inquery
	* @param nameOfofficer the name ofofficer
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery[] findBynameOfofficer_PrevAndNext(
		long inqueryId, java.lang.String nameOfofficer,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence()
				   .findBynameOfofficer_PrevAndNext(inqueryId, nameOfofficer,
			orderByComparator);
	}

	/**
	* Removes all the inqueries where nameOfofficer = &#63; from the database.
	*
	* @param nameOfofficer the name ofofficer
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBynameOfofficer(java.lang.String nameOfofficer)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBynameOfofficer(nameOfofficer);
	}

	/**
	* Returns the number of inqueries where nameOfofficer = &#63;.
	*
	* @param nameOfofficer the name ofofficer
	* @return the number of matching inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countBynameOfofficer(java.lang.String nameOfofficer)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBynameOfofficer(nameOfofficer);
	}

	/**
	* Caches the inquery in the entity cache if it is enabled.
	*
	* @param inquery the inquery
	*/
	public static void cacheResult(
		com.org.skali.sitanAdmin.model.Inquery inquery) {
		getPersistence().cacheResult(inquery);
	}

	/**
	* Caches the inqueries in the entity cache if it is enabled.
	*
	* @param inqueries the inqueries
	*/
	public static void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.Inquery> inqueries) {
		getPersistence().cacheResult(inqueries);
	}

	/**
	* Creates a new inquery with the primary key. Does not add the inquery to the database.
	*
	* @param inqueryId the primary key for the new inquery
	* @return the new inquery
	*/
	public static com.org.skali.sitanAdmin.model.Inquery create(long inqueryId) {
		return getPersistence().create(inqueryId);
	}

	/**
	* Removes the inquery with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param inqueryId the primary key of the inquery
	* @return the inquery that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery remove(long inqueryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().remove(inqueryId);
	}

	public static com.org.skali.sitanAdmin.model.Inquery updateImpl(
		com.org.skali.sitanAdmin.model.Inquery inquery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(inquery);
	}

	/**
	* Returns the inquery with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchInqueryException} if it could not be found.
	*
	* @param inqueryId the primary key of the inquery
	* @return the inquery
	* @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery findByPrimaryKey(
		long inqueryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchInqueryException {
		return getPersistence().findByPrimaryKey(inqueryId);
	}

	/**
	* Returns the inquery with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param inqueryId the primary key of the inquery
	* @return the inquery, or <code>null</code> if a inquery with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.Inquery fetchByPrimaryKey(
		long inqueryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(inqueryId);
	}

	/**
	* Returns all the inqueries.
	*
	* @return the inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the inqueries.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @return the range of inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the inqueries.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of inqueries
	* @param end the upper bound of the range of inqueries (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.Inquery> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the inqueries from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of inqueries.
	*
	* @return the number of inqueries
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static InqueryPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (InqueryPersistence)PortletBeanLocatorUtil.locate(com.org.skali.sitanAdmin.service.ClpSerializer.getServletContextName(),
					InqueryPersistence.class.getName());

			ReferenceRegistry.registerReference(InqueryUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(InqueryPersistence persistence) {
	}

	private static InqueryPersistence _persistence;
}