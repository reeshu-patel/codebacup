/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.org.skali.sitanAdmin.model.OfficerDetail;

import java.util.List;

/**
 * The persistence utility for the officer detail service. This utility wraps {@link OfficerDetailPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see OfficerDetailPersistence
 * @see OfficerDetailPersistenceImpl
 * @generated
 */
public class OfficerDetailUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(OfficerDetail officerDetail) {
		getPersistence().clearCache(officerDetail);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<OfficerDetail> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<OfficerDetail> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<OfficerDetail> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static OfficerDetail update(OfficerDetail officerDetail)
		throws SystemException {
		return getPersistence().update(officerDetail);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static OfficerDetail update(OfficerDetail officerDetail,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(officerDetail, serviceContext);
	}

	/**
	* Returns all the officer details where officerid = &#63;.
	*
	* @param officerid the officerid
	* @return the matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByofficerid(officerid);
	}

	/**
	* Returns a range of all the officer details where officerid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerid the officerid
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @return the range of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByofficerid(officerid, start, end);
	}

	/**
	* Returns an ordered range of all the officer details where officerid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerid the officerid
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findByofficerid(
		long officerid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByofficerid(officerid, start, end, orderByComparator);
	}

	/**
	* Returns the first officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail findByofficerid_First(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException {
		return getPersistence()
				   .findByofficerid_First(officerid, orderByComparator);
	}

	/**
	* Returns the first officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching officer detail, or <code>null</code> if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail fetchByofficerid_First(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByofficerid_First(officerid, orderByComparator);
	}

	/**
	* Returns the last officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail findByofficerid_Last(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException {
		return getPersistence()
				   .findByofficerid_Last(officerid, orderByComparator);
	}

	/**
	* Returns the last officer detail in the ordered set where officerid = &#63;.
	*
	* @param officerid the officerid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching officer detail, or <code>null</code> if a matching officer detail could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail fetchByofficerid_Last(
		long officerid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByofficerid_Last(officerid, orderByComparator);
	}

	/**
	* Removes all the officer details where officerid = &#63; from the database.
	*
	* @param officerid the officerid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByofficerid(long officerid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByofficerid(officerid);
	}

	/**
	* Returns the number of officer details where officerid = &#63;.
	*
	* @param officerid the officerid
	* @return the number of matching officer details
	* @throws SystemException if a system exception occurred
	*/
	public static int countByofficerid(long officerid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByofficerid(officerid);
	}

	/**
	* Caches the officer detail in the entity cache if it is enabled.
	*
	* @param officerDetail the officer detail
	*/
	public static void cacheResult(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail) {
		getPersistence().cacheResult(officerDetail);
	}

	/**
	* Caches the officer details in the entity cache if it is enabled.
	*
	* @param officerDetails the officer details
	*/
	public static void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> officerDetails) {
		getPersistence().cacheResult(officerDetails);
	}

	/**
	* Creates a new officer detail with the primary key. Does not add the officer detail to the database.
	*
	* @param officerid the primary key for the new officer detail
	* @return the new officer detail
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail create(
		long officerid) {
		return getPersistence().create(officerid);
	}

	/**
	* Removes the officer detail with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail remove(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException {
		return getPersistence().remove(officerid);
	}

	public static com.org.skali.sitanAdmin.model.OfficerDetail updateImpl(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(officerDetail);
	}

	/**
	* Returns the officer detail with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchOfficerDetailException} if it could not be found.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail
	* @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail findByPrimaryKey(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchOfficerDetailException {
		return getPersistence().findByPrimaryKey(officerid);
	}

	/**
	* Returns the officer detail with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param officerid the primary key of the officer detail
	* @return the officer detail, or <code>null</code> if a officer detail with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.OfficerDetail fetchByPrimaryKey(
		long officerid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(officerid);
	}

	/**
	* Returns all the officer details.
	*
	* @return the officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the officer details.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @return the range of officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the officer details.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of officer details
	* @param end the upper bound of the range of officer details (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of officer details
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.OfficerDetail> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the officer details from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of officer details.
	*
	* @return the number of officer details
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static OfficerDetailPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (OfficerDetailPersistence)PortletBeanLocatorUtil.locate(com.org.skali.sitanAdmin.service.ClpSerializer.getServletContextName(),
					OfficerDetailPersistence.class.getName());

			ReferenceRegistry.registerReference(OfficerDetailUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(OfficerDetailPersistence persistence) {
	}

	private static OfficerDetailPersistence _persistence;
}