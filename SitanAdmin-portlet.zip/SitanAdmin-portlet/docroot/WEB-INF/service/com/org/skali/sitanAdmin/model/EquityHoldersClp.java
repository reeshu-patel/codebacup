/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.EquityHoldersLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class EquityHoldersClp extends BaseModelImpl<EquityHolders>
	implements EquityHolders {
	public EquityHoldersClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return EquityHolders.class;
	}

	@Override
	public String getModelClassName() {
		return EquityHolders.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _equityholdersid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setEquityholdersid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _equityholdersid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("equityholdersid", getEquityholdersid());
		attributes.put("bilId", getBilId());
		attributes.put("name", getName());
		attributes.put("kpLama", getKpLama());
		attributes.put("newKp", getNewKp());
		attributes.put("value", getValue());
		attributes.put("percent", getPercent());
		attributes.put("gender", getGender());
		attributes.put("nation", getNation());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long equityholdersid = (Long)attributes.get("equityholdersid");

		if (equityholdersid != null) {
			setEquityholdersid(equityholdersid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String kpLama = (String)attributes.get("kpLama");

		if (kpLama != null) {
			setKpLama(kpLama);
		}

		String newKp = (String)attributes.get("newKp");

		if (newKp != null) {
			setNewKp(newKp);
		}

		String value = (String)attributes.get("value");

		if (value != null) {
			setValue(value);
		}

		String percent = (String)attributes.get("percent");

		if (percent != null) {
			setPercent(percent);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String nation = (String)attributes.get("nation");

		if (nation != null) {
			setNation(nation);
		}
	}

	@Override
	public long getEquityholdersid() {
		return _equityholdersid;
	}

	@Override
	public void setEquityholdersid(long equityholdersid) {
		_equityholdersid = equityholdersid;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setEquityholdersid", long.class);

				method.invoke(_equityHoldersRemoteModel, equityholdersid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_equityHoldersRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getName() {
		return _name;
	}

	@Override
	public void setName(String name) {
		_name = name;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setName", String.class);

				method.invoke(_equityHoldersRemoteModel, name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getKpLama() {
		return _kpLama;
	}

	@Override
	public void setKpLama(String kpLama) {
		_kpLama = kpLama;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setKpLama", String.class);

				method.invoke(_equityHoldersRemoteModel, kpLama);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNewKp() {
		return _newKp;
	}

	@Override
	public void setNewKp(String newKp) {
		_newKp = newKp;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setNewKp", String.class);

				method.invoke(_equityHoldersRemoteModel, newKp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getValue() {
		return _value;
	}

	@Override
	public void setValue(String value) {
		_value = value;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setValue", String.class);

				method.invoke(_equityHoldersRemoteModel, value);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPercent() {
		return _percent;
	}

	@Override
	public void setPercent(String percent) {
		_percent = percent;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setPercent", String.class);

				method.invoke(_equityHoldersRemoteModel, percent);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGender() {
		return _gender;
	}

	@Override
	public void setGender(String gender) {
		_gender = gender;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setGender", String.class);

				method.invoke(_equityHoldersRemoteModel, gender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNation() {
		return _nation;
	}

	@Override
	public void setNation(String nation) {
		_nation = nation;

		if (_equityHoldersRemoteModel != null) {
			try {
				Class<?> clazz = _equityHoldersRemoteModel.getClass();

				Method method = clazz.getMethod("setNation", String.class);

				method.invoke(_equityHoldersRemoteModel, nation);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEquityHoldersRemoteModel() {
		return _equityHoldersRemoteModel;
	}

	public void setEquityHoldersRemoteModel(
		BaseModel<?> equityHoldersRemoteModel) {
		_equityHoldersRemoteModel = equityHoldersRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _equityHoldersRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_equityHoldersRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EquityHoldersLocalServiceUtil.addEquityHolders(this);
		}
		else {
			EquityHoldersLocalServiceUtil.updateEquityHolders(this);
		}
	}

	@Override
	public EquityHolders toEscapedModel() {
		return (EquityHolders)ProxyUtil.newProxyInstance(EquityHolders.class.getClassLoader(),
			new Class[] { EquityHolders.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EquityHoldersClp clone = new EquityHoldersClp();

		clone.setEquityholdersid(getEquityholdersid());
		clone.setBilId(getBilId());
		clone.setName(getName());
		clone.setKpLama(getKpLama());
		clone.setNewKp(getNewKp());
		clone.setValue(getValue());
		clone.setPercent(getPercent());
		clone.setGender(getGender());
		clone.setNation(getNation());

		return clone;
	}

	@Override
	public int compareTo(EquityHolders equityHolders) {
		long primaryKey = equityHolders.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EquityHoldersClp)) {
			return false;
		}

		EquityHoldersClp equityHolders = (EquityHoldersClp)obj;

		long primaryKey = equityHolders.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{equityholdersid=");
		sb.append(getEquityholdersid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", name=");
		sb.append(getName());
		sb.append(", kpLama=");
		sb.append(getKpLama());
		sb.append(", newKp=");
		sb.append(getNewKp());
		sb.append(", value=");
		sb.append(getValue());
		sb.append(", percent=");
		sb.append(getPercent());
		sb.append(", gender=");
		sb.append(getGender());
		sb.append(", nation=");
		sb.append(getNation());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(31);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.EquityHolders");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>equityholdersid</column-name><column-value><![CDATA[");
		sb.append(getEquityholdersid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>name</column-name><column-value><![CDATA[");
		sb.append(getName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>kpLama</column-name><column-value><![CDATA[");
		sb.append(getKpLama());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>newKp</column-name><column-value><![CDATA[");
		sb.append(getNewKp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>value</column-name><column-value><![CDATA[");
		sb.append(getValue());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>percent</column-name><column-value><![CDATA[");
		sb.append(getPercent());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>gender</column-name><column-value><![CDATA[");
		sb.append(getGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nation</column-name><column-value><![CDATA[");
		sb.append(getNation());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _equityholdersid;
	private long _bilId;
	private String _name;
	private String _kpLama;
	private String _newKp;
	private String _value;
	private String _percent;
	private String _gender;
	private String _nation;
	private BaseModel<?> _equityHoldersRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}