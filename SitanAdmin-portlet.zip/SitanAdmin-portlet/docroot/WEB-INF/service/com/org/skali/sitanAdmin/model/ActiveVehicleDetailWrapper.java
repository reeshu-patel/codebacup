/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActiveVehicleDetail}.
 * </p>
 *
 * @author reeshu
 * @see ActiveVehicleDetail
 * @generated
 */
public class ActiveVehicleDetailWrapper implements ActiveVehicleDetail,
	ModelWrapper<ActiveVehicleDetail> {
	public ActiveVehicleDetailWrapper(ActiveVehicleDetail activeVehicleDetail) {
		_activeVehicleDetail = activeVehicleDetail;
	}

	@Override
	public Class<?> getModelClass() {
		return ActiveVehicleDetail.class;
	}

	@Override
	public String getModelClassName() {
		return ActiveVehicleDetail.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("vehicalid", getVehicalid());
		attributes.put("bilId", getBilId());
		attributes.put("classcode", getClasscode());
		attributes.put("byVehicle", getByVehicle());
		attributes.put("withoutMotor", getWithoutMotor());
		attributes.put("commencement", getCommencement());
		attributes.put("ageLimit", getAgeLimit());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long vehicalid = (Long)attributes.get("vehicalid");

		if (vehicalid != null) {
			setVehicalid(vehicalid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String classcode = (String)attributes.get("classcode");

		if (classcode != null) {
			setClasscode(classcode);
		}

		String byVehicle = (String)attributes.get("byVehicle");

		if (byVehicle != null) {
			setByVehicle(byVehicle);
		}

		String withoutMotor = (String)attributes.get("withoutMotor");

		if (withoutMotor != null) {
			setWithoutMotor(withoutMotor);
		}

		String commencement = (String)attributes.get("commencement");

		if (commencement != null) {
			setCommencement(commencement);
		}

		String ageLimit = (String)attributes.get("ageLimit");

		if (ageLimit != null) {
			setAgeLimit(ageLimit);
		}
	}

	/**
	* Returns the primary key of this active vehicle detail.
	*
	* @return the primary key of this active vehicle detail
	*/
	@Override
	public long getPrimaryKey() {
		return _activeVehicleDetail.getPrimaryKey();
	}

	/**
	* Sets the primary key of this active vehicle detail.
	*
	* @param primaryKey the primary key of this active vehicle detail
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_activeVehicleDetail.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the vehicalid of this active vehicle detail.
	*
	* @return the vehicalid of this active vehicle detail
	*/
	@Override
	public long getVehicalid() {
		return _activeVehicleDetail.getVehicalid();
	}

	/**
	* Sets the vehicalid of this active vehicle detail.
	*
	* @param vehicalid the vehicalid of this active vehicle detail
	*/
	@Override
	public void setVehicalid(long vehicalid) {
		_activeVehicleDetail.setVehicalid(vehicalid);
	}

	/**
	* Returns the bil ID of this active vehicle detail.
	*
	* @return the bil ID of this active vehicle detail
	*/
	@Override
	public long getBilId() {
		return _activeVehicleDetail.getBilId();
	}

	/**
	* Sets the bil ID of this active vehicle detail.
	*
	* @param bilId the bil ID of this active vehicle detail
	*/
	@Override
	public void setBilId(long bilId) {
		_activeVehicleDetail.setBilId(bilId);
	}

	/**
	* Returns the classcode of this active vehicle detail.
	*
	* @return the classcode of this active vehicle detail
	*/
	@Override
	public java.lang.String getClasscode() {
		return _activeVehicleDetail.getClasscode();
	}

	/**
	* Sets the classcode of this active vehicle detail.
	*
	* @param classcode the classcode of this active vehicle detail
	*/
	@Override
	public void setClasscode(java.lang.String classcode) {
		_activeVehicleDetail.setClasscode(classcode);
	}

	/**
	* Returns the by vehicle of this active vehicle detail.
	*
	* @return the by vehicle of this active vehicle detail
	*/
	@Override
	public java.lang.String getByVehicle() {
		return _activeVehicleDetail.getByVehicle();
	}

	/**
	* Sets the by vehicle of this active vehicle detail.
	*
	* @param byVehicle the by vehicle of this active vehicle detail
	*/
	@Override
	public void setByVehicle(java.lang.String byVehicle) {
		_activeVehicleDetail.setByVehicle(byVehicle);
	}

	/**
	* Returns the without motor of this active vehicle detail.
	*
	* @return the without motor of this active vehicle detail
	*/
	@Override
	public java.lang.String getWithoutMotor() {
		return _activeVehicleDetail.getWithoutMotor();
	}

	/**
	* Sets the without motor of this active vehicle detail.
	*
	* @param withoutMotor the without motor of this active vehicle detail
	*/
	@Override
	public void setWithoutMotor(java.lang.String withoutMotor) {
		_activeVehicleDetail.setWithoutMotor(withoutMotor);
	}

	/**
	* Returns the commencement of this active vehicle detail.
	*
	* @return the commencement of this active vehicle detail
	*/
	@Override
	public java.lang.String getCommencement() {
		return _activeVehicleDetail.getCommencement();
	}

	/**
	* Sets the commencement of this active vehicle detail.
	*
	* @param commencement the commencement of this active vehicle detail
	*/
	@Override
	public void setCommencement(java.lang.String commencement) {
		_activeVehicleDetail.setCommencement(commencement);
	}

	/**
	* Returns the age limit of this active vehicle detail.
	*
	* @return the age limit of this active vehicle detail
	*/
	@Override
	public java.lang.String getAgeLimit() {
		return _activeVehicleDetail.getAgeLimit();
	}

	/**
	* Sets the age limit of this active vehicle detail.
	*
	* @param ageLimit the age limit of this active vehicle detail
	*/
	@Override
	public void setAgeLimit(java.lang.String ageLimit) {
		_activeVehicleDetail.setAgeLimit(ageLimit);
	}

	@Override
	public boolean isNew() {
		return _activeVehicleDetail.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_activeVehicleDetail.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _activeVehicleDetail.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_activeVehicleDetail.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _activeVehicleDetail.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _activeVehicleDetail.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_activeVehicleDetail.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _activeVehicleDetail.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_activeVehicleDetail.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_activeVehicleDetail.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_activeVehicleDetail.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ActiveVehicleDetailWrapper((ActiveVehicleDetail)_activeVehicleDetail.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.ActiveVehicleDetail activeVehicleDetail) {
		return _activeVehicleDetail.compareTo(activeVehicleDetail);
	}

	@Override
	public int hashCode() {
		return _activeVehicleDetail.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.ActiveVehicleDetail> toCacheModel() {
		return _activeVehicleDetail.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.ActiveVehicleDetail toEscapedModel() {
		return new ActiveVehicleDetailWrapper(_activeVehicleDetail.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.ActiveVehicleDetail toUnescapedModel() {
		return new ActiveVehicleDetailWrapper(_activeVehicleDetail.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _activeVehicleDetail.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _activeVehicleDetail.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_activeVehicleDetail.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ActiveVehicleDetailWrapper)) {
			return false;
		}

		ActiveVehicleDetailWrapper activeVehicleDetailWrapper = (ActiveVehicleDetailWrapper)obj;

		if (Validator.equals(_activeVehicleDetail,
					activeVehicleDetailWrapper._activeVehicleDetail)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ActiveVehicleDetail getWrappedActiveVehicleDetail() {
		return _activeVehicleDetail;
	}

	@Override
	public ActiveVehicleDetail getWrappedModel() {
		return _activeVehicleDetail;
	}

	@Override
	public void resetOriginalValues() {
		_activeVehicleDetail.resetOriginalValues();
	}

	private ActiveVehicleDetail _activeVehicleDetail;
}