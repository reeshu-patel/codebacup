/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.ErrortypesServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.ErrortypesServiceSoap
 * @generated
 */
public class ErrortypesSoap implements Serializable {
	public static ErrortypesSoap toSoapModel(Errortypes model) {
		ErrortypesSoap soapModel = new ErrortypesSoap();

		soapModel.setErrortypeid(model.getErrortypeid());
		soapModel.setBilId(model.getBilId());
		soapModel.setErrortypes(model.getErrortypes());
		soapModel.setSourcetypes(model.getSourcetypes());

		return soapModel;
	}

	public static ErrortypesSoap[] toSoapModels(Errortypes[] models) {
		ErrortypesSoap[] soapModels = new ErrortypesSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ErrortypesSoap[][] toSoapModels(Errortypes[][] models) {
		ErrortypesSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ErrortypesSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ErrortypesSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ErrortypesSoap[] toSoapModels(List<Errortypes> models) {
		List<ErrortypesSoap> soapModels = new ArrayList<ErrortypesSoap>(models.size());

		for (Errortypes model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ErrortypesSoap[soapModels.size()]);
	}

	public ErrortypesSoap() {
	}

	public long getPrimaryKey() {
		return _errortypeid;
	}

	public void setPrimaryKey(long pk) {
		setErrortypeid(pk);
	}

	public long getErrortypeid() {
		return _errortypeid;
	}

	public void setErrortypeid(long errortypeid) {
		_errortypeid = errortypeid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getErrortypes() {
		return _errortypes;
	}

	public void setErrortypes(String errortypes) {
		_errortypes = errortypes;
	}

	public String getSourcetypes() {
		return _sourcetypes;
	}

	public void setSourcetypes(String sourcetypes) {
		_sourcetypes = sourcetypes;
	}

	private long _errortypeid;
	private long _bilId;
	private String _errortypes;
	private String _sourcetypes;
}