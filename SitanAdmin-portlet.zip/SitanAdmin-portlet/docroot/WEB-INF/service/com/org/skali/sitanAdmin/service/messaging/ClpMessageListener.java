/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.messaging;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

import com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailServiceUtil;
import com.org.skali.sitanAdmin.service.ActionSummeryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ActionSummeryServiceUtil;
import com.org.skali.sitanAdmin.service.ActiveVehicleDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ActiveVehicleDetailServiceUtil;
import com.org.skali.sitanAdmin.service.BillInqueryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.BillInqueryServiceUtil;
import com.org.skali.sitanAdmin.service.BoardDirectorLocalServiceUtil;
import com.org.skali.sitanAdmin.service.BoardDirectorServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.DocumentTreeLocalServiceUtil;
import com.org.skali.sitanAdmin.service.DocumentTreeServiceUtil;
import com.org.skali.sitanAdmin.service.EquityHoldersLocalServiceUtil;
import com.org.skali.sitanAdmin.service.EquityHoldersServiceUtil;
import com.org.skali.sitanAdmin.service.InqueryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.InqueryServiceUtil;
import com.org.skali.sitanAdmin.service.LicensesStatusLocalServiceUtil;
import com.org.skali.sitanAdmin.service.LicensesStatusServiceUtil;
import com.org.skali.sitanAdmin.service.OfficerDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.OfficerDetailServiceUtil;
import com.org.skali.sitanAdmin.service.RecoredComunicationLocalServiceUtil;
import com.org.skali.sitanAdmin.service.RecoredComunicationServiceUtil;
import com.org.skali.sitanAdmin.service.SitaanAdminLocalServiceUtil;
import com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil;
import com.org.skali.sitanAdmin.service.SourceTypesLocalServiceUtil;
import com.org.skali.sitanAdmin.service.SourceTypesServiceUtil;
import com.org.skali.sitanAdmin.service.complainUserinfoLocalServiceUtil;
import com.org.skali.sitanAdmin.service.complainUserinfoServiceUtil;
import com.org.skali.sitanAdmin.service.detailoksboydsLocalServiceUtil;
import com.org.skali.sitanAdmin.service.detailoksboydsServiceUtil;
import com.org.skali.sitanAdmin.service.vehicalInfoLocalServiceUtil;
import com.org.skali.sitanAdmin.service.vehicalInfoServiceUtil;
import com.org.skali.sitanAdmin.service.visualchecklistLocalServiceUtil;
import com.org.skali.sitanAdmin.service.visualchecklistServiceUtil;

/**
 * @author reeshu
 */
public class ClpMessageListener extends BaseMessageListener {
	public static String getServletContextName() {
		return ClpSerializer.getServletContextName();
	}

	@Override
	protected void doReceive(Message message) throws Exception {
		String command = message.getString("command");
		String servletContextName = message.getString("servletContextName");

		if (command.equals("undeploy") &&
				servletContextName.equals(getServletContextName())) {
			AcceptanceVehicleDetailLocalServiceUtil.clearService();

			AcceptanceVehicleDetailServiceUtil.clearService();
			ActionSummeryLocalServiceUtil.clearService();

			ActionSummeryServiceUtil.clearService();
			ActiveVehicleDetailLocalServiceUtil.clearService();

			ActiveVehicleDetailServiceUtil.clearService();
			BillInqueryLocalServiceUtil.clearService();

			BillInqueryServiceUtil.clearService();
			BoardDirectorLocalServiceUtil.clearService();

			BoardDirectorServiceUtil.clearService();
			complainUserinfoLocalServiceUtil.clearService();

			complainUserinfoServiceUtil.clearService();
			detailoksboydsLocalServiceUtil.clearService();

			detailoksboydsServiceUtil.clearService();
			DocumentTreeLocalServiceUtil.clearService();

			DocumentTreeServiceUtil.clearService();
			EquityHoldersLocalServiceUtil.clearService();

			EquityHoldersServiceUtil.clearService();
			InqueryLocalServiceUtil.clearService();

			InqueryServiceUtil.clearService();
			LicensesStatusLocalServiceUtil.clearService();

			LicensesStatusServiceUtil.clearService();
			OfficerDetailLocalServiceUtil.clearService();

			OfficerDetailServiceUtil.clearService();
			RecoredComunicationLocalServiceUtil.clearService();

			RecoredComunicationServiceUtil.clearService();
			SitaanAdminLocalServiceUtil.clearService();

			SitaanAdminServiceUtil.clearService();
			SourceTypesLocalServiceUtil.clearService();

			SourceTypesServiceUtil.clearService();
			vehicalInfoLocalServiceUtil.clearService();

			vehicalInfoServiceUtil.clearService();
			visualchecklistLocalServiceUtil.clearService();

			visualchecklistServiceUtil.clearService();
		}
	}
}