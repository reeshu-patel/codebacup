/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link SitaanAdminService}.
 *
 * @author reeshu
 * @see SitaanAdminService
 * @generated
 */
public class SitaanAdminServiceWrapper implements SitaanAdminService,
	ServiceWrapper<SitaanAdminService> {
	public SitaanAdminServiceWrapper(SitaanAdminService sitaanAdminService) {
		_sitaanAdminService = sitaanAdminService;
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _sitaanAdminService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_sitaanAdminService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _sitaanAdminService.invokeMethod(name, parameterTypes, arguments);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject FinedByColumn(
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String state,
		java.lang.String vehicleRegistrationNo,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String locationCageSita,
		java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String action, java.lang.String paymentStatus)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminService.FinedByColumn(dateSeized, checkSitesSita,
			source, ownerName, territory, state, vehicleRegistrationNo,
			referenceEffective, confiscatedPeriod, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, action,
			paymentStatus);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject FinedByBillId(long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminService.FinedByBillId(bilId);
	}

	@Override
	public java.util.List<com.liferay.portal.model.User> geCMDUsers()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminService.geCMDUsers();
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject ActionCaseByBillId(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminService.ActionCaseByBillId(bilId);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject UploadDocumentSearch(
		java.lang.String title)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _sitaanAdminService.UploadDocumentSearch(title);
	}

	@Override
	public void Upload_Document(java.io.File file, java.lang.String fileName)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		_sitaanAdminService.Upload_Document(file, fileName);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONArray Document_Binding_Tree()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.Document_Binding_Tree();
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject Officer_List()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.Officer_List();
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject VisualInspection(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.VisualInspection(bilId);
	}

	@Override
	public com.org.skali.sitanAdmin.model.visualchecklist VisualInspectionPost(
		long checkId, long bilId, java.lang.String numberplates,
		java.lang.String numberplatesNote, java.lang.String forwardlighting,
		java.lang.String forwardlightingNote, java.lang.String backlight,
		java.lang.String backlightNote, java.lang.String trafficLight,
		java.lang.String trafficLightNote, java.lang.String signallight,
		java.lang.String signallightNote, java.lang.String vehiclebody,
		java.lang.String vehiclebodyNote, java.lang.String vehicleAccessories,
		java.lang.String vehicleAccessoriesNote, java.lang.String windscreen,
		java.lang.String windscreenNote, java.lang.String rearMirror,
		java.lang.String rearMirrorNote, java.lang.String doormirror,
		java.lang.String doormirrorNote, java.lang.String vehicletires,
		java.lang.String vehicletiresNote, java.lang.String frontbumper,
		java.lang.String frontbumperNote, java.lang.String rearbumper,
		java.lang.String rearbumperNote, java.lang.String frontseat,
		java.lang.String frontseatNote, java.lang.String rearseats,
		java.lang.String rearseatsNote, java.lang.String note,
		java.lang.String investigatorname, java.lang.String investigatorEmail,
		java.lang.String investigatorphone)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.VisualInspectionPost(checkId, bilId,
			numberplates, numberplatesNote, forwardlighting,
			forwardlightingNote, backlight, backlightNote, trafficLight,
			trafficLightNote, signallight, signallightNote, vehiclebody,
			vehiclebodyNote, vehicleAccessories, vehicleAccessoriesNote,
			windscreen, windscreenNote, rearMirror, rearMirrorNote, doormirror,
			doormirrorNote, vehicletires, vehicletiresNote, frontbumper,
			frontbumperNote, rearbumper, rearbumperNote, frontseat,
			frontseatNote, rearseats, rearseatsNote, note, investigatorname,
			investigatorEmail, investigatorphone);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject SaveVisualInspection(
		long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.SaveVisualInspection(bilId, checkId);
	}

	@Override
	public void Multiple_Upload_Document(java.io.File[] file)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		_sitaanAdminService.Multiple_Upload_Document(file);
	}

	@Override
	public com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail AcceptaneceVehicalDetail(
		long vehicalid, long bilId, java.lang.String vehiNumberPlate,
		java.lang.String ownerName, java.lang.String companyRepresentative,
		java.lang.String kpNo, java.lang.String chronicle,
		java.lang.String Signature, java.lang.String accodocument,
		java.lang.String cardIdentity, java.lang.String drivingLicense,
		java.lang.String grantVehicle, java.lang.String attorney,
		java.lang.String numberPlateDetail)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.AcceptaneceVehicalDetail(vehicalid, bilId,
			vehiNumberPlate, ownerName, companyRepresentative, kpNo, chronicle,
			Signature, accodocument, cardIdentity, drivingLicense,
			grantVehicle, attorney, numberPlateDetail);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject FileAcceptaneceVehicalDetail(
		long vehicalid, long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException {
		return _sitaanAdminService.FileAcceptaneceVehicalDetail(vehicalid, bilId);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public SitaanAdminService getWrappedSitaanAdminService() {
		return _sitaanAdminService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedSitaanAdminService(
		SitaanAdminService sitaanAdminService) {
		_sitaanAdminService = sitaanAdminService;
	}

	@Override
	public SitaanAdminService getWrappedService() {
		return _sitaanAdminService;
	}

	@Override
	public void setWrappedService(SitaanAdminService sitaanAdminService) {
		_sitaanAdminService = sitaanAdminService;
	}

	private SitaanAdminService _sitaanAdminService;
}