/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.EquityHoldersServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.EquityHoldersServiceSoap
 * @generated
 */
public class EquityHoldersSoap implements Serializable {
	public static EquityHoldersSoap toSoapModel(EquityHolders model) {
		EquityHoldersSoap soapModel = new EquityHoldersSoap();

		soapModel.setEquityholdersid(model.getEquityholdersid());
		soapModel.setBilId(model.getBilId());
		soapModel.setName(model.getName());
		soapModel.setKpLama(model.getKpLama());
		soapModel.setNewKp(model.getNewKp());
		soapModel.setValue(model.getValue());
		soapModel.setPercent(model.getPercent());
		soapModel.setGender(model.getGender());
		soapModel.setNation(model.getNation());

		return soapModel;
	}

	public static EquityHoldersSoap[] toSoapModels(EquityHolders[] models) {
		EquityHoldersSoap[] soapModels = new EquityHoldersSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EquityHoldersSoap[][] toSoapModels(EquityHolders[][] models) {
		EquityHoldersSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EquityHoldersSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EquityHoldersSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EquityHoldersSoap[] toSoapModels(List<EquityHolders> models) {
		List<EquityHoldersSoap> soapModels = new ArrayList<EquityHoldersSoap>(models.size());

		for (EquityHolders model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EquityHoldersSoap[soapModels.size()]);
	}

	public EquityHoldersSoap() {
	}

	public long getPrimaryKey() {
		return _equityholdersid;
	}

	public void setPrimaryKey(long pk) {
		setEquityholdersid(pk);
	}

	public long getEquityholdersid() {
		return _equityholdersid;
	}

	public void setEquityholdersid(long equityholdersid) {
		_equityholdersid = equityholdersid;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public String getKpLama() {
		return _kpLama;
	}

	public void setKpLama(String kpLama) {
		_kpLama = kpLama;
	}

	public String getNewKp() {
		return _newKp;
	}

	public void setNewKp(String newKp) {
		_newKp = newKp;
	}

	public String getValue() {
		return _value;
	}

	public void setValue(String value) {
		_value = value;
	}

	public String getPercent() {
		return _percent;
	}

	public void setPercent(String percent) {
		_percent = percent;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getNation() {
		return _nation;
	}

	public void setNation(String nation) {
		_nation = nation;
	}

	private long _equityholdersid;
	private long _bilId;
	private String _name;
	private String _kpLama;
	private String _newKp;
	private String _value;
	private String _percent;
	private String _gender;
	private String _nation;
}