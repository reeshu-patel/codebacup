/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link BoardDirector}.
 * </p>
 *
 * @author reeshu
 * @see BoardDirector
 * @generated
 */
public class BoardDirectorWrapper implements BoardDirector,
	ModelWrapper<BoardDirector> {
	public BoardDirectorWrapper(BoardDirector boardDirector) {
		_boardDirector = boardDirector;
	}

	@Override
	public Class<?> getModelClass() {
		return BoardDirector.class;
	}

	@Override
	public String getModelClassName() {
		return BoardDirector.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("boarddirectorid", getBoarddirectorid());
		attributes.put("bilId", getBilId());
		attributes.put("wealp", getWealp());
		attributes.put("kplama", getKplama());
		attributes.put("newKp", getNewKp());
		attributes.put("position", getPosition());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long boarddirectorid = (Long)attributes.get("boarddirectorid");

		if (boarddirectorid != null) {
			setBoarddirectorid(boarddirectorid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String wealp = (String)attributes.get("wealp");

		if (wealp != null) {
			setWealp(wealp);
		}

		String kplama = (String)attributes.get("kplama");

		if (kplama != null) {
			setKplama(kplama);
		}

		String newKp = (String)attributes.get("newKp");

		if (newKp != null) {
			setNewKp(newKp);
		}

		String position = (String)attributes.get("position");

		if (position != null) {
			setPosition(position);
		}
	}

	/**
	* Returns the primary key of this board director.
	*
	* @return the primary key of this board director
	*/
	@Override
	public long getPrimaryKey() {
		return _boardDirector.getPrimaryKey();
	}

	/**
	* Sets the primary key of this board director.
	*
	* @param primaryKey the primary key of this board director
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_boardDirector.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the boarddirectorid of this board director.
	*
	* @return the boarddirectorid of this board director
	*/
	@Override
	public long getBoarddirectorid() {
		return _boardDirector.getBoarddirectorid();
	}

	/**
	* Sets the boarddirectorid of this board director.
	*
	* @param boarddirectorid the boarddirectorid of this board director
	*/
	@Override
	public void setBoarddirectorid(long boarddirectorid) {
		_boardDirector.setBoarddirectorid(boarddirectorid);
	}

	/**
	* Returns the bil ID of this board director.
	*
	* @return the bil ID of this board director
	*/
	@Override
	public long getBilId() {
		return _boardDirector.getBilId();
	}

	/**
	* Sets the bil ID of this board director.
	*
	* @param bilId the bil ID of this board director
	*/
	@Override
	public void setBilId(long bilId) {
		_boardDirector.setBilId(bilId);
	}

	/**
	* Returns the wealp of this board director.
	*
	* @return the wealp of this board director
	*/
	@Override
	public java.lang.String getWealp() {
		return _boardDirector.getWealp();
	}

	/**
	* Sets the wealp of this board director.
	*
	* @param wealp the wealp of this board director
	*/
	@Override
	public void setWealp(java.lang.String wealp) {
		_boardDirector.setWealp(wealp);
	}

	/**
	* Returns the kplama of this board director.
	*
	* @return the kplama of this board director
	*/
	@Override
	public java.lang.String getKplama() {
		return _boardDirector.getKplama();
	}

	/**
	* Sets the kplama of this board director.
	*
	* @param kplama the kplama of this board director
	*/
	@Override
	public void setKplama(java.lang.String kplama) {
		_boardDirector.setKplama(kplama);
	}

	/**
	* Returns the new kp of this board director.
	*
	* @return the new kp of this board director
	*/
	@Override
	public java.lang.String getNewKp() {
		return _boardDirector.getNewKp();
	}

	/**
	* Sets the new kp of this board director.
	*
	* @param newKp the new kp of this board director
	*/
	@Override
	public void setNewKp(java.lang.String newKp) {
		_boardDirector.setNewKp(newKp);
	}

	/**
	* Returns the position of this board director.
	*
	* @return the position of this board director
	*/
	@Override
	public java.lang.String getPosition() {
		return _boardDirector.getPosition();
	}

	/**
	* Sets the position of this board director.
	*
	* @param position the position of this board director
	*/
	@Override
	public void setPosition(java.lang.String position) {
		_boardDirector.setPosition(position);
	}

	@Override
	public boolean isNew() {
		return _boardDirector.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_boardDirector.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _boardDirector.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_boardDirector.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _boardDirector.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _boardDirector.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_boardDirector.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _boardDirector.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_boardDirector.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_boardDirector.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_boardDirector.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new BoardDirectorWrapper((BoardDirector)_boardDirector.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.BoardDirector boardDirector) {
		return _boardDirector.compareTo(boardDirector);
	}

	@Override
	public int hashCode() {
		return _boardDirector.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.BoardDirector> toCacheModel() {
		return _boardDirector.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.BoardDirector toEscapedModel() {
		return new BoardDirectorWrapper(_boardDirector.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.BoardDirector toUnescapedModel() {
		return new BoardDirectorWrapper(_boardDirector.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _boardDirector.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _boardDirector.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_boardDirector.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BoardDirectorWrapper)) {
			return false;
		}

		BoardDirectorWrapper boardDirectorWrapper = (BoardDirectorWrapper)obj;

		if (Validator.equals(_boardDirector, boardDirectorWrapper._boardDirector)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public BoardDirector getWrappedBoardDirector() {
		return _boardDirector;
	}

	@Override
	public BoardDirector getWrappedModel() {
		return _boardDirector;
	}

	@Override
	public void resetOriginalValues() {
		_boardDirector.resetOriginalValues();
	}

	private BoardDirector _boardDirector;
}