/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.ErrortypesSourceLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class ErrortypesSourceClp extends BaseModelImpl<ErrortypesSource>
	implements ErrortypesSource {
	public ErrortypesSourceClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return ErrortypesSource.class;
	}

	@Override
	public String getModelClassName() {
		return ErrortypesSource.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _errortypeid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setErrortypeid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _errortypeid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("errortypeid", getErrortypeid());
		attributes.put("bilId", getBilId());
		attributes.put("errortypes", getErrortypes());
		attributes.put("sourcetypes", getSourcetypes());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long errortypeid = (Long)attributes.get("errortypeid");

		if (errortypeid != null) {
			setErrortypeid(errortypeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String errortypes = (String)attributes.get("errortypes");

		if (errortypes != null) {
			setErrortypes(errortypes);
		}

		String sourcetypes = (String)attributes.get("sourcetypes");

		if (sourcetypes != null) {
			setSourcetypes(sourcetypes);
		}
	}

	@Override
	public long getErrortypeid() {
		return _errortypeid;
	}

	@Override
	public void setErrortypeid(long errortypeid) {
		_errortypeid = errortypeid;

		if (_errortypesSourceRemoteModel != null) {
			try {
				Class<?> clazz = _errortypesSourceRemoteModel.getClass();

				Method method = clazz.getMethod("setErrortypeid", long.class);

				method.invoke(_errortypesSourceRemoteModel, errortypeid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_errortypesSourceRemoteModel != null) {
			try {
				Class<?> clazz = _errortypesSourceRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_errortypesSourceRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getErrortypes() {
		return _errortypes;
	}

	@Override
	public void setErrortypes(String errortypes) {
		_errortypes = errortypes;

		if (_errortypesSourceRemoteModel != null) {
			try {
				Class<?> clazz = _errortypesSourceRemoteModel.getClass();

				Method method = clazz.getMethod("setErrortypes", String.class);

				method.invoke(_errortypesSourceRemoteModel, errortypes);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSourcetypes() {
		return _sourcetypes;
	}

	@Override
	public void setSourcetypes(String sourcetypes) {
		_sourcetypes = sourcetypes;

		if (_errortypesSourceRemoteModel != null) {
			try {
				Class<?> clazz = _errortypesSourceRemoteModel.getClass();

				Method method = clazz.getMethod("setSourcetypes", String.class);

				method.invoke(_errortypesSourceRemoteModel, sourcetypes);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getErrortypesSourceRemoteModel() {
		return _errortypesSourceRemoteModel;
	}

	public void setErrortypesSourceRemoteModel(
		BaseModel<?> errortypesSourceRemoteModel) {
		_errortypesSourceRemoteModel = errortypesSourceRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _errortypesSourceRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_errortypesSourceRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			ErrortypesSourceLocalServiceUtil.addErrortypesSource(this);
		}
		else {
			ErrortypesSourceLocalServiceUtil.updateErrortypesSource(this);
		}
	}

	@Override
	public ErrortypesSource toEscapedModel() {
		return (ErrortypesSource)ProxyUtil.newProxyInstance(ErrortypesSource.class.getClassLoader(),
			new Class[] { ErrortypesSource.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		ErrortypesSourceClp clone = new ErrortypesSourceClp();

		clone.setErrortypeid(getErrortypeid());
		clone.setBilId(getBilId());
		clone.setErrortypes(getErrortypes());
		clone.setSourcetypes(getSourcetypes());

		return clone;
	}

	@Override
	public int compareTo(ErrortypesSource errortypesSource) {
		long primaryKey = errortypesSource.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ErrortypesSourceClp)) {
			return false;
		}

		ErrortypesSourceClp errortypesSource = (ErrortypesSourceClp)obj;

		long primaryKey = errortypesSource.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{errortypeid=");
		sb.append(getErrortypeid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", errortypes=");
		sb.append(getErrortypes());
		sb.append(", sourcetypes=");
		sb.append(getSourcetypes());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(16);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.ErrortypesSource");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>errortypeid</column-name><column-value><![CDATA[");
		sb.append(getErrortypeid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>errortypes</column-name><column-value><![CDATA[");
		sb.append(getErrortypes());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>sourcetypes</column-name><column-value><![CDATA[");
		sb.append(getSourcetypes());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _errortypeid;
	private long _bilId;
	private String _errortypes;
	private String _sourcetypes;
	private BaseModel<?> _errortypesSourceRemoteModel;
}