/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActionSummery}.
 * </p>
 *
 * @author reeshu
 * @see ActionSummery
 * @generated
 */
public class ActionSummeryWrapper implements ActionSummery,
	ModelWrapper<ActionSummery> {
	public ActionSummeryWrapper(ActionSummery actionSummery) {
		_actionSummery = actionSummery;
	}

	@Override
	public Class<?> getModelClass() {
		return ActionSummery.class;
	}

	@Override
	public String getModelClassName() {
		return ActionSummery.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("actionsummeryid", getActionsummeryid());
		attributes.put("bilId", getBilId());
		attributes.put("dateTime", getDateTime());
		attributes.put("status", getStatus());
		attributes.put("action", getAction());
		attributes.put("actionBy", getActionBy());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long actionsummeryid = (Long)attributes.get("actionsummeryid");

		if (actionsummeryid != null) {
			setActionsummeryid(actionsummeryid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String dateTime = (String)attributes.get("dateTime");

		if (dateTime != null) {
			setDateTime(dateTime);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String action = (String)attributes.get("action");

		if (action != null) {
			setAction(action);
		}

		String actionBy = (String)attributes.get("actionBy");

		if (actionBy != null) {
			setActionBy(actionBy);
		}
	}

	/**
	* Returns the primary key of this action summery.
	*
	* @return the primary key of this action summery
	*/
	@Override
	public long getPrimaryKey() {
		return _actionSummery.getPrimaryKey();
	}

	/**
	* Sets the primary key of this action summery.
	*
	* @param primaryKey the primary key of this action summery
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_actionSummery.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the actionsummeryid of this action summery.
	*
	* @return the actionsummeryid of this action summery
	*/
	@Override
	public long getActionsummeryid() {
		return _actionSummery.getActionsummeryid();
	}

	/**
	* Sets the actionsummeryid of this action summery.
	*
	* @param actionsummeryid the actionsummeryid of this action summery
	*/
	@Override
	public void setActionsummeryid(long actionsummeryid) {
		_actionSummery.setActionsummeryid(actionsummeryid);
	}

	/**
	* Returns the bil ID of this action summery.
	*
	* @return the bil ID of this action summery
	*/
	@Override
	public long getBilId() {
		return _actionSummery.getBilId();
	}

	/**
	* Sets the bil ID of this action summery.
	*
	* @param bilId the bil ID of this action summery
	*/
	@Override
	public void setBilId(long bilId) {
		_actionSummery.setBilId(bilId);
	}

	/**
	* Returns the date time of this action summery.
	*
	* @return the date time of this action summery
	*/
	@Override
	public java.lang.String getDateTime() {
		return _actionSummery.getDateTime();
	}

	/**
	* Sets the date time of this action summery.
	*
	* @param dateTime the date time of this action summery
	*/
	@Override
	public void setDateTime(java.lang.String dateTime) {
		_actionSummery.setDateTime(dateTime);
	}

	/**
	* Returns the status of this action summery.
	*
	* @return the status of this action summery
	*/
	@Override
	public java.lang.String getStatus() {
		return _actionSummery.getStatus();
	}

	/**
	* Sets the status of this action summery.
	*
	* @param status the status of this action summery
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_actionSummery.setStatus(status);
	}

	/**
	* Returns the action of this action summery.
	*
	* @return the action of this action summery
	*/
	@Override
	public java.lang.String getAction() {
		return _actionSummery.getAction();
	}

	/**
	* Sets the action of this action summery.
	*
	* @param action the action of this action summery
	*/
	@Override
	public void setAction(java.lang.String action) {
		_actionSummery.setAction(action);
	}

	/**
	* Returns the action by of this action summery.
	*
	* @return the action by of this action summery
	*/
	@Override
	public java.lang.String getActionBy() {
		return _actionSummery.getActionBy();
	}

	/**
	* Sets the action by of this action summery.
	*
	* @param actionBy the action by of this action summery
	*/
	@Override
	public void setActionBy(java.lang.String actionBy) {
		_actionSummery.setActionBy(actionBy);
	}

	@Override
	public boolean isNew() {
		return _actionSummery.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_actionSummery.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _actionSummery.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_actionSummery.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _actionSummery.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _actionSummery.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_actionSummery.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _actionSummery.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_actionSummery.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_actionSummery.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_actionSummery.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ActionSummeryWrapper((ActionSummery)_actionSummery.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.ActionSummery actionSummery) {
		return _actionSummery.compareTo(actionSummery);
	}

	@Override
	public int hashCode() {
		return _actionSummery.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.ActionSummery> toCacheModel() {
		return _actionSummery.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.ActionSummery toEscapedModel() {
		return new ActionSummeryWrapper(_actionSummery.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.ActionSummery toUnescapedModel() {
		return new ActionSummeryWrapper(_actionSummery.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _actionSummery.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _actionSummery.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_actionSummery.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ActionSummeryWrapper)) {
			return false;
		}

		ActionSummeryWrapper actionSummeryWrapper = (ActionSummeryWrapper)obj;

		if (Validator.equals(_actionSummery, actionSummeryWrapper._actionSummery)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ActionSummery getWrappedActionSummery() {
		return _actionSummery;
	}

	@Override
	public ActionSummery getWrappedModel() {
		return _actionSummery;
	}

	@Override
	public void resetOriginalValues() {
		_actionSummery.resetOriginalValues();
	}

	private ActionSummery _actionSummery;
}