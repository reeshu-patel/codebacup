/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for Inquery. This utility wraps
 * {@link com.org.skali.sitanAdmin.service.impl.InqueryServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author reeshu
 * @see InqueryService
 * @see com.org.skali.sitanAdmin.service.base.InqueryServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.impl.InqueryServiceImpl
 * @generated
 */
public class InqueryServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.org.skali.sitanAdmin.service.impl.InqueryServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static com.liferay.portal.kernel.json.JSONObject getInqueryData(
		java.lang.String datesize, java.lang.String checkSitesDate,
		java.lang.String referenceEffective, java.lang.String source,
		java.lang.String nameofowner, java.lang.String vehicleRegistration,
		java.lang.String territory, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String nameOfofficer) throws java.text.ParseException {
		return getService()
				   .getInqueryData(datesize, checkSitesDate,
			referenceEffective, source, nameofowner, vehicleRegistration,
			territory, state, locationCageSita, foreclosureStatus, nameOfofficer);
	}

	public static void clearService() {
		_service = null;
	}

	public static InqueryService getService() {
		if (_service == null) {
			InvokableService invokableService = (InvokableService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					InqueryService.class.getName());

			if (invokableService instanceof InqueryService) {
				_service = (InqueryService)invokableService;
			}
			else {
				_service = new InqueryServiceClp(invokableService);
			}

			ReferenceRegistry.registerReference(InqueryServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(InqueryService service) {
	}

	private static InqueryService _service;
}