/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.visualchecklistLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class visualchecklistClp extends BaseModelImpl<visualchecklist>
	implements visualchecklist {
	public visualchecklistClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return visualchecklist.class;
	}

	@Override
	public String getModelClassName() {
		return visualchecklist.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _checkId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCheckId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _checkId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("checkId", getCheckId());
		attributes.put("bilId", getBilId());
		attributes.put("numberplates", getNumberplates());
		attributes.put("numberplatesNote", getNumberplatesNote());
		attributes.put("forwardlighting", getForwardlighting());
		attributes.put("forwardlightingNote", getForwardlightingNote());
		attributes.put("backlight", getBacklight());
		attributes.put("backlightNote", getBacklightNote());
		attributes.put("trafficLight", getTrafficLight());
		attributes.put("trafficLightNote", getTrafficLightNote());
		attributes.put("signallight", getSignallight());
		attributes.put("signallightNote", getSignallightNote());
		attributes.put("vehiclebody", getVehiclebody());
		attributes.put("vehiclebodyNote", getVehiclebodyNote());
		attributes.put("vehicleAccessories", getVehicleAccessories());
		attributes.put("vehicleAccessoriesNote", getVehicleAccessoriesNote());
		attributes.put("windscreen", getWindscreen());
		attributes.put("windscreenNote", getWindscreenNote());
		attributes.put("rearMirror", getRearMirror());
		attributes.put("rearMirrorNote", getRearMirrorNote());
		attributes.put("doormirror", getDoormirror());
		attributes.put("doormirrorNote", getDoormirrorNote());
		attributes.put("vehicletires", getVehicletires());
		attributes.put("vehicletiresNote", getVehicletiresNote());
		attributes.put("frontbumper", getFrontbumper());
		attributes.put("frontbumperNote", getFrontbumperNote());
		attributes.put("rearbumper", getRearbumper());
		attributes.put("rearbumperNote", getRearbumperNote());
		attributes.put("frontseat", getFrontseat());
		attributes.put("frontseatNote", getFrontseatNote());
		attributes.put("rearseats", getRearseats());
		attributes.put("rearseatsNote", getRearseatsNote());
		attributes.put("note", getNote());
		attributes.put("vehicleRegistrationNo", getVehicleRegistrationNo());
		attributes.put("model", getModel());
		attributes.put("color", getColor());
		attributes.put("dateofVehicles", getDateofVehicles());
		attributes.put("investigatorname", getInvestigatorname());
		attributes.put("investigatorphone", getInvestigatorphone());
		attributes.put("investigatorEmail", getInvestigatorEmail());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long checkId = (Long)attributes.get("checkId");

		if (checkId != null) {
			setCheckId(checkId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String numberplates = (String)attributes.get("numberplates");

		if (numberplates != null) {
			setNumberplates(numberplates);
		}

		String numberplatesNote = (String)attributes.get("numberplatesNote");

		if (numberplatesNote != null) {
			setNumberplatesNote(numberplatesNote);
		}

		String forwardlighting = (String)attributes.get("forwardlighting");

		if (forwardlighting != null) {
			setForwardlighting(forwardlighting);
		}

		String forwardlightingNote = (String)attributes.get(
				"forwardlightingNote");

		if (forwardlightingNote != null) {
			setForwardlightingNote(forwardlightingNote);
		}

		String backlight = (String)attributes.get("backlight");

		if (backlight != null) {
			setBacklight(backlight);
		}

		String backlightNote = (String)attributes.get("backlightNote");

		if (backlightNote != null) {
			setBacklightNote(backlightNote);
		}

		String trafficLight = (String)attributes.get("trafficLight");

		if (trafficLight != null) {
			setTrafficLight(trafficLight);
		}

		String trafficLightNote = (String)attributes.get("trafficLightNote");

		if (trafficLightNote != null) {
			setTrafficLightNote(trafficLightNote);
		}

		String signallight = (String)attributes.get("signallight");

		if (signallight != null) {
			setSignallight(signallight);
		}

		String signallightNote = (String)attributes.get("signallightNote");

		if (signallightNote != null) {
			setSignallightNote(signallightNote);
		}

		String vehiclebody = (String)attributes.get("vehiclebody");

		if (vehiclebody != null) {
			setVehiclebody(vehiclebody);
		}

		String vehiclebodyNote = (String)attributes.get("vehiclebodyNote");

		if (vehiclebodyNote != null) {
			setVehiclebodyNote(vehiclebodyNote);
		}

		String vehicleAccessories = (String)attributes.get("vehicleAccessories");

		if (vehicleAccessories != null) {
			setVehicleAccessories(vehicleAccessories);
		}

		String vehicleAccessoriesNote = (String)attributes.get(
				"vehicleAccessoriesNote");

		if (vehicleAccessoriesNote != null) {
			setVehicleAccessoriesNote(vehicleAccessoriesNote);
		}

		String windscreen = (String)attributes.get("windscreen");

		if (windscreen != null) {
			setWindscreen(windscreen);
		}

		String windscreenNote = (String)attributes.get("windscreenNote");

		if (windscreenNote != null) {
			setWindscreenNote(windscreenNote);
		}

		String rearMirror = (String)attributes.get("rearMirror");

		if (rearMirror != null) {
			setRearMirror(rearMirror);
		}

		String rearMirrorNote = (String)attributes.get("rearMirrorNote");

		if (rearMirrorNote != null) {
			setRearMirrorNote(rearMirrorNote);
		}

		String doormirror = (String)attributes.get("doormirror");

		if (doormirror != null) {
			setDoormirror(doormirror);
		}

		String doormirrorNote = (String)attributes.get("doormirrorNote");

		if (doormirrorNote != null) {
			setDoormirrorNote(doormirrorNote);
		}

		String vehicletires = (String)attributes.get("vehicletires");

		if (vehicletires != null) {
			setVehicletires(vehicletires);
		}

		String vehicletiresNote = (String)attributes.get("vehicletiresNote");

		if (vehicletiresNote != null) {
			setVehicletiresNote(vehicletiresNote);
		}

		String frontbumper = (String)attributes.get("frontbumper");

		if (frontbumper != null) {
			setFrontbumper(frontbumper);
		}

		String frontbumperNote = (String)attributes.get("frontbumperNote");

		if (frontbumperNote != null) {
			setFrontbumperNote(frontbumperNote);
		}

		String rearbumper = (String)attributes.get("rearbumper");

		if (rearbumper != null) {
			setRearbumper(rearbumper);
		}

		String rearbumperNote = (String)attributes.get("rearbumperNote");

		if (rearbumperNote != null) {
			setRearbumperNote(rearbumperNote);
		}

		String frontseat = (String)attributes.get("frontseat");

		if (frontseat != null) {
			setFrontseat(frontseat);
		}

		String frontseatNote = (String)attributes.get("frontseatNote");

		if (frontseatNote != null) {
			setFrontseatNote(frontseatNote);
		}

		String rearseats = (String)attributes.get("rearseats");

		if (rearseats != null) {
			setRearseats(rearseats);
		}

		String rearseatsNote = (String)attributes.get("rearseatsNote");

		if (rearseatsNote != null) {
			setRearseatsNote(rearseatsNote);
		}

		String note = (String)attributes.get("note");

		if (note != null) {
			setNote(note);
		}

		String vehicleRegistrationNo = (String)attributes.get(
				"vehicleRegistrationNo");

		if (vehicleRegistrationNo != null) {
			setVehicleRegistrationNo(vehicleRegistrationNo);
		}

		String model = (String)attributes.get("model");

		if (model != null) {
			setModel(model);
		}

		String color = (String)attributes.get("color");

		if (color != null) {
			setColor(color);
		}

		String dateofVehicles = (String)attributes.get("dateofVehicles");

		if (dateofVehicles != null) {
			setDateofVehicles(dateofVehicles);
		}

		String investigatorname = (String)attributes.get("investigatorname");

		if (investigatorname != null) {
			setInvestigatorname(investigatorname);
		}

		String investigatorphone = (String)attributes.get("investigatorphone");

		if (investigatorphone != null) {
			setInvestigatorphone(investigatorphone);
		}

		String investigatorEmail = (String)attributes.get("investigatorEmail");

		if (investigatorEmail != null) {
			setInvestigatorEmail(investigatorEmail);
		}
	}

	@Override
	public long getCheckId() {
		return _checkId;
	}

	@Override
	public void setCheckId(long checkId) {
		_checkId = checkId;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setCheckId", long.class);

				method.invoke(_visualchecklistRemoteModel, checkId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_visualchecklistRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNumberplates() {
		return _numberplates;
	}

	@Override
	public void setNumberplates(String numberplates) {
		_numberplates = numberplates;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setNumberplates", String.class);

				method.invoke(_visualchecklistRemoteModel, numberplates);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNumberplatesNote() {
		return _numberplatesNote;
	}

	@Override
	public void setNumberplatesNote(String numberplatesNote) {
		_numberplatesNote = numberplatesNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setNumberplatesNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, numberplatesNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getForwardlighting() {
		return _forwardlighting;
	}

	@Override
	public void setForwardlighting(String forwardlighting) {
		_forwardlighting = forwardlighting;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setForwardlighting",
						String.class);

				method.invoke(_visualchecklistRemoteModel, forwardlighting);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getForwardlightingNote() {
		return _forwardlightingNote;
	}

	@Override
	public void setForwardlightingNote(String forwardlightingNote) {
		_forwardlightingNote = forwardlightingNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setForwardlightingNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, forwardlightingNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBacklight() {
		return _backlight;
	}

	@Override
	public void setBacklight(String backlight) {
		_backlight = backlight;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setBacklight", String.class);

				method.invoke(_visualchecklistRemoteModel, backlight);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBacklightNote() {
		return _backlightNote;
	}

	@Override
	public void setBacklightNote(String backlightNote) {
		_backlightNote = backlightNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setBacklightNote", String.class);

				method.invoke(_visualchecklistRemoteModel, backlightNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrafficLight() {
		return _trafficLight;
	}

	@Override
	public void setTrafficLight(String trafficLight) {
		_trafficLight = trafficLight;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setTrafficLight", String.class);

				method.invoke(_visualchecklistRemoteModel, trafficLight);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrafficLightNote() {
		return _trafficLightNote;
	}

	@Override
	public void setTrafficLightNote(String trafficLightNote) {
		_trafficLightNote = trafficLightNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setTrafficLightNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, trafficLightNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSignallight() {
		return _signallight;
	}

	@Override
	public void setSignallight(String signallight) {
		_signallight = signallight;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setSignallight", String.class);

				method.invoke(_visualchecklistRemoteModel, signallight);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSignallightNote() {
		return _signallightNote;
	}

	@Override
	public void setSignallightNote(String signallightNote) {
		_signallightNote = signallightNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setSignallightNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, signallightNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehiclebody() {
		return _vehiclebody;
	}

	@Override
	public void setVehiclebody(String vehiclebody) {
		_vehiclebody = vehiclebody;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehiclebody", String.class);

				method.invoke(_visualchecklistRemoteModel, vehiclebody);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehiclebodyNote() {
		return _vehiclebodyNote;
	}

	@Override
	public void setVehiclebodyNote(String vehiclebodyNote) {
		_vehiclebodyNote = vehiclebodyNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehiclebodyNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, vehiclebodyNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehicleAccessories() {
		return _vehicleAccessories;
	}

	@Override
	public void setVehicleAccessories(String vehicleAccessories) {
		_vehicleAccessories = vehicleAccessories;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicleAccessories",
						String.class);

				method.invoke(_visualchecklistRemoteModel, vehicleAccessories);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehicleAccessoriesNote() {
		return _vehicleAccessoriesNote;
	}

	@Override
	public void setVehicleAccessoriesNote(String vehicleAccessoriesNote) {
		_vehicleAccessoriesNote = vehicleAccessoriesNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicleAccessoriesNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel,
					vehicleAccessoriesNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWindscreen() {
		return _windscreen;
	}

	@Override
	public void setWindscreen(String windscreen) {
		_windscreen = windscreen;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setWindscreen", String.class);

				method.invoke(_visualchecklistRemoteModel, windscreen);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWindscreenNote() {
		return _windscreenNote;
	}

	@Override
	public void setWindscreenNote(String windscreenNote) {
		_windscreenNote = windscreenNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setWindscreenNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, windscreenNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearMirror() {
		return _rearMirror;
	}

	@Override
	public void setRearMirror(String rearMirror) {
		_rearMirror = rearMirror;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearMirror", String.class);

				method.invoke(_visualchecklistRemoteModel, rearMirror);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearMirrorNote() {
		return _rearMirrorNote;
	}

	@Override
	public void setRearMirrorNote(String rearMirrorNote) {
		_rearMirrorNote = rearMirrorNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearMirrorNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, rearMirrorNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDoormirror() {
		return _doormirror;
	}

	@Override
	public void setDoormirror(String doormirror) {
		_doormirror = doormirror;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setDoormirror", String.class);

				method.invoke(_visualchecklistRemoteModel, doormirror);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDoormirrorNote() {
		return _doormirrorNote;
	}

	@Override
	public void setDoormirrorNote(String doormirrorNote) {
		_doormirrorNote = doormirrorNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setDoormirrorNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, doormirrorNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehicletires() {
		return _vehicletires;
	}

	@Override
	public void setVehicletires(String vehicletires) {
		_vehicletires = vehicletires;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicletires", String.class);

				method.invoke(_visualchecklistRemoteModel, vehicletires);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehicletiresNote() {
		return _vehicletiresNote;
	}

	@Override
	public void setVehicletiresNote(String vehicletiresNote) {
		_vehicletiresNote = vehicletiresNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicletiresNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, vehicletiresNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFrontbumper() {
		return _frontbumper;
	}

	@Override
	public void setFrontbumper(String frontbumper) {
		_frontbumper = frontbumper;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setFrontbumper", String.class);

				method.invoke(_visualchecklistRemoteModel, frontbumper);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFrontbumperNote() {
		return _frontbumperNote;
	}

	@Override
	public void setFrontbumperNote(String frontbumperNote) {
		_frontbumperNote = frontbumperNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setFrontbumperNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, frontbumperNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearbumper() {
		return _rearbumper;
	}

	@Override
	public void setRearbumper(String rearbumper) {
		_rearbumper = rearbumper;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearbumper", String.class);

				method.invoke(_visualchecklistRemoteModel, rearbumper);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearbumperNote() {
		return _rearbumperNote;
	}

	@Override
	public void setRearbumperNote(String rearbumperNote) {
		_rearbumperNote = rearbumperNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearbumperNote",
						String.class);

				method.invoke(_visualchecklistRemoteModel, rearbumperNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFrontseat() {
		return _frontseat;
	}

	@Override
	public void setFrontseat(String frontseat) {
		_frontseat = frontseat;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setFrontseat", String.class);

				method.invoke(_visualchecklistRemoteModel, frontseat);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFrontseatNote() {
		return _frontseatNote;
	}

	@Override
	public void setFrontseatNote(String frontseatNote) {
		_frontseatNote = frontseatNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setFrontseatNote", String.class);

				method.invoke(_visualchecklistRemoteModel, frontseatNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearseats() {
		return _rearseats;
	}

	@Override
	public void setRearseats(String rearseats) {
		_rearseats = rearseats;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearseats", String.class);

				method.invoke(_visualchecklistRemoteModel, rearseats);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRearseatsNote() {
		return _rearseatsNote;
	}

	@Override
	public void setRearseatsNote(String rearseatsNote) {
		_rearseatsNote = rearseatsNote;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setRearseatsNote", String.class);

				method.invoke(_visualchecklistRemoteModel, rearseatsNote);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNote() {
		return _note;
	}

	@Override
	public void setNote(String note) {
		_note = note;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setNote", String.class);

				method.invoke(_visualchecklistRemoteModel, note);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehicleRegistrationNo() {
		return _vehicleRegistrationNo;
	}

	@Override
	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		_vehicleRegistrationNo = vehicleRegistrationNo;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setVehicleRegistrationNo",
						String.class);

				method.invoke(_visualchecklistRemoteModel, vehicleRegistrationNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getModel() {
		return _model;
	}

	@Override
	public void setModel(String model) {
		_model = model;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setModel", String.class);

				method.invoke(_visualchecklistRemoteModel, model);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getColor() {
		return _color;
	}

	@Override
	public void setColor(String color) {
		_color = color;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setColor", String.class);

				method.invoke(_visualchecklistRemoteModel, color);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateofVehicles() {
		return _dateofVehicles;
	}

	@Override
	public void setDateofVehicles(String dateofVehicles) {
		_dateofVehicles = dateofVehicles;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setDateofVehicles",
						String.class);

				method.invoke(_visualchecklistRemoteModel, dateofVehicles);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getInvestigatorname() {
		return _investigatorname;
	}

	@Override
	public void setInvestigatorname(String investigatorname) {
		_investigatorname = investigatorname;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setInvestigatorname",
						String.class);

				method.invoke(_visualchecklistRemoteModel, investigatorname);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getInvestigatorphone() {
		return _investigatorphone;
	}

	@Override
	public void setInvestigatorphone(String investigatorphone) {
		_investigatorphone = investigatorphone;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setInvestigatorphone",
						String.class);

				method.invoke(_visualchecklistRemoteModel, investigatorphone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getInvestigatorEmail() {
		return _investigatorEmail;
	}

	@Override
	public void setInvestigatorEmail(String investigatorEmail) {
		_investigatorEmail = investigatorEmail;

		if (_visualchecklistRemoteModel != null) {
			try {
				Class<?> clazz = _visualchecklistRemoteModel.getClass();

				Method method = clazz.getMethod("setInvestigatorEmail",
						String.class);

				method.invoke(_visualchecklistRemoteModel, investigatorEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getvisualchecklistRemoteModel() {
		return _visualchecklistRemoteModel;
	}

	public void setvisualchecklistRemoteModel(
		BaseModel<?> visualchecklistRemoteModel) {
		_visualchecklistRemoteModel = visualchecklistRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _visualchecklistRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_visualchecklistRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			visualchecklistLocalServiceUtil.addvisualchecklist(this);
		}
		else {
			visualchecklistLocalServiceUtil.updatevisualchecklist(this);
		}
	}

	@Override
	public visualchecklist toEscapedModel() {
		return (visualchecklist)ProxyUtil.newProxyInstance(visualchecklist.class.getClassLoader(),
			new Class[] { visualchecklist.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		visualchecklistClp clone = new visualchecklistClp();

		clone.setCheckId(getCheckId());
		clone.setBilId(getBilId());
		clone.setNumberplates(getNumberplates());
		clone.setNumberplatesNote(getNumberplatesNote());
		clone.setForwardlighting(getForwardlighting());
		clone.setForwardlightingNote(getForwardlightingNote());
		clone.setBacklight(getBacklight());
		clone.setBacklightNote(getBacklightNote());
		clone.setTrafficLight(getTrafficLight());
		clone.setTrafficLightNote(getTrafficLightNote());
		clone.setSignallight(getSignallight());
		clone.setSignallightNote(getSignallightNote());
		clone.setVehiclebody(getVehiclebody());
		clone.setVehiclebodyNote(getVehiclebodyNote());
		clone.setVehicleAccessories(getVehicleAccessories());
		clone.setVehicleAccessoriesNote(getVehicleAccessoriesNote());
		clone.setWindscreen(getWindscreen());
		clone.setWindscreenNote(getWindscreenNote());
		clone.setRearMirror(getRearMirror());
		clone.setRearMirrorNote(getRearMirrorNote());
		clone.setDoormirror(getDoormirror());
		clone.setDoormirrorNote(getDoormirrorNote());
		clone.setVehicletires(getVehicletires());
		clone.setVehicletiresNote(getVehicletiresNote());
		clone.setFrontbumper(getFrontbumper());
		clone.setFrontbumperNote(getFrontbumperNote());
		clone.setRearbumper(getRearbumper());
		clone.setRearbumperNote(getRearbumperNote());
		clone.setFrontseat(getFrontseat());
		clone.setFrontseatNote(getFrontseatNote());
		clone.setRearseats(getRearseats());
		clone.setRearseatsNote(getRearseatsNote());
		clone.setNote(getNote());
		clone.setVehicleRegistrationNo(getVehicleRegistrationNo());
		clone.setModel(getModel());
		clone.setColor(getColor());
		clone.setDateofVehicles(getDateofVehicles());
		clone.setInvestigatorname(getInvestigatorname());
		clone.setInvestigatorphone(getInvestigatorphone());
		clone.setInvestigatorEmail(getInvestigatorEmail());

		return clone;
	}

	@Override
	public int compareTo(visualchecklist visualchecklist) {
		long primaryKey = visualchecklist.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof visualchecklistClp)) {
			return false;
		}

		visualchecklistClp visualchecklist = (visualchecklistClp)obj;

		long primaryKey = visualchecklist.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(81);

		sb.append("{checkId=");
		sb.append(getCheckId());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", numberplates=");
		sb.append(getNumberplates());
		sb.append(", numberplatesNote=");
		sb.append(getNumberplatesNote());
		sb.append(", forwardlighting=");
		sb.append(getForwardlighting());
		sb.append(", forwardlightingNote=");
		sb.append(getForwardlightingNote());
		sb.append(", backlight=");
		sb.append(getBacklight());
		sb.append(", backlightNote=");
		sb.append(getBacklightNote());
		sb.append(", trafficLight=");
		sb.append(getTrafficLight());
		sb.append(", trafficLightNote=");
		sb.append(getTrafficLightNote());
		sb.append(", signallight=");
		sb.append(getSignallight());
		sb.append(", signallightNote=");
		sb.append(getSignallightNote());
		sb.append(", vehiclebody=");
		sb.append(getVehiclebody());
		sb.append(", vehiclebodyNote=");
		sb.append(getVehiclebodyNote());
		sb.append(", vehicleAccessories=");
		sb.append(getVehicleAccessories());
		sb.append(", vehicleAccessoriesNote=");
		sb.append(getVehicleAccessoriesNote());
		sb.append(", windscreen=");
		sb.append(getWindscreen());
		sb.append(", windscreenNote=");
		sb.append(getWindscreenNote());
		sb.append(", rearMirror=");
		sb.append(getRearMirror());
		sb.append(", rearMirrorNote=");
		sb.append(getRearMirrorNote());
		sb.append(", doormirror=");
		sb.append(getDoormirror());
		sb.append(", doormirrorNote=");
		sb.append(getDoormirrorNote());
		sb.append(", vehicletires=");
		sb.append(getVehicletires());
		sb.append(", vehicletiresNote=");
		sb.append(getVehicletiresNote());
		sb.append(", frontbumper=");
		sb.append(getFrontbumper());
		sb.append(", frontbumperNote=");
		sb.append(getFrontbumperNote());
		sb.append(", rearbumper=");
		sb.append(getRearbumper());
		sb.append(", rearbumperNote=");
		sb.append(getRearbumperNote());
		sb.append(", frontseat=");
		sb.append(getFrontseat());
		sb.append(", frontseatNote=");
		sb.append(getFrontseatNote());
		sb.append(", rearseats=");
		sb.append(getRearseats());
		sb.append(", rearseatsNote=");
		sb.append(getRearseatsNote());
		sb.append(", note=");
		sb.append(getNote());
		sb.append(", vehicleRegistrationNo=");
		sb.append(getVehicleRegistrationNo());
		sb.append(", model=");
		sb.append(getModel());
		sb.append(", color=");
		sb.append(getColor());
		sb.append(", dateofVehicles=");
		sb.append(getDateofVehicles());
		sb.append(", investigatorname=");
		sb.append(getInvestigatorname());
		sb.append(", investigatorphone=");
		sb.append(getInvestigatorphone());
		sb.append(", investigatorEmail=");
		sb.append(getInvestigatorEmail());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(124);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.visualchecklist");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>checkId</column-name><column-value><![CDATA[");
		sb.append(getCheckId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>numberplates</column-name><column-value><![CDATA[");
		sb.append(getNumberplates());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>numberplatesNote</column-name><column-value><![CDATA[");
		sb.append(getNumberplatesNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>forwardlighting</column-name><column-value><![CDATA[");
		sb.append(getForwardlighting());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>forwardlightingNote</column-name><column-value><![CDATA[");
		sb.append(getForwardlightingNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>backlight</column-name><column-value><![CDATA[");
		sb.append(getBacklight());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>backlightNote</column-name><column-value><![CDATA[");
		sb.append(getBacklightNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trafficLight</column-name><column-value><![CDATA[");
		sb.append(getTrafficLight());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trafficLightNote</column-name><column-value><![CDATA[");
		sb.append(getTrafficLightNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>signallight</column-name><column-value><![CDATA[");
		sb.append(getSignallight());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>signallightNote</column-name><column-value><![CDATA[");
		sb.append(getSignallightNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehiclebody</column-name><column-value><![CDATA[");
		sb.append(getVehiclebody());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehiclebodyNote</column-name><column-value><![CDATA[");
		sb.append(getVehiclebodyNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehicleAccessories</column-name><column-value><![CDATA[");
		sb.append(getVehicleAccessories());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehicleAccessoriesNote</column-name><column-value><![CDATA[");
		sb.append(getVehicleAccessoriesNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>windscreen</column-name><column-value><![CDATA[");
		sb.append(getWindscreen());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>windscreenNote</column-name><column-value><![CDATA[");
		sb.append(getWindscreenNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearMirror</column-name><column-value><![CDATA[");
		sb.append(getRearMirror());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearMirrorNote</column-name><column-value><![CDATA[");
		sb.append(getRearMirrorNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>doormirror</column-name><column-value><![CDATA[");
		sb.append(getDoormirror());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>doormirrorNote</column-name><column-value><![CDATA[");
		sb.append(getDoormirrorNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehicletires</column-name><column-value><![CDATA[");
		sb.append(getVehicletires());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehicletiresNote</column-name><column-value><![CDATA[");
		sb.append(getVehicletiresNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>frontbumper</column-name><column-value><![CDATA[");
		sb.append(getFrontbumper());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>frontbumperNote</column-name><column-value><![CDATA[");
		sb.append(getFrontbumperNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearbumper</column-name><column-value><![CDATA[");
		sb.append(getRearbumper());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearbumperNote</column-name><column-value><![CDATA[");
		sb.append(getRearbumperNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>frontseat</column-name><column-value><![CDATA[");
		sb.append(getFrontseat());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>frontseatNote</column-name><column-value><![CDATA[");
		sb.append(getFrontseatNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearseats</column-name><column-value><![CDATA[");
		sb.append(getRearseats());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>rearseatsNote</column-name><column-value><![CDATA[");
		sb.append(getRearseatsNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>note</column-name><column-value><![CDATA[");
		sb.append(getNote());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehicleRegistrationNo</column-name><column-value><![CDATA[");
		sb.append(getVehicleRegistrationNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>model</column-name><column-value><![CDATA[");
		sb.append(getModel());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>color</column-name><column-value><![CDATA[");
		sb.append(getColor());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateofVehicles</column-name><column-value><![CDATA[");
		sb.append(getDateofVehicles());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>investigatorname</column-name><column-value><![CDATA[");
		sb.append(getInvestigatorname());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>investigatorphone</column-name><column-value><![CDATA[");
		sb.append(getInvestigatorphone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>investigatorEmail</column-name><column-value><![CDATA[");
		sb.append(getInvestigatorEmail());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _checkId;
	private long _bilId;
	private String _numberplates;
	private String _numberplatesNote;
	private String _forwardlighting;
	private String _forwardlightingNote;
	private String _backlight;
	private String _backlightNote;
	private String _trafficLight;
	private String _trafficLightNote;
	private String _signallight;
	private String _signallightNote;
	private String _vehiclebody;
	private String _vehiclebodyNote;
	private String _vehicleAccessories;
	private String _vehicleAccessoriesNote;
	private String _windscreen;
	private String _windscreenNote;
	private String _rearMirror;
	private String _rearMirrorNote;
	private String _doormirror;
	private String _doormirrorNote;
	private String _vehicletires;
	private String _vehicletiresNote;
	private String _frontbumper;
	private String _frontbumperNote;
	private String _rearbumper;
	private String _rearbumperNote;
	private String _frontseat;
	private String _frontseatNote;
	private String _rearseats;
	private String _rearseatsNote;
	private String _note;
	private String _vehicleRegistrationNo;
	private String _model;
	private String _color;
	private String _dateofVehicles;
	private String _investigatorname;
	private String _investigatorphone;
	private String _investigatorEmail;
	private BaseModel<?> _visualchecklistRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}