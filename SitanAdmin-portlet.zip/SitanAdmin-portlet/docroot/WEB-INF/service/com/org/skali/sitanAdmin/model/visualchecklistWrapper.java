/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link visualchecklist}.
 * </p>
 *
 * @author reeshu
 * @see visualchecklist
 * @generated
 */
public class visualchecklistWrapper implements visualchecklist,
	ModelWrapper<visualchecklist> {
	public visualchecklistWrapper(visualchecklist visualchecklist) {
		_visualchecklist = visualchecklist;
	}

	@Override
	public Class<?> getModelClass() {
		return visualchecklist.class;
	}

	@Override
	public String getModelClassName() {
		return visualchecklist.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("checkId", getCheckId());
		attributes.put("bilId", getBilId());
		attributes.put("numberplates", getNumberplates());
		attributes.put("numberplatesNote", getNumberplatesNote());
		attributes.put("forwardlighting", getForwardlighting());
		attributes.put("forwardlightingNote", getForwardlightingNote());
		attributes.put("backlight", getBacklight());
		attributes.put("backlightNote", getBacklightNote());
		attributes.put("trafficLight", getTrafficLight());
		attributes.put("trafficLightNote", getTrafficLightNote());
		attributes.put("signallight", getSignallight());
		attributes.put("signallightNote", getSignallightNote());
		attributes.put("vehiclebody", getVehiclebody());
		attributes.put("vehiclebodyNote", getVehiclebodyNote());
		attributes.put("vehicleAccessories", getVehicleAccessories());
		attributes.put("vehicleAccessoriesNote", getVehicleAccessoriesNote());
		attributes.put("windscreen", getWindscreen());
		attributes.put("windscreenNote", getWindscreenNote());
		attributes.put("rearMirror", getRearMirror());
		attributes.put("rearMirrorNote", getRearMirrorNote());
		attributes.put("doormirror", getDoormirror());
		attributes.put("doormirrorNote", getDoormirrorNote());
		attributes.put("vehicletires", getVehicletires());
		attributes.put("vehicletiresNote", getVehicletiresNote());
		attributes.put("frontbumper", getFrontbumper());
		attributes.put("frontbumperNote", getFrontbumperNote());
		attributes.put("rearbumper", getRearbumper());
		attributes.put("rearbumperNote", getRearbumperNote());
		attributes.put("frontseat", getFrontseat());
		attributes.put("frontseatNote", getFrontseatNote());
		attributes.put("rearseats", getRearseats());
		attributes.put("rearseatsNote", getRearseatsNote());
		attributes.put("note", getNote());
		attributes.put("vehicleRegistrationNo", getVehicleRegistrationNo());
		attributes.put("model", getModel());
		attributes.put("color", getColor());
		attributes.put("dateofVehicles", getDateofVehicles());
		attributes.put("investigatorname", getInvestigatorname());
		attributes.put("investigatorphone", getInvestigatorphone());
		attributes.put("investigatorEmail", getInvestigatorEmail());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long checkId = (Long)attributes.get("checkId");

		if (checkId != null) {
			setCheckId(checkId);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String numberplates = (String)attributes.get("numberplates");

		if (numberplates != null) {
			setNumberplates(numberplates);
		}

		String numberplatesNote = (String)attributes.get("numberplatesNote");

		if (numberplatesNote != null) {
			setNumberplatesNote(numberplatesNote);
		}

		String forwardlighting = (String)attributes.get("forwardlighting");

		if (forwardlighting != null) {
			setForwardlighting(forwardlighting);
		}

		String forwardlightingNote = (String)attributes.get(
				"forwardlightingNote");

		if (forwardlightingNote != null) {
			setForwardlightingNote(forwardlightingNote);
		}

		String backlight = (String)attributes.get("backlight");

		if (backlight != null) {
			setBacklight(backlight);
		}

		String backlightNote = (String)attributes.get("backlightNote");

		if (backlightNote != null) {
			setBacklightNote(backlightNote);
		}

		String trafficLight = (String)attributes.get("trafficLight");

		if (trafficLight != null) {
			setTrafficLight(trafficLight);
		}

		String trafficLightNote = (String)attributes.get("trafficLightNote");

		if (trafficLightNote != null) {
			setTrafficLightNote(trafficLightNote);
		}

		String signallight = (String)attributes.get("signallight");

		if (signallight != null) {
			setSignallight(signallight);
		}

		String signallightNote = (String)attributes.get("signallightNote");

		if (signallightNote != null) {
			setSignallightNote(signallightNote);
		}

		String vehiclebody = (String)attributes.get("vehiclebody");

		if (vehiclebody != null) {
			setVehiclebody(vehiclebody);
		}

		String vehiclebodyNote = (String)attributes.get("vehiclebodyNote");

		if (vehiclebodyNote != null) {
			setVehiclebodyNote(vehiclebodyNote);
		}

		String vehicleAccessories = (String)attributes.get("vehicleAccessories");

		if (vehicleAccessories != null) {
			setVehicleAccessories(vehicleAccessories);
		}

		String vehicleAccessoriesNote = (String)attributes.get(
				"vehicleAccessoriesNote");

		if (vehicleAccessoriesNote != null) {
			setVehicleAccessoriesNote(vehicleAccessoriesNote);
		}

		String windscreen = (String)attributes.get("windscreen");

		if (windscreen != null) {
			setWindscreen(windscreen);
		}

		String windscreenNote = (String)attributes.get("windscreenNote");

		if (windscreenNote != null) {
			setWindscreenNote(windscreenNote);
		}

		String rearMirror = (String)attributes.get("rearMirror");

		if (rearMirror != null) {
			setRearMirror(rearMirror);
		}

		String rearMirrorNote = (String)attributes.get("rearMirrorNote");

		if (rearMirrorNote != null) {
			setRearMirrorNote(rearMirrorNote);
		}

		String doormirror = (String)attributes.get("doormirror");

		if (doormirror != null) {
			setDoormirror(doormirror);
		}

		String doormirrorNote = (String)attributes.get("doormirrorNote");

		if (doormirrorNote != null) {
			setDoormirrorNote(doormirrorNote);
		}

		String vehicletires = (String)attributes.get("vehicletires");

		if (vehicletires != null) {
			setVehicletires(vehicletires);
		}

		String vehicletiresNote = (String)attributes.get("vehicletiresNote");

		if (vehicletiresNote != null) {
			setVehicletiresNote(vehicletiresNote);
		}

		String frontbumper = (String)attributes.get("frontbumper");

		if (frontbumper != null) {
			setFrontbumper(frontbumper);
		}

		String frontbumperNote = (String)attributes.get("frontbumperNote");

		if (frontbumperNote != null) {
			setFrontbumperNote(frontbumperNote);
		}

		String rearbumper = (String)attributes.get("rearbumper");

		if (rearbumper != null) {
			setRearbumper(rearbumper);
		}

		String rearbumperNote = (String)attributes.get("rearbumperNote");

		if (rearbumperNote != null) {
			setRearbumperNote(rearbumperNote);
		}

		String frontseat = (String)attributes.get("frontseat");

		if (frontseat != null) {
			setFrontseat(frontseat);
		}

		String frontseatNote = (String)attributes.get("frontseatNote");

		if (frontseatNote != null) {
			setFrontseatNote(frontseatNote);
		}

		String rearseats = (String)attributes.get("rearseats");

		if (rearseats != null) {
			setRearseats(rearseats);
		}

		String rearseatsNote = (String)attributes.get("rearseatsNote");

		if (rearseatsNote != null) {
			setRearseatsNote(rearseatsNote);
		}

		String note = (String)attributes.get("note");

		if (note != null) {
			setNote(note);
		}

		String vehicleRegistrationNo = (String)attributes.get(
				"vehicleRegistrationNo");

		if (vehicleRegistrationNo != null) {
			setVehicleRegistrationNo(vehicleRegistrationNo);
		}

		String model = (String)attributes.get("model");

		if (model != null) {
			setModel(model);
		}

		String color = (String)attributes.get("color");

		if (color != null) {
			setColor(color);
		}

		String dateofVehicles = (String)attributes.get("dateofVehicles");

		if (dateofVehicles != null) {
			setDateofVehicles(dateofVehicles);
		}

		String investigatorname = (String)attributes.get("investigatorname");

		if (investigatorname != null) {
			setInvestigatorname(investigatorname);
		}

		String investigatorphone = (String)attributes.get("investigatorphone");

		if (investigatorphone != null) {
			setInvestigatorphone(investigatorphone);
		}

		String investigatorEmail = (String)attributes.get("investigatorEmail");

		if (investigatorEmail != null) {
			setInvestigatorEmail(investigatorEmail);
		}
	}

	/**
	* Returns the primary key of this visualchecklist.
	*
	* @return the primary key of this visualchecklist
	*/
	@Override
	public long getPrimaryKey() {
		return _visualchecklist.getPrimaryKey();
	}

	/**
	* Sets the primary key of this visualchecklist.
	*
	* @param primaryKey the primary key of this visualchecklist
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_visualchecklist.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the check ID of this visualchecklist.
	*
	* @return the check ID of this visualchecklist
	*/
	@Override
	public long getCheckId() {
		return _visualchecklist.getCheckId();
	}

	/**
	* Sets the check ID of this visualchecklist.
	*
	* @param checkId the check ID of this visualchecklist
	*/
	@Override
	public void setCheckId(long checkId) {
		_visualchecklist.setCheckId(checkId);
	}

	/**
	* Returns the bil ID of this visualchecklist.
	*
	* @return the bil ID of this visualchecklist
	*/
	@Override
	public long getBilId() {
		return _visualchecklist.getBilId();
	}

	/**
	* Sets the bil ID of this visualchecklist.
	*
	* @param bilId the bil ID of this visualchecklist
	*/
	@Override
	public void setBilId(long bilId) {
		_visualchecklist.setBilId(bilId);
	}

	/**
	* Returns the numberplates of this visualchecklist.
	*
	* @return the numberplates of this visualchecklist
	*/
	@Override
	public java.lang.String getNumberplates() {
		return _visualchecklist.getNumberplates();
	}

	/**
	* Sets the numberplates of this visualchecklist.
	*
	* @param numberplates the numberplates of this visualchecklist
	*/
	@Override
	public void setNumberplates(java.lang.String numberplates) {
		_visualchecklist.setNumberplates(numberplates);
	}

	/**
	* Returns the numberplates note of this visualchecklist.
	*
	* @return the numberplates note of this visualchecklist
	*/
	@Override
	public java.lang.String getNumberplatesNote() {
		return _visualchecklist.getNumberplatesNote();
	}

	/**
	* Sets the numberplates note of this visualchecklist.
	*
	* @param numberplatesNote the numberplates note of this visualchecklist
	*/
	@Override
	public void setNumberplatesNote(java.lang.String numberplatesNote) {
		_visualchecklist.setNumberplatesNote(numberplatesNote);
	}

	/**
	* Returns the forwardlighting of this visualchecklist.
	*
	* @return the forwardlighting of this visualchecklist
	*/
	@Override
	public java.lang.String getForwardlighting() {
		return _visualchecklist.getForwardlighting();
	}

	/**
	* Sets the forwardlighting of this visualchecklist.
	*
	* @param forwardlighting the forwardlighting of this visualchecklist
	*/
	@Override
	public void setForwardlighting(java.lang.String forwardlighting) {
		_visualchecklist.setForwardlighting(forwardlighting);
	}

	/**
	* Returns the forwardlighting note of this visualchecklist.
	*
	* @return the forwardlighting note of this visualchecklist
	*/
	@Override
	public java.lang.String getForwardlightingNote() {
		return _visualchecklist.getForwardlightingNote();
	}

	/**
	* Sets the forwardlighting note of this visualchecklist.
	*
	* @param forwardlightingNote the forwardlighting note of this visualchecklist
	*/
	@Override
	public void setForwardlightingNote(java.lang.String forwardlightingNote) {
		_visualchecklist.setForwardlightingNote(forwardlightingNote);
	}

	/**
	* Returns the backlight of this visualchecklist.
	*
	* @return the backlight of this visualchecklist
	*/
	@Override
	public java.lang.String getBacklight() {
		return _visualchecklist.getBacklight();
	}

	/**
	* Sets the backlight of this visualchecklist.
	*
	* @param backlight the backlight of this visualchecklist
	*/
	@Override
	public void setBacklight(java.lang.String backlight) {
		_visualchecklist.setBacklight(backlight);
	}

	/**
	* Returns the backlight note of this visualchecklist.
	*
	* @return the backlight note of this visualchecklist
	*/
	@Override
	public java.lang.String getBacklightNote() {
		return _visualchecklist.getBacklightNote();
	}

	/**
	* Sets the backlight note of this visualchecklist.
	*
	* @param backlightNote the backlight note of this visualchecklist
	*/
	@Override
	public void setBacklightNote(java.lang.String backlightNote) {
		_visualchecklist.setBacklightNote(backlightNote);
	}

	/**
	* Returns the traffic light of this visualchecklist.
	*
	* @return the traffic light of this visualchecklist
	*/
	@Override
	public java.lang.String getTrafficLight() {
		return _visualchecklist.getTrafficLight();
	}

	/**
	* Sets the traffic light of this visualchecklist.
	*
	* @param trafficLight the traffic light of this visualchecklist
	*/
	@Override
	public void setTrafficLight(java.lang.String trafficLight) {
		_visualchecklist.setTrafficLight(trafficLight);
	}

	/**
	* Returns the traffic light note of this visualchecklist.
	*
	* @return the traffic light note of this visualchecklist
	*/
	@Override
	public java.lang.String getTrafficLightNote() {
		return _visualchecklist.getTrafficLightNote();
	}

	/**
	* Sets the traffic light note of this visualchecklist.
	*
	* @param trafficLightNote the traffic light note of this visualchecklist
	*/
	@Override
	public void setTrafficLightNote(java.lang.String trafficLightNote) {
		_visualchecklist.setTrafficLightNote(trafficLightNote);
	}

	/**
	* Returns the signallight of this visualchecklist.
	*
	* @return the signallight of this visualchecklist
	*/
	@Override
	public java.lang.String getSignallight() {
		return _visualchecklist.getSignallight();
	}

	/**
	* Sets the signallight of this visualchecklist.
	*
	* @param signallight the signallight of this visualchecklist
	*/
	@Override
	public void setSignallight(java.lang.String signallight) {
		_visualchecklist.setSignallight(signallight);
	}

	/**
	* Returns the signallight note of this visualchecklist.
	*
	* @return the signallight note of this visualchecklist
	*/
	@Override
	public java.lang.String getSignallightNote() {
		return _visualchecklist.getSignallightNote();
	}

	/**
	* Sets the signallight note of this visualchecklist.
	*
	* @param signallightNote the signallight note of this visualchecklist
	*/
	@Override
	public void setSignallightNote(java.lang.String signallightNote) {
		_visualchecklist.setSignallightNote(signallightNote);
	}

	/**
	* Returns the vehiclebody of this visualchecklist.
	*
	* @return the vehiclebody of this visualchecklist
	*/
	@Override
	public java.lang.String getVehiclebody() {
		return _visualchecklist.getVehiclebody();
	}

	/**
	* Sets the vehiclebody of this visualchecklist.
	*
	* @param vehiclebody the vehiclebody of this visualchecklist
	*/
	@Override
	public void setVehiclebody(java.lang.String vehiclebody) {
		_visualchecklist.setVehiclebody(vehiclebody);
	}

	/**
	* Returns the vehiclebody note of this visualchecklist.
	*
	* @return the vehiclebody note of this visualchecklist
	*/
	@Override
	public java.lang.String getVehiclebodyNote() {
		return _visualchecklist.getVehiclebodyNote();
	}

	/**
	* Sets the vehiclebody note of this visualchecklist.
	*
	* @param vehiclebodyNote the vehiclebody note of this visualchecklist
	*/
	@Override
	public void setVehiclebodyNote(java.lang.String vehiclebodyNote) {
		_visualchecklist.setVehiclebodyNote(vehiclebodyNote);
	}

	/**
	* Returns the vehicle accessories of this visualchecklist.
	*
	* @return the vehicle accessories of this visualchecklist
	*/
	@Override
	public java.lang.String getVehicleAccessories() {
		return _visualchecklist.getVehicleAccessories();
	}

	/**
	* Sets the vehicle accessories of this visualchecklist.
	*
	* @param vehicleAccessories the vehicle accessories of this visualchecklist
	*/
	@Override
	public void setVehicleAccessories(java.lang.String vehicleAccessories) {
		_visualchecklist.setVehicleAccessories(vehicleAccessories);
	}

	/**
	* Returns the vehicle accessories note of this visualchecklist.
	*
	* @return the vehicle accessories note of this visualchecklist
	*/
	@Override
	public java.lang.String getVehicleAccessoriesNote() {
		return _visualchecklist.getVehicleAccessoriesNote();
	}

	/**
	* Sets the vehicle accessories note of this visualchecklist.
	*
	* @param vehicleAccessoriesNote the vehicle accessories note of this visualchecklist
	*/
	@Override
	public void setVehicleAccessoriesNote(
		java.lang.String vehicleAccessoriesNote) {
		_visualchecklist.setVehicleAccessoriesNote(vehicleAccessoriesNote);
	}

	/**
	* Returns the windscreen of this visualchecklist.
	*
	* @return the windscreen of this visualchecklist
	*/
	@Override
	public java.lang.String getWindscreen() {
		return _visualchecklist.getWindscreen();
	}

	/**
	* Sets the windscreen of this visualchecklist.
	*
	* @param windscreen the windscreen of this visualchecklist
	*/
	@Override
	public void setWindscreen(java.lang.String windscreen) {
		_visualchecklist.setWindscreen(windscreen);
	}

	/**
	* Returns the windscreen note of this visualchecklist.
	*
	* @return the windscreen note of this visualchecklist
	*/
	@Override
	public java.lang.String getWindscreenNote() {
		return _visualchecklist.getWindscreenNote();
	}

	/**
	* Sets the windscreen note of this visualchecklist.
	*
	* @param windscreenNote the windscreen note of this visualchecklist
	*/
	@Override
	public void setWindscreenNote(java.lang.String windscreenNote) {
		_visualchecklist.setWindscreenNote(windscreenNote);
	}

	/**
	* Returns the rear mirror of this visualchecklist.
	*
	* @return the rear mirror of this visualchecklist
	*/
	@Override
	public java.lang.String getRearMirror() {
		return _visualchecklist.getRearMirror();
	}

	/**
	* Sets the rear mirror of this visualchecklist.
	*
	* @param rearMirror the rear mirror of this visualchecklist
	*/
	@Override
	public void setRearMirror(java.lang.String rearMirror) {
		_visualchecklist.setRearMirror(rearMirror);
	}

	/**
	* Returns the rear mirror note of this visualchecklist.
	*
	* @return the rear mirror note of this visualchecklist
	*/
	@Override
	public java.lang.String getRearMirrorNote() {
		return _visualchecklist.getRearMirrorNote();
	}

	/**
	* Sets the rear mirror note of this visualchecklist.
	*
	* @param rearMirrorNote the rear mirror note of this visualchecklist
	*/
	@Override
	public void setRearMirrorNote(java.lang.String rearMirrorNote) {
		_visualchecklist.setRearMirrorNote(rearMirrorNote);
	}

	/**
	* Returns the doormirror of this visualchecklist.
	*
	* @return the doormirror of this visualchecklist
	*/
	@Override
	public java.lang.String getDoormirror() {
		return _visualchecklist.getDoormirror();
	}

	/**
	* Sets the doormirror of this visualchecklist.
	*
	* @param doormirror the doormirror of this visualchecklist
	*/
	@Override
	public void setDoormirror(java.lang.String doormirror) {
		_visualchecklist.setDoormirror(doormirror);
	}

	/**
	* Returns the doormirror note of this visualchecklist.
	*
	* @return the doormirror note of this visualchecklist
	*/
	@Override
	public java.lang.String getDoormirrorNote() {
		return _visualchecklist.getDoormirrorNote();
	}

	/**
	* Sets the doormirror note of this visualchecklist.
	*
	* @param doormirrorNote the doormirror note of this visualchecklist
	*/
	@Override
	public void setDoormirrorNote(java.lang.String doormirrorNote) {
		_visualchecklist.setDoormirrorNote(doormirrorNote);
	}

	/**
	* Returns the vehicletires of this visualchecklist.
	*
	* @return the vehicletires of this visualchecklist
	*/
	@Override
	public java.lang.String getVehicletires() {
		return _visualchecklist.getVehicletires();
	}

	/**
	* Sets the vehicletires of this visualchecklist.
	*
	* @param vehicletires the vehicletires of this visualchecklist
	*/
	@Override
	public void setVehicletires(java.lang.String vehicletires) {
		_visualchecklist.setVehicletires(vehicletires);
	}

	/**
	* Returns the vehicletires note of this visualchecklist.
	*
	* @return the vehicletires note of this visualchecklist
	*/
	@Override
	public java.lang.String getVehicletiresNote() {
		return _visualchecklist.getVehicletiresNote();
	}

	/**
	* Sets the vehicletires note of this visualchecklist.
	*
	* @param vehicletiresNote the vehicletires note of this visualchecklist
	*/
	@Override
	public void setVehicletiresNote(java.lang.String vehicletiresNote) {
		_visualchecklist.setVehicletiresNote(vehicletiresNote);
	}

	/**
	* Returns the frontbumper of this visualchecklist.
	*
	* @return the frontbumper of this visualchecklist
	*/
	@Override
	public java.lang.String getFrontbumper() {
		return _visualchecklist.getFrontbumper();
	}

	/**
	* Sets the frontbumper of this visualchecklist.
	*
	* @param frontbumper the frontbumper of this visualchecklist
	*/
	@Override
	public void setFrontbumper(java.lang.String frontbumper) {
		_visualchecklist.setFrontbumper(frontbumper);
	}

	/**
	* Returns the frontbumper note of this visualchecklist.
	*
	* @return the frontbumper note of this visualchecklist
	*/
	@Override
	public java.lang.String getFrontbumperNote() {
		return _visualchecklist.getFrontbumperNote();
	}

	/**
	* Sets the frontbumper note of this visualchecklist.
	*
	* @param frontbumperNote the frontbumper note of this visualchecklist
	*/
	@Override
	public void setFrontbumperNote(java.lang.String frontbumperNote) {
		_visualchecklist.setFrontbumperNote(frontbumperNote);
	}

	/**
	* Returns the rearbumper of this visualchecklist.
	*
	* @return the rearbumper of this visualchecklist
	*/
	@Override
	public java.lang.String getRearbumper() {
		return _visualchecklist.getRearbumper();
	}

	/**
	* Sets the rearbumper of this visualchecklist.
	*
	* @param rearbumper the rearbumper of this visualchecklist
	*/
	@Override
	public void setRearbumper(java.lang.String rearbumper) {
		_visualchecklist.setRearbumper(rearbumper);
	}

	/**
	* Returns the rearbumper note of this visualchecklist.
	*
	* @return the rearbumper note of this visualchecklist
	*/
	@Override
	public java.lang.String getRearbumperNote() {
		return _visualchecklist.getRearbumperNote();
	}

	/**
	* Sets the rearbumper note of this visualchecklist.
	*
	* @param rearbumperNote the rearbumper note of this visualchecklist
	*/
	@Override
	public void setRearbumperNote(java.lang.String rearbumperNote) {
		_visualchecklist.setRearbumperNote(rearbumperNote);
	}

	/**
	* Returns the frontseat of this visualchecklist.
	*
	* @return the frontseat of this visualchecklist
	*/
	@Override
	public java.lang.String getFrontseat() {
		return _visualchecklist.getFrontseat();
	}

	/**
	* Sets the frontseat of this visualchecklist.
	*
	* @param frontseat the frontseat of this visualchecklist
	*/
	@Override
	public void setFrontseat(java.lang.String frontseat) {
		_visualchecklist.setFrontseat(frontseat);
	}

	/**
	* Returns the frontseat note of this visualchecklist.
	*
	* @return the frontseat note of this visualchecklist
	*/
	@Override
	public java.lang.String getFrontseatNote() {
		return _visualchecklist.getFrontseatNote();
	}

	/**
	* Sets the frontseat note of this visualchecklist.
	*
	* @param frontseatNote the frontseat note of this visualchecklist
	*/
	@Override
	public void setFrontseatNote(java.lang.String frontseatNote) {
		_visualchecklist.setFrontseatNote(frontseatNote);
	}

	/**
	* Returns the rearseats of this visualchecklist.
	*
	* @return the rearseats of this visualchecklist
	*/
	@Override
	public java.lang.String getRearseats() {
		return _visualchecklist.getRearseats();
	}

	/**
	* Sets the rearseats of this visualchecklist.
	*
	* @param rearseats the rearseats of this visualchecklist
	*/
	@Override
	public void setRearseats(java.lang.String rearseats) {
		_visualchecklist.setRearseats(rearseats);
	}

	/**
	* Returns the rearseats note of this visualchecklist.
	*
	* @return the rearseats note of this visualchecklist
	*/
	@Override
	public java.lang.String getRearseatsNote() {
		return _visualchecklist.getRearseatsNote();
	}

	/**
	* Sets the rearseats note of this visualchecklist.
	*
	* @param rearseatsNote the rearseats note of this visualchecklist
	*/
	@Override
	public void setRearseatsNote(java.lang.String rearseatsNote) {
		_visualchecklist.setRearseatsNote(rearseatsNote);
	}

	/**
	* Returns the note of this visualchecklist.
	*
	* @return the note of this visualchecklist
	*/
	@Override
	public java.lang.String getNote() {
		return _visualchecklist.getNote();
	}

	/**
	* Sets the note of this visualchecklist.
	*
	* @param note the note of this visualchecklist
	*/
	@Override
	public void setNote(java.lang.String note) {
		_visualchecklist.setNote(note);
	}

	/**
	* Returns the vehicle registration no of this visualchecklist.
	*
	* @return the vehicle registration no of this visualchecklist
	*/
	@Override
	public java.lang.String getVehicleRegistrationNo() {
		return _visualchecklist.getVehicleRegistrationNo();
	}

	/**
	* Sets the vehicle registration no of this visualchecklist.
	*
	* @param vehicleRegistrationNo the vehicle registration no of this visualchecklist
	*/
	@Override
	public void setVehicleRegistrationNo(java.lang.String vehicleRegistrationNo) {
		_visualchecklist.setVehicleRegistrationNo(vehicleRegistrationNo);
	}

	/**
	* Returns the model of this visualchecklist.
	*
	* @return the model of this visualchecklist
	*/
	@Override
	public java.lang.String getModel() {
		return _visualchecklist.getModel();
	}

	/**
	* Sets the model of this visualchecklist.
	*
	* @param model the model of this visualchecklist
	*/
	@Override
	public void setModel(java.lang.String model) {
		_visualchecklist.setModel(model);
	}

	/**
	* Returns the color of this visualchecklist.
	*
	* @return the color of this visualchecklist
	*/
	@Override
	public java.lang.String getColor() {
		return _visualchecklist.getColor();
	}

	/**
	* Sets the color of this visualchecklist.
	*
	* @param color the color of this visualchecklist
	*/
	@Override
	public void setColor(java.lang.String color) {
		_visualchecklist.setColor(color);
	}

	/**
	* Returns the dateof vehicles of this visualchecklist.
	*
	* @return the dateof vehicles of this visualchecklist
	*/
	@Override
	public java.lang.String getDateofVehicles() {
		return _visualchecklist.getDateofVehicles();
	}

	/**
	* Sets the dateof vehicles of this visualchecklist.
	*
	* @param dateofVehicles the dateof vehicles of this visualchecklist
	*/
	@Override
	public void setDateofVehicles(java.lang.String dateofVehicles) {
		_visualchecklist.setDateofVehicles(dateofVehicles);
	}

	/**
	* Returns the investigatorname of this visualchecklist.
	*
	* @return the investigatorname of this visualchecklist
	*/
	@Override
	public java.lang.String getInvestigatorname() {
		return _visualchecklist.getInvestigatorname();
	}

	/**
	* Sets the investigatorname of this visualchecklist.
	*
	* @param investigatorname the investigatorname of this visualchecklist
	*/
	@Override
	public void setInvestigatorname(java.lang.String investigatorname) {
		_visualchecklist.setInvestigatorname(investigatorname);
	}

	/**
	* Returns the investigatorphone of this visualchecklist.
	*
	* @return the investigatorphone of this visualchecklist
	*/
	@Override
	public java.lang.String getInvestigatorphone() {
		return _visualchecklist.getInvestigatorphone();
	}

	/**
	* Sets the investigatorphone of this visualchecklist.
	*
	* @param investigatorphone the investigatorphone of this visualchecklist
	*/
	@Override
	public void setInvestigatorphone(java.lang.String investigatorphone) {
		_visualchecklist.setInvestigatorphone(investigatorphone);
	}

	/**
	* Returns the investigator email of this visualchecklist.
	*
	* @return the investigator email of this visualchecklist
	*/
	@Override
	public java.lang.String getInvestigatorEmail() {
		return _visualchecklist.getInvestigatorEmail();
	}

	/**
	* Sets the investigator email of this visualchecklist.
	*
	* @param investigatorEmail the investigator email of this visualchecklist
	*/
	@Override
	public void setInvestigatorEmail(java.lang.String investigatorEmail) {
		_visualchecklist.setInvestigatorEmail(investigatorEmail);
	}

	@Override
	public boolean isNew() {
		return _visualchecklist.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_visualchecklist.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _visualchecklist.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_visualchecklist.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _visualchecklist.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _visualchecklist.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_visualchecklist.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _visualchecklist.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_visualchecklist.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_visualchecklist.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_visualchecklist.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new visualchecklistWrapper((visualchecklist)_visualchecklist.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.visualchecklist visualchecklist) {
		return _visualchecklist.compareTo(visualchecklist);
	}

	@Override
	public int hashCode() {
		return _visualchecklist.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.visualchecklist> toCacheModel() {
		return _visualchecklist.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.visualchecklist toEscapedModel() {
		return new visualchecklistWrapper(_visualchecklist.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.visualchecklist toUnescapedModel() {
		return new visualchecklistWrapper(_visualchecklist.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _visualchecklist.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _visualchecklist.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_visualchecklist.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof visualchecklistWrapper)) {
			return false;
		}

		visualchecklistWrapper visualchecklistWrapper = (visualchecklistWrapper)obj;

		if (Validator.equals(_visualchecklist,
					visualchecklistWrapper._visualchecklist)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public visualchecklist getWrappedvisualchecklist() {
		return _visualchecklist;
	}

	@Override
	public visualchecklist getWrappedModel() {
		return _visualchecklist;
	}

	@Override
	public void resetOriginalValues() {
		_visualchecklist.resetOriginalValues();
	}

	private visualchecklist _visualchecklist;
}