/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.org.skali.sitanAdmin.model.vehicalInfo;

import java.util.List;

/**
 * The persistence utility for the vehical info service. This utility wraps {@link vehicalInfoPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see vehicalInfoPersistence
 * @see vehicalInfoPersistenceImpl
 * @generated
 */
public class vehicalInfoUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(vehicalInfo vehicalInfo) {
		getPersistence().clearCache(vehicalInfo);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<vehicalInfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<vehicalInfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<vehicalInfo> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static vehicalInfo update(vehicalInfo vehicalInfo)
		throws SystemException {
		return getPersistence().update(vehicalInfo);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static vehicalInfo update(vehicalInfo vehicalInfo,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(vehicalInfo, serviceContext);
	}

	/**
	* Returns all the vehical infos where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId);
	}

	/**
	* Returns a range of all the vehical infos where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.vehicalInfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of vehical infos
	* @param end the upper bound of the range of vehical infos (not inclusive)
	* @return the range of matching vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end);
	}

	/**
	* Returns an ordered range of all the vehical infos where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.vehicalInfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of vehical infos
	* @param end the upper bound of the range of vehical infos (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBybilId(bilId, start, end, orderByComparator);
	}

	/**
	* Returns the first vehical info in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching vehical info
	* @throws com.org.skali.sitanAdmin.NoSuchvehicalInfoException if a matching vehical info could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvehicalInfoException {
		return getPersistence().findBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the first vehical info in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching vehical info, or <code>null</code> if a matching vehical info could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_First(bilId, orderByComparator);
	}

	/**
	* Returns the last vehical info in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching vehical info
	* @throws com.org.skali.sitanAdmin.NoSuchvehicalInfoException if a matching vehical info could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvehicalInfoException {
		return getPersistence().findBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Returns the last vehical info in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching vehical info, or <code>null</code> if a matching vehical info could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBybilId_Last(bilId, orderByComparator);
	}

	/**
	* Returns the vehical infos before and after the current vehical info in the ordered set where bilId = &#63;.
	*
	* @param vehicalId the primary key of the current vehical info
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next vehical info
	* @throws com.org.skali.sitanAdmin.NoSuchvehicalInfoException if a vehical info with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo[] findBybilId_PrevAndNext(
		long vehicalId, long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvehicalInfoException {
		return getPersistence()
				   .findBybilId_PrevAndNext(vehicalId, bilId, orderByComparator);
	}

	/**
	* Removes all the vehical infos where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBybilId(bilId);
	}

	/**
	* Returns the number of vehical infos where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBybilId(bilId);
	}

	/**
	* Caches the vehical info in the entity cache if it is enabled.
	*
	* @param vehicalInfo the vehical info
	*/
	public static void cacheResult(
		com.org.skali.sitanAdmin.model.vehicalInfo vehicalInfo) {
		getPersistence().cacheResult(vehicalInfo);
	}

	/**
	* Caches the vehical infos in the entity cache if it is enabled.
	*
	* @param vehicalInfos the vehical infos
	*/
	public static void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> vehicalInfos) {
		getPersistence().cacheResult(vehicalInfos);
	}

	/**
	* Creates a new vehical info with the primary key. Does not add the vehical info to the database.
	*
	* @param vehicalId the primary key for the new vehical info
	* @return the new vehical info
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo create(
		long vehicalId) {
		return getPersistence().create(vehicalId);
	}

	/**
	* Removes the vehical info with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param vehicalId the primary key of the vehical info
	* @return the vehical info that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchvehicalInfoException if a vehical info with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo remove(
		long vehicalId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvehicalInfoException {
		return getPersistence().remove(vehicalId);
	}

	public static com.org.skali.sitanAdmin.model.vehicalInfo updateImpl(
		com.org.skali.sitanAdmin.model.vehicalInfo vehicalInfo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(vehicalInfo);
	}

	/**
	* Returns the vehical info with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchvehicalInfoException} if it could not be found.
	*
	* @param vehicalId the primary key of the vehical info
	* @return the vehical info
	* @throws com.org.skali.sitanAdmin.NoSuchvehicalInfoException if a vehical info with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo findByPrimaryKey(
		long vehicalId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchvehicalInfoException {
		return getPersistence().findByPrimaryKey(vehicalId);
	}

	/**
	* Returns the vehical info with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param vehicalId the primary key of the vehical info
	* @return the vehical info, or <code>null</code> if a vehical info with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.vehicalInfo fetchByPrimaryKey(
		long vehicalId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(vehicalId);
	}

	/**
	* Returns all the vehical infos.
	*
	* @return the vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the vehical infos.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.vehicalInfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of vehical infos
	* @param end the upper bound of the range of vehical infos (not inclusive)
	* @return the range of vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the vehical infos.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.vehicalInfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of vehical infos
	* @param end the upper bound of the range of vehical infos (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.vehicalInfo> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the vehical infos from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of vehical infos.
	*
	* @return the number of vehical infos
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static vehicalInfoPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (vehicalInfoPersistence)PortletBeanLocatorUtil.locate(com.org.skali.sitanAdmin.service.ClpSerializer.getServletContextName(),
					vehicalInfoPersistence.class.getName());

			ReferenceRegistry.registerReference(vehicalInfoUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(vehicalInfoPersistence persistence) {
	}

	private static vehicalInfoPersistence _persistence;
}