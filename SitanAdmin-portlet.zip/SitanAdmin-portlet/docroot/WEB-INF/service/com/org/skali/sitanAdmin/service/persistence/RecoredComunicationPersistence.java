/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.org.skali.sitanAdmin.model.RecoredComunication;

/**
 * The persistence interface for the recored comunication service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see RecoredComunicationPersistenceImpl
 * @see RecoredComunicationUtil
 * @generated
 */
public interface RecoredComunicationPersistence extends BasePersistence<RecoredComunication> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link RecoredComunicationUtil} to access the recored comunication persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the recored comunications where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the recored comunications where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of recored comunications
	* @param end the upper bound of the range of recored comunications (not inclusive)
	* @return the range of matching recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the recored comunications where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of recored comunications
	* @param end the upper bound of the range of recored comunications (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first recored comunication in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recored comunication
	* @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a matching recored comunication could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;

	/**
	* Returns the first recored comunication in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recored comunication, or <code>null</code> if a matching recored comunication could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last recored comunication in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recored comunication
	* @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a matching recored comunication could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;

	/**
	* Returns the last recored comunication in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recored comunication, or <code>null</code> if a matching recored comunication could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the recored comunications before and after the current recored comunication in the ordered set where bilId = &#63;.
	*
	* @param recoredomuni the primary key of the current recored comunication
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next recored comunication
	* @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication[] findBybilId_PrevAndNext(
		long recoredomuni, long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;

	/**
	* Removes all the recored comunications where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of recored comunications where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the recored comunication in the entity cache if it is enabled.
	*
	* @param recoredComunication the recored comunication
	*/
	public void cacheResult(
		com.org.skali.sitanAdmin.model.RecoredComunication recoredComunication);

	/**
	* Caches the recored comunications in the entity cache if it is enabled.
	*
	* @param recoredComunications the recored comunications
	*/
	public void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> recoredComunications);

	/**
	* Creates a new recored comunication with the primary key. Does not add the recored comunication to the database.
	*
	* @param recoredomuni the primary key for the new recored comunication
	* @return the new recored comunication
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication create(
		long recoredomuni);

	/**
	* Removes the recored comunication with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param recoredomuni the primary key of the recored comunication
	* @return the recored comunication that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication remove(
		long recoredomuni)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;

	public com.org.skali.sitanAdmin.model.RecoredComunication updateImpl(
		com.org.skali.sitanAdmin.model.RecoredComunication recoredComunication)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the recored comunication with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchRecoredComunicationException} if it could not be found.
	*
	* @param recoredomuni the primary key of the recored comunication
	* @return the recored comunication
	* @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication findByPrimaryKey(
		long recoredomuni)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;

	/**
	* Returns the recored comunication with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param recoredomuni the primary key of the recored comunication
	* @return the recored comunication, or <code>null</code> if a recored comunication with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.RecoredComunication fetchByPrimaryKey(
		long recoredomuni)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the recored comunications.
	*
	* @return the recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the recored comunications.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of recored comunications
	* @param end the upper bound of the range of recored comunications (not inclusive)
	* @return the range of recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the recored comunications.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of recored comunications
	* @param end the upper bound of the range of recored comunications (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.RecoredComunication> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the recored comunications from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of recored comunications.
	*
	* @return the number of recored comunications
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}