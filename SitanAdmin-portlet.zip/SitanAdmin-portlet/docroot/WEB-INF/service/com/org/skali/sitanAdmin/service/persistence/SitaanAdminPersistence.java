/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.org.skali.sitanAdmin.model.SitaanAdmin;

/**
 * The persistence interface for the sitaan admin service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see SitaanAdminPersistenceImpl
 * @see SitaanAdminUtil
 * @generated
 */
public interface SitaanAdminPersistence extends BasePersistence<SitaanAdmin> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link SitaanAdminUtil} to access the sitaan admin persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the sitaan admins where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the sitaan admins where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where dateSeized = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dateSeized the date seized
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where dateSeized = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dateSeized the date seized
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBydateSeized(
		java.lang.String dateSeized, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBydateSeized_First(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBydateSeized_First(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBydateSeized_Last(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBydateSeized_Last(
		java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where dateSeized = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param dateSeized the date seized
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBydateSeized_PrevAndNext(
		long bilId, java.lang.String dateSeized,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where dateSeized = &#63; from the database.
	*
	* @param dateSeized the date seized
	* @throws SystemException if a system exception occurred
	*/
	public void removeBydateSeized(java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where dateSeized = &#63;.
	*
	* @param dateSeized the date seized
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBydateSeized(java.lang.String dateSeized)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where checkSitesSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesSita the check sites sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where checkSitesSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param checkSitesSita the check sites sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBycheckSitesSita(
		java.lang.String checkSitesSita, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBycheckSitesSita_First(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBycheckSitesSita_First(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBycheckSitesSita_Last(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBycheckSitesSita_Last(
		java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where checkSitesSita = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param checkSitesSita the check sites sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBycheckSitesSita_PrevAndNext(
		long bilId, java.lang.String checkSitesSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where checkSitesSita = &#63; from the database.
	*
	* @param checkSitesSita the check sites sita
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycheckSitesSita(java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where checkSitesSita = &#63;.
	*
	* @param checkSitesSita the check sites sita
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBycheckSitesSita(java.lang.String checkSitesSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where referenceEffective = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param referenceEffective the reference effective
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByreferenceEffective(
		java.lang.String referenceEffective, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByreferenceEffective_First(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByreferenceEffective_Last(
		java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where referenceEffective = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param referenceEffective the reference effective
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByreferenceEffective_PrevAndNext(
		long bilId, java.lang.String referenceEffective,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where referenceEffective = &#63; from the database.
	*
	* @param referenceEffective the reference effective
	* @throws SystemException if a system exception occurred
	*/
	public void removeByreferenceEffective(java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where referenceEffective = &#63;.
	*
	* @param referenceEffective the reference effective
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByreferenceEffective(java.lang.String referenceEffective)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param confiscatedPeriod the confiscated period
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where confiscatedPeriod = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param confiscatedPeriod the confiscated period
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByconfiscatedPeriod(
		java.lang.String confiscatedPeriod, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByconfiscatedPeriod_First(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByconfiscatedPeriod_First(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByconfiscatedPeriod_Last(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByconfiscatedPeriod_Last(
		java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param confiscatedPeriod the confiscated period
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByconfiscatedPeriod_PrevAndNext(
		long bilId, java.lang.String confiscatedPeriod,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where confiscatedPeriod = &#63; from the database.
	*
	* @param confiscatedPeriod the confiscated period
	* @throws SystemException if a system exception occurred
	*/
	public void removeByconfiscatedPeriod(java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where confiscatedPeriod = &#63;.
	*
	* @param confiscatedPeriod the confiscated period
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByconfiscatedPeriod(java.lang.String confiscatedPeriod)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where source = &#63;.
	*
	* @param source the source
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where source = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBysource(
		java.lang.String source, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBysource_First(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63;.
	*
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBysource_Last(
		java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param source the source
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBysource_PrevAndNext(
		long bilId, java.lang.String source,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where source = &#63; from the database.
	*
	* @param source the source
	* @throws SystemException if a system exception occurred
	*/
	public void removeBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where source = &#63;.
	*
	* @param source the source
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBysource(java.lang.String source)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where ownerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ownerName the owner name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where ownerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param ownerName the owner name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByownerName(
		java.lang.String ownerName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByownerName_First(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByownerName_First(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByownerName_Last(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByownerName_Last(
		java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where ownerName = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param ownerName the owner name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByownerName_PrevAndNext(
		long bilId, java.lang.String ownerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where ownerName = &#63; from the database.
	*
	* @param ownerName the owner name
	* @throws SystemException if a system exception occurred
	*/
	public void removeByownerName(java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where ownerName = &#63;.
	*
	* @param ownerName the owner name
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByownerName(java.lang.String ownerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByvehicleRegistrationNo_First(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByvehicleRegistrationNo_First(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByvehicleRegistrationNo_Last(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByvehicleRegistrationNo_Last(
		java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param vehicleRegistrationNo the vehicle registration no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByvehicleRegistrationNo_PrevAndNext(
		long bilId, java.lang.String vehicleRegistrationNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where vehicleRegistrationNo = &#63; from the database.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @throws SystemException if a system exception occurred
	*/
	public void removeByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where vehicleRegistrationNo = &#63;.
	*
	* @param vehicleRegistrationNo the vehicle registration no
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByvehicleRegistrationNo(
		java.lang.String vehicleRegistrationNo)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where territory = &#63;.
	*
	* @param territory the territory
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where territory = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param territory the territory
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByterritory(
		java.lang.String territory, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByterritory_First(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where territory = &#63;.
	*
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByterritory_Last(
		java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where territory = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param territory the territory
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByterritory_PrevAndNext(
		long bilId, java.lang.String territory,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where territory = &#63; from the database.
	*
	* @param territory the territory
	* @throws SystemException if a system exception occurred
	*/
	public void removeByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where territory = &#63;.
	*
	* @param territory the territory
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByterritory(java.lang.String territory)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where state = &#63;.
	*
	* @param state the state
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where state = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param state the state
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBystate(
		java.lang.String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBystate_First(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where state = &#63;.
	*
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBystate_Last(
		java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where state = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param state the state
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBystate_PrevAndNext(
		long bilId, java.lang.String state,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where state = &#63; from the database.
	*
	* @param state the state
	* @throws SystemException if a system exception occurred
	*/
	public void removeBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where state = &#63;.
	*
	* @param state the state
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBystate(java.lang.String state)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where locationCageSita = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param locationCageSita the location cage sita
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBylocationCageSita(
		java.lang.String locationCageSita, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBylocationCageSita_First(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBylocationCageSita_Last(
		java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where locationCageSita = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param locationCageSita the location cage sita
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBylocationCageSita_PrevAndNext(
		long bilId, java.lang.String locationCageSita,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where locationCageSita = &#63; from the database.
	*
	* @param locationCageSita the location cage sita
	* @throws SystemException if a system exception occurred
	*/
	public void removeBylocationCageSita(java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where locationCageSita = &#63;.
	*
	* @param locationCageSita the location cage sita
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBylocationCageSita(java.lang.String locationCageSita)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where foreclosureStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param foreclosureStatus the foreclosure status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByforeclosureStatus(
		java.lang.String foreclosureStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByforeclosureStatus_First(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByforeclosureStatus_Last(
		java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where foreclosureStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param foreclosureStatus the foreclosure status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByforeclosureStatus_PrevAndNext(
		long bilId, java.lang.String foreclosureStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where foreclosureStatus = &#63; from the database.
	*
	* @param foreclosureStatus the foreclosure status
	* @throws SystemException if a system exception occurred
	*/
	public void removeByforeclosureStatus(java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where foreclosureStatus = &#63;.
	*
	* @param foreclosureStatus the foreclosure status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByforeclosureStatus(java.lang.String foreclosureStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where resultsforeclosure = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where resultsforeclosure = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByresultsforeclosure(
		java.lang.String resultsforeclosure, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByresultsforeclosure_First(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByresultsforeclosure_First(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByresultsforeclosure_Last(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByresultsforeclosure_Last(
		java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where resultsforeclosure = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param resultsforeclosure the resultsforeclosure
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByresultsforeclosure_PrevAndNext(
		long bilId, java.lang.String resultsforeclosure,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where resultsforeclosure = &#63; from the database.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @throws SystemException if a system exception occurred
	*/
	public void removeByresultsforeclosure(java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where resultsforeclosure = &#63;.
	*
	* @param resultsforeclosure the resultsforeclosure
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByresultsforeclosure(java.lang.String resultsforeclosure)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findBypaymentStatus(
		boolean paymentStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBypaymentStatus_First(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBypaymentStatus_First(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findBypaymentStatus_Last(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchBypaymentStatus_Last(
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where paymentStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findBypaymentStatus_PrevAndNext(
		long bilId, boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where paymentStatus = &#63; from the database.
	*
	* @param paymentStatus the payment status
	* @throws SystemException if a system exception occurred
	*/
	public void removeBypaymentStatus(boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where paymentStatus = &#63;.
	*
	* @param paymentStatus the payment status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countBypaymentStatus(boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where officerName = &#63;.
	*
	* @param officerName the officer name
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where officerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerName the officer name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where officerName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param officerName the officer name
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByofficerName(
		java.lang.String officerName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByofficerName_First(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByofficerName_First(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByofficerName_Last(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByofficerName_Last(
		java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where officerName = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param officerName the officer name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByofficerName_PrevAndNext(
		long bilId, java.lang.String officerName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where officerName = &#63; from the database.
	*
	* @param officerName the officer name
	* @throws SystemException if a system exception occurred
	*/
	public void removeByofficerName(java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where officerName = &#63;.
	*
	* @param officerName the officer name
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByofficerName(java.lang.String officerName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where rightsReleased = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param rightsReleased the rights released
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where rightsReleased = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param rightsReleased the rights released
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByrightsReleased(
		java.lang.String rightsReleased, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByrightsReleased_First(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByrightsReleased_First(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByrightsReleased_Last(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByrightsReleased_Last(
		java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where rightsReleased = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param rightsReleased the rights released
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByrightsReleased_PrevAndNext(
		long bilId, java.lang.String rightsReleased,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where rightsReleased = &#63; from the database.
	*
	* @param rightsReleased the rights released
	* @throws SystemException if a system exception occurred
	*/
	public void removeByrightsReleased(java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where rightsReleased = &#63;.
	*
	* @param rightsReleased the rights released
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByrightsReleased(java.lang.String rightsReleased)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where acceptancedate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param acceptancedate the acceptancedate
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where acceptancedate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param acceptancedate the acceptancedate
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByacceptancedate(
		java.lang.String acceptancedate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByacceptancedate_First(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByacceptancedate_First(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByacceptancedate_Last(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByacceptancedate_Last(
		java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where acceptancedate = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param acceptancedate the acceptancedate
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByacceptancedate_PrevAndNext(
		long bilId, java.lang.String acceptancedate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where acceptancedate = &#63; from the database.
	*
	* @param acceptancedate the acceptancedate
	* @throws SystemException if a system exception occurred
	*/
	public void removeByacceptancedate(java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where acceptancedate = &#63;.
	*
	* @param acceptancedate the acceptancedate
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByacceptancedate(java.lang.String acceptancedate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @return the matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findByFinedByColumn(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByFinedByColumn_First(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByFinedByColumn_First(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByFinedByColumn_Last(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByFinedByColumn_Last(
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param bilId the primary key of the current sitaan admin
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin[] findByFinedByColumn_PrevAndNext(
		long bilId, java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String vehicleRegistrationNo,
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Removes all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63; from the database.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @throws SystemException if a system exception occurred
	*/
	public void removeByFinedByColumn(java.lang.String source,
		java.lang.String ownerName, java.lang.String territory,
		java.lang.String vehicleRegistrationNo, java.lang.String dateSeized,
		java.lang.String checkSitesSita, java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	*
	* @param source the source
	* @param ownerName the owner name
	* @param territory the territory
	* @param vehicleRegistrationNo the vehicle registration no
	* @param dateSeized the date seized
	* @param checkSitesSita the check sites sita
	* @param referenceEffective the reference effective
	* @param confiscatedPeriod the confiscated period
	* @param state the state
	* @param locationCageSita the location cage sita
	* @param foreclosureStatus the foreclosure status
	* @param resultsforeclosure the resultsforeclosure
	* @param officerName the officer name
	* @param rightsReleased the rights released
	* @param acceptancedate the acceptancedate
	* @param paymentStatus the payment status
	* @return the number of matching sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countByFinedByColumn(java.lang.String source,
		java.lang.String ownerName, java.lang.String territory,
		java.lang.String vehicleRegistrationNo, java.lang.String dateSeized,
		java.lang.String checkSitesSita, java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String state,
		java.lang.String locationCageSita, java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String rightsReleased, java.lang.String acceptancedate,
		boolean paymentStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the sitaan admin in the entity cache if it is enabled.
	*
	* @param sitaanAdmin the sitaan admin
	*/
	public void cacheResult(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin);

	/**
	* Caches the sitaan admins in the entity cache if it is enabled.
	*
	* @param sitaanAdmins the sitaan admins
	*/
	public void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> sitaanAdmins);

	/**
	* Creates a new sitaan admin with the primary key. Does not add the sitaan admin to the database.
	*
	* @param bilId the primary key for the new sitaan admin
	* @return the new sitaan admin
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin create(long bilId);

	/**
	* Removes the sitaan admin with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin remove(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	public com.org.skali.sitanAdmin.model.SitaanAdmin updateImpl(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the sitaan admin with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchSitaanAdminException} if it could not be found.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin
	* @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin findByPrimaryKey(
		long bilId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchSitaanAdminException;

	/**
	* Returns the sitaan admin with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param bilId the primary key of the sitaan admin
	* @return the sitaan admin, or <code>null</code> if a sitaan admin with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.SitaanAdmin fetchByPrimaryKey(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the sitaan admins.
	*
	* @return the sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the sitaan admins.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @return the range of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the sitaan admins.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of sitaan admins
	* @param end the upper bound of the range of sitaan admins (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.SitaanAdmin> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the sitaan admins from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of sitaan admins.
	*
	* @return the number of sitaan admins
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}