/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.BillInqueryServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.BillInqueryServiceSoap
 * @generated
 */
public class BillInquerySoap implements Serializable {
	public static BillInquerySoap toSoapModel(BillInquery model) {
		BillInquerySoap soapModel = new BillInquerySoap();

		soapModel.setBillinquery(model.getBillinquery());
		soapModel.setBilId(model.getBilId());
		soapModel.setComplaintDate(model.getComplaintDate());
		soapModel.setReferenceEffective(model.getReferenceEffective());
		soapModel.setSource(model.getSource());
		soapModel.setVehiclesNo(model.getVehiclesNo());
		soapModel.setCompanyName(model.getCompanyName());
		soapModel.setOffense(model.getOffense());
		soapModel.setVirtue(model.getVirtue());
		soapModel.setFilerating(model.getFilerating());
		soapModel.setCaseStatus(model.getCaseStatus());
		soapModel.setNameofofficer(model.getNameofofficer());
		soapModel.setError(model.getError());
		soapModel.setErrorType(model.getErrorType());

		return soapModel;
	}

	public static BillInquerySoap[] toSoapModels(BillInquery[] models) {
		BillInquerySoap[] soapModels = new BillInquerySoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static BillInquerySoap[][] toSoapModels(BillInquery[][] models) {
		BillInquerySoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new BillInquerySoap[models.length][models[0].length];
		}
		else {
			soapModels = new BillInquerySoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static BillInquerySoap[] toSoapModels(List<BillInquery> models) {
		List<BillInquerySoap> soapModels = new ArrayList<BillInquerySoap>(models.size());

		for (BillInquery model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new BillInquerySoap[soapModels.size()]);
	}

	public BillInquerySoap() {
	}

	public long getPrimaryKey() {
		return _billinquery;
	}

	public void setPrimaryKey(long pk) {
		setBillinquery(pk);
	}

	public long getBillinquery() {
		return _billinquery;
	}

	public void setBillinquery(long billinquery) {
		_billinquery = billinquery;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getComplaintDate() {
		return _complaintDate;
	}

	public void setComplaintDate(String complaintDate) {
		_complaintDate = complaintDate;
	}

	public String getReferenceEffective() {
		return _referenceEffective;
	}

	public void setReferenceEffective(String referenceEffective) {
		_referenceEffective = referenceEffective;
	}

	public String getSource() {
		return _source;
	}

	public void setSource(String source) {
		_source = source;
	}

	public String getVehiclesNo() {
		return _vehiclesNo;
	}

	public void setVehiclesNo(String vehiclesNo) {
		_vehiclesNo = vehiclesNo;
	}

	public String getCompanyName() {
		return _companyName;
	}

	public void setCompanyName(String companyName) {
		_companyName = companyName;
	}

	public String getOffense() {
		return _offense;
	}

	public void setOffense(String offense) {
		_offense = offense;
	}

	public String getVirtue() {
		return _virtue;
	}

	public void setVirtue(String virtue) {
		_virtue = virtue;
	}

	public String getFilerating() {
		return _filerating;
	}

	public void setFilerating(String filerating) {
		_filerating = filerating;
	}

	public String getCaseStatus() {
		return _caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		_caseStatus = caseStatus;
	}

	public String getNameofofficer() {
		return _nameofofficer;
	}

	public void setNameofofficer(String nameofofficer) {
		_nameofofficer = nameofofficer;
	}

	public String getError() {
		return _error;
	}

	public void setError(String error) {
		_error = error;
	}

	public String getErrorType() {
		return _errorType;
	}

	public void setErrorType(String errorType) {
		_errorType = errorType;
	}

	private long _billinquery;
	private long _bilId;
	private String _complaintDate;
	private String _referenceEffective;
	private String _source;
	private String _vehiclesNo;
	private String _companyName;
	private String _offense;
	private String _virtue;
	private String _filerating;
	private String _caseStatus;
	private String _nameofofficer;
	private String _error;
	private String _errorType;
}