/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link OfficerDetail}.
 * </p>
 *
 * @author reeshu
 * @see OfficerDetail
 * @generated
 */
public class OfficerDetailWrapper implements OfficerDetail,
	ModelWrapper<OfficerDetail> {
	public OfficerDetailWrapper(OfficerDetail officerDetail) {
		_officerDetail = officerDetail;
	}

	@Override
	public Class<?> getModelClass() {
		return OfficerDetail.class;
	}

	@Override
	public String getModelClassName() {
		return OfficerDetail.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("officerid", getOfficerid());
		attributes.put("officername", getOfficername());
		attributes.put("officertype", getOfficertype());
		attributes.put("office", getOffice());
		attributes.put("Officerpower", getOfficerpower());
		attributes.put("Date", getDate());
		attributes.put("officerphone", getOfficerphone());
		attributes.put("officerEmail", getOfficerEmail());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long officerid = (Long)attributes.get("officerid");

		if (officerid != null) {
			setOfficerid(officerid);
		}

		String officername = (String)attributes.get("officername");

		if (officername != null) {
			setOfficername(officername);
		}

		String officertype = (String)attributes.get("officertype");

		if (officertype != null) {
			setOfficertype(officertype);
		}

		String office = (String)attributes.get("office");

		if (office != null) {
			setOffice(office);
		}

		String Officerpower = (String)attributes.get("Officerpower");

		if (Officerpower != null) {
			setOfficerpower(Officerpower);
		}

		String Date = (String)attributes.get("Date");

		if (Date != null) {
			setDate(Date);
		}

		Long officerphone = (Long)attributes.get("officerphone");

		if (officerphone != null) {
			setOfficerphone(officerphone);
		}

		String officerEmail = (String)attributes.get("officerEmail");

		if (officerEmail != null) {
			setOfficerEmail(officerEmail);
		}
	}

	/**
	* Returns the primary key of this officer detail.
	*
	* @return the primary key of this officer detail
	*/
	@Override
	public long getPrimaryKey() {
		return _officerDetail.getPrimaryKey();
	}

	/**
	* Sets the primary key of this officer detail.
	*
	* @param primaryKey the primary key of this officer detail
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_officerDetail.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the officerid of this officer detail.
	*
	* @return the officerid of this officer detail
	*/
	@Override
	public long getOfficerid() {
		return _officerDetail.getOfficerid();
	}

	/**
	* Sets the officerid of this officer detail.
	*
	* @param officerid the officerid of this officer detail
	*/
	@Override
	public void setOfficerid(long officerid) {
		_officerDetail.setOfficerid(officerid);
	}

	/**
	* Returns the officername of this officer detail.
	*
	* @return the officername of this officer detail
	*/
	@Override
	public java.lang.String getOfficername() {
		return _officerDetail.getOfficername();
	}

	/**
	* Sets the officername of this officer detail.
	*
	* @param officername the officername of this officer detail
	*/
	@Override
	public void setOfficername(java.lang.String officername) {
		_officerDetail.setOfficername(officername);
	}

	/**
	* Returns the officertype of this officer detail.
	*
	* @return the officertype of this officer detail
	*/
	@Override
	public java.lang.String getOfficertype() {
		return _officerDetail.getOfficertype();
	}

	/**
	* Sets the officertype of this officer detail.
	*
	* @param officertype the officertype of this officer detail
	*/
	@Override
	public void setOfficertype(java.lang.String officertype) {
		_officerDetail.setOfficertype(officertype);
	}

	/**
	* Returns the office of this officer detail.
	*
	* @return the office of this officer detail
	*/
	@Override
	public java.lang.String getOffice() {
		return _officerDetail.getOffice();
	}

	/**
	* Sets the office of this officer detail.
	*
	* @param office the office of this officer detail
	*/
	@Override
	public void setOffice(java.lang.String office) {
		_officerDetail.setOffice(office);
	}

	/**
	* Returns the officerpower of this officer detail.
	*
	* @return the officerpower of this officer detail
	*/
	@Override
	public java.lang.String getOfficerpower() {
		return _officerDetail.getOfficerpower();
	}

	/**
	* Sets the officerpower of this officer detail.
	*
	* @param Officerpower the officerpower of this officer detail
	*/
	@Override
	public void setOfficerpower(java.lang.String Officerpower) {
		_officerDetail.setOfficerpower(Officerpower);
	}

	/**
	* Returns the date of this officer detail.
	*
	* @return the date of this officer detail
	*/
	@Override
	public java.lang.String getDate() {
		return _officerDetail.getDate();
	}

	/**
	* Sets the date of this officer detail.
	*
	* @param Date the date of this officer detail
	*/
	@Override
	public void setDate(java.lang.String Date) {
		_officerDetail.setDate(Date);
	}

	/**
	* Returns the officerphone of this officer detail.
	*
	* @return the officerphone of this officer detail
	*/
	@Override
	public long getOfficerphone() {
		return _officerDetail.getOfficerphone();
	}

	/**
	* Sets the officerphone of this officer detail.
	*
	* @param officerphone the officerphone of this officer detail
	*/
	@Override
	public void setOfficerphone(long officerphone) {
		_officerDetail.setOfficerphone(officerphone);
	}

	/**
	* Returns the officer email of this officer detail.
	*
	* @return the officer email of this officer detail
	*/
	@Override
	public java.lang.String getOfficerEmail() {
		return _officerDetail.getOfficerEmail();
	}

	/**
	* Sets the officer email of this officer detail.
	*
	* @param officerEmail the officer email of this officer detail
	*/
	@Override
	public void setOfficerEmail(java.lang.String officerEmail) {
		_officerDetail.setOfficerEmail(officerEmail);
	}

	@Override
	public boolean isNew() {
		return _officerDetail.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_officerDetail.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _officerDetail.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_officerDetail.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _officerDetail.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _officerDetail.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_officerDetail.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _officerDetail.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_officerDetail.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_officerDetail.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_officerDetail.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new OfficerDetailWrapper((OfficerDetail)_officerDetail.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail) {
		return _officerDetail.compareTo(officerDetail);
	}

	@Override
	public int hashCode() {
		return _officerDetail.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.OfficerDetail> toCacheModel() {
		return _officerDetail.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.OfficerDetail toEscapedModel() {
		return new OfficerDetailWrapper(_officerDetail.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.OfficerDetail toUnescapedModel() {
		return new OfficerDetailWrapper(_officerDetail.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _officerDetail.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _officerDetail.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_officerDetail.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OfficerDetailWrapper)) {
			return false;
		}

		OfficerDetailWrapper officerDetailWrapper = (OfficerDetailWrapper)obj;

		if (Validator.equals(_officerDetail, officerDetailWrapper._officerDetail)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public OfficerDetail getWrappedOfficerDetail() {
		return _officerDetail;
	}

	@Override
	public OfficerDetail getWrappedModel() {
		return _officerDetail;
	}

	@Override
	public void resetOriginalValues() {
		_officerDetail.resetOriginalValues();
	}

	private OfficerDetail _officerDetail;
}