/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link BillInquery}.
 * </p>
 *
 * @author reeshu
 * @see BillInquery
 * @generated
 */
public class BillInqueryWrapper implements BillInquery,
	ModelWrapper<BillInquery> {
	public BillInqueryWrapper(BillInquery billInquery) {
		_billInquery = billInquery;
	}

	@Override
	public Class<?> getModelClass() {
		return BillInquery.class;
	}

	@Override
	public String getModelClassName() {
		return BillInquery.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("billinquery", getBillinquery());
		attributes.put("bilId", getBilId());
		attributes.put("complaintDate", getComplaintDate());
		attributes.put("referenceEffective", getReferenceEffective());
		attributes.put("source", getSource());
		attributes.put("vehiclesNo", getVehiclesNo());
		attributes.put("companyName", getCompanyName());
		attributes.put("offense", getOffense());
		attributes.put("virtue", getVirtue());
		attributes.put("filerating", getFilerating());
		attributes.put("caseStatus", getCaseStatus());
		attributes.put("nameofofficer", getNameofofficer());
		attributes.put("error", getError());
		attributes.put("errorType", getErrorType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long billinquery = (Long)attributes.get("billinquery");

		if (billinquery != null) {
			setBillinquery(billinquery);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String complaintDate = (String)attributes.get("complaintDate");

		if (complaintDate != null) {
			setComplaintDate(complaintDate);
		}

		String referenceEffective = (String)attributes.get("referenceEffective");

		if (referenceEffective != null) {
			setReferenceEffective(referenceEffective);
		}

		String source = (String)attributes.get("source");

		if (source != null) {
			setSource(source);
		}

		String vehiclesNo = (String)attributes.get("vehiclesNo");

		if (vehiclesNo != null) {
			setVehiclesNo(vehiclesNo);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String offense = (String)attributes.get("offense");

		if (offense != null) {
			setOffense(offense);
		}

		String virtue = (String)attributes.get("virtue");

		if (virtue != null) {
			setVirtue(virtue);
		}

		String filerating = (String)attributes.get("filerating");

		if (filerating != null) {
			setFilerating(filerating);
		}

		String caseStatus = (String)attributes.get("caseStatus");

		if (caseStatus != null) {
			setCaseStatus(caseStatus);
		}

		String nameofofficer = (String)attributes.get("nameofofficer");

		if (nameofofficer != null) {
			setNameofofficer(nameofofficer);
		}

		String error = (String)attributes.get("error");

		if (error != null) {
			setError(error);
		}

		String errorType = (String)attributes.get("errorType");

		if (errorType != null) {
			setErrorType(errorType);
		}
	}

	/**
	* Returns the primary key of this bill inquery.
	*
	* @return the primary key of this bill inquery
	*/
	@Override
	public long getPrimaryKey() {
		return _billInquery.getPrimaryKey();
	}

	/**
	* Sets the primary key of this bill inquery.
	*
	* @param primaryKey the primary key of this bill inquery
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_billInquery.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the billinquery of this bill inquery.
	*
	* @return the billinquery of this bill inquery
	*/
	@Override
	public long getBillinquery() {
		return _billInquery.getBillinquery();
	}

	/**
	* Sets the billinquery of this bill inquery.
	*
	* @param billinquery the billinquery of this bill inquery
	*/
	@Override
	public void setBillinquery(long billinquery) {
		_billInquery.setBillinquery(billinquery);
	}

	/**
	* Returns the bil ID of this bill inquery.
	*
	* @return the bil ID of this bill inquery
	*/
	@Override
	public long getBilId() {
		return _billInquery.getBilId();
	}

	/**
	* Sets the bil ID of this bill inquery.
	*
	* @param bilId the bil ID of this bill inquery
	*/
	@Override
	public void setBilId(long bilId) {
		_billInquery.setBilId(bilId);
	}

	/**
	* Returns the complaint date of this bill inquery.
	*
	* @return the complaint date of this bill inquery
	*/
	@Override
	public java.lang.String getComplaintDate() {
		return _billInquery.getComplaintDate();
	}

	/**
	* Sets the complaint date of this bill inquery.
	*
	* @param complaintDate the complaint date of this bill inquery
	*/
	@Override
	public void setComplaintDate(java.lang.String complaintDate) {
		_billInquery.setComplaintDate(complaintDate);
	}

	/**
	* Returns the reference effective of this bill inquery.
	*
	* @return the reference effective of this bill inquery
	*/
	@Override
	public java.lang.String getReferenceEffective() {
		return _billInquery.getReferenceEffective();
	}

	/**
	* Sets the reference effective of this bill inquery.
	*
	* @param referenceEffective the reference effective of this bill inquery
	*/
	@Override
	public void setReferenceEffective(java.lang.String referenceEffective) {
		_billInquery.setReferenceEffective(referenceEffective);
	}

	/**
	* Returns the source of this bill inquery.
	*
	* @return the source of this bill inquery
	*/
	@Override
	public java.lang.String getSource() {
		return _billInquery.getSource();
	}

	/**
	* Sets the source of this bill inquery.
	*
	* @param source the source of this bill inquery
	*/
	@Override
	public void setSource(java.lang.String source) {
		_billInquery.setSource(source);
	}

	/**
	* Returns the vehicles no of this bill inquery.
	*
	* @return the vehicles no of this bill inquery
	*/
	@Override
	public java.lang.String getVehiclesNo() {
		return _billInquery.getVehiclesNo();
	}

	/**
	* Sets the vehicles no of this bill inquery.
	*
	* @param vehiclesNo the vehicles no of this bill inquery
	*/
	@Override
	public void setVehiclesNo(java.lang.String vehiclesNo) {
		_billInquery.setVehiclesNo(vehiclesNo);
	}

	/**
	* Returns the company name of this bill inquery.
	*
	* @return the company name of this bill inquery
	*/
	@Override
	public java.lang.String getCompanyName() {
		return _billInquery.getCompanyName();
	}

	/**
	* Sets the company name of this bill inquery.
	*
	* @param companyName the company name of this bill inquery
	*/
	@Override
	public void setCompanyName(java.lang.String companyName) {
		_billInquery.setCompanyName(companyName);
	}

	/**
	* Returns the offense of this bill inquery.
	*
	* @return the offense of this bill inquery
	*/
	@Override
	public java.lang.String getOffense() {
		return _billInquery.getOffense();
	}

	/**
	* Sets the offense of this bill inquery.
	*
	* @param offense the offense of this bill inquery
	*/
	@Override
	public void setOffense(java.lang.String offense) {
		_billInquery.setOffense(offense);
	}

	/**
	* Returns the virtue of this bill inquery.
	*
	* @return the virtue of this bill inquery
	*/
	@Override
	public java.lang.String getVirtue() {
		return _billInquery.getVirtue();
	}

	/**
	* Sets the virtue of this bill inquery.
	*
	* @param virtue the virtue of this bill inquery
	*/
	@Override
	public void setVirtue(java.lang.String virtue) {
		_billInquery.setVirtue(virtue);
	}

	/**
	* Returns the filerating of this bill inquery.
	*
	* @return the filerating of this bill inquery
	*/
	@Override
	public java.lang.String getFilerating() {
		return _billInquery.getFilerating();
	}

	/**
	* Sets the filerating of this bill inquery.
	*
	* @param filerating the filerating of this bill inquery
	*/
	@Override
	public void setFilerating(java.lang.String filerating) {
		_billInquery.setFilerating(filerating);
	}

	/**
	* Returns the case status of this bill inquery.
	*
	* @return the case status of this bill inquery
	*/
	@Override
	public java.lang.String getCaseStatus() {
		return _billInquery.getCaseStatus();
	}

	/**
	* Sets the case status of this bill inquery.
	*
	* @param caseStatus the case status of this bill inquery
	*/
	@Override
	public void setCaseStatus(java.lang.String caseStatus) {
		_billInquery.setCaseStatus(caseStatus);
	}

	/**
	* Returns the nameofofficer of this bill inquery.
	*
	* @return the nameofofficer of this bill inquery
	*/
	@Override
	public java.lang.String getNameofofficer() {
		return _billInquery.getNameofofficer();
	}

	/**
	* Sets the nameofofficer of this bill inquery.
	*
	* @param nameofofficer the nameofofficer of this bill inquery
	*/
	@Override
	public void setNameofofficer(java.lang.String nameofofficer) {
		_billInquery.setNameofofficer(nameofofficer);
	}

	/**
	* Returns the error of this bill inquery.
	*
	* @return the error of this bill inquery
	*/
	@Override
	public java.lang.String getError() {
		return _billInquery.getError();
	}

	/**
	* Sets the error of this bill inquery.
	*
	* @param error the error of this bill inquery
	*/
	@Override
	public void setError(java.lang.String error) {
		_billInquery.setError(error);
	}

	/**
	* Returns the error type of this bill inquery.
	*
	* @return the error type of this bill inquery
	*/
	@Override
	public java.lang.String getErrorType() {
		return _billInquery.getErrorType();
	}

	/**
	* Sets the error type of this bill inquery.
	*
	* @param errorType the error type of this bill inquery
	*/
	@Override
	public void setErrorType(java.lang.String errorType) {
		_billInquery.setErrorType(errorType);
	}

	@Override
	public boolean isNew() {
		return _billInquery.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_billInquery.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _billInquery.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_billInquery.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _billInquery.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _billInquery.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_billInquery.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _billInquery.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_billInquery.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_billInquery.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_billInquery.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new BillInqueryWrapper((BillInquery)_billInquery.clone());
	}

	@Override
	public int compareTo(com.org.skali.sitanAdmin.model.BillInquery billInquery) {
		return _billInquery.compareTo(billInquery);
	}

	@Override
	public int hashCode() {
		return _billInquery.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.BillInquery> toCacheModel() {
		return _billInquery.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.BillInquery toEscapedModel() {
		return new BillInqueryWrapper(_billInquery.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.BillInquery toUnescapedModel() {
		return new BillInqueryWrapper(_billInquery.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _billInquery.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _billInquery.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_billInquery.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BillInqueryWrapper)) {
			return false;
		}

		BillInqueryWrapper billInqueryWrapper = (BillInqueryWrapper)obj;

		if (Validator.equals(_billInquery, billInqueryWrapper._billInquery)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public BillInquery getWrappedBillInquery() {
		return _billInquery;
	}

	@Override
	public BillInquery getWrappedModel() {
		return _billInquery;
	}

	@Override
	public void resetOriginalValues() {
		_billInquery.resetOriginalValues();
	}

	private BillInquery _billInquery;
}