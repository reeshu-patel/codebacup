/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.ActionSummeryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class ActionSummeryClp extends BaseModelImpl<ActionSummery>
	implements ActionSummery {
	public ActionSummeryClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return ActionSummery.class;
	}

	@Override
	public String getModelClassName() {
		return ActionSummery.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _actionsummeryid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setActionsummeryid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _actionsummeryid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("actionsummeryid", getActionsummeryid());
		attributes.put("bilId", getBilId());
		attributes.put("dateTime", getDateTime());
		attributes.put("status", getStatus());
		attributes.put("action", getAction());
		attributes.put("actionBy", getActionBy());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long actionsummeryid = (Long)attributes.get("actionsummeryid");

		if (actionsummeryid != null) {
			setActionsummeryid(actionsummeryid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String dateTime = (String)attributes.get("dateTime");

		if (dateTime != null) {
			setDateTime(dateTime);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String action = (String)attributes.get("action");

		if (action != null) {
			setAction(action);
		}

		String actionBy = (String)attributes.get("actionBy");

		if (actionBy != null) {
			setActionBy(actionBy);
		}
	}

	@Override
	public long getActionsummeryid() {
		return _actionsummeryid;
	}

	@Override
	public void setActionsummeryid(long actionsummeryid) {
		_actionsummeryid = actionsummeryid;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setActionsummeryid", long.class);

				method.invoke(_actionSummeryRemoteModel, actionsummeryid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_actionSummeryRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDateTime() {
		return _dateTime;
	}

	@Override
	public void setDateTime(String dateTime) {
		_dateTime = dateTime;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setDateTime", String.class);

				method.invoke(_actionSummeryRemoteModel, dateTime);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_actionSummeryRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAction() {
		return _action;
	}

	@Override
	public void setAction(String action) {
		_action = action;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setAction", String.class);

				method.invoke(_actionSummeryRemoteModel, action);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getActionBy() {
		return _actionBy;
	}

	@Override
	public void setActionBy(String actionBy) {
		_actionBy = actionBy;

		if (_actionSummeryRemoteModel != null) {
			try {
				Class<?> clazz = _actionSummeryRemoteModel.getClass();

				Method method = clazz.getMethod("setActionBy", String.class);

				method.invoke(_actionSummeryRemoteModel, actionBy);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getActionSummeryRemoteModel() {
		return _actionSummeryRemoteModel;
	}

	public void setActionSummeryRemoteModel(
		BaseModel<?> actionSummeryRemoteModel) {
		_actionSummeryRemoteModel = actionSummeryRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _actionSummeryRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_actionSummeryRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			ActionSummeryLocalServiceUtil.addActionSummery(this);
		}
		else {
			ActionSummeryLocalServiceUtil.updateActionSummery(this);
		}
	}

	@Override
	public ActionSummery toEscapedModel() {
		return (ActionSummery)ProxyUtil.newProxyInstance(ActionSummery.class.getClassLoader(),
			new Class[] { ActionSummery.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		ActionSummeryClp clone = new ActionSummeryClp();

		clone.setActionsummeryid(getActionsummeryid());
		clone.setBilId(getBilId());
		clone.setDateTime(getDateTime());
		clone.setStatus(getStatus());
		clone.setAction(getAction());
		clone.setActionBy(getActionBy());

		return clone;
	}

	@Override
	public int compareTo(ActionSummery actionSummery) {
		long primaryKey = actionSummery.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ActionSummeryClp)) {
			return false;
		}

		ActionSummeryClp actionSummery = (ActionSummeryClp)obj;

		long primaryKey = actionSummery.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{actionsummeryid=");
		sb.append(getActionsummeryid());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", dateTime=");
		sb.append(getDateTime());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", action=");
		sb.append(getAction());
		sb.append(", actionBy=");
		sb.append(getActionBy());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.ActionSummery");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>actionsummeryid</column-name><column-value><![CDATA[");
		sb.append(getActionsummeryid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>dateTime</column-name><column-value><![CDATA[");
		sb.append(getDateTime());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>action</column-name><column-value><![CDATA[");
		sb.append(getAction());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>actionBy</column-name><column-value><![CDATA[");
		sb.append(getActionBy());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _actionsummeryid;
	private long _bilId;
	private String _dateTime;
	private String _status;
	private String _action;
	private String _actionBy;
	private BaseModel<?> _actionSummeryRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}