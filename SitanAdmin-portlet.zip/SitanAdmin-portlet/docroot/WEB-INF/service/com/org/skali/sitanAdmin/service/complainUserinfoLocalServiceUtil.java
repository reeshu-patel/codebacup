/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for complainUserinfo. This utility wraps
 * {@link com.org.skali.sitanAdmin.service.impl.complainUserinfoLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author reeshu
 * @see complainUserinfoLocalService
 * @see com.org.skali.sitanAdmin.service.base.complainUserinfoLocalServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.impl.complainUserinfoLocalServiceImpl
 * @generated
 */
public class complainUserinfoLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.org.skali.sitanAdmin.service.impl.complainUserinfoLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the complain userinfo to the database. Also notifies the appropriate model listeners.
	*
	* @param complainUserinfo the complain userinfo
	* @return the complain userinfo that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo addcomplainUserinfo(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addcomplainUserinfo(complainUserinfo);
	}

	/**
	* Creates a new complain userinfo with the primary key. Does not add the complain userinfo to the database.
	*
	* @param complainUserId the primary key for the new complain userinfo
	* @return the new complain userinfo
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo createcomplainUserinfo(
		long complainUserId) {
		return getService().createcomplainUserinfo(complainUserId);
	}

	/**
	* Deletes the complain userinfo with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param complainUserId the primary key of the complain userinfo
	* @return the complain userinfo that was removed
	* @throws PortalException if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo deletecomplainUserinfo(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deletecomplainUserinfo(complainUserId);
	}

	/**
	* Deletes the complain userinfo from the database. Also notifies the appropriate model listeners.
	*
	* @param complainUserinfo the complain userinfo
	* @return the complain userinfo that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo deletecomplainUserinfo(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deletecomplainUserinfo(complainUserinfo);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.org.skali.sitanAdmin.model.complainUserinfo fetchcomplainUserinfo(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchcomplainUserinfo(complainUserId);
	}

	/**
	* Returns the complain userinfo with the primary key.
	*
	* @param complainUserId the primary key of the complain userinfo
	* @return the complain userinfo
	* @throws PortalException if a complain userinfo with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo getcomplainUserinfo(
		long complainUserId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getcomplainUserinfo(complainUserId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the complain userinfos.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.complainUserinfoModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of complain userinfos
	* @param end the upper bound of the range of complain userinfos (not inclusive)
	* @return the range of complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> getcomplainUserinfos(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getcomplainUserinfos(start, end);
	}

	/**
	* Returns the number of complain userinfos.
	*
	* @return the number of complain userinfos
	* @throws SystemException if a system exception occurred
	*/
	public static int getcomplainUserinfosCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getcomplainUserinfosCount();
	}

	/**
	* Updates the complain userinfo in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param complainUserinfo the complain userinfo
	* @return the complain userinfo that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.org.skali.sitanAdmin.model.complainUserinfo updatecomplainUserinfo(
		com.org.skali.sitanAdmin.model.complainUserinfo complainUserinfo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updatecomplainUserinfo(complainUserinfo);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.org.skali.sitanAdmin.model.complainUserinfo> getsByBillId(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getsByBillId(bilId);
	}

	public static void clearService() {
		_service = null;
	}

	public static complainUserinfoLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					complainUserinfoLocalService.class.getName());

			if (invokableLocalService instanceof complainUserinfoLocalService) {
				_service = (complainUserinfoLocalService)invokableLocalService;
			}
			else {
				_service = new complainUserinfoLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(complainUserinfoLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(complainUserinfoLocalService service) {
	}

	private static complainUserinfoLocalService _service;
}