/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.org.skali.sitanAdmin.service.BillInqueryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author reeshu
 */
public class BillInqueryClp extends BaseModelImpl<BillInquery>
	implements BillInquery {
	public BillInqueryClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return BillInquery.class;
	}

	@Override
	public String getModelClassName() {
		return BillInquery.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _billinquery;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setBillinquery(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _billinquery;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("billinquery", getBillinquery());
		attributes.put("bilId", getBilId());
		attributes.put("complaintDate", getComplaintDate());
		attributes.put("referenceEffective", getReferenceEffective());
		attributes.put("source", getSource());
		attributes.put("vehiclesNo", getVehiclesNo());
		attributes.put("companyName", getCompanyName());
		attributes.put("offense", getOffense());
		attributes.put("virtue", getVirtue());
		attributes.put("filerating", getFilerating());
		attributes.put("caseStatus", getCaseStatus());
		attributes.put("nameofofficer", getNameofofficer());
		attributes.put("error", getError());
		attributes.put("errorType", getErrorType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long billinquery = (Long)attributes.get("billinquery");

		if (billinquery != null) {
			setBillinquery(billinquery);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String complaintDate = (String)attributes.get("complaintDate");

		if (complaintDate != null) {
			setComplaintDate(complaintDate);
		}

		String referenceEffective = (String)attributes.get("referenceEffective");

		if (referenceEffective != null) {
			setReferenceEffective(referenceEffective);
		}

		String source = (String)attributes.get("source");

		if (source != null) {
			setSource(source);
		}

		String vehiclesNo = (String)attributes.get("vehiclesNo");

		if (vehiclesNo != null) {
			setVehiclesNo(vehiclesNo);
		}

		String companyName = (String)attributes.get("companyName");

		if (companyName != null) {
			setCompanyName(companyName);
		}

		String offense = (String)attributes.get("offense");

		if (offense != null) {
			setOffense(offense);
		}

		String virtue = (String)attributes.get("virtue");

		if (virtue != null) {
			setVirtue(virtue);
		}

		String filerating = (String)attributes.get("filerating");

		if (filerating != null) {
			setFilerating(filerating);
		}

		String caseStatus = (String)attributes.get("caseStatus");

		if (caseStatus != null) {
			setCaseStatus(caseStatus);
		}

		String nameofofficer = (String)attributes.get("nameofofficer");

		if (nameofofficer != null) {
			setNameofofficer(nameofofficer);
		}

		String error = (String)attributes.get("error");

		if (error != null) {
			setError(error);
		}

		String errorType = (String)attributes.get("errorType");

		if (errorType != null) {
			setErrorType(errorType);
		}
	}

	@Override
	public long getBillinquery() {
		return _billinquery;
	}

	@Override
	public void setBillinquery(long billinquery) {
		_billinquery = billinquery;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setBillinquery", long.class);

				method.invoke(_billInqueryRemoteModel, billinquery);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getBilId() {
		return _bilId;
	}

	@Override
	public void setBilId(long bilId) {
		_bilId = bilId;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setBilId", long.class);

				method.invoke(_billInqueryRemoteModel, bilId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getComplaintDate() {
		return _complaintDate;
	}

	@Override
	public void setComplaintDate(String complaintDate) {
		_complaintDate = complaintDate;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setComplaintDate", String.class);

				method.invoke(_billInqueryRemoteModel, complaintDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getReferenceEffective() {
		return _referenceEffective;
	}

	@Override
	public void setReferenceEffective(String referenceEffective) {
		_referenceEffective = referenceEffective;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setReferenceEffective",
						String.class);

				method.invoke(_billInqueryRemoteModel, referenceEffective);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSource() {
		return _source;
	}

	@Override
	public void setSource(String source) {
		_source = source;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setSource", String.class);

				method.invoke(_billInqueryRemoteModel, source);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVehiclesNo() {
		return _vehiclesNo;
	}

	@Override
	public void setVehiclesNo(String vehiclesNo) {
		_vehiclesNo = vehiclesNo;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setVehiclesNo", String.class);

				method.invoke(_billInqueryRemoteModel, vehiclesNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCompanyName() {
		return _companyName;
	}

	@Override
	public void setCompanyName(String companyName) {
		_companyName = companyName;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyName", String.class);

				method.invoke(_billInqueryRemoteModel, companyName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOffense() {
		return _offense;
	}

	@Override
	public void setOffense(String offense) {
		_offense = offense;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setOffense", String.class);

				method.invoke(_billInqueryRemoteModel, offense);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVirtue() {
		return _virtue;
	}

	@Override
	public void setVirtue(String virtue) {
		_virtue = virtue;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setVirtue", String.class);

				method.invoke(_billInqueryRemoteModel, virtue);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFilerating() {
		return _filerating;
	}

	@Override
	public void setFilerating(String filerating) {
		_filerating = filerating;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setFilerating", String.class);

				method.invoke(_billInqueryRemoteModel, filerating);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCaseStatus() {
		return _caseStatus;
	}

	@Override
	public void setCaseStatus(String caseStatus) {
		_caseStatus = caseStatus;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setCaseStatus", String.class);

				method.invoke(_billInqueryRemoteModel, caseStatus);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameofofficer() {
		return _nameofofficer;
	}

	@Override
	public void setNameofofficer(String nameofofficer) {
		_nameofofficer = nameofofficer;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setNameofofficer", String.class);

				method.invoke(_billInqueryRemoteModel, nameofofficer);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getError() {
		return _error;
	}

	@Override
	public void setError(String error) {
		_error = error;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setError", String.class);

				method.invoke(_billInqueryRemoteModel, error);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getErrorType() {
		return _errorType;
	}

	@Override
	public void setErrorType(String errorType) {
		_errorType = errorType;

		if (_billInqueryRemoteModel != null) {
			try {
				Class<?> clazz = _billInqueryRemoteModel.getClass();

				Method method = clazz.getMethod("setErrorType", String.class);

				method.invoke(_billInqueryRemoteModel, errorType);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getBillInqueryRemoteModel() {
		return _billInqueryRemoteModel;
	}

	public void setBillInqueryRemoteModel(BaseModel<?> billInqueryRemoteModel) {
		_billInqueryRemoteModel = billInqueryRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _billInqueryRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_billInqueryRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			BillInqueryLocalServiceUtil.addBillInquery(this);
		}
		else {
			BillInqueryLocalServiceUtil.updateBillInquery(this);
		}
	}

	@Override
	public BillInquery toEscapedModel() {
		return (BillInquery)ProxyUtil.newProxyInstance(BillInquery.class.getClassLoader(),
			new Class[] { BillInquery.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		BillInqueryClp clone = new BillInqueryClp();

		clone.setBillinquery(getBillinquery());
		clone.setBilId(getBilId());
		clone.setComplaintDate(getComplaintDate());
		clone.setReferenceEffective(getReferenceEffective());
		clone.setSource(getSource());
		clone.setVehiclesNo(getVehiclesNo());
		clone.setCompanyName(getCompanyName());
		clone.setOffense(getOffense());
		clone.setVirtue(getVirtue());
		clone.setFilerating(getFilerating());
		clone.setCaseStatus(getCaseStatus());
		clone.setNameofofficer(getNameofofficer());
		clone.setError(getError());
		clone.setErrorType(getErrorType());

		return clone;
	}

	@Override
	public int compareTo(BillInquery billInquery) {
		long primaryKey = billInquery.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BillInqueryClp)) {
			return false;
		}

		BillInqueryClp billInquery = (BillInqueryClp)obj;

		long primaryKey = billInquery.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{billinquery=");
		sb.append(getBillinquery());
		sb.append(", bilId=");
		sb.append(getBilId());
		sb.append(", complaintDate=");
		sb.append(getComplaintDate());
		sb.append(", referenceEffective=");
		sb.append(getReferenceEffective());
		sb.append(", source=");
		sb.append(getSource());
		sb.append(", vehiclesNo=");
		sb.append(getVehiclesNo());
		sb.append(", companyName=");
		sb.append(getCompanyName());
		sb.append(", offense=");
		sb.append(getOffense());
		sb.append(", virtue=");
		sb.append(getVirtue());
		sb.append(", filerating=");
		sb.append(getFilerating());
		sb.append(", caseStatus=");
		sb.append(getCaseStatus());
		sb.append(", nameofofficer=");
		sb.append(getNameofofficer());
		sb.append(", error=");
		sb.append(getError());
		sb.append(", errorType=");
		sb.append(getErrorType());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(46);

		sb.append("<model><model-name>");
		sb.append("com.org.skali.sitanAdmin.model.BillInquery");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>billinquery</column-name><column-value><![CDATA[");
		sb.append(getBillinquery());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>bilId</column-name><column-value><![CDATA[");
		sb.append(getBilId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>complaintDate</column-name><column-value><![CDATA[");
		sb.append(getComplaintDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>referenceEffective</column-name><column-value><![CDATA[");
		sb.append(getReferenceEffective());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>source</column-name><column-value><![CDATA[");
		sb.append(getSource());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>vehiclesNo</column-name><column-value><![CDATA[");
		sb.append(getVehiclesNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyName</column-name><column-value><![CDATA[");
		sb.append(getCompanyName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>offense</column-name><column-value><![CDATA[");
		sb.append(getOffense());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>virtue</column-name><column-value><![CDATA[");
		sb.append(getVirtue());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>filerating</column-name><column-value><![CDATA[");
		sb.append(getFilerating());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>caseStatus</column-name><column-value><![CDATA[");
		sb.append(getCaseStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameofofficer</column-name><column-value><![CDATA[");
		sb.append(getNameofofficer());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>error</column-name><column-value><![CDATA[");
		sb.append(getError());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>errorType</column-name><column-value><![CDATA[");
		sb.append(getErrorType());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _billinquery;
	private long _bilId;
	private String _complaintDate;
	private String _referenceEffective;
	private String _source;
	private String _vehiclesNo;
	private String _companyName;
	private String _offense;
	private String _virtue;
	private String _filerating;
	private String _caseStatus;
	private String _nameofofficer;
	private String _error;
	private String _errorType;
	private BaseModel<?> _billInqueryRemoteModel;
	private Class<?> _clpSerializerClass = com.org.skali.sitanAdmin.service.ClpSerializer.class;
}