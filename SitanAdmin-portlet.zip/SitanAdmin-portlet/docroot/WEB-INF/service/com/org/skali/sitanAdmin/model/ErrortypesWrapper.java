/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Errortypes}.
 * </p>
 *
 * @author reeshu
 * @see Errortypes
 * @generated
 */
public class ErrortypesWrapper implements Errortypes, ModelWrapper<Errortypes> {
	public ErrortypesWrapper(Errortypes errortypes) {
		_errortypes = errortypes;
	}

	@Override
	public Class<?> getModelClass() {
		return Errortypes.class;
	}

	@Override
	public String getModelClassName() {
		return Errortypes.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("errortypeid", getErrortypeid());
		attributes.put("bilId", getBilId());
		attributes.put("errortypes", getErrortypes());
		attributes.put("sourcetypes", getSourcetypes());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long errortypeid = (Long)attributes.get("errortypeid");

		if (errortypeid != null) {
			setErrortypeid(errortypeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String errortypes = (String)attributes.get("errortypes");

		if (errortypes != null) {
			setErrortypes(errortypes);
		}

		String sourcetypes = (String)attributes.get("sourcetypes");

		if (sourcetypes != null) {
			setSourcetypes(sourcetypes);
		}
	}

	/**
	* Returns the primary key of this errortypes.
	*
	* @return the primary key of this errortypes
	*/
	@Override
	public long getPrimaryKey() {
		return _errortypes.getPrimaryKey();
	}

	/**
	* Sets the primary key of this errortypes.
	*
	* @param primaryKey the primary key of this errortypes
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_errortypes.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the errortypeid of this errortypes.
	*
	* @return the errortypeid of this errortypes
	*/
	@Override
	public long getErrortypeid() {
		return _errortypes.getErrortypeid();
	}

	/**
	* Sets the errortypeid of this errortypes.
	*
	* @param errortypeid the errortypeid of this errortypes
	*/
	@Override
	public void setErrortypeid(long errortypeid) {
		_errortypes.setErrortypeid(errortypeid);
	}

	/**
	* Returns the bil ID of this errortypes.
	*
	* @return the bil ID of this errortypes
	*/
	@Override
	public long getBilId() {
		return _errortypes.getBilId();
	}

	/**
	* Sets the bil ID of this errortypes.
	*
	* @param bilId the bil ID of this errortypes
	*/
	@Override
	public void setBilId(long bilId) {
		_errortypes.setBilId(bilId);
	}

	/**
	* Returns the errortypes of this errortypes.
	*
	* @return the errortypes of this errortypes
	*/
	@Override
	public java.lang.String getErrortypes() {
		return _errortypes.getErrortypes();
	}

	/**
	* Sets the errortypes of this errortypes.
	*
	* @param errortypes the errortypes of this errortypes
	*/
	@Override
	public void setErrortypes(java.lang.String errortypes) {
		_errortypes.setErrortypes(errortypes);
	}

	/**
	* Returns the sourcetypes of this errortypes.
	*
	* @return the sourcetypes of this errortypes
	*/
	@Override
	public java.lang.String getSourcetypes() {
		return _errortypes.getSourcetypes();
	}

	/**
	* Sets the sourcetypes of this errortypes.
	*
	* @param sourcetypes the sourcetypes of this errortypes
	*/
	@Override
	public void setSourcetypes(java.lang.String sourcetypes) {
		_errortypes.setSourcetypes(sourcetypes);
	}

	@Override
	public boolean isNew() {
		return _errortypes.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_errortypes.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _errortypes.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_errortypes.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _errortypes.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _errortypes.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_errortypes.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _errortypes.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_errortypes.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_errortypes.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_errortypes.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ErrortypesWrapper((Errortypes)_errortypes.clone());
	}

	@Override
	public int compareTo(Errortypes errortypes) {
		return _errortypes.compareTo(errortypes);
	}

	@Override
	public int hashCode() {
		return _errortypes.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<Errortypes> toCacheModel() {
		return _errortypes.toCacheModel();
	}

	@Override
	public Errortypes toEscapedModel() {
		return new ErrortypesWrapper(_errortypes.toEscapedModel());
	}

	@Override
	public Errortypes toUnescapedModel() {
		return new ErrortypesWrapper(_errortypes.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _errortypes.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _errortypes.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_errortypes.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ErrortypesWrapper)) {
			return false;
		}

		ErrortypesWrapper errortypesWrapper = (ErrortypesWrapper)obj;

		if (Validator.equals(_errortypes, errortypesWrapper._errortypes)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Errortypes getWrappedErrortypes() {
		return _errortypes;
	}

	@Override
	public Errortypes getWrappedModel() {
		return _errortypes;
	}

	@Override
	public void resetOriginalValues() {
		_errortypes.resetOriginalValues();
	}

	private Errortypes _errortypes;
}