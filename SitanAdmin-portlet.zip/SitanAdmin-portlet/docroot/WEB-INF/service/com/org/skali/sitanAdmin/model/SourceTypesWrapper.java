/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SourceTypes}.
 * </p>
 *
 * @author reeshu
 * @see SourceTypes
 * @generated
 */
public class SourceTypesWrapper implements SourceTypes,
	ModelWrapper<SourceTypes> {
	public SourceTypesWrapper(SourceTypes sourceTypes) {
		_sourceTypes = sourceTypes;
	}

	@Override
	public Class<?> getModelClass() {
		return SourceTypes.class;
	}

	@Override
	public String getModelClassName() {
		return SourceTypes.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("sourcetypeid", getSourcetypeid());
		attributes.put("bilId", getBilId());
		attributes.put("errortypes", getErrortypes());
		attributes.put("sourcetypes", getSourcetypes());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long sourcetypeid = (Long)attributes.get("sourcetypeid");

		if (sourcetypeid != null) {
			setSourcetypeid(sourcetypeid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String errortypes = (String)attributes.get("errortypes");

		if (errortypes != null) {
			setErrortypes(errortypes);
		}

		String sourcetypes = (String)attributes.get("sourcetypes");

		if (sourcetypes != null) {
			setSourcetypes(sourcetypes);
		}
	}

	/**
	* Returns the primary key of this source types.
	*
	* @return the primary key of this source types
	*/
	@Override
	public long getPrimaryKey() {
		return _sourceTypes.getPrimaryKey();
	}

	/**
	* Sets the primary key of this source types.
	*
	* @param primaryKey the primary key of this source types
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_sourceTypes.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the sourcetypeid of this source types.
	*
	* @return the sourcetypeid of this source types
	*/
	@Override
	public long getSourcetypeid() {
		return _sourceTypes.getSourcetypeid();
	}

	/**
	* Sets the sourcetypeid of this source types.
	*
	* @param sourcetypeid the sourcetypeid of this source types
	*/
	@Override
	public void setSourcetypeid(long sourcetypeid) {
		_sourceTypes.setSourcetypeid(sourcetypeid);
	}

	/**
	* Returns the bil ID of this source types.
	*
	* @return the bil ID of this source types
	*/
	@Override
	public long getBilId() {
		return _sourceTypes.getBilId();
	}

	/**
	* Sets the bil ID of this source types.
	*
	* @param bilId the bil ID of this source types
	*/
	@Override
	public void setBilId(long bilId) {
		_sourceTypes.setBilId(bilId);
	}

	/**
	* Returns the errortypes of this source types.
	*
	* @return the errortypes of this source types
	*/
	@Override
	public java.lang.String getErrortypes() {
		return _sourceTypes.getErrortypes();
	}

	/**
	* Sets the errortypes of this source types.
	*
	* @param errortypes the errortypes of this source types
	*/
	@Override
	public void setErrortypes(java.lang.String errortypes) {
		_sourceTypes.setErrortypes(errortypes);
	}

	/**
	* Returns the sourcetypes of this source types.
	*
	* @return the sourcetypes of this source types
	*/
	@Override
	public java.lang.String getSourcetypes() {
		return _sourceTypes.getSourcetypes();
	}

	/**
	* Sets the sourcetypes of this source types.
	*
	* @param sourcetypes the sourcetypes of this source types
	*/
	@Override
	public void setSourcetypes(java.lang.String sourcetypes) {
		_sourceTypes.setSourcetypes(sourcetypes);
	}

	@Override
	public boolean isNew() {
		return _sourceTypes.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_sourceTypes.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _sourceTypes.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_sourceTypes.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _sourceTypes.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _sourceTypes.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_sourceTypes.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _sourceTypes.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_sourceTypes.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_sourceTypes.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_sourceTypes.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SourceTypesWrapper((SourceTypes)_sourceTypes.clone());
	}

	@Override
	public int compareTo(com.org.skali.sitanAdmin.model.SourceTypes sourceTypes) {
		return _sourceTypes.compareTo(sourceTypes);
	}

	@Override
	public int hashCode() {
		return _sourceTypes.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.SourceTypes> toCacheModel() {
		return _sourceTypes.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.SourceTypes toEscapedModel() {
		return new SourceTypesWrapper(_sourceTypes.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.SourceTypes toUnescapedModel() {
		return new SourceTypesWrapper(_sourceTypes.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _sourceTypes.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _sourceTypes.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_sourceTypes.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SourceTypesWrapper)) {
			return false;
		}

		SourceTypesWrapper sourceTypesWrapper = (SourceTypesWrapper)obj;

		if (Validator.equals(_sourceTypes, sourceTypesWrapper._sourceTypes)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public SourceTypes getWrappedSourceTypes() {
		return _sourceTypes;
	}

	@Override
	public SourceTypes getWrappedModel() {
		return _sourceTypes;
	}

	@Override
	public void resetOriginalValues() {
		_sourceTypes.resetOriginalValues();
	}

	private SourceTypes _sourceTypes;
}