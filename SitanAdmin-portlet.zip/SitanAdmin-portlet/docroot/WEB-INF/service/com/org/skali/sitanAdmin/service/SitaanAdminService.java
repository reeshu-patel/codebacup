/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.jsonwebservice.JSONWebService;
import com.liferay.portal.kernel.transaction.Isolation;
import com.liferay.portal.kernel.transaction.Transactional;
import com.liferay.portal.security.ac.AccessControlled;
import com.liferay.portal.service.BaseService;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service interface for SitaanAdmin. Methods of this
 * service are expected to have security checks based on the propagated JAAS
 * credentials because this service can be accessed remotely.
 *
 * @author reeshu
 * @see SitaanAdminServiceUtil
 * @see com.org.skali.sitanAdmin.service.base.SitaanAdminServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.impl.SitaanAdminServiceImpl
 * @generated
 */
@AccessControlled
@JSONWebService
@Transactional(isolation = Isolation.PORTAL, rollbackFor =  {
	PortalException.class, SystemException.class})
public interface SitaanAdminService extends BaseService, InvokableService {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link SitaanAdminServiceUtil} to access the sitaan admin remote service. Add custom service methods to {@link com.org.skali.sitanAdmin.service.impl.SitaanAdminServiceImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
	 */

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public java.lang.String getBeanIdentifier();

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public void setBeanIdentifier(java.lang.String beanIdentifier);

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "SitaAdmin_DashBoard_Search", method = "POST")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject FinedByColumn(
		java.lang.String dateSeized, java.lang.String checkSitesSita,
		java.lang.String source, java.lang.String ownerName,
		java.lang.String territory, java.lang.String state,
		java.lang.String vehicleRegistrationNo,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String locationCageSita,
		java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String action, java.lang.String paymentStatus)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "New_Case_Information_BillId", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject FinedByBillId(long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Cmd_User_List", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public java.util.List<com.liferay.portal.model.User> geCMDUsers()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "End_Action_Case_Informarmation_BillId", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject ActionCaseByBillId(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Upload_Document_Search", method = "PUT")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject UploadDocumentSearch(
		java.lang.String title)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Upload_Document", method = "POST")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public void Upload_Document(java.io.File file, java.lang.String fileName)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Document_Binding_Tree", method = "PUT")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONArray Document_Binding_Tree()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Officer_List", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject Officer_List()
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Visual_Inspection_Get", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject VisualInspection(
		long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Visual_Inspection_POST", method = "POST")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.org.skali.sitanAdmin.model.visualchecklist VisualInspectionPost(
		long checkId, long bilId, java.lang.String numberplates,
		java.lang.String numberplatesNote, java.lang.String forwardlighting,
		java.lang.String forwardlightingNote, java.lang.String backlight,
		java.lang.String backlightNote, java.lang.String trafficLight,
		java.lang.String trafficLightNote, java.lang.String signallight,
		java.lang.String signallightNote, java.lang.String vehiclebody,
		java.lang.String vehiclebodyNote, java.lang.String vehicleAccessories,
		java.lang.String vehicleAccessoriesNote, java.lang.String windscreen,
		java.lang.String windscreenNote, java.lang.String rearMirror,
		java.lang.String rearMirrorNote, java.lang.String doormirror,
		java.lang.String doormirrorNote, java.lang.String vehicletires,
		java.lang.String vehicletiresNote, java.lang.String frontbumper,
		java.lang.String frontbumperNote, java.lang.String rearbumper,
		java.lang.String rearbumperNote, java.lang.String frontseat,
		java.lang.String frontseatNote, java.lang.String rearseats,
		java.lang.String rearseatsNote, java.lang.String note,
		java.lang.String investigatorname, java.lang.String investigatorEmail,
		java.lang.String investigatorphone)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "File_Visual_Inspection_Get", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject SaveVisualInspection(
		long bilId, long checkId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Multiple_Upload_Document", method = "POST")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public void Multiple_Upload_Document(java.io.File[] file)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "Acceptanece_Vehical_Detail_POST", method = "POST")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail AcceptaneceVehicalDetail(
		long vehicalid, long bilId, java.lang.String vehiNumberPlate,
		java.lang.String ownerName, java.lang.String companyRepresentative,
		java.lang.String kpNo, java.lang.String chronicle,
		java.lang.String Signature, java.lang.String accodocument,
		java.lang.String cardIdentity, java.lang.String drivingLicense,
		java.lang.String grantVehicle, java.lang.String attorney,
		java.lang.String numberPlateDetail)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;

	@com.liferay.portal.kernel.jsonwebservice.JSONWebService(value = "File_Acceptanece_Vehical_Detail_Get", method = "GET")
	@com.liferay.portal.security.ac.AccessControlled(guestAccessEnabled = true)
	public com.liferay.portal.kernel.json.JSONObject FileAcceptaneceVehicalDetail(
		long vehicalid, long bilId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.io.IOException;
}