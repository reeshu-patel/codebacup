/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.org.skali.sitanAdmin.service.http.visualchecklistServiceSoap}.
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.http.visualchecklistServiceSoap
 * @generated
 */
public class visualchecklistSoap implements Serializable {
	public static visualchecklistSoap toSoapModel(visualchecklist model) {
		visualchecklistSoap soapModel = new visualchecklistSoap();

		soapModel.setCheckId(model.getCheckId());
		soapModel.setBilId(model.getBilId());
		soapModel.setNumberplates(model.getNumberplates());
		soapModel.setNumberplatesNote(model.getNumberplatesNote());
		soapModel.setForwardlighting(model.getForwardlighting());
		soapModel.setForwardlightingNote(model.getForwardlightingNote());
		soapModel.setBacklight(model.getBacklight());
		soapModel.setBacklightNote(model.getBacklightNote());
		soapModel.setTrafficLight(model.getTrafficLight());
		soapModel.setTrafficLightNote(model.getTrafficLightNote());
		soapModel.setSignallight(model.getSignallight());
		soapModel.setSignallightNote(model.getSignallightNote());
		soapModel.setVehiclebody(model.getVehiclebody());
		soapModel.setVehiclebodyNote(model.getVehiclebodyNote());
		soapModel.setVehicleAccessories(model.getVehicleAccessories());
		soapModel.setVehicleAccessoriesNote(model.getVehicleAccessoriesNote());
		soapModel.setWindscreen(model.getWindscreen());
		soapModel.setWindscreenNote(model.getWindscreenNote());
		soapModel.setRearMirror(model.getRearMirror());
		soapModel.setRearMirrorNote(model.getRearMirrorNote());
		soapModel.setDoormirror(model.getDoormirror());
		soapModel.setDoormirrorNote(model.getDoormirrorNote());
		soapModel.setVehicletires(model.getVehicletires());
		soapModel.setVehicletiresNote(model.getVehicletiresNote());
		soapModel.setFrontbumper(model.getFrontbumper());
		soapModel.setFrontbumperNote(model.getFrontbumperNote());
		soapModel.setRearbumper(model.getRearbumper());
		soapModel.setRearbumperNote(model.getRearbumperNote());
		soapModel.setFrontseat(model.getFrontseat());
		soapModel.setFrontseatNote(model.getFrontseatNote());
		soapModel.setRearseats(model.getRearseats());
		soapModel.setRearseatsNote(model.getRearseatsNote());
		soapModel.setNote(model.getNote());
		soapModel.setVehicleRegistrationNo(model.getVehicleRegistrationNo());
		soapModel.setModel(model.getModel());
		soapModel.setColor(model.getColor());
		soapModel.setDateofVehicles(model.getDateofVehicles());
		soapModel.setInvestigatorname(model.getInvestigatorname());
		soapModel.setInvestigatorphone(model.getInvestigatorphone());
		soapModel.setInvestigatorEmail(model.getInvestigatorEmail());

		return soapModel;
	}

	public static visualchecklistSoap[] toSoapModels(visualchecklist[] models) {
		visualchecklistSoap[] soapModels = new visualchecklistSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static visualchecklistSoap[][] toSoapModels(
		visualchecklist[][] models) {
		visualchecklistSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new visualchecklistSoap[models.length][models[0].length];
		}
		else {
			soapModels = new visualchecklistSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static visualchecklistSoap[] toSoapModels(
		List<visualchecklist> models) {
		List<visualchecklistSoap> soapModels = new ArrayList<visualchecklistSoap>(models.size());

		for (visualchecklist model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new visualchecklistSoap[soapModels.size()]);
	}

	public visualchecklistSoap() {
	}

	public long getPrimaryKey() {
		return _checkId;
	}

	public void setPrimaryKey(long pk) {
		setCheckId(pk);
	}

	public long getCheckId() {
		return _checkId;
	}

	public void setCheckId(long checkId) {
		_checkId = checkId;
	}

	public long getBilId() {
		return _bilId;
	}

	public void setBilId(long bilId) {
		_bilId = bilId;
	}

	public String getNumberplates() {
		return _numberplates;
	}

	public void setNumberplates(String numberplates) {
		_numberplates = numberplates;
	}

	public String getNumberplatesNote() {
		return _numberplatesNote;
	}

	public void setNumberplatesNote(String numberplatesNote) {
		_numberplatesNote = numberplatesNote;
	}

	public String getForwardlighting() {
		return _forwardlighting;
	}

	public void setForwardlighting(String forwardlighting) {
		_forwardlighting = forwardlighting;
	}

	public String getForwardlightingNote() {
		return _forwardlightingNote;
	}

	public void setForwardlightingNote(String forwardlightingNote) {
		_forwardlightingNote = forwardlightingNote;
	}

	public String getBacklight() {
		return _backlight;
	}

	public void setBacklight(String backlight) {
		_backlight = backlight;
	}

	public String getBacklightNote() {
		return _backlightNote;
	}

	public void setBacklightNote(String backlightNote) {
		_backlightNote = backlightNote;
	}

	public String getTrafficLight() {
		return _trafficLight;
	}

	public void setTrafficLight(String trafficLight) {
		_trafficLight = trafficLight;
	}

	public String getTrafficLightNote() {
		return _trafficLightNote;
	}

	public void setTrafficLightNote(String trafficLightNote) {
		_trafficLightNote = trafficLightNote;
	}

	public String getSignallight() {
		return _signallight;
	}

	public void setSignallight(String signallight) {
		_signallight = signallight;
	}

	public String getSignallightNote() {
		return _signallightNote;
	}

	public void setSignallightNote(String signallightNote) {
		_signallightNote = signallightNote;
	}

	public String getVehiclebody() {
		return _vehiclebody;
	}

	public void setVehiclebody(String vehiclebody) {
		_vehiclebody = vehiclebody;
	}

	public String getVehiclebodyNote() {
		return _vehiclebodyNote;
	}

	public void setVehiclebodyNote(String vehiclebodyNote) {
		_vehiclebodyNote = vehiclebodyNote;
	}

	public String getVehicleAccessories() {
		return _vehicleAccessories;
	}

	public void setVehicleAccessories(String vehicleAccessories) {
		_vehicleAccessories = vehicleAccessories;
	}

	public String getVehicleAccessoriesNote() {
		return _vehicleAccessoriesNote;
	}

	public void setVehicleAccessoriesNote(String vehicleAccessoriesNote) {
		_vehicleAccessoriesNote = vehicleAccessoriesNote;
	}

	public String getWindscreen() {
		return _windscreen;
	}

	public void setWindscreen(String windscreen) {
		_windscreen = windscreen;
	}

	public String getWindscreenNote() {
		return _windscreenNote;
	}

	public void setWindscreenNote(String windscreenNote) {
		_windscreenNote = windscreenNote;
	}

	public String getRearMirror() {
		return _rearMirror;
	}

	public void setRearMirror(String rearMirror) {
		_rearMirror = rearMirror;
	}

	public String getRearMirrorNote() {
		return _rearMirrorNote;
	}

	public void setRearMirrorNote(String rearMirrorNote) {
		_rearMirrorNote = rearMirrorNote;
	}

	public String getDoormirror() {
		return _doormirror;
	}

	public void setDoormirror(String doormirror) {
		_doormirror = doormirror;
	}

	public String getDoormirrorNote() {
		return _doormirrorNote;
	}

	public void setDoormirrorNote(String doormirrorNote) {
		_doormirrorNote = doormirrorNote;
	}

	public String getVehicletires() {
		return _vehicletires;
	}

	public void setVehicletires(String vehicletires) {
		_vehicletires = vehicletires;
	}

	public String getVehicletiresNote() {
		return _vehicletiresNote;
	}

	public void setVehicletiresNote(String vehicletiresNote) {
		_vehicletiresNote = vehicletiresNote;
	}

	public String getFrontbumper() {
		return _frontbumper;
	}

	public void setFrontbumper(String frontbumper) {
		_frontbumper = frontbumper;
	}

	public String getFrontbumperNote() {
		return _frontbumperNote;
	}

	public void setFrontbumperNote(String frontbumperNote) {
		_frontbumperNote = frontbumperNote;
	}

	public String getRearbumper() {
		return _rearbumper;
	}

	public void setRearbumper(String rearbumper) {
		_rearbumper = rearbumper;
	}

	public String getRearbumperNote() {
		return _rearbumperNote;
	}

	public void setRearbumperNote(String rearbumperNote) {
		_rearbumperNote = rearbumperNote;
	}

	public String getFrontseat() {
		return _frontseat;
	}

	public void setFrontseat(String frontseat) {
		_frontseat = frontseat;
	}

	public String getFrontseatNote() {
		return _frontseatNote;
	}

	public void setFrontseatNote(String frontseatNote) {
		_frontseatNote = frontseatNote;
	}

	public String getRearseats() {
		return _rearseats;
	}

	public void setRearseats(String rearseats) {
		_rearseats = rearseats;
	}

	public String getRearseatsNote() {
		return _rearseatsNote;
	}

	public void setRearseatsNote(String rearseatsNote) {
		_rearseatsNote = rearseatsNote;
	}

	public String getNote() {
		return _note;
	}

	public void setNote(String note) {
		_note = note;
	}

	public String getVehicleRegistrationNo() {
		return _vehicleRegistrationNo;
	}

	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		_vehicleRegistrationNo = vehicleRegistrationNo;
	}

	public String getModel() {
		return _model;
	}

	public void setModel(String model) {
		_model = model;
	}

	public String getColor() {
		return _color;
	}

	public void setColor(String color) {
		_color = color;
	}

	public String getDateofVehicles() {
		return _dateofVehicles;
	}

	public void setDateofVehicles(String dateofVehicles) {
		_dateofVehicles = dateofVehicles;
	}

	public String getInvestigatorname() {
		return _investigatorname;
	}

	public void setInvestigatorname(String investigatorname) {
		_investigatorname = investigatorname;
	}

	public String getInvestigatorphone() {
		return _investigatorphone;
	}

	public void setInvestigatorphone(String investigatorphone) {
		_investigatorphone = investigatorphone;
	}

	public String getInvestigatorEmail() {
		return _investigatorEmail;
	}

	public void setInvestigatorEmail(String investigatorEmail) {
		_investigatorEmail = investigatorEmail;
	}

	private long _checkId;
	private long _bilId;
	private String _numberplates;
	private String _numberplatesNote;
	private String _forwardlighting;
	private String _forwardlightingNote;
	private String _backlight;
	private String _backlightNote;
	private String _trafficLight;
	private String _trafficLightNote;
	private String _signallight;
	private String _signallightNote;
	private String _vehiclebody;
	private String _vehiclebodyNote;
	private String _vehicleAccessories;
	private String _vehicleAccessoriesNote;
	private String _windscreen;
	private String _windscreenNote;
	private String _rearMirror;
	private String _rearMirrorNote;
	private String _doormirror;
	private String _doormirrorNote;
	private String _vehicletires;
	private String _vehicletiresNote;
	private String _frontbumper;
	private String _frontbumperNote;
	private String _rearbumper;
	private String _rearbumperNote;
	private String _frontseat;
	private String _frontseatNote;
	private String _rearseats;
	private String _rearseatsNote;
	private String _note;
	private String _vehicleRegistrationNo;
	private String _model;
	private String _color;
	private String _dateofVehicles;
	private String _investigatorname;
	private String _investigatorphone;
	private String _investigatorEmail;
}