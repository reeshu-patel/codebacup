/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.org.skali.sitanAdmin.model.Errortypes;

/**
 * The persistence interface for the errortypes service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see ErrortypesPersistenceImpl
 * @see ErrortypesUtil
 * @generated
 */
public interface ErrortypesPersistence extends BasePersistence<Errortypes> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link ErrortypesUtil} to access the errortypes persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the errortypeses where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the matching errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findBybilId(
		long bilId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the errortypeses where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of errortypeses
	* @param end the upper bound of the range of errortypeses (not inclusive)
	* @return the range of matching errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findBybilId(
		long bilId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the errortypeses where bilId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param bilId the bil ID
	* @param start the lower bound of the range of errortypeses
	* @param end the upper bound of the range of errortypeses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findBybilId(
		long bilId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first errortypes in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching errortypes
	* @throws com.org.skali.sitanAdmin.NoSuchErrortypesException if a matching errortypes could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes findBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchErrortypesException;

	/**
	* Returns the first errortypes in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching errortypes, or <code>null</code> if a matching errortypes could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes fetchBybilId_First(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last errortypes in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching errortypes
	* @throws com.org.skali.sitanAdmin.NoSuchErrortypesException if a matching errortypes could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes findBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchErrortypesException;

	/**
	* Returns the last errortypes in the ordered set where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching errortypes, or <code>null</code> if a matching errortypes could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes fetchBybilId_Last(
		long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the errortypeses before and after the current errortypes in the ordered set where bilId = &#63;.
	*
	* @param errortypeid the primary key of the current errortypes
	* @param bilId the bil ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next errortypes
	* @throws com.org.skali.sitanAdmin.NoSuchErrortypesException if a errortypes with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes[] findBybilId_PrevAndNext(
		long errortypeid, long bilId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchErrortypesException;

	/**
	* Removes all the errortypeses where bilId = &#63; from the database.
	*
	* @param bilId the bil ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of errortypeses where bilId = &#63;.
	*
	* @param bilId the bil ID
	* @return the number of matching errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public int countBybilId(long bilId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the errortypes in the entity cache if it is enabled.
	*
	* @param errortypes the errortypes
	*/
	public void cacheResult(
		com.org.skali.sitanAdmin.model.Errortypes errortypes);

	/**
	* Caches the errortypeses in the entity cache if it is enabled.
	*
	* @param errortypeses the errortypeses
	*/
	public void cacheResult(
		java.util.List<com.org.skali.sitanAdmin.model.Errortypes> errortypeses);

	/**
	* Creates a new errortypes with the primary key. Does not add the errortypes to the database.
	*
	* @param errortypeid the primary key for the new errortypes
	* @return the new errortypes
	*/
	public com.org.skali.sitanAdmin.model.Errortypes create(long errortypeid);

	/**
	* Removes the errortypes with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param errortypeid the primary key of the errortypes
	* @return the errortypes that was removed
	* @throws com.org.skali.sitanAdmin.NoSuchErrortypesException if a errortypes with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes remove(long errortypeid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchErrortypesException;

	public com.org.skali.sitanAdmin.model.Errortypes updateImpl(
		com.org.skali.sitanAdmin.model.Errortypes errortypes)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the errortypes with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchErrortypesException} if it could not be found.
	*
	* @param errortypeid the primary key of the errortypes
	* @return the errortypes
	* @throws com.org.skali.sitanAdmin.NoSuchErrortypesException if a errortypes with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes findByPrimaryKey(
		long errortypeid)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.org.skali.sitanAdmin.NoSuchErrortypesException;

	/**
	* Returns the errortypes with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param errortypeid the primary key of the errortypes
	* @return the errortypes, or <code>null</code> if a errortypes with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.org.skali.sitanAdmin.model.Errortypes fetchByPrimaryKey(
		long errortypeid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the errortypeses.
	*
	* @return the errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the errortypeses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of errortypeses
	* @param end the upper bound of the range of errortypeses (not inclusive)
	* @return the range of errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the errortypeses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ErrortypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of errortypeses
	* @param end the upper bound of the range of errortypeses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.org.skali.sitanAdmin.model.Errortypes> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the errortypeses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of errortypeses.
	*
	* @return the number of errortypeses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}