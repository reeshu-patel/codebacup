/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LicensesStatus}.
 * </p>
 *
 * @author reeshu
 * @see LicensesStatus
 * @generated
 */
public class LicensesStatusWrapper implements LicensesStatus,
	ModelWrapper<LicensesStatus> {
	public LicensesStatusWrapper(LicensesStatus licensesStatus) {
		_licensesStatus = licensesStatus;
	}

	@Override
	public Class<?> getModelClass() {
		return LicensesStatus.class;
	}

	@Override
	public String getModelClassName() {
		return LicensesStatus.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("licensesstatusid", getLicensesstatusid());
		attributes.put("bilId", getBilId());
		attributes.put("active", getActive());
		attributes.put("noActive", getNoActive());
		attributes.put("moreoverHadAge", getMoreoverHadAge());
		attributes.put("finishedWithin", getFinishedWithin());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long licensesstatusid = (Long)attributes.get("licensesstatusid");

		if (licensesstatusid != null) {
			setLicensesstatusid(licensesstatusid);
		}

		Long bilId = (Long)attributes.get("bilId");

		if (bilId != null) {
			setBilId(bilId);
		}

		String active = (String)attributes.get("active");

		if (active != null) {
			setActive(active);
		}

		String noActive = (String)attributes.get("noActive");

		if (noActive != null) {
			setNoActive(noActive);
		}

		String moreoverHadAge = (String)attributes.get("moreoverHadAge");

		if (moreoverHadAge != null) {
			setMoreoverHadAge(moreoverHadAge);
		}

		String finishedWithin = (String)attributes.get("finishedWithin");

		if (finishedWithin != null) {
			setFinishedWithin(finishedWithin);
		}
	}

	/**
	* Returns the primary key of this licenses status.
	*
	* @return the primary key of this licenses status
	*/
	@Override
	public long getPrimaryKey() {
		return _licensesStatus.getPrimaryKey();
	}

	/**
	* Sets the primary key of this licenses status.
	*
	* @param primaryKey the primary key of this licenses status
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_licensesStatus.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the licensesstatusid of this licenses status.
	*
	* @return the licensesstatusid of this licenses status
	*/
	@Override
	public long getLicensesstatusid() {
		return _licensesStatus.getLicensesstatusid();
	}

	/**
	* Sets the licensesstatusid of this licenses status.
	*
	* @param licensesstatusid the licensesstatusid of this licenses status
	*/
	@Override
	public void setLicensesstatusid(long licensesstatusid) {
		_licensesStatus.setLicensesstatusid(licensesstatusid);
	}

	/**
	* Returns the bil ID of this licenses status.
	*
	* @return the bil ID of this licenses status
	*/
	@Override
	public long getBilId() {
		return _licensesStatus.getBilId();
	}

	/**
	* Sets the bil ID of this licenses status.
	*
	* @param bilId the bil ID of this licenses status
	*/
	@Override
	public void setBilId(long bilId) {
		_licensesStatus.setBilId(bilId);
	}

	/**
	* Returns the active of this licenses status.
	*
	* @return the active of this licenses status
	*/
	@Override
	public java.lang.String getActive() {
		return _licensesStatus.getActive();
	}

	/**
	* Sets the active of this licenses status.
	*
	* @param active the active of this licenses status
	*/
	@Override
	public void setActive(java.lang.String active) {
		_licensesStatus.setActive(active);
	}

	/**
	* Returns the no active of this licenses status.
	*
	* @return the no active of this licenses status
	*/
	@Override
	public java.lang.String getNoActive() {
		return _licensesStatus.getNoActive();
	}

	/**
	* Sets the no active of this licenses status.
	*
	* @param noActive the no active of this licenses status
	*/
	@Override
	public void setNoActive(java.lang.String noActive) {
		_licensesStatus.setNoActive(noActive);
	}

	/**
	* Returns the moreover had age of this licenses status.
	*
	* @return the moreover had age of this licenses status
	*/
	@Override
	public java.lang.String getMoreoverHadAge() {
		return _licensesStatus.getMoreoverHadAge();
	}

	/**
	* Sets the moreover had age of this licenses status.
	*
	* @param moreoverHadAge the moreover had age of this licenses status
	*/
	@Override
	public void setMoreoverHadAge(java.lang.String moreoverHadAge) {
		_licensesStatus.setMoreoverHadAge(moreoverHadAge);
	}

	/**
	* Returns the finished within of this licenses status.
	*
	* @return the finished within of this licenses status
	*/
	@Override
	public java.lang.String getFinishedWithin() {
		return _licensesStatus.getFinishedWithin();
	}

	/**
	* Sets the finished within of this licenses status.
	*
	* @param finishedWithin the finished within of this licenses status
	*/
	@Override
	public void setFinishedWithin(java.lang.String finishedWithin) {
		_licensesStatus.setFinishedWithin(finishedWithin);
	}

	@Override
	public boolean isNew() {
		return _licensesStatus.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_licensesStatus.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _licensesStatus.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_licensesStatus.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _licensesStatus.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _licensesStatus.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_licensesStatus.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _licensesStatus.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_licensesStatus.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_licensesStatus.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_licensesStatus.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LicensesStatusWrapper((LicensesStatus)_licensesStatus.clone());
	}

	@Override
	public int compareTo(
		com.org.skali.sitanAdmin.model.LicensesStatus licensesStatus) {
		return _licensesStatus.compareTo(licensesStatus);
	}

	@Override
	public int hashCode() {
		return _licensesStatus.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.org.skali.sitanAdmin.model.LicensesStatus> toCacheModel() {
		return _licensesStatus.toCacheModel();
	}

	@Override
	public com.org.skali.sitanAdmin.model.LicensesStatus toEscapedModel() {
		return new LicensesStatusWrapper(_licensesStatus.toEscapedModel());
	}

	@Override
	public com.org.skali.sitanAdmin.model.LicensesStatus toUnescapedModel() {
		return new LicensesStatusWrapper(_licensesStatus.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _licensesStatus.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _licensesStatus.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_licensesStatus.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LicensesStatusWrapper)) {
			return false;
		}

		LicensesStatusWrapper licensesStatusWrapper = (LicensesStatusWrapper)obj;

		if (Validator.equals(_licensesStatus,
					licensesStatusWrapper._licensesStatus)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LicensesStatus getWrappedLicensesStatus() {
		return _licensesStatus;
	}

	@Override
	public LicensesStatus getWrappedModel() {
		return _licensesStatus;
	}

	@Override
	public void resetOriginalValues() {
		_licensesStatus.resetOriginalValues();
	}

	private LicensesStatus _licensesStatus;
}