/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchRecoredComunicationException;
import com.org.skali.sitanAdmin.model.RecoredComunication;
import com.org.skali.sitanAdmin.model.impl.RecoredComunicationImpl;
import com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the recored comunication service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see RecoredComunicationPersistence
 * @see RecoredComunicationUtil
 * @generated
 */
public class RecoredComunicationPersistenceImpl extends BasePersistenceImpl<RecoredComunication>
	implements RecoredComunicationPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link RecoredComunicationUtil} to access the recored comunication persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = RecoredComunicationImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED,
			RecoredComunicationImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED,
			RecoredComunicationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED,
			RecoredComunicationImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED,
			RecoredComunicationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			RecoredComunicationModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the recored comunications where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findBybilId(long bilId)
		throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the recored comunications where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of recored comunications
	 * @param end the upper bound of the range of recored comunications (not inclusive)
	 * @return the range of matching recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the recored comunications where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of recored comunications
	 * @param end the upper bound of the range of recored comunications (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findBybilId(long bilId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<RecoredComunication> list = (List<RecoredComunication>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (RecoredComunication recoredComunication : list) {
				if ((bilId != recoredComunication.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_RECOREDCOMUNICATION_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(RecoredComunicationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<RecoredComunication>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RecoredComunication>(list);
				}
				else {
					list = (List<RecoredComunication>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first recored comunication in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching recored comunication
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a matching recored comunication could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchRecoredComunicationException, SystemException {
		RecoredComunication recoredComunication = fetchBybilId_First(bilId,
				orderByComparator);

		if (recoredComunication != null) {
			return recoredComunication;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchRecoredComunicationException(msg.toString());
	}

	/**
	 * Returns the first recored comunication in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching recored comunication, or <code>null</code> if a matching recored comunication could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<RecoredComunication> list = findBybilId(bilId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last recored comunication in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching recored comunication
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a matching recored comunication could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchRecoredComunicationException, SystemException {
		RecoredComunication recoredComunication = fetchBybilId_Last(bilId,
				orderByComparator);

		if (recoredComunication != null) {
			return recoredComunication;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchRecoredComunicationException(msg.toString());
	}

	/**
	 * Returns the last recored comunication in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching recored comunication, or <code>null</code> if a matching recored comunication could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<RecoredComunication> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the recored comunications before and after the current recored comunication in the ordered set where bilId = &#63;.
	 *
	 * @param recoredomuni the primary key of the current recored comunication
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next recored comunication
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication[] findBybilId_PrevAndNext(long recoredomuni,
		long bilId, OrderByComparator orderByComparator)
		throws NoSuchRecoredComunicationException, SystemException {
		RecoredComunication recoredComunication = findByPrimaryKey(recoredomuni);

		Session session = null;

		try {
			session = openSession();

			RecoredComunication[] array = new RecoredComunicationImpl[3];

			array[0] = getBybilId_PrevAndNext(session, recoredComunication,
					bilId, orderByComparator, true);

			array[1] = recoredComunication;

			array[2] = getBybilId_PrevAndNext(session, recoredComunication,
					bilId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected RecoredComunication getBybilId_PrevAndNext(Session session,
		RecoredComunication recoredComunication, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_RECOREDCOMUNICATION_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(RecoredComunicationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(recoredComunication);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<RecoredComunication> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the recored comunications where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (RecoredComunication recoredComunication : findBybilId(bilId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(recoredComunication);
		}
	}

	/**
	 * Returns the number of recored comunications where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_RECOREDCOMUNICATION_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "recoredComunication.bilId = ?";

	public RecoredComunicationPersistenceImpl() {
		setModelClass(RecoredComunication.class);
	}

	/**
	 * Caches the recored comunication in the entity cache if it is enabled.
	 *
	 * @param recoredComunication the recored comunication
	 */
	@Override
	public void cacheResult(RecoredComunication recoredComunication) {
		EntityCacheUtil.putResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationImpl.class, recoredComunication.getPrimaryKey(),
			recoredComunication);

		recoredComunication.resetOriginalValues();
	}

	/**
	 * Caches the recored comunications in the entity cache if it is enabled.
	 *
	 * @param recoredComunications the recored comunications
	 */
	@Override
	public void cacheResult(List<RecoredComunication> recoredComunications) {
		for (RecoredComunication recoredComunication : recoredComunications) {
			if (EntityCacheUtil.getResult(
						RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
						RecoredComunicationImpl.class,
						recoredComunication.getPrimaryKey()) == null) {
				cacheResult(recoredComunication);
			}
			else {
				recoredComunication.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all recored comunications.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(RecoredComunicationImpl.class.getName());
		}

		EntityCacheUtil.clearCache(RecoredComunicationImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the recored comunication.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(RecoredComunication recoredComunication) {
		EntityCacheUtil.removeResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationImpl.class, recoredComunication.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<RecoredComunication> recoredComunications) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (RecoredComunication recoredComunication : recoredComunications) {
			EntityCacheUtil.removeResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
				RecoredComunicationImpl.class,
				recoredComunication.getPrimaryKey());
		}
	}

	/**
	 * Creates a new recored comunication with the primary key. Does not add the recored comunication to the database.
	 *
	 * @param recoredomuni the primary key for the new recored comunication
	 * @return the new recored comunication
	 */
	@Override
	public RecoredComunication create(long recoredomuni) {
		RecoredComunication recoredComunication = new RecoredComunicationImpl();

		recoredComunication.setNew(true);
		recoredComunication.setPrimaryKey(recoredomuni);

		return recoredComunication;
	}

	/**
	 * Removes the recored comunication with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param recoredomuni the primary key of the recored comunication
	 * @return the recored comunication that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication remove(long recoredomuni)
		throws NoSuchRecoredComunicationException, SystemException {
		return remove((Serializable)recoredomuni);
	}

	/**
	 * Removes the recored comunication with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the recored comunication
	 * @return the recored comunication that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication remove(Serializable primaryKey)
		throws NoSuchRecoredComunicationException, SystemException {
		Session session = null;

		try {
			session = openSession();

			RecoredComunication recoredComunication = (RecoredComunication)session.get(RecoredComunicationImpl.class,
					primaryKey);

			if (recoredComunication == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchRecoredComunicationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(recoredComunication);
		}
		catch (NoSuchRecoredComunicationException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected RecoredComunication removeImpl(
		RecoredComunication recoredComunication) throws SystemException {
		recoredComunication = toUnwrappedModel(recoredComunication);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(recoredComunication)) {
				recoredComunication = (RecoredComunication)session.get(RecoredComunicationImpl.class,
						recoredComunication.getPrimaryKeyObj());
			}

			if (recoredComunication != null) {
				session.delete(recoredComunication);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (recoredComunication != null) {
			clearCache(recoredComunication);
		}

		return recoredComunication;
	}

	@Override
	public RecoredComunication updateImpl(
		com.org.skali.sitanAdmin.model.RecoredComunication recoredComunication)
		throws SystemException {
		recoredComunication = toUnwrappedModel(recoredComunication);

		boolean isNew = recoredComunication.isNew();

		RecoredComunicationModelImpl recoredComunicationModelImpl = (RecoredComunicationModelImpl)recoredComunication;

		Session session = null;

		try {
			session = openSession();

			if (recoredComunication.isNew()) {
				session.save(recoredComunication);

				recoredComunication.setNew(false);
			}
			else {
				session.merge(recoredComunication);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !RecoredComunicationModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((recoredComunicationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						recoredComunicationModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { recoredComunicationModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}
		}

		EntityCacheUtil.putResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
			RecoredComunicationImpl.class, recoredComunication.getPrimaryKey(),
			recoredComunication);

		return recoredComunication;
	}

	protected RecoredComunication toUnwrappedModel(
		RecoredComunication recoredComunication) {
		if (recoredComunication instanceof RecoredComunicationImpl) {
			return recoredComunication;
		}

		RecoredComunicationImpl recoredComunicationImpl = new RecoredComunicationImpl();

		recoredComunicationImpl.setNew(recoredComunication.isNew());
		recoredComunicationImpl.setPrimaryKey(recoredComunication.getPrimaryKey());

		recoredComunicationImpl.setRecoredomuni(recoredComunication.getRecoredomuni());
		recoredComunicationImpl.setBilId(recoredComunication.getBilId());
		recoredComunicationImpl.setDateTime(recoredComunication.getDateTime());
		recoredComunicationImpl.setContact(recoredComunication.getContact());
		recoredComunicationImpl.setCommunicationMethod(recoredComunication.getCommunicationMethod());
		recoredComunicationImpl.setTelefon(recoredComunication.getTelefon());
		recoredComunicationImpl.setParticle(recoredComunication.getParticle());
		recoredComunicationImpl.setPaymentAmount(recoredComunication.getPaymentAmount());
		recoredComunicationImpl.setPaymentMethod(recoredComunication.getPaymentMethod());
		recoredComunicationImpl.setPaymentDate(recoredComunication.getPaymentDate());
		recoredComunicationImpl.setReferralPayment(recoredComunication.getReferralPayment());

		return recoredComunicationImpl;
	}

	/**
	 * Returns the recored comunication with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the recored comunication
	 * @return the recored comunication
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication findByPrimaryKey(Serializable primaryKey)
		throws NoSuchRecoredComunicationException, SystemException {
		RecoredComunication recoredComunication = fetchByPrimaryKey(primaryKey);

		if (recoredComunication == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchRecoredComunicationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return recoredComunication;
	}

	/**
	 * Returns the recored comunication with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchRecoredComunicationException} if it could not be found.
	 *
	 * @param recoredomuni the primary key of the recored comunication
	 * @return the recored comunication
	 * @throws com.org.skali.sitanAdmin.NoSuchRecoredComunicationException if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication findByPrimaryKey(long recoredomuni)
		throws NoSuchRecoredComunicationException, SystemException {
		return findByPrimaryKey((Serializable)recoredomuni);
	}

	/**
	 * Returns the recored comunication with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the recored comunication
	 * @return the recored comunication, or <code>null</code> if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		RecoredComunication recoredComunication = (RecoredComunication)EntityCacheUtil.getResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
				RecoredComunicationImpl.class, primaryKey);

		if (recoredComunication == _nullRecoredComunication) {
			return null;
		}

		if (recoredComunication == null) {
			Session session = null;

			try {
				session = openSession();

				recoredComunication = (RecoredComunication)session.get(RecoredComunicationImpl.class,
						primaryKey);

				if (recoredComunication != null) {
					cacheResult(recoredComunication);
				}
				else {
					EntityCacheUtil.putResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
						RecoredComunicationImpl.class, primaryKey,
						_nullRecoredComunication);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(RecoredComunicationModelImpl.ENTITY_CACHE_ENABLED,
					RecoredComunicationImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return recoredComunication;
	}

	/**
	 * Returns the recored comunication with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param recoredomuni the primary key of the recored comunication
	 * @return the recored comunication, or <code>null</code> if a recored comunication with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RecoredComunication fetchByPrimaryKey(long recoredomuni)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)recoredomuni);
	}

	/**
	 * Returns all the recored comunications.
	 *
	 * @return the recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the recored comunications.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of recored comunications
	 * @param end the upper bound of the range of recored comunications (not inclusive)
	 * @return the range of recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the recored comunications.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.RecoredComunicationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of recored comunications
	 * @param end the upper bound of the range of recored comunications (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RecoredComunication> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<RecoredComunication> list = (List<RecoredComunication>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_RECOREDCOMUNICATION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_RECOREDCOMUNICATION;

				if (pagination) {
					sql = sql.concat(RecoredComunicationModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<RecoredComunication>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RecoredComunication>(list);
				}
				else {
					list = (List<RecoredComunication>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the recored comunications from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (RecoredComunication recoredComunication : findAll()) {
			remove(recoredComunication);
		}
	}

	/**
	 * Returns the number of recored comunications.
	 *
	 * @return the number of recored comunications
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_RECOREDCOMUNICATION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the recored comunication persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.RecoredComunication")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<RecoredComunication>> listenersList = new ArrayList<ModelListener<RecoredComunication>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<RecoredComunication>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(RecoredComunicationImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_RECOREDCOMUNICATION = "SELECT recoredComunication FROM RecoredComunication recoredComunication";
	private static final String _SQL_SELECT_RECOREDCOMUNICATION_WHERE = "SELECT recoredComunication FROM RecoredComunication recoredComunication WHERE ";
	private static final String _SQL_COUNT_RECOREDCOMUNICATION = "SELECT COUNT(recoredComunication) FROM RecoredComunication recoredComunication";
	private static final String _SQL_COUNT_RECOREDCOMUNICATION_WHERE = "SELECT COUNT(recoredComunication) FROM RecoredComunication recoredComunication WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "recoredComunication.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No RecoredComunication exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No RecoredComunication exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(RecoredComunicationPersistenceImpl.class);
	private static RecoredComunication _nullRecoredComunication = new RecoredComunicationImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<RecoredComunication> toCacheModel() {
				return _nullRecoredComunicationCacheModel;
			}
		};

	private static CacheModel<RecoredComunication> _nullRecoredComunicationCacheModel =
		new CacheModel<RecoredComunication>() {
			@Override
			public RecoredComunication toEntityModel() {
				return _nullRecoredComunication;
			}
		};
}