/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.BillInquery;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing BillInquery in entity cache.
 *
 * @author reeshu
 * @see BillInquery
 * @generated
 */
public class BillInqueryCacheModel implements CacheModel<BillInquery>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{billinquery=");
		sb.append(billinquery);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", complaintDate=");
		sb.append(complaintDate);
		sb.append(", referenceEffective=");
		sb.append(referenceEffective);
		sb.append(", source=");
		sb.append(source);
		sb.append(", vehiclesNo=");
		sb.append(vehiclesNo);
		sb.append(", companyName=");
		sb.append(companyName);
		sb.append(", offense=");
		sb.append(offense);
		sb.append(", virtue=");
		sb.append(virtue);
		sb.append(", filerating=");
		sb.append(filerating);
		sb.append(", caseStatus=");
		sb.append(caseStatus);
		sb.append(", nameofofficer=");
		sb.append(nameofofficer);
		sb.append(", error=");
		sb.append(error);
		sb.append(", errorType=");
		sb.append(errorType);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public BillInquery toEntityModel() {
		BillInqueryImpl billInqueryImpl = new BillInqueryImpl();

		billInqueryImpl.setBillinquery(billinquery);
		billInqueryImpl.setBilId(bilId);

		if (complaintDate == null) {
			billInqueryImpl.setComplaintDate(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setComplaintDate(complaintDate);
		}

		if (referenceEffective == null) {
			billInqueryImpl.setReferenceEffective(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setReferenceEffective(referenceEffective);
		}

		if (source == null) {
			billInqueryImpl.setSource(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setSource(source);
		}

		if (vehiclesNo == null) {
			billInqueryImpl.setVehiclesNo(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setVehiclesNo(vehiclesNo);
		}

		if (companyName == null) {
			billInqueryImpl.setCompanyName(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setCompanyName(companyName);
		}

		if (offense == null) {
			billInqueryImpl.setOffense(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setOffense(offense);
		}

		if (virtue == null) {
			billInqueryImpl.setVirtue(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setVirtue(virtue);
		}

		if (filerating == null) {
			billInqueryImpl.setFilerating(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setFilerating(filerating);
		}

		if (caseStatus == null) {
			billInqueryImpl.setCaseStatus(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setCaseStatus(caseStatus);
		}

		if (nameofofficer == null) {
			billInqueryImpl.setNameofofficer(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setNameofofficer(nameofofficer);
		}

		if (error == null) {
			billInqueryImpl.setError(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setError(error);
		}

		if (errorType == null) {
			billInqueryImpl.setErrorType(StringPool.BLANK);
		}
		else {
			billInqueryImpl.setErrorType(errorType);
		}

		billInqueryImpl.resetOriginalValues();

		return billInqueryImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		billinquery = objectInput.readLong();
		bilId = objectInput.readLong();
		complaintDate = objectInput.readUTF();
		referenceEffective = objectInput.readUTF();
		source = objectInput.readUTF();
		vehiclesNo = objectInput.readUTF();
		companyName = objectInput.readUTF();
		offense = objectInput.readUTF();
		virtue = objectInput.readUTF();
		filerating = objectInput.readUTF();
		caseStatus = objectInput.readUTF();
		nameofofficer = objectInput.readUTF();
		error = objectInput.readUTF();
		errorType = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(billinquery);
		objectOutput.writeLong(bilId);

		if (complaintDate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(complaintDate);
		}

		if (referenceEffective == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(referenceEffective);
		}

		if (source == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(source);
		}

		if (vehiclesNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehiclesNo);
		}

		if (companyName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyName);
		}

		if (offense == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(offense);
		}

		if (virtue == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(virtue);
		}

		if (filerating == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(filerating);
		}

		if (caseStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(caseStatus);
		}

		if (nameofofficer == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameofofficer);
		}

		if (error == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(error);
		}

		if (errorType == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(errorType);
		}
	}

	public long billinquery;
	public long bilId;
	public String complaintDate;
	public String referenceEffective;
	public String source;
	public String vehiclesNo;
	public String companyName;
	public String offense;
	public String virtue;
	public String filerating;
	public String caseStatus;
	public String nameofofficer;
	public String error;
	public String errorType;
}