/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchEquityHoldersException;
import com.org.skali.sitanAdmin.model.EquityHolders;
import com.org.skali.sitanAdmin.model.impl.EquityHoldersImpl;
import com.org.skali.sitanAdmin.model.impl.EquityHoldersModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the equity holders service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see EquityHoldersPersistence
 * @see EquityHoldersUtil
 * @generated
 */
public class EquityHoldersPersistenceImpl extends BasePersistenceImpl<EquityHolders>
	implements EquityHoldersPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link EquityHoldersUtil} to access the equity holders persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = EquityHoldersImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED,
			EquityHoldersImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED,
			EquityHoldersImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED,
			EquityHoldersImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED,
			EquityHoldersImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findBybilId", new String[] { Long.class.getName() },
			EquityHoldersModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the equity holderses where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findBybilId(long bilId)
		throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the equity holderses where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.EquityHoldersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of equity holderses
	 * @param end the upper bound of the range of equity holderses (not inclusive)
	 * @return the range of matching equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the equity holderses where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.EquityHoldersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of equity holderses
	 * @param end the upper bound of the range of equity holderses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findBybilId(long bilId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<EquityHolders> list = (List<EquityHolders>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (EquityHolders equityHolders : list) {
				if ((bilId != equityHolders.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_EQUITYHOLDERS_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(EquityHoldersModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<EquityHolders>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EquityHolders>(list);
				}
				else {
					list = (List<EquityHolders>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first equity holders in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching equity holders
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a matching equity holders could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchEquityHoldersException, SystemException {
		EquityHolders equityHolders = fetchBybilId_First(bilId,
				orderByComparator);

		if (equityHolders != null) {
			return equityHolders;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEquityHoldersException(msg.toString());
	}

	/**
	 * Returns the first equity holders in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching equity holders, or <code>null</code> if a matching equity holders could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<EquityHolders> list = findBybilId(bilId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last equity holders in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching equity holders
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a matching equity holders could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchEquityHoldersException, SystemException {
		EquityHolders equityHolders = fetchBybilId_Last(bilId, orderByComparator);

		if (equityHolders != null) {
			return equityHolders;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEquityHoldersException(msg.toString());
	}

	/**
	 * Returns the last equity holders in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching equity holders, or <code>null</code> if a matching equity holders could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<EquityHolders> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the equity holderses before and after the current equity holders in the ordered set where bilId = &#63;.
	 *
	 * @param equityholdersid the primary key of the current equity holders
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next equity holders
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders[] findBybilId_PrevAndNext(long equityholdersid,
		long bilId, OrderByComparator orderByComparator)
		throws NoSuchEquityHoldersException, SystemException {
		EquityHolders equityHolders = findByPrimaryKey(equityholdersid);

		Session session = null;

		try {
			session = openSession();

			EquityHolders[] array = new EquityHoldersImpl[3];

			array[0] = getBybilId_PrevAndNext(session, equityHolders, bilId,
					orderByComparator, true);

			array[1] = equityHolders;

			array[2] = getBybilId_PrevAndNext(session, equityHolders, bilId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected EquityHolders getBybilId_PrevAndNext(Session session,
		EquityHolders equityHolders, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_EQUITYHOLDERS_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(EquityHoldersModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(equityHolders);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<EquityHolders> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the equity holderses where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (EquityHolders equityHolders : findBybilId(bilId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(equityHolders);
		}
	}

	/**
	 * Returns the number of equity holderses where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_EQUITYHOLDERS_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "equityHolders.bilId = ?";

	public EquityHoldersPersistenceImpl() {
		setModelClass(EquityHolders.class);
	}

	/**
	 * Caches the equity holders in the entity cache if it is enabled.
	 *
	 * @param equityHolders the equity holders
	 */
	@Override
	public void cacheResult(EquityHolders equityHolders) {
		EntityCacheUtil.putResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersImpl.class, equityHolders.getPrimaryKey(),
			equityHolders);

		equityHolders.resetOriginalValues();
	}

	/**
	 * Caches the equity holderses in the entity cache if it is enabled.
	 *
	 * @param equityHolderses the equity holderses
	 */
	@Override
	public void cacheResult(List<EquityHolders> equityHolderses) {
		for (EquityHolders equityHolders : equityHolderses) {
			if (EntityCacheUtil.getResult(
						EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
						EquityHoldersImpl.class, equityHolders.getPrimaryKey()) == null) {
				cacheResult(equityHolders);
			}
			else {
				equityHolders.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all equity holderses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(EquityHoldersImpl.class.getName());
		}

		EntityCacheUtil.clearCache(EquityHoldersImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the equity holders.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EquityHolders equityHolders) {
		EntityCacheUtil.removeResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersImpl.class, equityHolders.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<EquityHolders> equityHolderses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (EquityHolders equityHolders : equityHolderses) {
			EntityCacheUtil.removeResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
				EquityHoldersImpl.class, equityHolders.getPrimaryKey());
		}
	}

	/**
	 * Creates a new equity holders with the primary key. Does not add the equity holders to the database.
	 *
	 * @param equityholdersid the primary key for the new equity holders
	 * @return the new equity holders
	 */
	@Override
	public EquityHolders create(long equityholdersid) {
		EquityHolders equityHolders = new EquityHoldersImpl();

		equityHolders.setNew(true);
		equityHolders.setPrimaryKey(equityholdersid);

		return equityHolders;
	}

	/**
	 * Removes the equity holders with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param equityholdersid the primary key of the equity holders
	 * @return the equity holders that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders remove(long equityholdersid)
		throws NoSuchEquityHoldersException, SystemException {
		return remove((Serializable)equityholdersid);
	}

	/**
	 * Removes the equity holders with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the equity holders
	 * @return the equity holders that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders remove(Serializable primaryKey)
		throws NoSuchEquityHoldersException, SystemException {
		Session session = null;

		try {
			session = openSession();

			EquityHolders equityHolders = (EquityHolders)session.get(EquityHoldersImpl.class,
					primaryKey);

			if (equityHolders == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEquityHoldersException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(equityHolders);
		}
		catch (NoSuchEquityHoldersException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EquityHolders removeImpl(EquityHolders equityHolders)
		throws SystemException {
		equityHolders = toUnwrappedModel(equityHolders);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(equityHolders)) {
				equityHolders = (EquityHolders)session.get(EquityHoldersImpl.class,
						equityHolders.getPrimaryKeyObj());
			}

			if (equityHolders != null) {
				session.delete(equityHolders);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (equityHolders != null) {
			clearCache(equityHolders);
		}

		return equityHolders;
	}

	@Override
	public EquityHolders updateImpl(
		com.org.skali.sitanAdmin.model.EquityHolders equityHolders)
		throws SystemException {
		equityHolders = toUnwrappedModel(equityHolders);

		boolean isNew = equityHolders.isNew();

		EquityHoldersModelImpl equityHoldersModelImpl = (EquityHoldersModelImpl)equityHolders;

		Session session = null;

		try {
			session = openSession();

			if (equityHolders.isNew()) {
				session.save(equityHolders);

				equityHolders.setNew(false);
			}
			else {
				session.merge(equityHolders);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !EquityHoldersModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((equityHoldersModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						equityHoldersModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { equityHoldersModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}
		}

		EntityCacheUtil.putResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
			EquityHoldersImpl.class, equityHolders.getPrimaryKey(),
			equityHolders);

		return equityHolders;
	}

	protected EquityHolders toUnwrappedModel(EquityHolders equityHolders) {
		if (equityHolders instanceof EquityHoldersImpl) {
			return equityHolders;
		}

		EquityHoldersImpl equityHoldersImpl = new EquityHoldersImpl();

		equityHoldersImpl.setNew(equityHolders.isNew());
		equityHoldersImpl.setPrimaryKey(equityHolders.getPrimaryKey());

		equityHoldersImpl.setEquityholdersid(equityHolders.getEquityholdersid());
		equityHoldersImpl.setBilId(equityHolders.getBilId());
		equityHoldersImpl.setName(equityHolders.getName());
		equityHoldersImpl.setKpLama(equityHolders.getKpLama());
		equityHoldersImpl.setNewKp(equityHolders.getNewKp());
		equityHoldersImpl.setValue(equityHolders.getValue());
		equityHoldersImpl.setPercent(equityHolders.getPercent());
		equityHoldersImpl.setGender(equityHolders.getGender());
		equityHoldersImpl.setNation(equityHolders.getNation());

		return equityHoldersImpl;
	}

	/**
	 * Returns the equity holders with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the equity holders
	 * @return the equity holders
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEquityHoldersException, SystemException {
		EquityHolders equityHolders = fetchByPrimaryKey(primaryKey);

		if (equityHolders == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEquityHoldersException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return equityHolders;
	}

	/**
	 * Returns the equity holders with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchEquityHoldersException} if it could not be found.
	 *
	 * @param equityholdersid the primary key of the equity holders
	 * @return the equity holders
	 * @throws com.org.skali.sitanAdmin.NoSuchEquityHoldersException if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders findByPrimaryKey(long equityholdersid)
		throws NoSuchEquityHoldersException, SystemException {
		return findByPrimaryKey((Serializable)equityholdersid);
	}

	/**
	 * Returns the equity holders with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the equity holders
	 * @return the equity holders, or <code>null</code> if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		EquityHolders equityHolders = (EquityHolders)EntityCacheUtil.getResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
				EquityHoldersImpl.class, primaryKey);

		if (equityHolders == _nullEquityHolders) {
			return null;
		}

		if (equityHolders == null) {
			Session session = null;

			try {
				session = openSession();

				equityHolders = (EquityHolders)session.get(EquityHoldersImpl.class,
						primaryKey);

				if (equityHolders != null) {
					cacheResult(equityHolders);
				}
				else {
					EntityCacheUtil.putResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
						EquityHoldersImpl.class, primaryKey, _nullEquityHolders);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(EquityHoldersModelImpl.ENTITY_CACHE_ENABLED,
					EquityHoldersImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return equityHolders;
	}

	/**
	 * Returns the equity holders with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param equityholdersid the primary key of the equity holders
	 * @return the equity holders, or <code>null</code> if a equity holders with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EquityHolders fetchByPrimaryKey(long equityholdersid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)equityholdersid);
	}

	/**
	 * Returns all the equity holderses.
	 *
	 * @return the equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the equity holderses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.EquityHoldersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of equity holderses
	 * @param end the upper bound of the range of equity holderses (not inclusive)
	 * @return the range of equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the equity holderses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.EquityHoldersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of equity holderses
	 * @param end the upper bound of the range of equity holderses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EquityHolders> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<EquityHolders> list = (List<EquityHolders>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_EQUITYHOLDERS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_EQUITYHOLDERS;

				if (pagination) {
					sql = sql.concat(EquityHoldersModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<EquityHolders>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EquityHolders>(list);
				}
				else {
					list = (List<EquityHolders>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the equity holderses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (EquityHolders equityHolders : findAll()) {
			remove(equityHolders);
		}
	}

	/**
	 * Returns the number of equity holderses.
	 *
	 * @return the number of equity holderses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_EQUITYHOLDERS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the equity holders persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.EquityHolders")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<EquityHolders>> listenersList = new ArrayList<ModelListener<EquityHolders>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<EquityHolders>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(EquityHoldersImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_EQUITYHOLDERS = "SELECT equityHolders FROM EquityHolders equityHolders";
	private static final String _SQL_SELECT_EQUITYHOLDERS_WHERE = "SELECT equityHolders FROM EquityHolders equityHolders WHERE ";
	private static final String _SQL_COUNT_EQUITYHOLDERS = "SELECT COUNT(equityHolders) FROM EquityHolders equityHolders";
	private static final String _SQL_COUNT_EQUITYHOLDERS_WHERE = "SELECT COUNT(equityHolders) FROM EquityHolders equityHolders WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "equityHolders.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No EquityHolders exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No EquityHolders exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(EquityHoldersPersistenceImpl.class);
	private static EquityHolders _nullEquityHolders = new EquityHoldersImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<EquityHolders> toCacheModel() {
				return _nullEquityHoldersCacheModel;
			}
		};

	private static CacheModel<EquityHolders> _nullEquityHoldersCacheModel = new CacheModel<EquityHolders>() {
			@Override
			public EquityHolders toEntityModel() {
				return _nullEquityHolders;
			}
		};
}