/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.ActiveVehicleDetail;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing ActiveVehicleDetail in entity cache.
 *
 * @author reeshu
 * @see ActiveVehicleDetail
 * @generated
 */
public class ActiveVehicleDetailCacheModel implements CacheModel<ActiveVehicleDetail>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{vehicalid=");
		sb.append(vehicalid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", classcode=");
		sb.append(classcode);
		sb.append(", byVehicle=");
		sb.append(byVehicle);
		sb.append(", withoutMotor=");
		sb.append(withoutMotor);
		sb.append(", commencement=");
		sb.append(commencement);
		sb.append(", ageLimit=");
		sb.append(ageLimit);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ActiveVehicleDetail toEntityModel() {
		ActiveVehicleDetailImpl activeVehicleDetailImpl = new ActiveVehicleDetailImpl();

		activeVehicleDetailImpl.setVehicalid(vehicalid);
		activeVehicleDetailImpl.setBilId(bilId);

		if (classcode == null) {
			activeVehicleDetailImpl.setClasscode(StringPool.BLANK);
		}
		else {
			activeVehicleDetailImpl.setClasscode(classcode);
		}

		if (byVehicle == null) {
			activeVehicleDetailImpl.setByVehicle(StringPool.BLANK);
		}
		else {
			activeVehicleDetailImpl.setByVehicle(byVehicle);
		}

		if (withoutMotor == null) {
			activeVehicleDetailImpl.setWithoutMotor(StringPool.BLANK);
		}
		else {
			activeVehicleDetailImpl.setWithoutMotor(withoutMotor);
		}

		if (commencement == null) {
			activeVehicleDetailImpl.setCommencement(StringPool.BLANK);
		}
		else {
			activeVehicleDetailImpl.setCommencement(commencement);
		}

		if (ageLimit == null) {
			activeVehicleDetailImpl.setAgeLimit(StringPool.BLANK);
		}
		else {
			activeVehicleDetailImpl.setAgeLimit(ageLimit);
		}

		activeVehicleDetailImpl.resetOriginalValues();

		return activeVehicleDetailImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		vehicalid = objectInput.readLong();
		bilId = objectInput.readLong();
		classcode = objectInput.readUTF();
		byVehicle = objectInput.readUTF();
		withoutMotor = objectInput.readUTF();
		commencement = objectInput.readUTF();
		ageLimit = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(vehicalid);
		objectOutput.writeLong(bilId);

		if (classcode == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(classcode);
		}

		if (byVehicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(byVehicle);
		}

		if (withoutMotor == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(withoutMotor);
		}

		if (commencement == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(commencement);
		}

		if (ageLimit == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ageLimit);
		}
	}

	public long vehicalid;
	public long bilId;
	public String classcode;
	public String byVehicle;
	public String withoutMotor;
	public String commencement;
	public String ageLimit;
}