/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.DocumentTree;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing DocumentTree in entity cache.
 *
 * @author reeshu
 * @see DocumentTree
 * @generated
 */
public class DocumentTreeCacheModel implements CacheModel<DocumentTree>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{documenttreeid=");
		sb.append(documenttreeid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", fileentryid=");
		sb.append(fileentryid);
		sb.append(", folderid=");
		sb.append(folderid);
		sb.append(", foldername=");
		sb.append(foldername);
		sb.append(", title=");
		sb.append(title);
		sb.append(", description=");
		sb.append(description);
		sb.append(", leaf=");
		sb.append(leaf);
		sb.append(", type=");
		sb.append(type);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public DocumentTree toEntityModel() {
		DocumentTreeImpl documentTreeImpl = new DocumentTreeImpl();

		documentTreeImpl.setDocumenttreeid(documenttreeid);
		documentTreeImpl.setBilId(bilId);
		documentTreeImpl.setFileentryid(fileentryid);
		documentTreeImpl.setFolderid(folderid);

		if (foldername == null) {
			documentTreeImpl.setFoldername(StringPool.BLANK);
		}
		else {
			documentTreeImpl.setFoldername(foldername);
		}

		if (title == null) {
			documentTreeImpl.setTitle(StringPool.BLANK);
		}
		else {
			documentTreeImpl.setTitle(title);
		}

		if (description == null) {
			documentTreeImpl.setDescription(StringPool.BLANK);
		}
		else {
			documentTreeImpl.setDescription(description);
		}

		if (leaf == null) {
			documentTreeImpl.setLeaf(StringPool.BLANK);
		}
		else {
			documentTreeImpl.setLeaf(leaf);
		}

		if (type == null) {
			documentTreeImpl.setType(StringPool.BLANK);
		}
		else {
			documentTreeImpl.setType(type);
		}

		documentTreeImpl.resetOriginalValues();

		return documentTreeImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		documenttreeid = objectInput.readLong();
		bilId = objectInput.readLong();
		fileentryid = objectInput.readLong();
		folderid = objectInput.readLong();
		foldername = objectInput.readUTF();
		title = objectInput.readUTF();
		description = objectInput.readUTF();
		leaf = objectInput.readUTF();
		type = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(documenttreeid);
		objectOutput.writeLong(bilId);
		objectOutput.writeLong(fileentryid);
		objectOutput.writeLong(folderid);

		if (foldername == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(foldername);
		}

		if (title == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(title);
		}

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}

		if (leaf == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(leaf);
		}

		if (type == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(type);
		}
	}

	public long documenttreeid;
	public long bilId;
	public long fileentryid;
	public long folderid;
	public String foldername;
	public String title;
	public String description;
	public String leaf;
	public String type;
}