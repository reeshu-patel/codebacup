/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.SitaanAdmin;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing SitaanAdmin in entity cache.
 *
 * @author reeshu
 * @see SitaanAdmin
 * @generated
 */
public class SitaanAdminCacheModel implements CacheModel<SitaanAdmin>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(95);

		sb.append("{bilId=");
		sb.append(bilId);
		sb.append(", dateSeized=");
		sb.append(dateSeized);
		sb.append(", checkSitesSita=");
		sb.append(checkSitesSita);
		sb.append(", referenceEffective=");
		sb.append(referenceEffective);
		sb.append(", confiscatedPeriod=");
		sb.append(confiscatedPeriod);
		sb.append(", source=");
		sb.append(source);
		sb.append(", ownerName=");
		sb.append(ownerName);
		sb.append(", vehicleRegistrationNo=");
		sb.append(vehicleRegistrationNo);
		sb.append(", territory=");
		sb.append(territory);
		sb.append(", state=");
		sb.append(state);
		sb.append(", locationCageSita=");
		sb.append(locationCageSita);
		sb.append(", foreclosureStatus=");
		sb.append(foreclosureStatus);
		sb.append(", resultsforeclosure=");
		sb.append(resultsforeclosure);
		sb.append(", officerName=");
		sb.append(officerName);
		sb.append(", action=");
		sb.append(action);
		sb.append(", actionBy=");
		sb.append(actionBy);
		sb.append(", rightsReleased=");
		sb.append(rightsReleased);
		sb.append(", acceptancedate=");
		sb.append(acceptancedate);
		sb.append(", paymentStatus=");
		sb.append(paymentStatus);
		sb.append(", caseStatus=");
		sb.append(caseStatus);
		sb.append(", error=");
		sb.append(error);
		sb.append(", companyName=");
		sb.append(companyName);
		sb.append(", virtue=");
		sb.append(virtue);
		sb.append(", nameofofficer=");
		sb.append(nameofofficer);
		sb.append(", filerating=");
		sb.append(filerating);
		sb.append(", submittername=");
		sb.append(submittername);
		sb.append(", passportNo=");
		sb.append(passportNo);
		sb.append(", power=");
		sb.append(power);
		sb.append(", office=");
		sb.append(office);
		sb.append(", chronicle=");
		sb.append(chronicle);
		sb.append(", typeofgoods=");
		sb.append(typeofgoods);
		sb.append(", quantity=");
		sb.append(quantity);
		sb.append(", record=");
		sb.append(record);
		sb.append(", inspectorsName=");
		sb.append(inspectorsName);
		sb.append(", category=");
		sb.append(category);
		sb.append(", typeofComplaint=");
		sb.append(typeofComplaint);
		sb.append(", classLicense=");
		sb.append(classLicense);
		sb.append(", particle=");
		sb.append(particle);
		sb.append(", dateofincident=");
		sb.append(dateofincident);
		sb.append(", timeEvent=");
		sb.append(timeEvent);
		sb.append(", locationofincident=");
		sb.append(locationofincident);
		sb.append(", terminal=");
		sb.append(terminal);
		sb.append(", bookie=");
		sb.append(bookie);
		sb.append(", landmark=");
		sb.append(landmark);
		sb.append(", internalStakeholder=");
		sb.append(internalStakeholder);
		sb.append(", externalStakeholder=");
		sb.append(externalStakeholder);
		sb.append(", foreclosureStatusType=");
		sb.append(foreclosureStatusType);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SitaanAdmin toEntityModel() {
		SitaanAdminImpl sitaanAdminImpl = new SitaanAdminImpl();

		sitaanAdminImpl.setBilId(bilId);

		if (dateSeized == null) {
			sitaanAdminImpl.setDateSeized(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setDateSeized(dateSeized);
		}

		if (checkSitesSita == null) {
			sitaanAdminImpl.setCheckSitesSita(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setCheckSitesSita(checkSitesSita);
		}

		if (referenceEffective == null) {
			sitaanAdminImpl.setReferenceEffective(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setReferenceEffective(referenceEffective);
		}

		if (confiscatedPeriod == null) {
			sitaanAdminImpl.setConfiscatedPeriod(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setConfiscatedPeriod(confiscatedPeriod);
		}

		if (source == null) {
			sitaanAdminImpl.setSource(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setSource(source);
		}

		if (ownerName == null) {
			sitaanAdminImpl.setOwnerName(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setOwnerName(ownerName);
		}

		if (vehicleRegistrationNo == null) {
			sitaanAdminImpl.setVehicleRegistrationNo(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setVehicleRegistrationNo(vehicleRegistrationNo);
		}

		if (territory == null) {
			sitaanAdminImpl.setTerritory(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setTerritory(territory);
		}

		if (state == null) {
			sitaanAdminImpl.setState(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setState(state);
		}

		if (locationCageSita == null) {
			sitaanAdminImpl.setLocationCageSita(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setLocationCageSita(locationCageSita);
		}

		if (foreclosureStatus == null) {
			sitaanAdminImpl.setForeclosureStatus(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setForeclosureStatus(foreclosureStatus);
		}

		if (resultsforeclosure == null) {
			sitaanAdminImpl.setResultsforeclosure(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setResultsforeclosure(resultsforeclosure);
		}

		if (officerName == null) {
			sitaanAdminImpl.setOfficerName(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setOfficerName(officerName);
		}

		if (action == null) {
			sitaanAdminImpl.setAction(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setAction(action);
		}

		if (actionBy == null) {
			sitaanAdminImpl.setActionBy(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setActionBy(actionBy);
		}

		if (rightsReleased == null) {
			sitaanAdminImpl.setRightsReleased(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setRightsReleased(rightsReleased);
		}

		if (acceptancedate == null) {
			sitaanAdminImpl.setAcceptancedate(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setAcceptancedate(acceptancedate);
		}

		sitaanAdminImpl.setPaymentStatus(paymentStatus);

		if (caseStatus == null) {
			sitaanAdminImpl.setCaseStatus(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setCaseStatus(caseStatus);
		}

		if (error == null) {
			sitaanAdminImpl.setError(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setError(error);
		}

		if (companyName == null) {
			sitaanAdminImpl.setCompanyName(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setCompanyName(companyName);
		}

		if (virtue == null) {
			sitaanAdminImpl.setVirtue(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setVirtue(virtue);
		}

		if (nameofofficer == null) {
			sitaanAdminImpl.setNameofofficer(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setNameofofficer(nameofofficer);
		}

		if (filerating == null) {
			sitaanAdminImpl.setFilerating(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setFilerating(filerating);
		}

		if (submittername == null) {
			sitaanAdminImpl.setSubmittername(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setSubmittername(submittername);
		}

		sitaanAdminImpl.setPassportNo(passportNo);

		if (power == null) {
			sitaanAdminImpl.setPower(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setPower(power);
		}

		if (office == null) {
			sitaanAdminImpl.setOffice(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setOffice(office);
		}

		if (chronicle == null) {
			sitaanAdminImpl.setChronicle(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setChronicle(chronicle);
		}

		if (typeofgoods == null) {
			sitaanAdminImpl.setTypeofgoods(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setTypeofgoods(typeofgoods);
		}

		sitaanAdminImpl.setQuantity(quantity);
		sitaanAdminImpl.setRecord(record);

		if (inspectorsName == null) {
			sitaanAdminImpl.setInspectorsName(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setInspectorsName(inspectorsName);
		}

		if (category == null) {
			sitaanAdminImpl.setCategory(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setCategory(category);
		}

		if (typeofComplaint == null) {
			sitaanAdminImpl.setTypeofComplaint(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setTypeofComplaint(typeofComplaint);
		}

		if (classLicense == null) {
			sitaanAdminImpl.setClassLicense(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setClassLicense(classLicense);
		}

		if (particle == null) {
			sitaanAdminImpl.setParticle(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setParticle(particle);
		}

		if (dateofincident == null) {
			sitaanAdminImpl.setDateofincident(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setDateofincident(dateofincident);
		}

		if (timeEvent == null) {
			sitaanAdminImpl.setTimeEvent(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setTimeEvent(timeEvent);
		}

		if (locationofincident == null) {
			sitaanAdminImpl.setLocationofincident(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setLocationofincident(locationofincident);
		}

		if (terminal == null) {
			sitaanAdminImpl.setTerminal(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setTerminal(terminal);
		}

		if (bookie == null) {
			sitaanAdminImpl.setBookie(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setBookie(bookie);
		}

		if (landmark == null) {
			sitaanAdminImpl.setLandmark(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setLandmark(landmark);
		}

		if (internalStakeholder == null) {
			sitaanAdminImpl.setInternalStakeholder(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setInternalStakeholder(internalStakeholder);
		}

		if (externalStakeholder == null) {
			sitaanAdminImpl.setExternalStakeholder(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setExternalStakeholder(externalStakeholder);
		}

		if (foreclosureStatusType == null) {
			sitaanAdminImpl.setForeclosureStatusType(StringPool.BLANK);
		}
		else {
			sitaanAdminImpl.setForeclosureStatusType(foreclosureStatusType);
		}

		sitaanAdminImpl.resetOriginalValues();

		return sitaanAdminImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		bilId = objectInput.readLong();
		dateSeized = objectInput.readUTF();
		checkSitesSita = objectInput.readUTF();
		referenceEffective = objectInput.readUTF();
		confiscatedPeriod = objectInput.readUTF();
		source = objectInput.readUTF();
		ownerName = objectInput.readUTF();
		vehicleRegistrationNo = objectInput.readUTF();
		territory = objectInput.readUTF();
		state = objectInput.readUTF();
		locationCageSita = objectInput.readUTF();
		foreclosureStatus = objectInput.readUTF();
		resultsforeclosure = objectInput.readUTF();
		officerName = objectInput.readUTF();
		action = objectInput.readUTF();
		actionBy = objectInput.readUTF();
		rightsReleased = objectInput.readUTF();
		acceptancedate = objectInput.readUTF();
		paymentStatus = objectInput.readBoolean();
		caseStatus = objectInput.readUTF();
		error = objectInput.readUTF();
		companyName = objectInput.readUTF();
		virtue = objectInput.readUTF();
		nameofofficer = objectInput.readUTF();
		filerating = objectInput.readUTF();
		submittername = objectInput.readUTF();
		passportNo = objectInput.readLong();
		power = objectInput.readUTF();
		office = objectInput.readUTF();
		chronicle = objectInput.readUTF();
		typeofgoods = objectInput.readUTF();
		quantity = objectInput.readLong();
		record = objectInput.readLong();
		inspectorsName = objectInput.readUTF();
		category = objectInput.readUTF();
		typeofComplaint = objectInput.readUTF();
		classLicense = objectInput.readUTF();
		particle = objectInput.readUTF();
		dateofincident = objectInput.readUTF();
		timeEvent = objectInput.readUTF();
		locationofincident = objectInput.readUTF();
		terminal = objectInput.readUTF();
		bookie = objectInput.readUTF();
		landmark = objectInput.readUTF();
		internalStakeholder = objectInput.readUTF();
		externalStakeholder = objectInput.readUTF();
		foreclosureStatusType = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(bilId);

		if (dateSeized == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateSeized);
		}

		if (checkSitesSita == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(checkSitesSita);
		}

		if (referenceEffective == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(referenceEffective);
		}

		if (confiscatedPeriod == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(confiscatedPeriod);
		}

		if (source == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(source);
		}

		if (ownerName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ownerName);
		}

		if (vehicleRegistrationNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleRegistrationNo);
		}

		if (territory == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(territory);
		}

		if (state == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (locationCageSita == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(locationCageSita);
		}

		if (foreclosureStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(foreclosureStatus);
		}

		if (resultsforeclosure == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(resultsforeclosure);
		}

		if (officerName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(officerName);
		}

		if (action == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(action);
		}

		if (actionBy == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(actionBy);
		}

		if (rightsReleased == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rightsReleased);
		}

		if (acceptancedate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(acceptancedate);
		}

		objectOutput.writeBoolean(paymentStatus);

		if (caseStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(caseStatus);
		}

		if (error == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(error);
		}

		if (companyName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyName);
		}

		if (virtue == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(virtue);
		}

		if (nameofofficer == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameofofficer);
		}

		if (filerating == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(filerating);
		}

		if (submittername == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(submittername);
		}

		objectOutput.writeLong(passportNo);

		if (power == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(power);
		}

		if (office == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(office);
		}

		if (chronicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(chronicle);
		}

		if (typeofgoods == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeofgoods);
		}

		objectOutput.writeLong(quantity);
		objectOutput.writeLong(record);

		if (inspectorsName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(inspectorsName);
		}

		if (category == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(category);
		}

		if (typeofComplaint == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeofComplaint);
		}

		if (classLicense == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(classLicense);
		}

		if (particle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(particle);
		}

		if (dateofincident == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofincident);
		}

		if (timeEvent == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(timeEvent);
		}

		if (locationofincident == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(locationofincident);
		}

		if (terminal == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(terminal);
		}

		if (bookie == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bookie);
		}

		if (landmark == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(landmark);
		}

		if (internalStakeholder == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(internalStakeholder);
		}

		if (externalStakeholder == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(externalStakeholder);
		}

		if (foreclosureStatusType == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(foreclosureStatusType);
		}
	}

	public long bilId;
	public String dateSeized;
	public String checkSitesSita;
	public String referenceEffective;
	public String confiscatedPeriod;
	public String source;
	public String ownerName;
	public String vehicleRegistrationNo;
	public String territory;
	public String state;
	public String locationCageSita;
	public String foreclosureStatus;
	public String resultsforeclosure;
	public String officerName;
	public String action;
	public String actionBy;
	public String rightsReleased;
	public String acceptancedate;
	public boolean paymentStatus;
	public String caseStatus;
	public String error;
	public String companyName;
	public String virtue;
	public String nameofofficer;
	public String filerating;
	public String submittername;
	public long passportNo;
	public String power;
	public String office;
	public String chronicle;
	public String typeofgoods;
	public long quantity;
	public long record;
	public String inspectorsName;
	public String category;
	public String typeofComplaint;
	public String classLicense;
	public String particle;
	public String dateofincident;
	public String timeEvent;
	public String locationofincident;
	public String terminal;
	public String bookie;
	public String landmark;
	public String internalStakeholder;
	public String externalStakeholder;
	public String foreclosureStatusType;
}