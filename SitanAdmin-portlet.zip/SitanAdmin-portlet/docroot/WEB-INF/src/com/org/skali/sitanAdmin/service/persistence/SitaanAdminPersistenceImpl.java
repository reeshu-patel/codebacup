/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchSitaanAdminException;
import com.org.skali.sitanAdmin.model.SitaanAdmin;
import com.org.skali.sitanAdmin.model.impl.SitaanAdminImpl;
import com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the sitaan admin service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see SitaanAdminPersistence
 * @see SitaanAdminUtil
 * @generated
 */
public class SitaanAdminPersistenceImpl extends BasePersistenceImpl<SitaanAdmin>
	implements SitaanAdminPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SitaanAdminUtil} to access the sitaan admin persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SitaanAdminImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			SitaanAdminModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the sitaan admins where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBybilId(long bilId) throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBybilId(long bilId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if ((bilId != sitaanAdmin.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBybilId_First(bilId, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBybilId(bilId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBybilId_Last(bilId, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the sitaan admins where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBybilId(bilId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "sitaanAdmin.bilId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DATESEIZED =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBydateSeized",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESEIZED =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBydateSeized",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.DATESEIZED_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DATESEIZED = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydateSeized",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBydateSeized(String dateSeized)
		throws SystemException {
		return findBydateSeized(dateSeized, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where dateSeized = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dateSeized the date seized
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBydateSeized(String dateSeized, int start,
		int end) throws SystemException {
		return findBydateSeized(dateSeized, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where dateSeized = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param dateSeized the date seized
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBydateSeized(String dateSeized, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESEIZED;
			finderArgs = new Object[] { dateSeized };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DATESEIZED;
			finderArgs = new Object[] { dateSeized, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(dateSeized, sitaanAdmin.getDateSeized())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindDateSeized = false;

			if (dateSeized == null) {
				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_1);
			}
			else if (dateSeized.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_3);
			}
			else {
				bindDateSeized = true;

				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDateSeized) {
					qPos.add(dateSeized);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBydateSeized_First(String dateSeized,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBydateSeized_First(dateSeized,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("dateSeized=");
		msg.append(dateSeized);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBydateSeized_First(String dateSeized,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBydateSeized(dateSeized, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBydateSeized_Last(String dateSeized,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBydateSeized_Last(dateSeized,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("dateSeized=");
		msg.append(dateSeized);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBydateSeized_Last(String dateSeized,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBydateSeized(dateSeized);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBydateSeized(dateSeized, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where dateSeized = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param dateSeized the date seized
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBydateSeized_PrevAndNext(long bilId,
		String dateSeized, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBydateSeized_PrevAndNext(session, sitaanAdmin,
					dateSeized, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBydateSeized_PrevAndNext(session, sitaanAdmin,
					dateSeized, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBydateSeized_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String dateSeized,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindDateSeized = false;

		if (dateSeized == null) {
			query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_1);
		}
		else if (dateSeized.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_3);
		}
		else {
			bindDateSeized = true;

			query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindDateSeized) {
			qPos.add(dateSeized);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where dateSeized = &#63; from the database.
	 *
	 * @param dateSeized the date seized
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBydateSeized(String dateSeized) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBydateSeized(dateSeized,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where dateSeized = &#63;.
	 *
	 * @param dateSeized the date seized
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydateSeized(String dateSeized) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DATESEIZED;

		Object[] finderArgs = new Object[] { dateSeized };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindDateSeized = false;

			if (dateSeized == null) {
				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_1);
			}
			else if (dateSeized.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_3);
			}
			else {
				bindDateSeized = true;

				query.append(_FINDER_COLUMN_DATESEIZED_DATESEIZED_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDateSeized) {
					qPos.add(dateSeized);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DATESEIZED_DATESEIZED_1 = "sitaanAdmin.dateSeized IS NULL";
	private static final String _FINDER_COLUMN_DATESEIZED_DATESEIZED_2 = "sitaanAdmin.dateSeized = ?";
	private static final String _FINDER_COLUMN_DATESEIZED_DATESEIZED_3 = "(sitaanAdmin.dateSeized IS NULL OR sitaanAdmin.dateSeized = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKSITESSITA =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycheckSitesSita",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESSITA =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycheckSitesSita",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.CHECKSITESSITA_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CHECKSITESSITA = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycheckSitesSita",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBycheckSitesSita(String checkSitesSita)
		throws SystemException {
		return findBycheckSitesSita(checkSitesSita, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where checkSitesSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkSitesSita the check sites sita
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBycheckSitesSita(String checkSitesSita,
		int start, int end) throws SystemException {
		return findBycheckSitesSita(checkSitesSita, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where checkSitesSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkSitesSita the check sites sita
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBycheckSitesSita(String checkSitesSita,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESSITA;
			finderArgs = new Object[] { checkSitesSita };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKSITESSITA;
			finderArgs = new Object[] {
					checkSitesSita,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(checkSitesSita,
							sitaanAdmin.getCheckSitesSita())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindCheckSitesSita = false;

			if (checkSitesSita == null) {
				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_1);
			}
			else if (checkSitesSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_3);
			}
			else {
				bindCheckSitesSita = true;

				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCheckSitesSita) {
					qPos.add(checkSitesSita);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBycheckSitesSita_First(String checkSitesSita,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBycheckSitesSita_First(checkSitesSita,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkSitesSita=");
		msg.append(checkSitesSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBycheckSitesSita_First(String checkSitesSita,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBycheckSitesSita(checkSitesSita, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBycheckSitesSita_Last(String checkSitesSita,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBycheckSitesSita_Last(checkSitesSita,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkSitesSita=");
		msg.append(checkSitesSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBycheckSitesSita_Last(String checkSitesSita,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBycheckSitesSita(checkSitesSita);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBycheckSitesSita(checkSitesSita,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where checkSitesSita = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param checkSitesSita the check sites sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBycheckSitesSita_PrevAndNext(long bilId,
		String checkSitesSita, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBycheckSitesSita_PrevAndNext(session, sitaanAdmin,
					checkSitesSita, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBycheckSitesSita_PrevAndNext(session, sitaanAdmin,
					checkSitesSita, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBycheckSitesSita_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String checkSitesSita,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindCheckSitesSita = false;

		if (checkSitesSita == null) {
			query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_1);
		}
		else if (checkSitesSita.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_3);
		}
		else {
			bindCheckSitesSita = true;

			query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCheckSitesSita) {
			qPos.add(checkSitesSita);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where checkSitesSita = &#63; from the database.
	 *
	 * @param checkSitesSita the check sites sita
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBycheckSitesSita(String checkSitesSita)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBycheckSitesSita(checkSitesSita,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where checkSitesSita = &#63;.
	 *
	 * @param checkSitesSita the check sites sita
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBycheckSitesSita(String checkSitesSita)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKSITESSITA;

		Object[] finderArgs = new Object[] { checkSitesSita };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindCheckSitesSita = false;

			if (checkSitesSita == null) {
				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_1);
			}
			else if (checkSitesSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_3);
			}
			else {
				bindCheckSitesSita = true;

				query.append(_FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCheckSitesSita) {
					qPos.add(checkSitesSita);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_1 = "sitaanAdmin.checkSitesSita IS NULL";
	private static final String _FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_2 = "sitaanAdmin.checkSitesSita = ?";
	private static final String _FINDER_COLUMN_CHECKSITESSITA_CHECKSITESSITA_3 = "(sitaanAdmin.checkSitesSita IS NULL OR sitaanAdmin.checkSitesSita = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_REFERENCEEFFECTIVE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByreferenceEffective",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByreferenceEffective",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.REFERENCEEFFECTIVE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByreferenceEffective", new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByreferenceEffective(String referenceEffective)
		throws SystemException {
		return findByreferenceEffective(referenceEffective, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where referenceEffective = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param referenceEffective the reference effective
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByreferenceEffective(
		String referenceEffective, int start, int end)
		throws SystemException {
		return findByreferenceEffective(referenceEffective, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where referenceEffective = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param referenceEffective the reference effective
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByreferenceEffective(
		String referenceEffective, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE;
			finderArgs = new Object[] { referenceEffective };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_REFERENCEEFFECTIVE;
			finderArgs = new Object[] {
					referenceEffective,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(referenceEffective,
							sitaanAdmin.getReferenceEffective())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByreferenceEffective_First(
		String referenceEffective, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByreferenceEffective_First(referenceEffective,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("referenceEffective=");
		msg.append(referenceEffective);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByreferenceEffective_First(
		String referenceEffective, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByreferenceEffective(referenceEffective,
				0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByreferenceEffective_Last(
		String referenceEffective, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByreferenceEffective_Last(referenceEffective,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("referenceEffective=");
		msg.append(referenceEffective);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByreferenceEffective_Last(
		String referenceEffective, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByreferenceEffective(referenceEffective);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByreferenceEffective(referenceEffective,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where referenceEffective = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByreferenceEffective_PrevAndNext(long bilId,
		String referenceEffective, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByreferenceEffective_PrevAndNext(session,
					sitaanAdmin, referenceEffective, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByreferenceEffective_PrevAndNext(session,
					sitaanAdmin, referenceEffective, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByreferenceEffective_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String referenceEffective,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindReferenceEffective = false;

		if (referenceEffective == null) {
			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
		}
		else if (referenceEffective.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
		}
		else {
			bindReferenceEffective = true;

			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindReferenceEffective) {
			qPos.add(referenceEffective);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where referenceEffective = &#63; from the database.
	 *
	 * @param referenceEffective the reference effective
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByreferenceEffective(String referenceEffective)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByreferenceEffective(
				referenceEffective, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByreferenceEffective(String referenceEffective)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE;

		Object[] finderArgs = new Object[] { referenceEffective };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1 =
		"sitaanAdmin.referenceEffective IS NULL";
	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2 =
		"sitaanAdmin.referenceEffective = ?";
	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3 =
		"(sitaanAdmin.referenceEffective IS NULL OR sitaanAdmin.referenceEffective = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CONFISCATEDPERIOD =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByconfiscatedPeriod",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CONFISCATEDPERIOD =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByconfiscatedPeriod", new String[] { String.class.getName() },
			SitaanAdminModelImpl.CONFISCATEDPERIOD_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CONFISCATEDPERIOD = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByconfiscatedPeriod", new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByconfiscatedPeriod(String confiscatedPeriod)
		throws SystemException {
		return findByconfiscatedPeriod(confiscatedPeriod, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where confiscatedPeriod = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByconfiscatedPeriod(String confiscatedPeriod,
		int start, int end) throws SystemException {
		return findByconfiscatedPeriod(confiscatedPeriod, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where confiscatedPeriod = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByconfiscatedPeriod(String confiscatedPeriod,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CONFISCATEDPERIOD;
			finderArgs = new Object[] { confiscatedPeriod };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CONFISCATEDPERIOD;
			finderArgs = new Object[] {
					confiscatedPeriod,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(confiscatedPeriod,
							sitaanAdmin.getConfiscatedPeriod())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindConfiscatedPeriod = false;

			if (confiscatedPeriod == null) {
				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_1);
			}
			else if (confiscatedPeriod.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_3);
			}
			else {
				bindConfiscatedPeriod = true;

				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindConfiscatedPeriod) {
					qPos.add(confiscatedPeriod);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByconfiscatedPeriod_First(String confiscatedPeriod,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByconfiscatedPeriod_First(confiscatedPeriod,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("confiscatedPeriod=");
		msg.append(confiscatedPeriod);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByconfiscatedPeriod_First(
		String confiscatedPeriod, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByconfiscatedPeriod(confiscatedPeriod, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByconfiscatedPeriod_Last(String confiscatedPeriod,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByconfiscatedPeriod_Last(confiscatedPeriod,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("confiscatedPeriod=");
		msg.append(confiscatedPeriod);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByconfiscatedPeriod_Last(String confiscatedPeriod,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByconfiscatedPeriod(confiscatedPeriod);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByconfiscatedPeriod(confiscatedPeriod,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where confiscatedPeriod = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param confiscatedPeriod the confiscated period
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByconfiscatedPeriod_PrevAndNext(long bilId,
		String confiscatedPeriod, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByconfiscatedPeriod_PrevAndNext(session, sitaanAdmin,
					confiscatedPeriod, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByconfiscatedPeriod_PrevAndNext(session, sitaanAdmin,
					confiscatedPeriod, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByconfiscatedPeriod_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String confiscatedPeriod,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindConfiscatedPeriod = false;

		if (confiscatedPeriod == null) {
			query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_1);
		}
		else if (confiscatedPeriod.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_3);
		}
		else {
			bindConfiscatedPeriod = true;

			query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindConfiscatedPeriod) {
			qPos.add(confiscatedPeriod);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where confiscatedPeriod = &#63; from the database.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByconfiscatedPeriod(String confiscatedPeriod)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByconfiscatedPeriod(
				confiscatedPeriod, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where confiscatedPeriod = &#63;.
	 *
	 * @param confiscatedPeriod the confiscated period
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByconfiscatedPeriod(String confiscatedPeriod)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CONFISCATEDPERIOD;

		Object[] finderArgs = new Object[] { confiscatedPeriod };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindConfiscatedPeriod = false;

			if (confiscatedPeriod == null) {
				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_1);
			}
			else if (confiscatedPeriod.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_3);
			}
			else {
				bindConfiscatedPeriod = true;

				query.append(_FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindConfiscatedPeriod) {
					qPos.add(confiscatedPeriod);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_1 =
		"sitaanAdmin.confiscatedPeriod IS NULL";
	private static final String _FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_2 =
		"sitaanAdmin.confiscatedPeriod = ?";
	private static final String _FINDER_COLUMN_CONFISCATEDPERIOD_CONFISCATEDPERIOD_3 =
		"(sitaanAdmin.confiscatedPeriod IS NULL OR sitaanAdmin.confiscatedPeriod = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_SOURCE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBysource",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBysource",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.SOURCE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_SOURCE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBysource",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where source = &#63;.
	 *
	 * @param source the source
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBysource(String source)
		throws SystemException {
		return findBysource(source, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where source = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBysource(String source, int start, int end)
		throws SystemException {
		return findBysource(source, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where source = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBysource(String source, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE;
			finderArgs = new Object[] { source };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_SOURCE;
			finderArgs = new Object[] { source, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(source, sitaanAdmin.getSource())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBysource_First(String source,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBysource_First(source, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBysource_First(String source,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBysource(source, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBysource_Last(String source,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBysource_Last(source, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBysource_Last(String source,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBysource(source);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBysource(source, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBysource_PrevAndNext(long bilId, String source,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBysource_PrevAndNext(session, sitaanAdmin, source,
					orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBysource_PrevAndNext(session, sitaanAdmin, source,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBysource_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String source,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindSource = false;

		if (source == null) {
			query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
		}
		else if (source.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
		}
		else {
			bindSource = true;

			query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSource) {
			qPos.add(source);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where source = &#63; from the database.
	 *
	 * @param source the source
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBysource(String source) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBysource(source, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where source = &#63;.
	 *
	 * @param source the source
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBysource(String source) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_SOURCE;

		Object[] finderArgs = new Object[] { source };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SOURCE_SOURCE_1 = "sitaanAdmin.source IS NULL";
	private static final String _FINDER_COLUMN_SOURCE_SOURCE_2 = "sitaanAdmin.source = ?";
	private static final String _FINDER_COLUMN_SOURCE_SOURCE_3 = "(sitaanAdmin.source IS NULL OR sitaanAdmin.source = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_OWNERNAME =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByownerName",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OWNERNAME =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByownerName",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.OWNERNAME_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_OWNERNAME = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByownerName",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByownerName(String ownerName)
		throws SystemException {
		return findByownerName(ownerName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the sitaan admins where ownerName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ownerName the owner name
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByownerName(String ownerName, int start,
		int end) throws SystemException {
		return findByownerName(ownerName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where ownerName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param ownerName the owner name
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByownerName(String ownerName, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OWNERNAME;
			finderArgs = new Object[] { ownerName };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_OWNERNAME;
			finderArgs = new Object[] { ownerName, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(ownerName, sitaanAdmin.getOwnerName())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindOwnerName = false;

			if (ownerName == null) {
				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_1);
			}
			else if (ownerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_3);
			}
			else {
				bindOwnerName = true;

				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindOwnerName) {
					qPos.add(ownerName);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByownerName_First(String ownerName,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByownerName_First(ownerName,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ownerName=");
		msg.append(ownerName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByownerName_First(String ownerName,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findByownerName(ownerName, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByownerName_Last(String ownerName,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByownerName_Last(ownerName,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("ownerName=");
		msg.append(ownerName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByownerName_Last(String ownerName,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByownerName(ownerName);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByownerName(ownerName, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where ownerName = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param ownerName the owner name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByownerName_PrevAndNext(long bilId,
		String ownerName, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByownerName_PrevAndNext(session, sitaanAdmin,
					ownerName, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByownerName_PrevAndNext(session, sitaanAdmin,
					ownerName, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByownerName_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String ownerName,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindOwnerName = false;

		if (ownerName == null) {
			query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_1);
		}
		else if (ownerName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_3);
		}
		else {
			bindOwnerName = true;

			query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindOwnerName) {
			qPos.add(ownerName);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where ownerName = &#63; from the database.
	 *
	 * @param ownerName the owner name
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByownerName(String ownerName) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByownerName(ownerName,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where ownerName = &#63;.
	 *
	 * @param ownerName the owner name
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByownerName(String ownerName) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_OWNERNAME;

		Object[] finderArgs = new Object[] { ownerName };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindOwnerName = false;

			if (ownerName == null) {
				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_1);
			}
			else if (ownerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_3);
			}
			else {
				bindOwnerName = true;

				query.append(_FINDER_COLUMN_OWNERNAME_OWNERNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindOwnerName) {
					qPos.add(ownerName);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_OWNERNAME_OWNERNAME_1 = "sitaanAdmin.ownerName IS NULL";
	private static final String _FINDER_COLUMN_OWNERNAME_OWNERNAME_2 = "sitaanAdmin.ownerName = ?";
	private static final String _FINDER_COLUMN_OWNERNAME_OWNERNAME_3 = "(sitaanAdmin.ownerName IS NULL OR sitaanAdmin.ownerName = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByvehicleRegistrationNo",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByvehicleRegistrationNo",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.VEHICLEREGISTRATIONNO_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_VEHICLEREGISTRATIONNO = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByvehicleRegistrationNo",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByvehicleRegistrationNo(
		String vehicleRegistrationNo) throws SystemException {
		return findByvehicleRegistrationNo(vehicleRegistrationNo,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByvehicleRegistrationNo(
		String vehicleRegistrationNo, int start, int end)
		throws SystemException {
		return findByvehicleRegistrationNo(vehicleRegistrationNo, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where vehicleRegistrationNo = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByvehicleRegistrationNo(
		String vehicleRegistrationNo, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO;
			finderArgs = new Object[] { vehicleRegistrationNo };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO;
			finderArgs = new Object[] {
					vehicleRegistrationNo,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(vehicleRegistrationNo,
							sitaanAdmin.getVehicleRegistrationNo())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindVehicleRegistrationNo = false;

			if (vehicleRegistrationNo == null) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_1);
			}
			else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_3);
			}
			else {
				bindVehicleRegistrationNo = true;

				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVehicleRegistrationNo) {
					qPos.add(vehicleRegistrationNo);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByvehicleRegistrationNo_First(
		String vehicleRegistrationNo, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByvehicleRegistrationNo_First(vehicleRegistrationNo,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vehicleRegistrationNo=");
		msg.append(vehicleRegistrationNo);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByvehicleRegistrationNo_First(
		String vehicleRegistrationNo, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByvehicleRegistrationNo(vehicleRegistrationNo,
				0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByvehicleRegistrationNo_Last(
		String vehicleRegistrationNo, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByvehicleRegistrationNo_Last(vehicleRegistrationNo,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vehicleRegistrationNo=");
		msg.append(vehicleRegistrationNo);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByvehicleRegistrationNo_Last(
		String vehicleRegistrationNo, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByvehicleRegistrationNo(vehicleRegistrationNo);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByvehicleRegistrationNo(vehicleRegistrationNo,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where vehicleRegistrationNo = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByvehicleRegistrationNo_PrevAndNext(long bilId,
		String vehicleRegistrationNo, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByvehicleRegistrationNo_PrevAndNext(session,
					sitaanAdmin, vehicleRegistrationNo, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByvehicleRegistrationNo_PrevAndNext(session,
					sitaanAdmin, vehicleRegistrationNo, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByvehicleRegistrationNo_PrevAndNext(
		Session session, SitaanAdmin sitaanAdmin, String vehicleRegistrationNo,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindVehicleRegistrationNo = false;

		if (vehicleRegistrationNo == null) {
			query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_1);
		}
		else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_3);
		}
		else {
			bindVehicleRegistrationNo = true;

			query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindVehicleRegistrationNo) {
			qPos.add(vehicleRegistrationNo);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where vehicleRegistrationNo = &#63; from the database.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByvehicleRegistrationNo(String vehicleRegistrationNo)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByvehicleRegistrationNo(
				vehicleRegistrationNo, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
				null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where vehicleRegistrationNo = &#63;.
	 *
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByvehicleRegistrationNo(String vehicleRegistrationNo)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_VEHICLEREGISTRATIONNO;

		Object[] finderArgs = new Object[] { vehicleRegistrationNo };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindVehicleRegistrationNo = false;

			if (vehicleRegistrationNo == null) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_1);
			}
			else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_3);
			}
			else {
				bindVehicleRegistrationNo = true;

				query.append(_FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVehicleRegistrationNo) {
					qPos.add(vehicleRegistrationNo);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_1 =
		"sitaanAdmin.vehicleRegistrationNo IS NULL";
	private static final String _FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_2 =
		"sitaanAdmin.vehicleRegistrationNo = ?";
	private static final String _FINDER_COLUMN_VEHICLEREGISTRATIONNO_VEHICLEREGISTRATIONNO_3 =
		"(sitaanAdmin.vehicleRegistrationNo IS NULL OR sitaanAdmin.vehicleRegistrationNo = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TERRITORY =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByterritory",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByterritory",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.TERRITORY_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TERRITORY = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByterritory",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where territory = &#63;.
	 *
	 * @param territory the territory
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByterritory(String territory)
		throws SystemException {
		return findByterritory(territory, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the sitaan admins where territory = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param territory the territory
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByterritory(String territory, int start,
		int end) throws SystemException {
		return findByterritory(territory, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where territory = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param territory the territory
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByterritory(String territory, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY;
			finderArgs = new Object[] { territory };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TERRITORY;
			finderArgs = new Object[] { territory, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(territory, sitaanAdmin.getTerritory())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTerritory) {
					qPos.add(territory);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByterritory_First(String territory,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByterritory_First(territory,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("territory=");
		msg.append(territory);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByterritory_First(String territory,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findByterritory(territory, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByterritory_Last(String territory,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByterritory_Last(territory,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("territory=");
		msg.append(territory);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByterritory_Last(String territory,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByterritory(territory);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByterritory(territory, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where territory = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByterritory_PrevAndNext(long bilId,
		String territory, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByterritory_PrevAndNext(session, sitaanAdmin,
					territory, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByterritory_PrevAndNext(session, sitaanAdmin,
					territory, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByterritory_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String territory,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindTerritory = false;

		if (territory == null) {
			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
		}
		else if (territory.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
		}
		else {
			bindTerritory = true;

			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTerritory) {
			qPos.add(territory);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where territory = &#63; from the database.
	 *
	 * @param territory the territory
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByterritory(String territory) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByterritory(territory,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where territory = &#63;.
	 *
	 * @param territory the territory
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByterritory(String territory) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TERRITORY;

		Object[] finderArgs = new Object[] { territory };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTerritory) {
					qPos.add(territory);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_1 = "sitaanAdmin.territory IS NULL";
	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_2 = "sitaanAdmin.territory = ?";
	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_3 = "(sitaanAdmin.territory IS NULL OR sitaanAdmin.territory = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STATE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBystate",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBystate",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.STATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STATE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBystate",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where state = &#63;.
	 *
	 * @param state the state
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBystate(String state)
		throws SystemException {
		return findBystate(state, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBystate(String state, int start, int end)
		throws SystemException {
		return findBystate(state, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBystate(String state, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE;
			finderArgs = new Object[] { state };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STATE;
			finderArgs = new Object[] { state, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(state, sitaanAdmin.getState())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_STATE_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindState) {
					qPos.add(state);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBystate_First(String state,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBystate_First(state, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("state=");
		msg.append(state);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBystate_First(String state,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBystate(state, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBystate_Last(String state,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBystate_Last(state, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("state=");
		msg.append(state);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBystate_Last(String state,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBystate(state);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBystate(state, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where state = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBystate_PrevAndNext(long bilId, String state,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBystate_PrevAndNext(session, sitaanAdmin, state,
					orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBystate_PrevAndNext(session, sitaanAdmin, state,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBystate_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String state,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindState = false;

		if (state == null) {
			query.append(_FINDER_COLUMN_STATE_STATE_1);
		}
		else if (state.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_STATE_STATE_3);
		}
		else {
			bindState = true;

			query.append(_FINDER_COLUMN_STATE_STATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindState) {
			qPos.add(state);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where state = &#63; from the database.
	 *
	 * @param state the state
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBystate(String state) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBystate(state, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where state = &#63;.
	 *
	 * @param state the state
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBystate(String state) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STATE;

		Object[] finderArgs = new Object[] { state };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_STATE_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindState) {
					qPos.add(state);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATE_STATE_1 = "sitaanAdmin.state IS NULL";
	private static final String _FINDER_COLUMN_STATE_STATE_2 = "sitaanAdmin.state = ?";
	private static final String _FINDER_COLUMN_STATE_STATE_3 = "(sitaanAdmin.state IS NULL OR sitaanAdmin.state = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_LOCATIONCAGESITA =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBylocationCageSita",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findBylocationCageSita", new String[] { String.class.getName() },
			SitaanAdminModelImpl.LOCATIONCAGESITA_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_LOCATIONCAGESITA = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countBylocationCageSita", new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBylocationCageSita(String locationCageSita)
		throws SystemException {
		return findBylocationCageSita(locationCageSita, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where locationCageSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param locationCageSita the location cage sita
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBylocationCageSita(String locationCageSita,
		int start, int end) throws SystemException {
		return findBylocationCageSita(locationCageSita, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where locationCageSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param locationCageSita the location cage sita
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBylocationCageSita(String locationCageSita,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA;
			finderArgs = new Object[] { locationCageSita };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_LOCATIONCAGESITA;
			finderArgs = new Object[] {
					locationCageSita,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(locationCageSita,
							sitaanAdmin.getLocationCageSita())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBylocationCageSita_First(String locationCageSita,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBylocationCageSita_First(locationCageSita,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("locationCageSita=");
		msg.append(locationCageSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBylocationCageSita_First(String locationCageSita,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBylocationCageSita(locationCageSita, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBylocationCageSita_Last(String locationCageSita,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBylocationCageSita_Last(locationCageSita,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("locationCageSita=");
		msg.append(locationCageSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBylocationCageSita_Last(String locationCageSita,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBylocationCageSita(locationCageSita);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBylocationCageSita(locationCageSita,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where locationCageSita = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBylocationCageSita_PrevAndNext(long bilId,
		String locationCageSita, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBylocationCageSita_PrevAndNext(session, sitaanAdmin,
					locationCageSita, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBylocationCageSita_PrevAndNext(session, sitaanAdmin,
					locationCageSita, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBylocationCageSita_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String locationCageSita,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindLocationCageSita = false;

		if (locationCageSita == null) {
			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
		}
		else if (locationCageSita.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
		}
		else {
			bindLocationCageSita = true;

			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindLocationCageSita) {
			qPos.add(locationCageSita);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where locationCageSita = &#63; from the database.
	 *
	 * @param locationCageSita the location cage sita
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBylocationCageSita(String locationCageSita)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBylocationCageSita(
				locationCageSita, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBylocationCageSita(String locationCageSita)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_LOCATIONCAGESITA;

		Object[] finderArgs = new Object[] { locationCageSita };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1 =
		"sitaanAdmin.locationCageSita IS NULL";
	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2 =
		"sitaanAdmin.locationCageSita = ?";
	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3 =
		"(sitaanAdmin.locationCageSita IS NULL OR sitaanAdmin.locationCageSita = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_FORECLOSURESTATUS =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByforeclosureStatus",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByforeclosureStatus", new String[] { String.class.getName() },
			SitaanAdminModelImpl.FORECLOSURESTATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_FORECLOSURESTATUS = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByforeclosureStatus", new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		return findByforeclosureStatus(foreclosureStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where foreclosureStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByforeclosureStatus(String foreclosureStatus,
		int start, int end) throws SystemException {
		return findByforeclosureStatus(foreclosureStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where foreclosureStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByforeclosureStatus(String foreclosureStatus,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS;
			finderArgs = new Object[] { foreclosureStatus };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_FORECLOSURESTATUS;
			finderArgs = new Object[] {
					foreclosureStatus,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(foreclosureStatus,
							sitaanAdmin.getForeclosureStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByforeclosureStatus_First(String foreclosureStatus,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByforeclosureStatus_First(foreclosureStatus,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByforeclosureStatus_First(
		String foreclosureStatus, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByforeclosureStatus(foreclosureStatus, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByforeclosureStatus_Last(String foreclosureStatus,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByforeclosureStatus_Last(foreclosureStatus,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByforeclosureStatus_Last(String foreclosureStatus,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByforeclosureStatus(foreclosureStatus);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByforeclosureStatus(foreclosureStatus,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByforeclosureStatus_PrevAndNext(long bilId,
		String foreclosureStatus, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByforeclosureStatus_PrevAndNext(session, sitaanAdmin,
					foreclosureStatus, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByforeclosureStatus_PrevAndNext(session, sitaanAdmin,
					foreclosureStatus, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByforeclosureStatus_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String foreclosureStatus,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindForeclosureStatus = false;

		if (foreclosureStatus == null) {
			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
		}
		else if (foreclosureStatus.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
		}
		else {
			bindForeclosureStatus = true;

			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindForeclosureStatus) {
			qPos.add(foreclosureStatus);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where foreclosureStatus = &#63; from the database.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByforeclosureStatus(
				foreclosureStatus, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_FORECLOSURESTATUS;

		Object[] finderArgs = new Object[] { foreclosureStatus };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1 =
		"sitaanAdmin.foreclosureStatus IS NULL";
	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2 =
		"sitaanAdmin.foreclosureStatus = ?";
	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3 =
		"(sitaanAdmin.foreclosureStatus IS NULL OR sitaanAdmin.foreclosureStatus = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_RESULTSFORECLOSURE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByresultsforeclosure",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RESULTSFORECLOSURE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByresultsforeclosure",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.RESULTSFORECLOSURE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_RESULTSFORECLOSURE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByresultsforeclosure", new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByresultsforeclosure(String resultsforeclosure)
		throws SystemException {
		return findByresultsforeclosure(resultsforeclosure, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where resultsforeclosure = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByresultsforeclosure(
		String resultsforeclosure, int start, int end)
		throws SystemException {
		return findByresultsforeclosure(resultsforeclosure, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where resultsforeclosure = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByresultsforeclosure(
		String resultsforeclosure, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RESULTSFORECLOSURE;
			finderArgs = new Object[] { resultsforeclosure };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_RESULTSFORECLOSURE;
			finderArgs = new Object[] {
					resultsforeclosure,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(resultsforeclosure,
							sitaanAdmin.getResultsforeclosure())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindResultsforeclosure = false;

			if (resultsforeclosure == null) {
				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_1);
			}
			else if (resultsforeclosure.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_3);
			}
			else {
				bindResultsforeclosure = true;

				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindResultsforeclosure) {
					qPos.add(resultsforeclosure);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByresultsforeclosure_First(
		String resultsforeclosure, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByresultsforeclosure_First(resultsforeclosure,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("resultsforeclosure=");
		msg.append(resultsforeclosure);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByresultsforeclosure_First(
		String resultsforeclosure, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByresultsforeclosure(resultsforeclosure,
				0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByresultsforeclosure_Last(
		String resultsforeclosure, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByresultsforeclosure_Last(resultsforeclosure,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("resultsforeclosure=");
		msg.append(resultsforeclosure);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByresultsforeclosure_Last(
		String resultsforeclosure, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByresultsforeclosure(resultsforeclosure);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByresultsforeclosure(resultsforeclosure,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where resultsforeclosure = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param resultsforeclosure the resultsforeclosure
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByresultsforeclosure_PrevAndNext(long bilId,
		String resultsforeclosure, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByresultsforeclosure_PrevAndNext(session,
					sitaanAdmin, resultsforeclosure, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByresultsforeclosure_PrevAndNext(session,
					sitaanAdmin, resultsforeclosure, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByresultsforeclosure_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String resultsforeclosure,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindResultsforeclosure = false;

		if (resultsforeclosure == null) {
			query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_1);
		}
		else if (resultsforeclosure.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_3);
		}
		else {
			bindResultsforeclosure = true;

			query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindResultsforeclosure) {
			qPos.add(resultsforeclosure);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where resultsforeclosure = &#63; from the database.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByresultsforeclosure(String resultsforeclosure)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByresultsforeclosure(
				resultsforeclosure, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where resultsforeclosure = &#63;.
	 *
	 * @param resultsforeclosure the resultsforeclosure
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByresultsforeclosure(String resultsforeclosure)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_RESULTSFORECLOSURE;

		Object[] finderArgs = new Object[] { resultsforeclosure };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindResultsforeclosure = false;

			if (resultsforeclosure == null) {
				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_1);
			}
			else if (resultsforeclosure.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_3);
			}
			else {
				bindResultsforeclosure = true;

				query.append(_FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindResultsforeclosure) {
					qPos.add(resultsforeclosure);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_1 =
		"sitaanAdmin.resultsforeclosure IS NULL";
	private static final String _FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_2 =
		"sitaanAdmin.resultsforeclosure = ?";
	private static final String _FINDER_COLUMN_RESULTSFORECLOSURE_RESULTSFORECLOSURE_3 =
		"(sitaanAdmin.resultsforeclosure IS NULL OR sitaanAdmin.resultsforeclosure = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_PAYMENTSTATUS =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBypaymentStatus",
			new String[] {
				Boolean.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PAYMENTSTATUS =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBypaymentStatus",
			new String[] { Boolean.class.getName() },
			SitaanAdminModelImpl.PAYMENTSTATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PAYMENTSTATUS = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBypaymentStatus",
			new String[] { Boolean.class.getName() });

	/**
	 * Returns all the sitaan admins where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBypaymentStatus(boolean paymentStatus)
		throws SystemException {
		return findBypaymentStatus(paymentStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where paymentStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param paymentStatus the payment status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBypaymentStatus(boolean paymentStatus,
		int start, int end) throws SystemException {
		return findBypaymentStatus(paymentStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where paymentStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param paymentStatus the payment status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findBypaymentStatus(boolean paymentStatus,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PAYMENTSTATUS;
			finderArgs = new Object[] { paymentStatus };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_PAYMENTSTATUS;
			finderArgs = new Object[] {
					paymentStatus,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if ((paymentStatus != sitaanAdmin.getPaymentStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			query.append(_FINDER_COLUMN_PAYMENTSTATUS_PAYMENTSTATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(paymentStatus);

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBypaymentStatus_First(boolean paymentStatus,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBypaymentStatus_First(paymentStatus,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("paymentStatus=");
		msg.append(paymentStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBypaymentStatus_First(boolean paymentStatus,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findBypaymentStatus(paymentStatus, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findBypaymentStatus_Last(boolean paymentStatus,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchBypaymentStatus_Last(paymentStatus,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("paymentStatus=");
		msg.append(paymentStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchBypaymentStatus_Last(boolean paymentStatus,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBypaymentStatus(paymentStatus);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findBypaymentStatus(paymentStatus, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where paymentStatus = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findBypaymentStatus_PrevAndNext(long bilId,
		boolean paymentStatus, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getBypaymentStatus_PrevAndNext(session, sitaanAdmin,
					paymentStatus, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getBypaymentStatus_PrevAndNext(session, sitaanAdmin,
					paymentStatus, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getBypaymentStatus_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, boolean paymentStatus,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		query.append(_FINDER_COLUMN_PAYMENTSTATUS_PAYMENTSTATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(paymentStatus);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where paymentStatus = &#63; from the database.
	 *
	 * @param paymentStatus the payment status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBypaymentStatus(boolean paymentStatus)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findBypaymentStatus(paymentStatus,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where paymentStatus = &#63;.
	 *
	 * @param paymentStatus the payment status
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBypaymentStatus(boolean paymentStatus)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PAYMENTSTATUS;

		Object[] finderArgs = new Object[] { paymentStatus };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			query.append(_FINDER_COLUMN_PAYMENTSTATUS_PAYMENTSTATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(paymentStatus);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PAYMENTSTATUS_PAYMENTSTATUS_2 = "sitaanAdmin.paymentStatus = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_OFFICERNAME =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByofficerName",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERNAME =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByofficerName",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.OFFICERNAME_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_OFFICERNAME = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByofficerName",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByofficerName(String officerName)
		throws SystemException {
		return findByofficerName(officerName, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where officerName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param officerName the officer name
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByofficerName(String officerName, int start,
		int end) throws SystemException {
		return findByofficerName(officerName, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where officerName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param officerName the officer name
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByofficerName(String officerName, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERNAME;
			finderArgs = new Object[] { officerName };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_OFFICERNAME;
			finderArgs = new Object[] { officerName, start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(officerName, sitaanAdmin.getOfficerName())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindOfficerName = false;

			if (officerName == null) {
				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_1);
			}
			else if (officerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_3);
			}
			else {
				bindOfficerName = true;

				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindOfficerName) {
					qPos.add(officerName);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByofficerName_First(String officerName,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByofficerName_First(officerName,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("officerName=");
		msg.append(officerName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByofficerName_First(String officerName,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findByofficerName(officerName, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByofficerName_Last(String officerName,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByofficerName_Last(officerName,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("officerName=");
		msg.append(officerName);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByofficerName_Last(String officerName,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByofficerName(officerName);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByofficerName(officerName, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where officerName = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param officerName the officer name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByofficerName_PrevAndNext(long bilId,
		String officerName, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByofficerName_PrevAndNext(session, sitaanAdmin,
					officerName, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByofficerName_PrevAndNext(session, sitaanAdmin,
					officerName, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByofficerName_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String officerName,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindOfficerName = false;

		if (officerName == null) {
			query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_1);
		}
		else if (officerName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_3);
		}
		else {
			bindOfficerName = true;

			query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindOfficerName) {
			qPos.add(officerName);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where officerName = &#63; from the database.
	 *
	 * @param officerName the officer name
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByofficerName(String officerName)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByofficerName(officerName,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where officerName = &#63;.
	 *
	 * @param officerName the officer name
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByofficerName(String officerName) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_OFFICERNAME;

		Object[] finderArgs = new Object[] { officerName };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindOfficerName = false;

			if (officerName == null) {
				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_1);
			}
			else if (officerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_3);
			}
			else {
				bindOfficerName = true;

				query.append(_FINDER_COLUMN_OFFICERNAME_OFFICERNAME_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindOfficerName) {
					qPos.add(officerName);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_OFFICERNAME_OFFICERNAME_1 = "sitaanAdmin.officerName IS NULL";
	private static final String _FINDER_COLUMN_OFFICERNAME_OFFICERNAME_2 = "sitaanAdmin.officerName = ?";
	private static final String _FINDER_COLUMN_OFFICERNAME_OFFICERNAME_3 = "(sitaanAdmin.officerName IS NULL OR sitaanAdmin.officerName = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_RIGHTSRELEASED =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByrightsReleased",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RIGHTSRELEASED =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByrightsReleased",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.RIGHTSRELEASED_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_RIGHTSRELEASED = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByrightsReleased",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByrightsReleased(String rightsReleased)
		throws SystemException {
		return findByrightsReleased(rightsReleased, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where rightsReleased = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param rightsReleased the rights released
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByrightsReleased(String rightsReleased,
		int start, int end) throws SystemException {
		return findByrightsReleased(rightsReleased, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where rightsReleased = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param rightsReleased the rights released
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByrightsReleased(String rightsReleased,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RIGHTSRELEASED;
			finderArgs = new Object[] { rightsReleased };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_RIGHTSRELEASED;
			finderArgs = new Object[] {
					rightsReleased,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(rightsReleased,
							sitaanAdmin.getRightsReleased())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindRightsReleased = false;

			if (rightsReleased == null) {
				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_1);
			}
			else if (rightsReleased.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_3);
			}
			else {
				bindRightsReleased = true;

				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindRightsReleased) {
					qPos.add(rightsReleased);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByrightsReleased_First(String rightsReleased,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByrightsReleased_First(rightsReleased,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("rightsReleased=");
		msg.append(rightsReleased);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByrightsReleased_First(String rightsReleased,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findByrightsReleased(rightsReleased, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByrightsReleased_Last(String rightsReleased,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByrightsReleased_Last(rightsReleased,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("rightsReleased=");
		msg.append(rightsReleased);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByrightsReleased_Last(String rightsReleased,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByrightsReleased(rightsReleased);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByrightsReleased(rightsReleased,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where rightsReleased = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param rightsReleased the rights released
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByrightsReleased_PrevAndNext(long bilId,
		String rightsReleased, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByrightsReleased_PrevAndNext(session, sitaanAdmin,
					rightsReleased, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByrightsReleased_PrevAndNext(session, sitaanAdmin,
					rightsReleased, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByrightsReleased_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String rightsReleased,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindRightsReleased = false;

		if (rightsReleased == null) {
			query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_1);
		}
		else if (rightsReleased.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_3);
		}
		else {
			bindRightsReleased = true;

			query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindRightsReleased) {
			qPos.add(rightsReleased);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where rightsReleased = &#63; from the database.
	 *
	 * @param rightsReleased the rights released
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByrightsReleased(String rightsReleased)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByrightsReleased(rightsReleased,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where rightsReleased = &#63;.
	 *
	 * @param rightsReleased the rights released
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByrightsReleased(String rightsReleased)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_RIGHTSRELEASED;

		Object[] finderArgs = new Object[] { rightsReleased };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindRightsReleased = false;

			if (rightsReleased == null) {
				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_1);
			}
			else if (rightsReleased.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_3);
			}
			else {
				bindRightsReleased = true;

				query.append(_FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindRightsReleased) {
					qPos.add(rightsReleased);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_1 = "sitaanAdmin.rightsReleased IS NULL";
	private static final String _FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_2 = "sitaanAdmin.rightsReleased = ?";
	private static final String _FINDER_COLUMN_RIGHTSRELEASED_RIGHTSRELEASED_3 = "(sitaanAdmin.rightsReleased IS NULL OR sitaanAdmin.rightsReleased = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ACCEPTANCEDATE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByacceptancedate",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACCEPTANCEDATE =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByacceptancedate",
			new String[] { String.class.getName() },
			SitaanAdminModelImpl.ACCEPTANCEDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ACCEPTANCEDATE = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByacceptancedate",
			new String[] { String.class.getName() });

	/**
	 * Returns all the sitaan admins where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByacceptancedate(String acceptancedate)
		throws SystemException {
		return findByacceptancedate(acceptancedate, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where acceptancedate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param acceptancedate the acceptancedate
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByacceptancedate(String acceptancedate,
		int start, int end) throws SystemException {
		return findByacceptancedate(acceptancedate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where acceptancedate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param acceptancedate the acceptancedate
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByacceptancedate(String acceptancedate,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACCEPTANCEDATE;
			finderArgs = new Object[] { acceptancedate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ACCEPTANCEDATE;
			finderArgs = new Object[] {
					acceptancedate,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(acceptancedate,
							sitaanAdmin.getAcceptancedate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindAcceptancedate = false;

			if (acceptancedate == null) {
				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_1);
			}
			else if (acceptancedate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_3);
			}
			else {
				bindAcceptancedate = true;

				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAcceptancedate) {
					qPos.add(acceptancedate);
				}

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByacceptancedate_First(String acceptancedate,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByacceptancedate_First(acceptancedate,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("acceptancedate=");
		msg.append(acceptancedate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByacceptancedate_First(String acceptancedate,
		OrderByComparator orderByComparator) throws SystemException {
		List<SitaanAdmin> list = findByacceptancedate(acceptancedate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByacceptancedate_Last(String acceptancedate,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByacceptancedate_Last(acceptancedate,
				orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("acceptancedate=");
		msg.append(acceptancedate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByacceptancedate_Last(String acceptancedate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByacceptancedate(acceptancedate);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByacceptancedate(acceptancedate,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where acceptancedate = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param acceptancedate the acceptancedate
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByacceptancedate_PrevAndNext(long bilId,
		String acceptancedate, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByacceptancedate_PrevAndNext(session, sitaanAdmin,
					acceptancedate, orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByacceptancedate_PrevAndNext(session, sitaanAdmin,
					acceptancedate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByacceptancedate_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String acceptancedate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindAcceptancedate = false;

		if (acceptancedate == null) {
			query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_1);
		}
		else if (acceptancedate.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_3);
		}
		else {
			bindAcceptancedate = true;

			query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindAcceptancedate) {
			qPos.add(acceptancedate);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where acceptancedate = &#63; from the database.
	 *
	 * @param acceptancedate the acceptancedate
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByacceptancedate(String acceptancedate)
		throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByacceptancedate(acceptancedate,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where acceptancedate = &#63;.
	 *
	 * @param acceptancedate the acceptancedate
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByacceptancedate(String acceptancedate)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ACCEPTANCEDATE;

		Object[] finderArgs = new Object[] { acceptancedate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindAcceptancedate = false;

			if (acceptancedate == null) {
				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_1);
			}
			else if (acceptancedate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_3);
			}
			else {
				bindAcceptancedate = true;

				query.append(_FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAcceptancedate) {
					qPos.add(acceptancedate);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_1 = "sitaanAdmin.acceptancedate IS NULL";
	private static final String _FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_2 = "sitaanAdmin.acceptancedate = ?";
	private static final String _FINDER_COLUMN_ACCEPTANCEDATE_ACCEPTANCEDATE_3 = "(sitaanAdmin.acceptancedate IS NULL OR sitaanAdmin.acceptancedate = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_FINEDBYCOLUMN =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByFinedByColumn",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FINEDBYCOLUMN =
		new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, SitaanAdminImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByFinedByColumn",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName()
			},
			SitaanAdminModelImpl.SOURCE_COLUMN_BITMASK |
			SitaanAdminModelImpl.OWNERNAME_COLUMN_BITMASK |
			SitaanAdminModelImpl.TERRITORY_COLUMN_BITMASK |
			SitaanAdminModelImpl.VEHICLEREGISTRATIONNO_COLUMN_BITMASK |
			SitaanAdminModelImpl.DATESEIZED_COLUMN_BITMASK |
			SitaanAdminModelImpl.CHECKSITESSITA_COLUMN_BITMASK |
			SitaanAdminModelImpl.REFERENCEEFFECTIVE_COLUMN_BITMASK |
			SitaanAdminModelImpl.CONFISCATEDPERIOD_COLUMN_BITMASK |
			SitaanAdminModelImpl.STATE_COLUMN_BITMASK |
			SitaanAdminModelImpl.LOCATIONCAGESITA_COLUMN_BITMASK |
			SitaanAdminModelImpl.FORECLOSURESTATUS_COLUMN_BITMASK |
			SitaanAdminModelImpl.RESULTSFORECLOSURE_COLUMN_BITMASK |
			SitaanAdminModelImpl.OFFICERNAME_COLUMN_BITMASK |
			SitaanAdminModelImpl.RIGHTSRELEASED_COLUMN_BITMASK |
			SitaanAdminModelImpl.ACCEPTANCEDATE_COLUMN_BITMASK |
			SitaanAdminModelImpl.PAYMENTSTATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_FINEDBYCOLUMN = new FinderPath(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByFinedByColumn",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), String.class.getName(),
				String.class.getName(), Boolean.class.getName()
			});

	/**
	 * Returns all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @return the matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByFinedByColumn(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus) throws SystemException {
		return findByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByFinedByColumn(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, int start, int end) throws SystemException {
		return findByFinedByColumn(source, ownerName, territory,
			vehicleRegistrationNo, dateSeized, checkSitesSita,
			referenceEffective, confiscatedPeriod, state, locationCageSita,
			foreclosureStatus, resultsforeclosure, officerName, rightsReleased,
			acceptancedate, paymentStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findByFinedByColumn(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FINEDBYCOLUMN;
			finderArgs = new Object[] {
					source, ownerName, territory, vehicleRegistrationNo,
					dateSeized, checkSitesSita, referenceEffective,
					confiscatedPeriod, state, locationCageSita,
					foreclosureStatus, resultsforeclosure, officerName,
					rightsReleased, acceptancedate, paymentStatus
				};
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_FINEDBYCOLUMN;
			finderArgs = new Object[] {
					source, ownerName, territory, vehicleRegistrationNo,
					dateSeized, checkSitesSita, referenceEffective,
					confiscatedPeriod, state, locationCageSita,
					foreclosureStatus, resultsforeclosure, officerName,
					rightsReleased, acceptancedate, paymentStatus,
					
					start, end, orderByComparator
				};
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SitaanAdmin sitaanAdmin : list) {
				if (!Validator.equals(source, sitaanAdmin.getSource()) ||
						!Validator.equals(ownerName, sitaanAdmin.getOwnerName()) ||
						!Validator.equals(territory, sitaanAdmin.getTerritory()) ||
						!Validator.equals(vehicleRegistrationNo,
							sitaanAdmin.getVehicleRegistrationNo()) ||
						!Validator.equals(dateSeized,
							sitaanAdmin.getDateSeized()) ||
						!Validator.equals(checkSitesSita,
							sitaanAdmin.getCheckSitesSita()) ||
						!Validator.equals(referenceEffective,
							sitaanAdmin.getReferenceEffective()) ||
						!Validator.equals(confiscatedPeriod,
							sitaanAdmin.getConfiscatedPeriod()) ||
						!Validator.equals(state, sitaanAdmin.getState()) ||
						!Validator.equals(locationCageSita,
							sitaanAdmin.getLocationCageSita()) ||
						!Validator.equals(foreclosureStatus,
							sitaanAdmin.getForeclosureStatus()) ||
						!Validator.equals(resultsforeclosure,
							sitaanAdmin.getResultsforeclosure()) ||
						!Validator.equals(officerName,
							sitaanAdmin.getOfficerName()) ||
						!Validator.equals(rightsReleased,
							sitaanAdmin.getRightsReleased()) ||
						!Validator.equals(acceptancedate,
							sitaanAdmin.getAcceptancedate()) ||
						(paymentStatus != sitaanAdmin.getPaymentStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(18 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(18);
			}

			query.append(_SQL_SELECT_SITAANADMIN_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_2);
			}

			boolean bindOwnerName = false;

			if (ownerName == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_1);
			}
			else if (ownerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_3);
			}
			else {
				bindOwnerName = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_2);
			}

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_2);
			}

			boolean bindVehicleRegistrationNo = false;

			if (vehicleRegistrationNo == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_1);
			}
			else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_3);
			}
			else {
				bindVehicleRegistrationNo = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_2);
			}

			boolean bindDateSeized = false;

			if (dateSeized == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_1);
			}
			else if (dateSeized.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_3);
			}
			else {
				bindDateSeized = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_2);
			}

			boolean bindCheckSitesSita = false;

			if (checkSitesSita == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_1);
			}
			else if (checkSitesSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_3);
			}
			else {
				bindCheckSitesSita = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_2);
			}

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_2);
			}

			boolean bindConfiscatedPeriod = false;

			if (confiscatedPeriod == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_1);
			}
			else if (confiscatedPeriod.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_3);
			}
			else {
				bindConfiscatedPeriod = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_2);
			}

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_2);
			}

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_2);
			}

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_2);
			}

			boolean bindResultsforeclosure = false;

			if (resultsforeclosure == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_1);
			}
			else if (resultsforeclosure.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_3);
			}
			else {
				bindResultsforeclosure = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_2);
			}

			boolean bindOfficerName = false;

			if (officerName == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_1);
			}
			else if (officerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_3);
			}
			else {
				bindOfficerName = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_2);
			}

			boolean bindRightsReleased = false;

			if (rightsReleased == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_1);
			}
			else if (rightsReleased.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_3);
			}
			else {
				bindRightsReleased = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_2);
			}

			boolean bindAcceptancedate = false;

			if (acceptancedate == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_1);
			}
			else if (acceptancedate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_3);
			}
			else {
				bindAcceptancedate = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_2);
			}

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_PAYMENTSTATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				if (bindOwnerName) {
					qPos.add(ownerName);
				}

				if (bindTerritory) {
					qPos.add(territory);
				}

				if (bindVehicleRegistrationNo) {
					qPos.add(vehicleRegistrationNo);
				}

				if (bindDateSeized) {
					qPos.add(dateSeized);
				}

				if (bindCheckSitesSita) {
					qPos.add(checkSitesSita);
				}

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				if (bindConfiscatedPeriod) {
					qPos.add(confiscatedPeriod);
				}

				if (bindState) {
					qPos.add(state);
				}

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				if (bindResultsforeclosure) {
					qPos.add(resultsforeclosure);
				}

				if (bindOfficerName) {
					qPos.add(officerName);
				}

				if (bindRightsReleased) {
					qPos.add(rightsReleased);
				}

				if (bindAcceptancedate) {
					qPos.add(acceptancedate);
				}

				qPos.add(paymentStatus);

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByFinedByColumn_First(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByFinedByColumn_First(source, ownerName,
				territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(34);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(", ownerName=");
		msg.append(ownerName);

		msg.append(", territory=");
		msg.append(territory);

		msg.append(", vehicleRegistrationNo=");
		msg.append(vehicleRegistrationNo);

		msg.append(", dateSeized=");
		msg.append(dateSeized);

		msg.append(", checkSitesSita=");
		msg.append(checkSitesSita);

		msg.append(", referenceEffective=");
		msg.append(referenceEffective);

		msg.append(", confiscatedPeriod=");
		msg.append(confiscatedPeriod);

		msg.append(", state=");
		msg.append(state);

		msg.append(", locationCageSita=");
		msg.append(locationCageSita);

		msg.append(", foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(", resultsforeclosure=");
		msg.append(resultsforeclosure);

		msg.append(", officerName=");
		msg.append(officerName);

		msg.append(", rightsReleased=");
		msg.append(rightsReleased);

		msg.append(", acceptancedate=");
		msg.append(acceptancedate);

		msg.append(", paymentStatus=");
		msg.append(paymentStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the first sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByFinedByColumn_First(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, OrderByComparator orderByComparator)
		throws SystemException {
		List<SitaanAdmin> list = findByFinedByColumn(source, ownerName,
				territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByFinedByColumn_Last(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByFinedByColumn_Last(source, ownerName,
				territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus, orderByComparator);

		if (sitaanAdmin != null) {
			return sitaanAdmin;
		}

		StringBundler msg = new StringBundler(34);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(", ownerName=");
		msg.append(ownerName);

		msg.append(", territory=");
		msg.append(territory);

		msg.append(", vehicleRegistrationNo=");
		msg.append(vehicleRegistrationNo);

		msg.append(", dateSeized=");
		msg.append(dateSeized);

		msg.append(", checkSitesSita=");
		msg.append(checkSitesSita);

		msg.append(", referenceEffective=");
		msg.append(referenceEffective);

		msg.append(", confiscatedPeriod=");
		msg.append(confiscatedPeriod);

		msg.append(", state=");
		msg.append(state);

		msg.append(", locationCageSita=");
		msg.append(locationCageSita);

		msg.append(", foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(", resultsforeclosure=");
		msg.append(resultsforeclosure);

		msg.append(", officerName=");
		msg.append(officerName);

		msg.append(", rightsReleased=");
		msg.append(rightsReleased);

		msg.append(", acceptancedate=");
		msg.append(acceptancedate);

		msg.append(", paymentStatus=");
		msg.append(paymentStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSitaanAdminException(msg.toString());
	}

	/**
	 * Returns the last sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sitaan admin, or <code>null</code> if a matching sitaan admin could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByFinedByColumn_Last(String source,
		String ownerName, String territory, String vehicleRegistrationNo,
		String dateSeized, String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByFinedByColumn(source, ownerName, territory,
				vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus);

		if (count == 0) {
			return null;
		}

		List<SitaanAdmin> list = findByFinedByColumn(source, ownerName,
				territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the sitaan admins before and after the current sitaan admin in the ordered set where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param bilId the primary key of the current sitaan admin
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin[] findByFinedByColumn_PrevAndNext(long bilId,
		String source, String ownerName, String territory,
		String vehicleRegistrationNo, String dateSeized, String checkSitesSita,
		String referenceEffective, String confiscatedPeriod, String state,
		String locationCageSita, String foreclosureStatus,
		String resultsforeclosure, String officerName, String rightsReleased,
		String acceptancedate, boolean paymentStatus,
		OrderByComparator orderByComparator)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = findByPrimaryKey(bilId);

		Session session = null;

		try {
			session = openSession();

			SitaanAdmin[] array = new SitaanAdminImpl[3];

			array[0] = getByFinedByColumn_PrevAndNext(session, sitaanAdmin,
					source, ownerName, territory, vehicleRegistrationNo,
					dateSeized, checkSitesSita, referenceEffective,
					confiscatedPeriod, state, locationCageSita,
					foreclosureStatus, resultsforeclosure, officerName,
					rightsReleased, acceptancedate, paymentStatus,
					orderByComparator, true);

			array[1] = sitaanAdmin;

			array[2] = getByFinedByColumn_PrevAndNext(session, sitaanAdmin,
					source, ownerName, territory, vehicleRegistrationNo,
					dateSeized, checkSitesSita, referenceEffective,
					confiscatedPeriod, state, locationCageSita,
					foreclosureStatus, resultsforeclosure, officerName,
					rightsReleased, acceptancedate, paymentStatus,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SitaanAdmin getByFinedByColumn_PrevAndNext(Session session,
		SitaanAdmin sitaanAdmin, String source, String ownerName,
		String territory, String vehicleRegistrationNo, String dateSeized,
		String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SITAANADMIN_WHERE);

		boolean bindSource = false;

		if (source == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_1);
		}
		else if (source.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_3);
		}
		else {
			bindSource = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_2);
		}

		boolean bindOwnerName = false;

		if (ownerName == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_1);
		}
		else if (ownerName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_3);
		}
		else {
			bindOwnerName = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_2);
		}

		boolean bindTerritory = false;

		if (territory == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_1);
		}
		else if (territory.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_3);
		}
		else {
			bindTerritory = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_2);
		}

		boolean bindVehicleRegistrationNo = false;

		if (vehicleRegistrationNo == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_1);
		}
		else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_3);
		}
		else {
			bindVehicleRegistrationNo = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_2);
		}

		boolean bindDateSeized = false;

		if (dateSeized == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_1);
		}
		else if (dateSeized.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_3);
		}
		else {
			bindDateSeized = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_2);
		}

		boolean bindCheckSitesSita = false;

		if (checkSitesSita == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_1);
		}
		else if (checkSitesSita.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_3);
		}
		else {
			bindCheckSitesSita = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_2);
		}

		boolean bindReferenceEffective = false;

		if (referenceEffective == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_1);
		}
		else if (referenceEffective.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_3);
		}
		else {
			bindReferenceEffective = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_2);
		}

		boolean bindConfiscatedPeriod = false;

		if (confiscatedPeriod == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_1);
		}
		else if (confiscatedPeriod.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_3);
		}
		else {
			bindConfiscatedPeriod = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_2);
		}

		boolean bindState = false;

		if (state == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_1);
		}
		else if (state.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_3);
		}
		else {
			bindState = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_2);
		}

		boolean bindLocationCageSita = false;

		if (locationCageSita == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_1);
		}
		else if (locationCageSita.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_3);
		}
		else {
			bindLocationCageSita = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_2);
		}

		boolean bindForeclosureStatus = false;

		if (foreclosureStatus == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_1);
		}
		else if (foreclosureStatus.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_3);
		}
		else {
			bindForeclosureStatus = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_2);
		}

		boolean bindResultsforeclosure = false;

		if (resultsforeclosure == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_1);
		}
		else if (resultsforeclosure.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_3);
		}
		else {
			bindResultsforeclosure = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_2);
		}

		boolean bindOfficerName = false;

		if (officerName == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_1);
		}
		else if (officerName.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_3);
		}
		else {
			bindOfficerName = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_2);
		}

		boolean bindRightsReleased = false;

		if (rightsReleased == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_1);
		}
		else if (rightsReleased.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_3);
		}
		else {
			bindRightsReleased = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_2);
		}

		boolean bindAcceptancedate = false;

		if (acceptancedate == null) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_1);
		}
		else if (acceptancedate.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_3);
		}
		else {
			bindAcceptancedate = true;

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_2);
		}

		query.append(_FINDER_COLUMN_FINEDBYCOLUMN_PAYMENTSTATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SitaanAdminModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSource) {
			qPos.add(source);
		}

		if (bindOwnerName) {
			qPos.add(ownerName);
		}

		if (bindTerritory) {
			qPos.add(territory);
		}

		if (bindVehicleRegistrationNo) {
			qPos.add(vehicleRegistrationNo);
		}

		if (bindDateSeized) {
			qPos.add(dateSeized);
		}

		if (bindCheckSitesSita) {
			qPos.add(checkSitesSita);
		}

		if (bindReferenceEffective) {
			qPos.add(referenceEffective);
		}

		if (bindConfiscatedPeriod) {
			qPos.add(confiscatedPeriod);
		}

		if (bindState) {
			qPos.add(state);
		}

		if (bindLocationCageSita) {
			qPos.add(locationCageSita);
		}

		if (bindForeclosureStatus) {
			qPos.add(foreclosureStatus);
		}

		if (bindResultsforeclosure) {
			qPos.add(resultsforeclosure);
		}

		if (bindOfficerName) {
			qPos.add(officerName);
		}

		if (bindRightsReleased) {
			qPos.add(rightsReleased);
		}

		if (bindAcceptancedate) {
			qPos.add(acceptancedate);
		}

		qPos.add(paymentStatus);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sitaanAdmin);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SitaanAdmin> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63; from the database.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByFinedByColumn(String source, String ownerName,
		String territory, String vehicleRegistrationNo, String dateSeized,
		String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus) throws SystemException {
		for (SitaanAdmin sitaanAdmin : findByFinedByColumn(source, ownerName,
				territory, vehicleRegistrationNo, dateSeized, checkSitesSita,
				referenceEffective, confiscatedPeriod, state, locationCageSita,
				foreclosureStatus, resultsforeclosure, officerName,
				rightsReleased, acceptancedate, paymentStatus,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins where source = &#63; and ownerName = &#63; and territory = &#63; and vehicleRegistrationNo = &#63; and dateSeized = &#63; and checkSitesSita = &#63; and referenceEffective = &#63; and confiscatedPeriod = &#63; and state = &#63; and locationCageSita = &#63; and foreclosureStatus = &#63; and resultsforeclosure = &#63; and officerName = &#63; and rightsReleased = &#63; and acceptancedate = &#63; and paymentStatus = &#63;.
	 *
	 * @param source the source
	 * @param ownerName the owner name
	 * @param territory the territory
	 * @param vehicleRegistrationNo the vehicle registration no
	 * @param dateSeized the date seized
	 * @param checkSitesSita the check sites sita
	 * @param referenceEffective the reference effective
	 * @param confiscatedPeriod the confiscated period
	 * @param state the state
	 * @param locationCageSita the location cage sita
	 * @param foreclosureStatus the foreclosure status
	 * @param resultsforeclosure the resultsforeclosure
	 * @param officerName the officer name
	 * @param rightsReleased the rights released
	 * @param acceptancedate the acceptancedate
	 * @param paymentStatus the payment status
	 * @return the number of matching sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByFinedByColumn(String source, String ownerName,
		String territory, String vehicleRegistrationNo, String dateSeized,
		String checkSitesSita, String referenceEffective,
		String confiscatedPeriod, String state, String locationCageSita,
		String foreclosureStatus, String resultsforeclosure,
		String officerName, String rightsReleased, String acceptancedate,
		boolean paymentStatus) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_FINEDBYCOLUMN;

		Object[] finderArgs = new Object[] {
				source, ownerName, territory, vehicleRegistrationNo, dateSeized,
				checkSitesSita, referenceEffective, confiscatedPeriod, state,
				locationCageSita, foreclosureStatus, resultsforeclosure,
				officerName, rightsReleased, acceptancedate, paymentStatus
			};

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(17);

			query.append(_SQL_COUNT_SITAANADMIN_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_2);
			}

			boolean bindOwnerName = false;

			if (ownerName == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_1);
			}
			else if (ownerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_3);
			}
			else {
				bindOwnerName = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_2);
			}

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_2);
			}

			boolean bindVehicleRegistrationNo = false;

			if (vehicleRegistrationNo == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_1);
			}
			else if (vehicleRegistrationNo.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_3);
			}
			else {
				bindVehicleRegistrationNo = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_2);
			}

			boolean bindDateSeized = false;

			if (dateSeized == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_1);
			}
			else if (dateSeized.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_3);
			}
			else {
				bindDateSeized = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_2);
			}

			boolean bindCheckSitesSita = false;

			if (checkSitesSita == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_1);
			}
			else if (checkSitesSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_3);
			}
			else {
				bindCheckSitesSita = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_2);
			}

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_2);
			}

			boolean bindConfiscatedPeriod = false;

			if (confiscatedPeriod == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_1);
			}
			else if (confiscatedPeriod.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_3);
			}
			else {
				bindConfiscatedPeriod = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_2);
			}

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_STATE_2);
			}

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_2);
			}

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_2);
			}

			boolean bindResultsforeclosure = false;

			if (resultsforeclosure == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_1);
			}
			else if (resultsforeclosure.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_3);
			}
			else {
				bindResultsforeclosure = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_2);
			}

			boolean bindOfficerName = false;

			if (officerName == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_1);
			}
			else if (officerName.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_3);
			}
			else {
				bindOfficerName = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_2);
			}

			boolean bindRightsReleased = false;

			if (rightsReleased == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_1);
			}
			else if (rightsReleased.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_3);
			}
			else {
				bindRightsReleased = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_2);
			}

			boolean bindAcceptancedate = false;

			if (acceptancedate == null) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_1);
			}
			else if (acceptancedate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_3);
			}
			else {
				bindAcceptancedate = true;

				query.append(_FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_2);
			}

			query.append(_FINDER_COLUMN_FINEDBYCOLUMN_PAYMENTSTATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				if (bindOwnerName) {
					qPos.add(ownerName);
				}

				if (bindTerritory) {
					qPos.add(territory);
				}

				if (bindVehicleRegistrationNo) {
					qPos.add(vehicleRegistrationNo);
				}

				if (bindDateSeized) {
					qPos.add(dateSeized);
				}

				if (bindCheckSitesSita) {
					qPos.add(checkSitesSita);
				}

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				if (bindConfiscatedPeriod) {
					qPos.add(confiscatedPeriod);
				}

				if (bindState) {
					qPos.add(state);
				}

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				if (bindResultsforeclosure) {
					qPos.add(resultsforeclosure);
				}

				if (bindOfficerName) {
					qPos.add(officerName);
				}

				if (bindRightsReleased) {
					qPos.add(rightsReleased);
				}

				if (bindAcceptancedate) {
					qPos.add(acceptancedate);
				}

				qPos.add(paymentStatus);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_1 = "sitaanAdmin.source IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_2 = "sitaanAdmin.source = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_SOURCE_3 = "(sitaanAdmin.source IS NULL OR sitaanAdmin.source = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_1 = "sitaanAdmin.ownerName IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_2 = "sitaanAdmin.ownerName = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OWNERNAME_3 = "(sitaanAdmin.ownerName IS NULL OR sitaanAdmin.ownerName = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_1 = "sitaanAdmin.territory IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_2 = "sitaanAdmin.territory = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_TERRITORY_3 = "(sitaanAdmin.territory IS NULL OR sitaanAdmin.territory = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_1 =
		"sitaanAdmin.vehicleRegistrationNo IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_2 =
		"sitaanAdmin.vehicleRegistrationNo = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_VEHICLEREGISTRATIONNO_3 =
		"(sitaanAdmin.vehicleRegistrationNo IS NULL OR sitaanAdmin.vehicleRegistrationNo = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_1 = "sitaanAdmin.dateSeized IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_2 = "sitaanAdmin.dateSeized = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_DATESEIZED_3 = "(sitaanAdmin.dateSeized IS NULL OR sitaanAdmin.dateSeized = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_1 = "sitaanAdmin.checkSitesSita IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_2 = "sitaanAdmin.checkSitesSita = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CHECKSITESSITA_3 = "(sitaanAdmin.checkSitesSita IS NULL OR sitaanAdmin.checkSitesSita = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_1 =
		"sitaanAdmin.referenceEffective IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_2 =
		"sitaanAdmin.referenceEffective = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_REFERENCEEFFECTIVE_3 =
		"(sitaanAdmin.referenceEffective IS NULL OR sitaanAdmin.referenceEffective = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_1 =
		"sitaanAdmin.confiscatedPeriod IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_2 =
		"sitaanAdmin.confiscatedPeriod = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_CONFISCATEDPERIOD_3 =
		"(sitaanAdmin.confiscatedPeriod IS NULL OR sitaanAdmin.confiscatedPeriod = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_STATE_1 = "sitaanAdmin.state IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_STATE_2 = "sitaanAdmin.state = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_STATE_3 = "(sitaanAdmin.state IS NULL OR sitaanAdmin.state = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_1 = "sitaanAdmin.locationCageSita IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_2 = "sitaanAdmin.locationCageSita = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_LOCATIONCAGESITA_3 = "(sitaanAdmin.locationCageSita IS NULL OR sitaanAdmin.locationCageSita = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_1 =
		"sitaanAdmin.foreclosureStatus IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_2 =
		"sitaanAdmin.foreclosureStatus = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_FORECLOSURESTATUS_3 =
		"(sitaanAdmin.foreclosureStatus IS NULL OR sitaanAdmin.foreclosureStatus = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_1 =
		"sitaanAdmin.resultsforeclosure IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_2 =
		"sitaanAdmin.resultsforeclosure = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RESULTSFORECLOSURE_3 =
		"(sitaanAdmin.resultsforeclosure IS NULL OR sitaanAdmin.resultsforeclosure = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_1 = "sitaanAdmin.officerName IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_2 = "sitaanAdmin.officerName = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_OFFICERNAME_3 = "(sitaanAdmin.officerName IS NULL OR sitaanAdmin.officerName = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_1 = "sitaanAdmin.rightsReleased IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_2 = "sitaanAdmin.rightsReleased = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_RIGHTSRELEASED_3 = "(sitaanAdmin.rightsReleased IS NULL OR sitaanAdmin.rightsReleased = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_1 = "sitaanAdmin.acceptancedate IS NULL AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_2 = "sitaanAdmin.acceptancedate = ? AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_ACCEPTANCEDATE_3 = "(sitaanAdmin.acceptancedate IS NULL OR sitaanAdmin.acceptancedate = '') AND ";
	private static final String _FINDER_COLUMN_FINEDBYCOLUMN_PAYMENTSTATUS_2 = "sitaanAdmin.paymentStatus = ?";

	public SitaanAdminPersistenceImpl() {
		setModelClass(SitaanAdmin.class);
	}

	/**
	 * Caches the sitaan admin in the entity cache if it is enabled.
	 *
	 * @param sitaanAdmin the sitaan admin
	 */
	@Override
	public void cacheResult(SitaanAdmin sitaanAdmin) {
		EntityCacheUtil.putResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminImpl.class, sitaanAdmin.getPrimaryKey(), sitaanAdmin);

		sitaanAdmin.resetOriginalValues();
	}

	/**
	 * Caches the sitaan admins in the entity cache if it is enabled.
	 *
	 * @param sitaanAdmins the sitaan admins
	 */
	@Override
	public void cacheResult(List<SitaanAdmin> sitaanAdmins) {
		for (SitaanAdmin sitaanAdmin : sitaanAdmins) {
			if (EntityCacheUtil.getResult(
						SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
						SitaanAdminImpl.class, sitaanAdmin.getPrimaryKey()) == null) {
				cacheResult(sitaanAdmin);
			}
			else {
				sitaanAdmin.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all sitaan admins.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SitaanAdminImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SitaanAdminImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the sitaan admin.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(SitaanAdmin sitaanAdmin) {
		EntityCacheUtil.removeResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminImpl.class, sitaanAdmin.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<SitaanAdmin> sitaanAdmins) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (SitaanAdmin sitaanAdmin : sitaanAdmins) {
			EntityCacheUtil.removeResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
				SitaanAdminImpl.class, sitaanAdmin.getPrimaryKey());
		}
	}

	/**
	 * Creates a new sitaan admin with the primary key. Does not add the sitaan admin to the database.
	 *
	 * @param bilId the primary key for the new sitaan admin
	 * @return the new sitaan admin
	 */
	@Override
	public SitaanAdmin create(long bilId) {
		SitaanAdmin sitaanAdmin = new SitaanAdminImpl();

		sitaanAdmin.setNew(true);
		sitaanAdmin.setPrimaryKey(bilId);

		return sitaanAdmin;
	}

	/**
	 * Removes the sitaan admin with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param bilId the primary key of the sitaan admin
	 * @return the sitaan admin that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin remove(long bilId)
		throws NoSuchSitaanAdminException, SystemException {
		return remove((Serializable)bilId);
	}

	/**
	 * Removes the sitaan admin with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the sitaan admin
	 * @return the sitaan admin that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin remove(Serializable primaryKey)
		throws NoSuchSitaanAdminException, SystemException {
		Session session = null;

		try {
			session = openSession();

			SitaanAdmin sitaanAdmin = (SitaanAdmin)session.get(SitaanAdminImpl.class,
					primaryKey);

			if (sitaanAdmin == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSitaanAdminException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(sitaanAdmin);
		}
		catch (NoSuchSitaanAdminException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected SitaanAdmin removeImpl(SitaanAdmin sitaanAdmin)
		throws SystemException {
		sitaanAdmin = toUnwrappedModel(sitaanAdmin);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(sitaanAdmin)) {
				sitaanAdmin = (SitaanAdmin)session.get(SitaanAdminImpl.class,
						sitaanAdmin.getPrimaryKeyObj());
			}

			if (sitaanAdmin != null) {
				session.delete(sitaanAdmin);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (sitaanAdmin != null) {
			clearCache(sitaanAdmin);
		}

		return sitaanAdmin;
	}

	@Override
	public SitaanAdmin updateImpl(
		com.org.skali.sitanAdmin.model.SitaanAdmin sitaanAdmin)
		throws SystemException {
		sitaanAdmin = toUnwrappedModel(sitaanAdmin);

		boolean isNew = sitaanAdmin.isNew();

		SitaanAdminModelImpl sitaanAdminModelImpl = (SitaanAdminModelImpl)sitaanAdmin;

		Session session = null;

		try {
			session = openSession();

			if (sitaanAdmin.isNew()) {
				session.save(sitaanAdmin);

				sitaanAdmin.setNew(false);
			}
			else {
				session.merge(sitaanAdmin);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SitaanAdminModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { sitaanAdminModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESEIZED.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalDateSeized()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATESEIZED,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESEIZED,
					args);

				args = new Object[] { sitaanAdminModelImpl.getDateSeized() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATESEIZED,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESEIZED,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESSITA.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalCheckSitesSita()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKSITESSITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESSITA,
					args);

				args = new Object[] { sitaanAdminModelImpl.getCheckSitesSita() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKSITESSITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESSITA,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalReferenceEffective()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE,
					args);

				args = new Object[] { sitaanAdminModelImpl.getReferenceEffective() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CONFISCATEDPERIOD.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalConfiscatedPeriod()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CONFISCATEDPERIOD,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CONFISCATEDPERIOD,
					args);

				args = new Object[] { sitaanAdminModelImpl.getConfiscatedPeriod() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CONFISCATEDPERIOD,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CONFISCATEDPERIOD,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalSource()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SOURCE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE,
					args);

				args = new Object[] { sitaanAdminModelImpl.getSource() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SOURCE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OWNERNAME.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalOwnerName()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OWNERNAME,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OWNERNAME,
					args);

				args = new Object[] { sitaanAdminModelImpl.getOwnerName() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OWNERNAME,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OWNERNAME,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalVehicleRegistrationNo()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICLEREGISTRATIONNO,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO,
					args);

				args = new Object[] {
						sitaanAdminModelImpl.getVehicleRegistrationNo()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICLEREGISTRATIONNO,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATIONNO,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalTerritory()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TERRITORY,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY,
					args);

				args = new Object[] { sitaanAdminModelImpl.getTerritory() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TERRITORY,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalState()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE,
					args);

				args = new Object[] { sitaanAdminModelImpl.getState() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalLocationCageSita()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_LOCATIONCAGESITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA,
					args);

				args = new Object[] { sitaanAdminModelImpl.getLocationCageSita() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_LOCATIONCAGESITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalForeclosureStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORECLOSURESTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS,
					args);

				args = new Object[] { sitaanAdminModelImpl.getForeclosureStatus() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORECLOSURESTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RESULTSFORECLOSURE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalResultsforeclosure()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RESULTSFORECLOSURE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RESULTSFORECLOSURE,
					args);

				args = new Object[] { sitaanAdminModelImpl.getResultsforeclosure() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RESULTSFORECLOSURE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RESULTSFORECLOSURE,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PAYMENTSTATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalPaymentStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PAYMENTSTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PAYMENTSTATUS,
					args);

				args = new Object[] { sitaanAdminModelImpl.getPaymentStatus() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PAYMENTSTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PAYMENTSTATUS,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERNAME.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalOfficerName()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OFFICERNAME,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERNAME,
					args);

				args = new Object[] { sitaanAdminModelImpl.getOfficerName() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OFFICERNAME,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERNAME,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RIGHTSRELEASED.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalRightsReleased()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RIGHTSRELEASED,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RIGHTSRELEASED,
					args);

				args = new Object[] { sitaanAdminModelImpl.getRightsReleased() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RIGHTSRELEASED,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RIGHTSRELEASED,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACCEPTANCEDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalAcceptancedate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACCEPTANCEDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACCEPTANCEDATE,
					args);

				args = new Object[] { sitaanAdminModelImpl.getAcceptancedate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACCEPTANCEDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACCEPTANCEDATE,
					args);
			}

			if ((sitaanAdminModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FINEDBYCOLUMN.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sitaanAdminModelImpl.getOriginalSource(),
						sitaanAdminModelImpl.getOriginalOwnerName(),
						sitaanAdminModelImpl.getOriginalTerritory(),
						sitaanAdminModelImpl.getOriginalVehicleRegistrationNo(),
						sitaanAdminModelImpl.getOriginalDateSeized(),
						sitaanAdminModelImpl.getOriginalCheckSitesSita(),
						sitaanAdminModelImpl.getOriginalReferenceEffective(),
						sitaanAdminModelImpl.getOriginalConfiscatedPeriod(),
						sitaanAdminModelImpl.getOriginalState(),
						sitaanAdminModelImpl.getOriginalLocationCageSita(),
						sitaanAdminModelImpl.getOriginalForeclosureStatus(),
						sitaanAdminModelImpl.getOriginalResultsforeclosure(),
						sitaanAdminModelImpl.getOriginalOfficerName(),
						sitaanAdminModelImpl.getOriginalRightsReleased(),
						sitaanAdminModelImpl.getOriginalAcceptancedate(),
						sitaanAdminModelImpl.getOriginalPaymentStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FINEDBYCOLUMN,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FINEDBYCOLUMN,
					args);

				args = new Object[] {
						sitaanAdminModelImpl.getSource(),
						sitaanAdminModelImpl.getOwnerName(),
						sitaanAdminModelImpl.getTerritory(),
						sitaanAdminModelImpl.getVehicleRegistrationNo(),
						sitaanAdminModelImpl.getDateSeized(),
						sitaanAdminModelImpl.getCheckSitesSita(),
						sitaanAdminModelImpl.getReferenceEffective(),
						sitaanAdminModelImpl.getConfiscatedPeriod(),
						sitaanAdminModelImpl.getState(),
						sitaanAdminModelImpl.getLocationCageSita(),
						sitaanAdminModelImpl.getForeclosureStatus(),
						sitaanAdminModelImpl.getResultsforeclosure(),
						sitaanAdminModelImpl.getOfficerName(),
						sitaanAdminModelImpl.getRightsReleased(),
						sitaanAdminModelImpl.getAcceptancedate(),
						sitaanAdminModelImpl.getPaymentStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FINEDBYCOLUMN,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FINEDBYCOLUMN,
					args);
			}
		}

		EntityCacheUtil.putResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
			SitaanAdminImpl.class, sitaanAdmin.getPrimaryKey(), sitaanAdmin);

		return sitaanAdmin;
	}

	protected SitaanAdmin toUnwrappedModel(SitaanAdmin sitaanAdmin) {
		if (sitaanAdmin instanceof SitaanAdminImpl) {
			return sitaanAdmin;
		}

		SitaanAdminImpl sitaanAdminImpl = new SitaanAdminImpl();

		sitaanAdminImpl.setNew(sitaanAdmin.isNew());
		sitaanAdminImpl.setPrimaryKey(sitaanAdmin.getPrimaryKey());

		sitaanAdminImpl.setBilId(sitaanAdmin.getBilId());
		sitaanAdminImpl.setDateSeized(sitaanAdmin.getDateSeized());
		sitaanAdminImpl.setCheckSitesSita(sitaanAdmin.getCheckSitesSita());
		sitaanAdminImpl.setReferenceEffective(sitaanAdmin.getReferenceEffective());
		sitaanAdminImpl.setConfiscatedPeriod(sitaanAdmin.getConfiscatedPeriod());
		sitaanAdminImpl.setSource(sitaanAdmin.getSource());
		sitaanAdminImpl.setOwnerName(sitaanAdmin.getOwnerName());
		sitaanAdminImpl.setVehicleRegistrationNo(sitaanAdmin.getVehicleRegistrationNo());
		sitaanAdminImpl.setTerritory(sitaanAdmin.getTerritory());
		sitaanAdminImpl.setState(sitaanAdmin.getState());
		sitaanAdminImpl.setLocationCageSita(sitaanAdmin.getLocationCageSita());
		sitaanAdminImpl.setForeclosureStatus(sitaanAdmin.getForeclosureStatus());
		sitaanAdminImpl.setResultsforeclosure(sitaanAdmin.getResultsforeclosure());
		sitaanAdminImpl.setOfficerName(sitaanAdmin.getOfficerName());
		sitaanAdminImpl.setAction(sitaanAdmin.getAction());
		sitaanAdminImpl.setActionBy(sitaanAdmin.getActionBy());
		sitaanAdminImpl.setRightsReleased(sitaanAdmin.getRightsReleased());
		sitaanAdminImpl.setAcceptancedate(sitaanAdmin.getAcceptancedate());
		sitaanAdminImpl.setPaymentStatus(sitaanAdmin.isPaymentStatus());
		sitaanAdminImpl.setCaseStatus(sitaanAdmin.getCaseStatus());
		sitaanAdminImpl.setError(sitaanAdmin.getError());
		sitaanAdminImpl.setCompanyName(sitaanAdmin.getCompanyName());
		sitaanAdminImpl.setVirtue(sitaanAdmin.getVirtue());
		sitaanAdminImpl.setNameofofficer(sitaanAdmin.getNameofofficer());
		sitaanAdminImpl.setFilerating(sitaanAdmin.getFilerating());
		sitaanAdminImpl.setSubmittername(sitaanAdmin.getSubmittername());
		sitaanAdminImpl.setPassportNo(sitaanAdmin.getPassportNo());
		sitaanAdminImpl.setPower(sitaanAdmin.getPower());
		sitaanAdminImpl.setOffice(sitaanAdmin.getOffice());
		sitaanAdminImpl.setChronicle(sitaanAdmin.getChronicle());
		sitaanAdminImpl.setTypeofgoods(sitaanAdmin.getTypeofgoods());
		sitaanAdminImpl.setQuantity(sitaanAdmin.getQuantity());
		sitaanAdminImpl.setRecord(sitaanAdmin.getRecord());
		sitaanAdminImpl.setInspectorsName(sitaanAdmin.getInspectorsName());
		sitaanAdminImpl.setCategory(sitaanAdmin.getCategory());
		sitaanAdminImpl.setTypeofComplaint(sitaanAdmin.getTypeofComplaint());
		sitaanAdminImpl.setClassLicense(sitaanAdmin.getClassLicense());
		sitaanAdminImpl.setParticle(sitaanAdmin.getParticle());
		sitaanAdminImpl.setDateofincident(sitaanAdmin.getDateofincident());
		sitaanAdminImpl.setTimeEvent(sitaanAdmin.getTimeEvent());
		sitaanAdminImpl.setLocationofincident(sitaanAdmin.getLocationofincident());
		sitaanAdminImpl.setTerminal(sitaanAdmin.getTerminal());
		sitaanAdminImpl.setBookie(sitaanAdmin.getBookie());
		sitaanAdminImpl.setLandmark(sitaanAdmin.getLandmark());
		sitaanAdminImpl.setInternalStakeholder(sitaanAdmin.getInternalStakeholder());
		sitaanAdminImpl.setExternalStakeholder(sitaanAdmin.getExternalStakeholder());
		sitaanAdminImpl.setForeclosureStatusType(sitaanAdmin.getForeclosureStatusType());

		return sitaanAdminImpl;
	}

	/**
	 * Returns the sitaan admin with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the sitaan admin
	 * @return the sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSitaanAdminException, SystemException {
		SitaanAdmin sitaanAdmin = fetchByPrimaryKey(primaryKey);

		if (sitaanAdmin == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSitaanAdminException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return sitaanAdmin;
	}

	/**
	 * Returns the sitaan admin with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchSitaanAdminException} if it could not be found.
	 *
	 * @param bilId the primary key of the sitaan admin
	 * @return the sitaan admin
	 * @throws com.org.skali.sitanAdmin.NoSuchSitaanAdminException if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin findByPrimaryKey(long bilId)
		throws NoSuchSitaanAdminException, SystemException {
		return findByPrimaryKey((Serializable)bilId);
	}

	/**
	 * Returns the sitaan admin with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the sitaan admin
	 * @return the sitaan admin, or <code>null</code> if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		SitaanAdmin sitaanAdmin = (SitaanAdmin)EntityCacheUtil.getResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
				SitaanAdminImpl.class, primaryKey);

		if (sitaanAdmin == _nullSitaanAdmin) {
			return null;
		}

		if (sitaanAdmin == null) {
			Session session = null;

			try {
				session = openSession();

				sitaanAdmin = (SitaanAdmin)session.get(SitaanAdminImpl.class,
						primaryKey);

				if (sitaanAdmin != null) {
					cacheResult(sitaanAdmin);
				}
				else {
					EntityCacheUtil.putResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
						SitaanAdminImpl.class, primaryKey, _nullSitaanAdmin);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SitaanAdminModelImpl.ENTITY_CACHE_ENABLED,
					SitaanAdminImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return sitaanAdmin;
	}

	/**
	 * Returns the sitaan admin with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param bilId the primary key of the sitaan admin
	 * @return the sitaan admin, or <code>null</code> if a sitaan admin with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SitaanAdmin fetchByPrimaryKey(long bilId) throws SystemException {
		return fetchByPrimaryKey((Serializable)bilId);
	}

	/**
	 * Returns all the sitaan admins.
	 *
	 * @return the sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the sitaan admins.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @return the range of sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the sitaan admins.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SitaanAdminModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of sitaan admins
	 * @param end the upper bound of the range of sitaan admins (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SitaanAdmin> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<SitaanAdmin> list = (List<SitaanAdmin>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SITAANADMIN);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SITAANADMIN;

				if (pagination) {
					sql = sql.concat(SitaanAdminModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SitaanAdmin>(list);
				}
				else {
					list = (List<SitaanAdmin>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the sitaan admins from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (SitaanAdmin sitaanAdmin : findAll()) {
			remove(sitaanAdmin);
		}
	}

	/**
	 * Returns the number of sitaan admins.
	 *
	 * @return the number of sitaan admins
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SITAANADMIN);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the sitaan admin persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.SitaanAdmin")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<SitaanAdmin>> listenersList = new ArrayList<ModelListener<SitaanAdmin>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<SitaanAdmin>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SitaanAdminImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SITAANADMIN = "SELECT sitaanAdmin FROM SitaanAdmin sitaanAdmin";
	private static final String _SQL_SELECT_SITAANADMIN_WHERE = "SELECT sitaanAdmin FROM SitaanAdmin sitaanAdmin WHERE ";
	private static final String _SQL_COUNT_SITAANADMIN = "SELECT COUNT(sitaanAdmin) FROM SitaanAdmin sitaanAdmin";
	private static final String _SQL_COUNT_SITAANADMIN_WHERE = "SELECT COUNT(sitaanAdmin) FROM SitaanAdmin sitaanAdmin WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "sitaanAdmin.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No SitaanAdmin exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No SitaanAdmin exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SitaanAdminPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"state"
			});
	private static SitaanAdmin _nullSitaanAdmin = new SitaanAdminImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<SitaanAdmin> toCacheModel() {
				return _nullSitaanAdminCacheModel;
			}
		};

	private static CacheModel<SitaanAdmin> _nullSitaanAdminCacheModel = new CacheModel<SitaanAdmin>() {
			@Override
			public SitaanAdmin toEntityModel() {
				return _nullSitaanAdmin;
			}
		};
}