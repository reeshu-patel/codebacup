/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing AcceptanceVehicleDetail in entity cache.
 *
 * @author reeshu
 * @see AcceptanceVehicleDetail
 * @generated
 */
public class AcceptanceVehicleDetailCacheModel implements CacheModel<AcceptanceVehicleDetail>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{vehicalid=");
		sb.append(vehicalid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", vehiNumberPlate=");
		sb.append(vehiNumberPlate);
		sb.append(", ownerName=");
		sb.append(ownerName);
		sb.append(", companyRepresentative=");
		sb.append(companyRepresentative);
		sb.append(", kpNo=");
		sb.append(kpNo);
		sb.append(", chronicle=");
		sb.append(chronicle);
		sb.append(", Signature=");
		sb.append(Signature);
		sb.append(", accodocument=");
		sb.append(accodocument);
		sb.append(", cardIdentity=");
		sb.append(cardIdentity);
		sb.append(", drivingLicense=");
		sb.append(drivingLicense);
		sb.append(", grantVehicle=");
		sb.append(grantVehicle);
		sb.append(", attorney=");
		sb.append(attorney);
		sb.append(", numberPlateDetail=");
		sb.append(numberPlateDetail);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public AcceptanceVehicleDetail toEntityModel() {
		AcceptanceVehicleDetailImpl acceptanceVehicleDetailImpl = new AcceptanceVehicleDetailImpl();

		acceptanceVehicleDetailImpl.setVehicalid(vehicalid);
		acceptanceVehicleDetailImpl.setBilId(bilId);

		if (vehiNumberPlate == null) {
			acceptanceVehicleDetailImpl.setVehiNumberPlate(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setVehiNumberPlate(vehiNumberPlate);
		}

		if (ownerName == null) {
			acceptanceVehicleDetailImpl.setOwnerName(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setOwnerName(ownerName);
		}

		if (companyRepresentative == null) {
			acceptanceVehicleDetailImpl.setCompanyRepresentative(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setCompanyRepresentative(companyRepresentative);
		}

		if (kpNo == null) {
			acceptanceVehicleDetailImpl.setKpNo(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setKpNo(kpNo);
		}

		if (chronicle == null) {
			acceptanceVehicleDetailImpl.setChronicle(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setChronicle(chronicle);
		}

		if (Signature == null) {
			acceptanceVehicleDetailImpl.setSignature(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setSignature(Signature);
		}

		if (accodocument == null) {
			acceptanceVehicleDetailImpl.setAccodocument(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setAccodocument(accodocument);
		}

		if (cardIdentity == null) {
			acceptanceVehicleDetailImpl.setCardIdentity(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setCardIdentity(cardIdentity);
		}

		if (drivingLicense == null) {
			acceptanceVehicleDetailImpl.setDrivingLicense(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setDrivingLicense(drivingLicense);
		}

		if (grantVehicle == null) {
			acceptanceVehicleDetailImpl.setGrantVehicle(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setGrantVehicle(grantVehicle);
		}

		if (attorney == null) {
			acceptanceVehicleDetailImpl.setAttorney(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setAttorney(attorney);
		}

		if (numberPlateDetail == null) {
			acceptanceVehicleDetailImpl.setNumberPlateDetail(StringPool.BLANK);
		}
		else {
			acceptanceVehicleDetailImpl.setNumberPlateDetail(numberPlateDetail);
		}

		acceptanceVehicleDetailImpl.resetOriginalValues();

		return acceptanceVehicleDetailImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		vehicalid = objectInput.readLong();
		bilId = objectInput.readLong();
		vehiNumberPlate = objectInput.readUTF();
		ownerName = objectInput.readUTF();
		companyRepresentative = objectInput.readUTF();
		kpNo = objectInput.readUTF();
		chronicle = objectInput.readUTF();
		Signature = objectInput.readUTF();
		accodocument = objectInput.readUTF();
		cardIdentity = objectInput.readUTF();
		drivingLicense = objectInput.readUTF();
		grantVehicle = objectInput.readUTF();
		attorney = objectInput.readUTF();
		numberPlateDetail = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(vehicalid);
		objectOutput.writeLong(bilId);

		if (vehiNumberPlate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehiNumberPlate);
		}

		if (ownerName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ownerName);
		}

		if (companyRepresentative == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyRepresentative);
		}

		if (kpNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(kpNo);
		}

		if (chronicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(chronicle);
		}

		if (Signature == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(Signature);
		}

		if (accodocument == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(accodocument);
		}

		if (cardIdentity == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(cardIdentity);
		}

		if (drivingLicense == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(drivingLicense);
		}

		if (grantVehicle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(grantVehicle);
		}

		if (attorney == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(attorney);
		}

		if (numberPlateDetail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(numberPlateDetail);
		}
	}

	public long vehicalid;
	public long bilId;
	public String vehiNumberPlate;
	public String ownerName;
	public String companyRepresentative;
	public String kpNo;
	public String chronicle;
	public String Signature;
	public String accodocument;
	public String cardIdentity;
	public String drivingLicense;
	public String grantVehicle;
	public String attorney;
	public String numberPlateDetail;
}