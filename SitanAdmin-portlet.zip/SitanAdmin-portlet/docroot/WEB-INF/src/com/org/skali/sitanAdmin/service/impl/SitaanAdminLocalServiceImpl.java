/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.service.impl;

import java.util.List;


import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.org.skali.sitanAdmin.model.SitaanAdmin;
import com.org.skali.sitanAdmin.model.complainUserinfo;
import com.org.skali.sitanAdmin.model.detailoksboyds;
import com.org.skali.sitanAdmin.model.vehicalInfo;
import com.org.skali.sitanAdmin.service.base.SitaanAdminLocalServiceBaseImpl;

/**
 * The implementation of the sitaan admin local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.org.skali.sitanAdmin.service.SitaanAdminLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.base.SitaanAdminLocalServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.SitaanAdminLocalServiceUtil
 */
public class SitaanAdminLocalServiceImpl extends SitaanAdminLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.org.skali.sitanAdmin.service.SitaanAdminLocalServiceUtil} to access the sitaan admin local service.
	 */
	
	public List<SitaanAdmin> getsByBilId(long billid) throws SystemException, PortalException {

		   List<SitaanAdmin> bill = sitaanAdminPersistence.findBybilId(billid);

		    return bill;
		}
	
	public List<SitaanAdmin> getsByDateSeized(String dateSeized) throws SystemException, PortalException {

		   List<SitaanAdmin> dateSeiz = sitaanAdminPersistence.findBydateSeized(dateSeized);

		    return dateSeiz;
		}
	
	public List<SitaanAdmin> getsByCheckSitesSita(String checkSitesSita) throws SystemException, PortalException {

		   List<SitaanAdmin> checkSites = sitaanAdminPersistence.findBycheckSitesSita(checkSitesSita);

		    return checkSites;
		}
	public List<SitaanAdmin> getsByReferenceEffective(String referenceEffective) throws SystemException, PortalException {

		   List<SitaanAdmin> referenceEffectiv = sitaanAdminPersistence.findByreferenceEffective(referenceEffective);

		    return referenceEffectiv;
		}
	
	public List<SitaanAdmin> getsByConfiscatedPeriod(String confiscatedPeriod) throws SystemException, PortalException {

		   List<SitaanAdmin> confiscated = sitaanAdminPersistence.findByconfiscatedPeriod(confiscatedPeriod);

		    return confiscated;
		}
	public List<SitaanAdmin> getsBySource(String source) throws SystemException, PortalException {

		   List<SitaanAdmin> sourc = sitaanAdminPersistence.findBysource(source);

		    return sourc;
		}
	
	public List<SitaanAdmin> getsByOwnerName(String ownerName) throws SystemException, PortalException {

		   List<SitaanAdmin> owner = sitaanAdminPersistence.findByownerName(ownerName);

		    return owner;
		}
	
	public List<SitaanAdmin> getsByVehicleRegistrationNo(String vehicleRegistrationNo) throws SystemException, PortalException {

		   List<SitaanAdmin> vehicleReginNo = sitaanAdminPersistence.findByvehicleRegistrationNo(vehicleRegistrationNo);

		    return vehicleReginNo;
		}
	
	public List<SitaanAdmin> getsByTerritory(String territory) throws SystemException, PortalException {

		   List<SitaanAdmin> territ = sitaanAdminPersistence.findByterritory(territory);

		    return territ;
		}
	
	public List<SitaanAdmin> getsByState(String state) throws SystemException, PortalException {

		   List<SitaanAdmin> stat = sitaanAdminPersistence.findBystate(state);

		    return stat;
		}
	public List<SitaanAdmin> getsByLocationCageSita(String locationCageSita) throws SystemException, PortalException {

		   List<SitaanAdmin> locationSite = sitaanAdminPersistence.findBylocationCageSita(locationCageSita);

		    return locationSite;
		}
	
	public List<SitaanAdmin> getsByForeclosureStatus(String foreclosureStatus) throws SystemException, PortalException {

		   List<SitaanAdmin> forecloseStatus = sitaanAdminPersistence.findByforeclosureStatus(foreclosureStatus);

		    return forecloseStatus;
		}
	
	public List<SitaanAdmin> getsByResultsforeclosure(String resultsforeclosure) throws SystemException, PortalException {

		   List<SitaanAdmin> resultsfore = sitaanAdminPersistence.findByresultsforeclosure(resultsforeclosure);

		    return resultsfore;
		}
	
	public List<SitaanAdmin> getsByFinedByColumn(String source,String ownerName,String territory,String vehicleRegistrationNo,String dateSeized,String checkSitesSita,String referenceEffective,String confiscatedPeriod,String state,String locationCageSita,String foreclosureStatus,String resultsforeclosure, String officerName,String  rightsReleased,String acceptancedate,boolean paymentStatus) throws SystemException, PortalException {

		   List<SitaanAdmin> sot = sitaanAdminPersistence.findByFinedByColumn(source, ownerName, territory, vehicleRegistrationNo, dateSeized, checkSitesSita, referenceEffective, confiscatedPeriod, state, locationCageSita, foreclosureStatus, resultsforeclosure, officerName, rightsReleased, acceptancedate, paymentStatus);
		   
		    return sot;
		}
	
	
}