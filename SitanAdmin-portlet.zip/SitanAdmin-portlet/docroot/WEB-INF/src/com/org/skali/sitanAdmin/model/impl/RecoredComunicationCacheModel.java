/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.RecoredComunication;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RecoredComunication in entity cache.
 *
 * @author reeshu
 * @see RecoredComunication
 * @generated
 */
public class RecoredComunicationCacheModel implements CacheModel<RecoredComunication>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{recoredomuni=");
		sb.append(recoredomuni);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", dateTime=");
		sb.append(dateTime);
		sb.append(", contact=");
		sb.append(contact);
		sb.append(", communicationMethod=");
		sb.append(communicationMethod);
		sb.append(", telefon=");
		sb.append(telefon);
		sb.append(", particle=");
		sb.append(particle);
		sb.append(", paymentAmount=");
		sb.append(paymentAmount);
		sb.append(", paymentMethod=");
		sb.append(paymentMethod);
		sb.append(", paymentDate=");
		sb.append(paymentDate);
		sb.append(", referralPayment=");
		sb.append(referralPayment);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RecoredComunication toEntityModel() {
		RecoredComunicationImpl recoredComunicationImpl = new RecoredComunicationImpl();

		recoredComunicationImpl.setRecoredomuni(recoredomuni);
		recoredComunicationImpl.setBilId(bilId);

		if (dateTime == null) {
			recoredComunicationImpl.setDateTime(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setDateTime(dateTime);
		}

		if (contact == null) {
			recoredComunicationImpl.setContact(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setContact(contact);
		}

		if (communicationMethod == null) {
			recoredComunicationImpl.setCommunicationMethod(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setCommunicationMethod(communicationMethod);
		}

		recoredComunicationImpl.setTelefon(telefon);

		if (particle == null) {
			recoredComunicationImpl.setParticle(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setParticle(particle);
		}

		if (paymentAmount == null) {
			recoredComunicationImpl.setPaymentAmount(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setPaymentAmount(paymentAmount);
		}

		if (paymentMethod == null) {
			recoredComunicationImpl.setPaymentMethod(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setPaymentMethod(paymentMethod);
		}

		if (paymentDate == null) {
			recoredComunicationImpl.setPaymentDate(StringPool.BLANK);
		}
		else {
			recoredComunicationImpl.setPaymentDate(paymentDate);
		}

		recoredComunicationImpl.setReferralPayment(referralPayment);

		recoredComunicationImpl.resetOriginalValues();

		return recoredComunicationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		recoredomuni = objectInput.readLong();
		bilId = objectInput.readLong();
		dateTime = objectInput.readUTF();
		contact = objectInput.readUTF();
		communicationMethod = objectInput.readUTF();
		telefon = objectInput.readLong();
		particle = objectInput.readUTF();
		paymentAmount = objectInput.readUTF();
		paymentMethod = objectInput.readUTF();
		paymentDate = objectInput.readUTF();
		referralPayment = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(recoredomuni);
		objectOutput.writeLong(bilId);

		if (dateTime == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateTime);
		}

		if (contact == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(contact);
		}

		if (communicationMethod == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(communicationMethod);
		}

		objectOutput.writeLong(telefon);

		if (particle == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(particle);
		}

		if (paymentAmount == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(paymentAmount);
		}

		if (paymentMethod == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(paymentMethod);
		}

		if (paymentDate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(paymentDate);
		}

		objectOutput.writeLong(referralPayment);
	}

	public long recoredomuni;
	public long bilId;
	public String dateTime;
	public String contact;
	public String communicationMethod;
	public long telefon;
	public String particle;
	public String paymentAmount;
	public String paymentMethod;
	public String paymentDate;
	public long referralPayment;
}