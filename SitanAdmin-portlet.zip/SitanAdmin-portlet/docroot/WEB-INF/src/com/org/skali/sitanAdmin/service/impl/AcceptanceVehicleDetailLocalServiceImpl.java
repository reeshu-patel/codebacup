/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail;
import com.org.skali.sitanAdmin.model.SitaanAdmin;
import com.org.skali.sitanAdmin.service.base.AcceptanceVehicleDetailLocalServiceBaseImpl;

/**
 * The implementation of the acceptance vehicle detail local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.base.AcceptanceVehicleDetailLocalServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailLocalServiceUtil
 */
public class AcceptanceVehicleDetailLocalServiceImpl
	extends AcceptanceVehicleDetailLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailLocalServiceUtil} to access the acceptance vehicle detail local service.
	 */
	
	public List<AcceptanceVehicleDetail> getsByBilId(long bilId) throws SystemException, PortalException {

		   List<AcceptanceVehicleDetail> bill = acceptanceVehicleDetailPersistence.findBybilId(bilId);

		    return bill;
		    
		}
	
	public List<AcceptanceVehicleDetail> getsByVehicalAndBillId(long bilId,long vehicalid) throws SystemException, PortalException {

		   List<AcceptanceVehicleDetail> vehicalId = acceptanceVehicleDetailPersistence.findByvehicalidBillId(bilId, vehicalid);

		    return vehicalId;
		}
}