/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException;
import com.org.skali.sitanAdmin.model.ActiveVehicleDetail;
import com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailImpl;
import com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the active vehicle detail service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see ActiveVehicleDetailPersistence
 * @see ActiveVehicleDetailUtil
 * @generated
 */
public class ActiveVehicleDetailPersistenceImpl extends BasePersistenceImpl<ActiveVehicleDetail>
	implements ActiveVehicleDetailPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link ActiveVehicleDetailUtil} to access the active vehicle detail persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = ActiveVehicleDetailImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			ActiveVehicleDetailModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the active vehicle details where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findBybilId(long bilId)
		throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the active vehicle details where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of active vehicle details
	 * @param end the upper bound of the range of active vehicle details (not inclusive)
	 * @return the range of matching active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the active vehicle details where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of active vehicle details
	 * @param end the upper bound of the range of active vehicle details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findBybilId(long bilId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<ActiveVehicleDetail> list = (List<ActiveVehicleDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (ActiveVehicleDetail activeVehicleDetail : list) {
				if ((bilId != activeVehicleDetail.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_ACTIVEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(ActiveVehicleDetailModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<ActiveVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<ActiveVehicleDetail>(list);
				}
				else {
					list = (List<ActiveVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first active vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching active vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a matching active vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchActiveVehicleDetailException, SystemException {
		ActiveVehicleDetail activeVehicleDetail = fetchBybilId_First(bilId,
				orderByComparator);

		if (activeVehicleDetail != null) {
			return activeVehicleDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchActiveVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the first active vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching active vehicle detail, or <code>null</code> if a matching active vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<ActiveVehicleDetail> list = findBybilId(bilId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last active vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching active vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a matching active vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchActiveVehicleDetailException, SystemException {
		ActiveVehicleDetail activeVehicleDetail = fetchBybilId_Last(bilId,
				orderByComparator);

		if (activeVehicleDetail != null) {
			return activeVehicleDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchActiveVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the last active vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching active vehicle detail, or <code>null</code> if a matching active vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<ActiveVehicleDetail> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the active vehicle details before and after the current active vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param vehicalid the primary key of the current active vehicle detail
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next active vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail[] findBybilId_PrevAndNext(long vehicalid,
		long bilId, OrderByComparator orderByComparator)
		throws NoSuchActiveVehicleDetailException, SystemException {
		ActiveVehicleDetail activeVehicleDetail = findByPrimaryKey(vehicalid);

		Session session = null;

		try {
			session = openSession();

			ActiveVehicleDetail[] array = new ActiveVehicleDetailImpl[3];

			array[0] = getBybilId_PrevAndNext(session, activeVehicleDetail,
					bilId, orderByComparator, true);

			array[1] = activeVehicleDetail;

			array[2] = getBybilId_PrevAndNext(session, activeVehicleDetail,
					bilId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected ActiveVehicleDetail getBybilId_PrevAndNext(Session session,
		ActiveVehicleDetail activeVehicleDetail, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_ACTIVEVEHICLEDETAIL_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(ActiveVehicleDetailModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(activeVehicleDetail);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<ActiveVehicleDetail> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the active vehicle details where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (ActiveVehicleDetail activeVehicleDetail : findBybilId(bilId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(activeVehicleDetail);
		}
	}

	/**
	 * Returns the number of active vehicle details where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_ACTIVEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "activeVehicleDetail.bilId = ?";

	public ActiveVehicleDetailPersistenceImpl() {
		setModelClass(ActiveVehicleDetail.class);
	}

	/**
	 * Caches the active vehicle detail in the entity cache if it is enabled.
	 *
	 * @param activeVehicleDetail the active vehicle detail
	 */
	@Override
	public void cacheResult(ActiveVehicleDetail activeVehicleDetail) {
		EntityCacheUtil.putResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class, activeVehicleDetail.getPrimaryKey(),
			activeVehicleDetail);

		activeVehicleDetail.resetOriginalValues();
	}

	/**
	 * Caches the active vehicle details in the entity cache if it is enabled.
	 *
	 * @param activeVehicleDetails the active vehicle details
	 */
	@Override
	public void cacheResult(List<ActiveVehicleDetail> activeVehicleDetails) {
		for (ActiveVehicleDetail activeVehicleDetail : activeVehicleDetails) {
			if (EntityCacheUtil.getResult(
						ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
						ActiveVehicleDetailImpl.class,
						activeVehicleDetail.getPrimaryKey()) == null) {
				cacheResult(activeVehicleDetail);
			}
			else {
				activeVehicleDetail.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all active vehicle details.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(ActiveVehicleDetailImpl.class.getName());
		}

		EntityCacheUtil.clearCache(ActiveVehicleDetailImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the active vehicle detail.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(ActiveVehicleDetail activeVehicleDetail) {
		EntityCacheUtil.removeResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class, activeVehicleDetail.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<ActiveVehicleDetail> activeVehicleDetails) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (ActiveVehicleDetail activeVehicleDetail : activeVehicleDetails) {
			EntityCacheUtil.removeResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
				ActiveVehicleDetailImpl.class,
				activeVehicleDetail.getPrimaryKey());
		}
	}

	/**
	 * Creates a new active vehicle detail with the primary key. Does not add the active vehicle detail to the database.
	 *
	 * @param vehicalid the primary key for the new active vehicle detail
	 * @return the new active vehicle detail
	 */
	@Override
	public ActiveVehicleDetail create(long vehicalid) {
		ActiveVehicleDetail activeVehicleDetail = new ActiveVehicleDetailImpl();

		activeVehicleDetail.setNew(true);
		activeVehicleDetail.setPrimaryKey(vehicalid);

		return activeVehicleDetail;
	}

	/**
	 * Removes the active vehicle detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param vehicalid the primary key of the active vehicle detail
	 * @return the active vehicle detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail remove(long vehicalid)
		throws NoSuchActiveVehicleDetailException, SystemException {
		return remove((Serializable)vehicalid);
	}

	/**
	 * Removes the active vehicle detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the active vehicle detail
	 * @return the active vehicle detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail remove(Serializable primaryKey)
		throws NoSuchActiveVehicleDetailException, SystemException {
		Session session = null;

		try {
			session = openSession();

			ActiveVehicleDetail activeVehicleDetail = (ActiveVehicleDetail)session.get(ActiveVehicleDetailImpl.class,
					primaryKey);

			if (activeVehicleDetail == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchActiveVehicleDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(activeVehicleDetail);
		}
		catch (NoSuchActiveVehicleDetailException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected ActiveVehicleDetail removeImpl(
		ActiveVehicleDetail activeVehicleDetail) throws SystemException {
		activeVehicleDetail = toUnwrappedModel(activeVehicleDetail);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(activeVehicleDetail)) {
				activeVehicleDetail = (ActiveVehicleDetail)session.get(ActiveVehicleDetailImpl.class,
						activeVehicleDetail.getPrimaryKeyObj());
			}

			if (activeVehicleDetail != null) {
				session.delete(activeVehicleDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (activeVehicleDetail != null) {
			clearCache(activeVehicleDetail);
		}

		return activeVehicleDetail;
	}

	@Override
	public ActiveVehicleDetail updateImpl(
		com.org.skali.sitanAdmin.model.ActiveVehicleDetail activeVehicleDetail)
		throws SystemException {
		activeVehicleDetail = toUnwrappedModel(activeVehicleDetail);

		boolean isNew = activeVehicleDetail.isNew();

		ActiveVehicleDetailModelImpl activeVehicleDetailModelImpl = (ActiveVehicleDetailModelImpl)activeVehicleDetail;

		Session session = null;

		try {
			session = openSession();

			if (activeVehicleDetail.isNew()) {
				session.save(activeVehicleDetail);

				activeVehicleDetail.setNew(false);
			}
			else {
				session.merge(activeVehicleDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !ActiveVehicleDetailModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((activeVehicleDetailModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						activeVehicleDetailModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { activeVehicleDetailModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}
		}

		EntityCacheUtil.putResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			ActiveVehicleDetailImpl.class, activeVehicleDetail.getPrimaryKey(),
			activeVehicleDetail);

		return activeVehicleDetail;
	}

	protected ActiveVehicleDetail toUnwrappedModel(
		ActiveVehicleDetail activeVehicleDetail) {
		if (activeVehicleDetail instanceof ActiveVehicleDetailImpl) {
			return activeVehicleDetail;
		}

		ActiveVehicleDetailImpl activeVehicleDetailImpl = new ActiveVehicleDetailImpl();

		activeVehicleDetailImpl.setNew(activeVehicleDetail.isNew());
		activeVehicleDetailImpl.setPrimaryKey(activeVehicleDetail.getPrimaryKey());

		activeVehicleDetailImpl.setVehicalid(activeVehicleDetail.getVehicalid());
		activeVehicleDetailImpl.setBilId(activeVehicleDetail.getBilId());
		activeVehicleDetailImpl.setClasscode(activeVehicleDetail.getClasscode());
		activeVehicleDetailImpl.setByVehicle(activeVehicleDetail.getByVehicle());
		activeVehicleDetailImpl.setWithoutMotor(activeVehicleDetail.getWithoutMotor());
		activeVehicleDetailImpl.setCommencement(activeVehicleDetail.getCommencement());
		activeVehicleDetailImpl.setAgeLimit(activeVehicleDetail.getAgeLimit());

		return activeVehicleDetailImpl;
	}

	/**
	 * Returns the active vehicle detail with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the active vehicle detail
	 * @return the active vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail findByPrimaryKey(Serializable primaryKey)
		throws NoSuchActiveVehicleDetailException, SystemException {
		ActiveVehicleDetail activeVehicleDetail = fetchByPrimaryKey(primaryKey);

		if (activeVehicleDetail == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchActiveVehicleDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return activeVehicleDetail;
	}

	/**
	 * Returns the active vehicle detail with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException} if it could not be found.
	 *
	 * @param vehicalid the primary key of the active vehicle detail
	 * @return the active vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchActiveVehicleDetailException if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail findByPrimaryKey(long vehicalid)
		throws NoSuchActiveVehicleDetailException, SystemException {
		return findByPrimaryKey((Serializable)vehicalid);
	}

	/**
	 * Returns the active vehicle detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the active vehicle detail
	 * @return the active vehicle detail, or <code>null</code> if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		ActiveVehicleDetail activeVehicleDetail = (ActiveVehicleDetail)EntityCacheUtil.getResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
				ActiveVehicleDetailImpl.class, primaryKey);

		if (activeVehicleDetail == _nullActiveVehicleDetail) {
			return null;
		}

		if (activeVehicleDetail == null) {
			Session session = null;

			try {
				session = openSession();

				activeVehicleDetail = (ActiveVehicleDetail)session.get(ActiveVehicleDetailImpl.class,
						primaryKey);

				if (activeVehicleDetail != null) {
					cacheResult(activeVehicleDetail);
				}
				else {
					EntityCacheUtil.putResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
						ActiveVehicleDetailImpl.class, primaryKey,
						_nullActiveVehicleDetail);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(ActiveVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
					ActiveVehicleDetailImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return activeVehicleDetail;
	}

	/**
	 * Returns the active vehicle detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param vehicalid the primary key of the active vehicle detail
	 * @return the active vehicle detail, or <code>null</code> if a active vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public ActiveVehicleDetail fetchByPrimaryKey(long vehicalid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)vehicalid);
	}

	/**
	 * Returns all the active vehicle details.
	 *
	 * @return the active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the active vehicle details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of active vehicle details
	 * @param end the upper bound of the range of active vehicle details (not inclusive)
	 * @return the range of active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the active vehicle details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.ActiveVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of active vehicle details
	 * @param end the upper bound of the range of active vehicle details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<ActiveVehicleDetail> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<ActiveVehicleDetail> list = (List<ActiveVehicleDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_ACTIVEVEHICLEDETAIL);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_ACTIVEVEHICLEDETAIL;

				if (pagination) {
					sql = sql.concat(ActiveVehicleDetailModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<ActiveVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<ActiveVehicleDetail>(list);
				}
				else {
					list = (List<ActiveVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the active vehicle details from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (ActiveVehicleDetail activeVehicleDetail : findAll()) {
			remove(activeVehicleDetail);
		}
	}

	/**
	 * Returns the number of active vehicle details.
	 *
	 * @return the number of active vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_ACTIVEVEHICLEDETAIL);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the active vehicle detail persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.ActiveVehicleDetail")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<ActiveVehicleDetail>> listenersList = new ArrayList<ModelListener<ActiveVehicleDetail>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<ActiveVehicleDetail>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(ActiveVehicleDetailImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_ACTIVEVEHICLEDETAIL = "SELECT activeVehicleDetail FROM ActiveVehicleDetail activeVehicleDetail";
	private static final String _SQL_SELECT_ACTIVEVEHICLEDETAIL_WHERE = "SELECT activeVehicleDetail FROM ActiveVehicleDetail activeVehicleDetail WHERE ";
	private static final String _SQL_COUNT_ACTIVEVEHICLEDETAIL = "SELECT COUNT(activeVehicleDetail) FROM ActiveVehicleDetail activeVehicleDetail";
	private static final String _SQL_COUNT_ACTIVEVEHICLEDETAIL_WHERE = "SELECT COUNT(activeVehicleDetail) FROM ActiveVehicleDetail activeVehicleDetail WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "activeVehicleDetail.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ActiveVehicleDetail exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ActiveVehicleDetail exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(ActiveVehicleDetailPersistenceImpl.class);
	private static ActiveVehicleDetail _nullActiveVehicleDetail = new ActiveVehicleDetailImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<ActiveVehicleDetail> toCacheModel() {
				return _nullActiveVehicleDetailCacheModel;
			}
		};

	private static CacheModel<ActiveVehicleDetail> _nullActiveVehicleDetailCacheModel =
		new CacheModel<ActiveVehicleDetail>() {
			@Override
			public ActiveVehicleDetail toEntityModel() {
				return _nullActiveVehicleDetail;
			}
		};
}