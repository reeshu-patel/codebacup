/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchSourceTypesException;
import com.org.skali.sitanAdmin.model.SourceTypes;
import com.org.skali.sitanAdmin.model.impl.SourceTypesImpl;
import com.org.skali.sitanAdmin.model.impl.SourceTypesModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the source types service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see SourceTypesPersistence
 * @see SourceTypesUtil
 * @generated
 */
public class SourceTypesPersistenceImpl extends BasePersistenceImpl<SourceTypes>
	implements SourceTypesPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SourceTypesUtil} to access the source types persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SourceTypesImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, SourceTypesImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, SourceTypesImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, SourceTypesImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, SourceTypesImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			SourceTypesModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the source typeses where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findBybilId(long bilId) throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the source typeses where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SourceTypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of source typeses
	 * @param end the upper bound of the range of source typeses (not inclusive)
	 * @return the range of matching source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the source typeses where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SourceTypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of source typeses
	 * @param end the upper bound of the range of source typeses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findBybilId(long bilId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<SourceTypes> list = (List<SourceTypes>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SourceTypes sourceTypes : list) {
				if ((bilId != sourceTypes.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SOURCETYPES_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SourceTypesModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<SourceTypes>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SourceTypes>(list);
				}
				else {
					list = (List<SourceTypes>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first source types in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching source types
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a matching source types could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchSourceTypesException, SystemException {
		SourceTypes sourceTypes = fetchBybilId_First(bilId, orderByComparator);

		if (sourceTypes != null) {
			return sourceTypes;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSourceTypesException(msg.toString());
	}

	/**
	 * Returns the first source types in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching source types, or <code>null</code> if a matching source types could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<SourceTypes> list = findBybilId(bilId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last source types in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching source types
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a matching source types could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchSourceTypesException, SystemException {
		SourceTypes sourceTypes = fetchBybilId_Last(bilId, orderByComparator);

		if (sourceTypes != null) {
			return sourceTypes;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSourceTypesException(msg.toString());
	}

	/**
	 * Returns the last source types in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching source types, or <code>null</code> if a matching source types could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<SourceTypes> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the source typeses before and after the current source types in the ordered set where bilId = &#63;.
	 *
	 * @param sourcetypeid the primary key of the current source types
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next source types
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes[] findBybilId_PrevAndNext(long sourcetypeid, long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchSourceTypesException, SystemException {
		SourceTypes sourceTypes = findByPrimaryKey(sourcetypeid);

		Session session = null;

		try {
			session = openSession();

			SourceTypes[] array = new SourceTypesImpl[3];

			array[0] = getBybilId_PrevAndNext(session, sourceTypes, bilId,
					orderByComparator, true);

			array[1] = sourceTypes;

			array[2] = getBybilId_PrevAndNext(session, sourceTypes, bilId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SourceTypes getBybilId_PrevAndNext(Session session,
		SourceTypes sourceTypes, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SOURCETYPES_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SourceTypesModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(sourceTypes);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SourceTypes> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the source typeses where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (SourceTypes sourceTypes : findBybilId(bilId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(sourceTypes);
		}
	}

	/**
	 * Returns the number of source typeses where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SOURCETYPES_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "sourceTypes.bilId = ?";

	public SourceTypesPersistenceImpl() {
		setModelClass(SourceTypes.class);
	}

	/**
	 * Caches the source types in the entity cache if it is enabled.
	 *
	 * @param sourceTypes the source types
	 */
	@Override
	public void cacheResult(SourceTypes sourceTypes) {
		EntityCacheUtil.putResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesImpl.class, sourceTypes.getPrimaryKey(), sourceTypes);

		sourceTypes.resetOriginalValues();
	}

	/**
	 * Caches the source typeses in the entity cache if it is enabled.
	 *
	 * @param sourceTypeses the source typeses
	 */
	@Override
	public void cacheResult(List<SourceTypes> sourceTypeses) {
		for (SourceTypes sourceTypes : sourceTypeses) {
			if (EntityCacheUtil.getResult(
						SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
						SourceTypesImpl.class, sourceTypes.getPrimaryKey()) == null) {
				cacheResult(sourceTypes);
			}
			else {
				sourceTypes.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all source typeses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SourceTypesImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SourceTypesImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the source types.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(SourceTypes sourceTypes) {
		EntityCacheUtil.removeResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesImpl.class, sourceTypes.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<SourceTypes> sourceTypeses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (SourceTypes sourceTypes : sourceTypeses) {
			EntityCacheUtil.removeResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
				SourceTypesImpl.class, sourceTypes.getPrimaryKey());
		}
	}

	/**
	 * Creates a new source types with the primary key. Does not add the source types to the database.
	 *
	 * @param sourcetypeid the primary key for the new source types
	 * @return the new source types
	 */
	@Override
	public SourceTypes create(long sourcetypeid) {
		SourceTypes sourceTypes = new SourceTypesImpl();

		sourceTypes.setNew(true);
		sourceTypes.setPrimaryKey(sourcetypeid);

		return sourceTypes;
	}

	/**
	 * Removes the source types with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param sourcetypeid the primary key of the source types
	 * @return the source types that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes remove(long sourcetypeid)
		throws NoSuchSourceTypesException, SystemException {
		return remove((Serializable)sourcetypeid);
	}

	/**
	 * Removes the source types with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the source types
	 * @return the source types that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes remove(Serializable primaryKey)
		throws NoSuchSourceTypesException, SystemException {
		Session session = null;

		try {
			session = openSession();

			SourceTypes sourceTypes = (SourceTypes)session.get(SourceTypesImpl.class,
					primaryKey);

			if (sourceTypes == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSourceTypesException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(sourceTypes);
		}
		catch (NoSuchSourceTypesException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected SourceTypes removeImpl(SourceTypes sourceTypes)
		throws SystemException {
		sourceTypes = toUnwrappedModel(sourceTypes);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(sourceTypes)) {
				sourceTypes = (SourceTypes)session.get(SourceTypesImpl.class,
						sourceTypes.getPrimaryKeyObj());
			}

			if (sourceTypes != null) {
				session.delete(sourceTypes);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (sourceTypes != null) {
			clearCache(sourceTypes);
		}

		return sourceTypes;
	}

	@Override
	public SourceTypes updateImpl(
		com.org.skali.sitanAdmin.model.SourceTypes sourceTypes)
		throws SystemException {
		sourceTypes = toUnwrappedModel(sourceTypes);

		boolean isNew = sourceTypes.isNew();

		SourceTypesModelImpl sourceTypesModelImpl = (SourceTypesModelImpl)sourceTypes;

		Session session = null;

		try {
			session = openSession();

			if (sourceTypes.isNew()) {
				session.save(sourceTypes);

				sourceTypes.setNew(false);
			}
			else {
				session.merge(sourceTypes);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SourceTypesModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((sourceTypesModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						sourceTypesModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { sourceTypesModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}
		}

		EntityCacheUtil.putResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
			SourceTypesImpl.class, sourceTypes.getPrimaryKey(), sourceTypes);

		return sourceTypes;
	}

	protected SourceTypes toUnwrappedModel(SourceTypes sourceTypes) {
		if (sourceTypes instanceof SourceTypesImpl) {
			return sourceTypes;
		}

		SourceTypesImpl sourceTypesImpl = new SourceTypesImpl();

		sourceTypesImpl.setNew(sourceTypes.isNew());
		sourceTypesImpl.setPrimaryKey(sourceTypes.getPrimaryKey());

		sourceTypesImpl.setSourcetypeid(sourceTypes.getSourcetypeid());
		sourceTypesImpl.setBilId(sourceTypes.getBilId());
		sourceTypesImpl.setErrortypes(sourceTypes.getErrortypes());
		sourceTypesImpl.setSourcetypes(sourceTypes.getSourcetypes());

		return sourceTypesImpl;
	}

	/**
	 * Returns the source types with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the source types
	 * @return the source types
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSourceTypesException, SystemException {
		SourceTypes sourceTypes = fetchByPrimaryKey(primaryKey);

		if (sourceTypes == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSourceTypesException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return sourceTypes;
	}

	/**
	 * Returns the source types with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchSourceTypesException} if it could not be found.
	 *
	 * @param sourcetypeid the primary key of the source types
	 * @return the source types
	 * @throws com.org.skali.sitanAdmin.NoSuchSourceTypesException if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes findByPrimaryKey(long sourcetypeid)
		throws NoSuchSourceTypesException, SystemException {
		return findByPrimaryKey((Serializable)sourcetypeid);
	}

	/**
	 * Returns the source types with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the source types
	 * @return the source types, or <code>null</code> if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		SourceTypes sourceTypes = (SourceTypes)EntityCacheUtil.getResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
				SourceTypesImpl.class, primaryKey);

		if (sourceTypes == _nullSourceTypes) {
			return null;
		}

		if (sourceTypes == null) {
			Session session = null;

			try {
				session = openSession();

				sourceTypes = (SourceTypes)session.get(SourceTypesImpl.class,
						primaryKey);

				if (sourceTypes != null) {
					cacheResult(sourceTypes);
				}
				else {
					EntityCacheUtil.putResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
						SourceTypesImpl.class, primaryKey, _nullSourceTypes);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SourceTypesModelImpl.ENTITY_CACHE_ENABLED,
					SourceTypesImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return sourceTypes;
	}

	/**
	 * Returns the source types with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param sourcetypeid the primary key of the source types
	 * @return the source types, or <code>null</code> if a source types with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SourceTypes fetchByPrimaryKey(long sourcetypeid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)sourcetypeid);
	}

	/**
	 * Returns all the source typeses.
	 *
	 * @return the source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the source typeses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SourceTypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of source typeses
	 * @param end the upper bound of the range of source typeses (not inclusive)
	 * @return the range of source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the source typeses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.SourceTypesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of source typeses
	 * @param end the upper bound of the range of source typeses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SourceTypes> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<SourceTypes> list = (List<SourceTypes>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SOURCETYPES);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SOURCETYPES;

				if (pagination) {
					sql = sql.concat(SourceTypesModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<SourceTypes>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SourceTypes>(list);
				}
				else {
					list = (List<SourceTypes>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the source typeses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (SourceTypes sourceTypes : findAll()) {
			remove(sourceTypes);
		}
	}

	/**
	 * Returns the number of source typeses.
	 *
	 * @return the number of source typeses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SOURCETYPES);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the source types persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.SourceTypes")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<SourceTypes>> listenersList = new ArrayList<ModelListener<SourceTypes>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<SourceTypes>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SourceTypesImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SOURCETYPES = "SELECT sourceTypes FROM SourceTypes sourceTypes";
	private static final String _SQL_SELECT_SOURCETYPES_WHERE = "SELECT sourceTypes FROM SourceTypes sourceTypes WHERE ";
	private static final String _SQL_COUNT_SOURCETYPES = "SELECT COUNT(sourceTypes) FROM SourceTypes sourceTypes";
	private static final String _SQL_COUNT_SOURCETYPES_WHERE = "SELECT COUNT(sourceTypes) FROM SourceTypes sourceTypes WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "sourceTypes.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No SourceTypes exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No SourceTypes exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SourceTypesPersistenceImpl.class);
	private static SourceTypes _nullSourceTypes = new SourceTypesImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<SourceTypes> toCacheModel() {
				return _nullSourceTypesCacheModel;
			}
		};

	private static CacheModel<SourceTypes> _nullSourceTypesCacheModel = new CacheModel<SourceTypes>() {
			@Override
			public SourceTypes toEntityModel() {
				return _nullSourceTypes;
			}
		};
}