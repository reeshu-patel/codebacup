/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.ActionSummery;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing ActionSummery in entity cache.
 *
 * @author reeshu
 * @see ActionSummery
 * @generated
 */
public class ActionSummeryCacheModel implements CacheModel<ActionSummery>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{actionsummeryid=");
		sb.append(actionsummeryid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", dateTime=");
		sb.append(dateTime);
		sb.append(", status=");
		sb.append(status);
		sb.append(", action=");
		sb.append(action);
		sb.append(", actionBy=");
		sb.append(actionBy);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ActionSummery toEntityModel() {
		ActionSummeryImpl actionSummeryImpl = new ActionSummeryImpl();

		actionSummeryImpl.setActionsummeryid(actionsummeryid);
		actionSummeryImpl.setBilId(bilId);

		if (dateTime == null) {
			actionSummeryImpl.setDateTime(StringPool.BLANK);
		}
		else {
			actionSummeryImpl.setDateTime(dateTime);
		}

		if (status == null) {
			actionSummeryImpl.setStatus(StringPool.BLANK);
		}
		else {
			actionSummeryImpl.setStatus(status);
		}

		if (action == null) {
			actionSummeryImpl.setAction(StringPool.BLANK);
		}
		else {
			actionSummeryImpl.setAction(action);
		}

		if (actionBy == null) {
			actionSummeryImpl.setActionBy(StringPool.BLANK);
		}
		else {
			actionSummeryImpl.setActionBy(actionBy);
		}

		actionSummeryImpl.resetOriginalValues();

		return actionSummeryImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		actionsummeryid = objectInput.readLong();
		bilId = objectInput.readLong();
		dateTime = objectInput.readUTF();
		status = objectInput.readUTF();
		action = objectInput.readUTF();
		actionBy = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(actionsummeryid);
		objectOutput.writeLong(bilId);

		if (dateTime == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateTime);
		}

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (action == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(action);
		}

		if (actionBy == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(actionBy);
		}
	}

	public long actionsummeryid;
	public long bilId;
	public String dateTime;
	public String status;
	public String action;
	public String actionBy;
}