/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.SourceTypes;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing SourceTypes in entity cache.
 *
 * @author reeshu
 * @see SourceTypes
 * @generated
 */
public class SourceTypesCacheModel implements CacheModel<SourceTypes>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{sourcetypeid=");
		sb.append(sourcetypeid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", errortypes=");
		sb.append(errortypes);
		sb.append(", sourcetypes=");
		sb.append(sourcetypes);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SourceTypes toEntityModel() {
		SourceTypesImpl sourceTypesImpl = new SourceTypesImpl();

		sourceTypesImpl.setSourcetypeid(sourcetypeid);
		sourceTypesImpl.setBilId(bilId);

		if (errortypes == null) {
			sourceTypesImpl.setErrortypes(StringPool.BLANK);
		}
		else {
			sourceTypesImpl.setErrortypes(errortypes);
		}

		if (sourcetypes == null) {
			sourceTypesImpl.setSourcetypes(StringPool.BLANK);
		}
		else {
			sourceTypesImpl.setSourcetypes(sourcetypes);
		}

		sourceTypesImpl.resetOriginalValues();

		return sourceTypesImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		sourcetypeid = objectInput.readLong();
		bilId = objectInput.readLong();
		errortypes = objectInput.readUTF();
		sourcetypes = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(sourcetypeid);
		objectOutput.writeLong(bilId);

		if (errortypes == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(errortypes);
		}

		if (sourcetypes == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(sourcetypes);
		}
	}

	public long sourcetypeid;
	public long bilId;
	public String errortypes;
	public String sourcetypes;
}