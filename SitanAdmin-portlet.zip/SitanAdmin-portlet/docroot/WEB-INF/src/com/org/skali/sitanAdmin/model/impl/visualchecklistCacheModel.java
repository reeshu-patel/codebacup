/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.visualchecklist;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing visualchecklist in entity cache.
 *
 * @author reeshu
 * @see visualchecklist
 * @generated
 */
public class visualchecklistCacheModel implements CacheModel<visualchecklist>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(81);

		sb.append("{checkId=");
		sb.append(checkId);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", numberplates=");
		sb.append(numberplates);
		sb.append(", numberplatesNote=");
		sb.append(numberplatesNote);
		sb.append(", forwardlighting=");
		sb.append(forwardlighting);
		sb.append(", forwardlightingNote=");
		sb.append(forwardlightingNote);
		sb.append(", backlight=");
		sb.append(backlight);
		sb.append(", backlightNote=");
		sb.append(backlightNote);
		sb.append(", trafficLight=");
		sb.append(trafficLight);
		sb.append(", trafficLightNote=");
		sb.append(trafficLightNote);
		sb.append(", signallight=");
		sb.append(signallight);
		sb.append(", signallightNote=");
		sb.append(signallightNote);
		sb.append(", vehiclebody=");
		sb.append(vehiclebody);
		sb.append(", vehiclebodyNote=");
		sb.append(vehiclebodyNote);
		sb.append(", vehicleAccessories=");
		sb.append(vehicleAccessories);
		sb.append(", vehicleAccessoriesNote=");
		sb.append(vehicleAccessoriesNote);
		sb.append(", windscreen=");
		sb.append(windscreen);
		sb.append(", windscreenNote=");
		sb.append(windscreenNote);
		sb.append(", rearMirror=");
		sb.append(rearMirror);
		sb.append(", rearMirrorNote=");
		sb.append(rearMirrorNote);
		sb.append(", doormirror=");
		sb.append(doormirror);
		sb.append(", doormirrorNote=");
		sb.append(doormirrorNote);
		sb.append(", vehicletires=");
		sb.append(vehicletires);
		sb.append(", vehicletiresNote=");
		sb.append(vehicletiresNote);
		sb.append(", frontbumper=");
		sb.append(frontbumper);
		sb.append(", frontbumperNote=");
		sb.append(frontbumperNote);
		sb.append(", rearbumper=");
		sb.append(rearbumper);
		sb.append(", rearbumperNote=");
		sb.append(rearbumperNote);
		sb.append(", frontseat=");
		sb.append(frontseat);
		sb.append(", frontseatNote=");
		sb.append(frontseatNote);
		sb.append(", rearseats=");
		sb.append(rearseats);
		sb.append(", rearseatsNote=");
		sb.append(rearseatsNote);
		sb.append(", note=");
		sb.append(note);
		sb.append(", vehicleRegistrationNo=");
		sb.append(vehicleRegistrationNo);
		sb.append(", model=");
		sb.append(model);
		sb.append(", color=");
		sb.append(color);
		sb.append(", dateofVehicles=");
		sb.append(dateofVehicles);
		sb.append(", investigatorname=");
		sb.append(investigatorname);
		sb.append(", investigatorphone=");
		sb.append(investigatorphone);
		sb.append(", investigatorEmail=");
		sb.append(investigatorEmail);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public visualchecklist toEntityModel() {
		visualchecklistImpl visualchecklistImpl = new visualchecklistImpl();

		visualchecklistImpl.setCheckId(checkId);
		visualchecklistImpl.setBilId(bilId);

		if (numberplates == null) {
			visualchecklistImpl.setNumberplates(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setNumberplates(numberplates);
		}

		if (numberplatesNote == null) {
			visualchecklistImpl.setNumberplatesNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setNumberplatesNote(numberplatesNote);
		}

		if (forwardlighting == null) {
			visualchecklistImpl.setForwardlighting(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setForwardlighting(forwardlighting);
		}

		if (forwardlightingNote == null) {
			visualchecklistImpl.setForwardlightingNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setForwardlightingNote(forwardlightingNote);
		}

		if (backlight == null) {
			visualchecklistImpl.setBacklight(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setBacklight(backlight);
		}

		if (backlightNote == null) {
			visualchecklistImpl.setBacklightNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setBacklightNote(backlightNote);
		}

		if (trafficLight == null) {
			visualchecklistImpl.setTrafficLight(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setTrafficLight(trafficLight);
		}

		if (trafficLightNote == null) {
			visualchecklistImpl.setTrafficLightNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setTrafficLightNote(trafficLightNote);
		}

		if (signallight == null) {
			visualchecklistImpl.setSignallight(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setSignallight(signallight);
		}

		if (signallightNote == null) {
			visualchecklistImpl.setSignallightNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setSignallightNote(signallightNote);
		}

		if (vehiclebody == null) {
			visualchecklistImpl.setVehiclebody(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehiclebody(vehiclebody);
		}

		if (vehiclebodyNote == null) {
			visualchecklistImpl.setVehiclebodyNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehiclebodyNote(vehiclebodyNote);
		}

		if (vehicleAccessories == null) {
			visualchecklistImpl.setVehicleAccessories(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehicleAccessories(vehicleAccessories);
		}

		if (vehicleAccessoriesNote == null) {
			visualchecklistImpl.setVehicleAccessoriesNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehicleAccessoriesNote(vehicleAccessoriesNote);
		}

		if (windscreen == null) {
			visualchecklistImpl.setWindscreen(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setWindscreen(windscreen);
		}

		if (windscreenNote == null) {
			visualchecklistImpl.setWindscreenNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setWindscreenNote(windscreenNote);
		}

		if (rearMirror == null) {
			visualchecklistImpl.setRearMirror(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearMirror(rearMirror);
		}

		if (rearMirrorNote == null) {
			visualchecklistImpl.setRearMirrorNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearMirrorNote(rearMirrorNote);
		}

		if (doormirror == null) {
			visualchecklistImpl.setDoormirror(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setDoormirror(doormirror);
		}

		if (doormirrorNote == null) {
			visualchecklistImpl.setDoormirrorNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setDoormirrorNote(doormirrorNote);
		}

		if (vehicletires == null) {
			visualchecklistImpl.setVehicletires(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehicletires(vehicletires);
		}

		if (vehicletiresNote == null) {
			visualchecklistImpl.setVehicletiresNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehicletiresNote(vehicletiresNote);
		}

		if (frontbumper == null) {
			visualchecklistImpl.setFrontbumper(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setFrontbumper(frontbumper);
		}

		if (frontbumperNote == null) {
			visualchecklistImpl.setFrontbumperNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setFrontbumperNote(frontbumperNote);
		}

		if (rearbumper == null) {
			visualchecklistImpl.setRearbumper(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearbumper(rearbumper);
		}

		if (rearbumperNote == null) {
			visualchecklistImpl.setRearbumperNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearbumperNote(rearbumperNote);
		}

		if (frontseat == null) {
			visualchecklistImpl.setFrontseat(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setFrontseat(frontseat);
		}

		if (frontseatNote == null) {
			visualchecklistImpl.setFrontseatNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setFrontseatNote(frontseatNote);
		}

		if (rearseats == null) {
			visualchecklistImpl.setRearseats(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearseats(rearseats);
		}

		if (rearseatsNote == null) {
			visualchecklistImpl.setRearseatsNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setRearseatsNote(rearseatsNote);
		}

		if (note == null) {
			visualchecklistImpl.setNote(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setNote(note);
		}

		if (vehicleRegistrationNo == null) {
			visualchecklistImpl.setVehicleRegistrationNo(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setVehicleRegistrationNo(vehicleRegistrationNo);
		}

		if (model == null) {
			visualchecklistImpl.setModel(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setModel(model);
		}

		if (color == null) {
			visualchecklistImpl.setColor(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setColor(color);
		}

		if (dateofVehicles == null) {
			visualchecklistImpl.setDateofVehicles(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setDateofVehicles(dateofVehicles);
		}

		if (investigatorname == null) {
			visualchecklistImpl.setInvestigatorname(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setInvestigatorname(investigatorname);
		}

		if (investigatorphone == null) {
			visualchecklistImpl.setInvestigatorphone(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setInvestigatorphone(investigatorphone);
		}

		if (investigatorEmail == null) {
			visualchecklistImpl.setInvestigatorEmail(StringPool.BLANK);
		}
		else {
			visualchecklistImpl.setInvestigatorEmail(investigatorEmail);
		}

		visualchecklistImpl.resetOriginalValues();

		return visualchecklistImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		checkId = objectInput.readLong();
		bilId = objectInput.readLong();
		numberplates = objectInput.readUTF();
		numberplatesNote = objectInput.readUTF();
		forwardlighting = objectInput.readUTF();
		forwardlightingNote = objectInput.readUTF();
		backlight = objectInput.readUTF();
		backlightNote = objectInput.readUTF();
		trafficLight = objectInput.readUTF();
		trafficLightNote = objectInput.readUTF();
		signallight = objectInput.readUTF();
		signallightNote = objectInput.readUTF();
		vehiclebody = objectInput.readUTF();
		vehiclebodyNote = objectInput.readUTF();
		vehicleAccessories = objectInput.readUTF();
		vehicleAccessoriesNote = objectInput.readUTF();
		windscreen = objectInput.readUTF();
		windscreenNote = objectInput.readUTF();
		rearMirror = objectInput.readUTF();
		rearMirrorNote = objectInput.readUTF();
		doormirror = objectInput.readUTF();
		doormirrorNote = objectInput.readUTF();
		vehicletires = objectInput.readUTF();
		vehicletiresNote = objectInput.readUTF();
		frontbumper = objectInput.readUTF();
		frontbumperNote = objectInput.readUTF();
		rearbumper = objectInput.readUTF();
		rearbumperNote = objectInput.readUTF();
		frontseat = objectInput.readUTF();
		frontseatNote = objectInput.readUTF();
		rearseats = objectInput.readUTF();
		rearseatsNote = objectInput.readUTF();
		note = objectInput.readUTF();
		vehicleRegistrationNo = objectInput.readUTF();
		model = objectInput.readUTF();
		color = objectInput.readUTF();
		dateofVehicles = objectInput.readUTF();
		investigatorname = objectInput.readUTF();
		investigatorphone = objectInput.readUTF();
		investigatorEmail = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(checkId);
		objectOutput.writeLong(bilId);

		if (numberplates == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(numberplates);
		}

		if (numberplatesNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(numberplatesNote);
		}

		if (forwardlighting == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(forwardlighting);
		}

		if (forwardlightingNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(forwardlightingNote);
		}

		if (backlight == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(backlight);
		}

		if (backlightNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(backlightNote);
		}

		if (trafficLight == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trafficLight);
		}

		if (trafficLightNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trafficLightNote);
		}

		if (signallight == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(signallight);
		}

		if (signallightNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(signallightNote);
		}

		if (vehiclebody == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehiclebody);
		}

		if (vehiclebodyNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehiclebodyNote);
		}

		if (vehicleAccessories == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleAccessories);
		}

		if (vehicleAccessoriesNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleAccessoriesNote);
		}

		if (windscreen == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(windscreen);
		}

		if (windscreenNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(windscreenNote);
		}

		if (rearMirror == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearMirror);
		}

		if (rearMirrorNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearMirrorNote);
		}

		if (doormirror == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(doormirror);
		}

		if (doormirrorNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(doormirrorNote);
		}

		if (vehicletires == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicletires);
		}

		if (vehicletiresNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicletiresNote);
		}

		if (frontbumper == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(frontbumper);
		}

		if (frontbumperNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(frontbumperNote);
		}

		if (rearbumper == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearbumper);
		}

		if (rearbumperNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearbumperNote);
		}

		if (frontseat == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(frontseat);
		}

		if (frontseatNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(frontseatNote);
		}

		if (rearseats == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearseats);
		}

		if (rearseatsNote == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(rearseatsNote);
		}

		if (note == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(note);
		}

		if (vehicleRegistrationNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleRegistrationNo);
		}

		if (model == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(model);
		}

		if (color == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(color);
		}

		if (dateofVehicles == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofVehicles);
		}

		if (investigatorname == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorname);
		}

		if (investigatorphone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorphone);
		}

		if (investigatorEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorEmail);
		}
	}

	public long checkId;
	public long bilId;
	public String numberplates;
	public String numberplatesNote;
	public String forwardlighting;
	public String forwardlightingNote;
	public String backlight;
	public String backlightNote;
	public String trafficLight;
	public String trafficLightNote;
	public String signallight;
	public String signallightNote;
	public String vehiclebody;
	public String vehiclebodyNote;
	public String vehicleAccessories;
	public String vehicleAccessoriesNote;
	public String windscreen;
	public String windscreenNote;
	public String rearMirror;
	public String rearMirrorNote;
	public String doormirror;
	public String doormirrorNote;
	public String vehicletires;
	public String vehicletiresNote;
	public String frontbumper;
	public String frontbumperNote;
	public String rearbumper;
	public String rearbumperNote;
	public String frontseat;
	public String frontseatNote;
	public String rearseats;
	public String rearseatsNote;
	public String note;
	public String vehicleRegistrationNo;
	public String model;
	public String color;
	public String dateofVehicles;
	public String investigatorname;
	public String investigatorphone;
	public String investigatorEmail;
}