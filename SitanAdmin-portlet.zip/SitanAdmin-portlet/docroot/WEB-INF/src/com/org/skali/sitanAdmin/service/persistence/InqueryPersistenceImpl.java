/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchInqueryException;
import com.org.skali.sitanAdmin.model.Inquery;
import com.org.skali.sitanAdmin.model.impl.InqueryImpl;
import com.org.skali.sitanAdmin.model.impl.InqueryModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the inquery service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see InqueryPersistence
 * @see InqueryUtil
 * @generated
 */
public class InqueryPersistenceImpl extends BasePersistenceImpl<Inquery>
	implements InqueryPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link InqueryUtil} to access the inquery persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = InqueryImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DATESIZE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBydatesize",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESIZE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBydatesize",
			new String[] { String.class.getName() },
			InqueryModelImpl.DATESIZE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DATESIZE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBydatesize",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBydatesize(String datesize)
		throws SystemException {
		return findBydatesize(datesize, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the inqueries where datesize = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param datesize the datesize
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBydatesize(String datesize, int start, int end)
		throws SystemException {
		return findBydatesize(datesize, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where datesize = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param datesize the datesize
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBydatesize(String datesize, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESIZE;
			finderArgs = new Object[] { datesize };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DATESIZE;
			finderArgs = new Object[] { datesize, start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(datesize, inquery.getDatesize())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindDatesize = false;

			if (datesize == null) {
				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_1);
			}
			else if (datesize.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_3);
			}
			else {
				bindDatesize = true;

				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDatesize) {
					qPos.add(datesize);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBydatesize_First(String datesize,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBydatesize_First(datesize, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("datesize=");
		msg.append(datesize);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBydatesize_First(String datesize,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBydatesize(datesize, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBydatesize_Last(String datesize,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBydatesize_Last(datesize, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("datesize=");
		msg.append(datesize);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBydatesize_Last(String datesize,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBydatesize(datesize);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBydatesize(datesize, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where datesize = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param datesize the datesize
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBydatesize_PrevAndNext(long inqueryId,
		String datesize, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBydatesize_PrevAndNext(session, inquery, datesize,
					orderByComparator, true);

			array[1] = inquery;

			array[2] = getBydatesize_PrevAndNext(session, inquery, datesize,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBydatesize_PrevAndNext(Session session,
		Inquery inquery, String datesize, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindDatesize = false;

		if (datesize == null) {
			query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_1);
		}
		else if (datesize.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_3);
		}
		else {
			bindDatesize = true;

			query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindDatesize) {
			qPos.add(datesize);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where datesize = &#63; from the database.
	 *
	 * @param datesize the datesize
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBydatesize(String datesize) throws SystemException {
		for (Inquery inquery : findBydatesize(datesize, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where datesize = &#63;.
	 *
	 * @param datesize the datesize
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBydatesize(String datesize) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DATESIZE;

		Object[] finderArgs = new Object[] { datesize };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindDatesize = false;

			if (datesize == null) {
				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_1);
			}
			else if (datesize.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_3);
			}
			else {
				bindDatesize = true;

				query.append(_FINDER_COLUMN_DATESIZE_DATESIZE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDatesize) {
					qPos.add(datesize);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DATESIZE_DATESIZE_1 = "inquery.datesize IS NULL";
	private static final String _FINDER_COLUMN_DATESIZE_DATESIZE_2 = "inquery.datesize = ?";
	private static final String _FINDER_COLUMN_DATESIZE_DATESIZE_3 = "(inquery.datesize IS NULL OR inquery.datesize = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKSITESDATE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycheckSitesDate",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESDATE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycheckSitesDate",
			new String[] { String.class.getName() },
			InqueryModelImpl.CHECKSITESDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CHECKSITESDATE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycheckSitesDate",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBycheckSitesDate(String checkSitesDate)
		throws SystemException {
		return findBycheckSitesDate(checkSitesDate, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where checkSitesDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkSitesDate the check sites date
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBycheckSitesDate(String checkSitesDate, int start,
		int end) throws SystemException {
		return findBycheckSitesDate(checkSitesDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where checkSitesDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkSitesDate the check sites date
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBycheckSitesDate(String checkSitesDate, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESDATE;
			finderArgs = new Object[] { checkSitesDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKSITESDATE;
			finderArgs = new Object[] {
					checkSitesDate,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(checkSitesDate,
							inquery.getCheckSitesDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindCheckSitesDate = false;

			if (checkSitesDate == null) {
				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_1);
			}
			else if (checkSitesDate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_3);
			}
			else {
				bindCheckSitesDate = true;

				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCheckSitesDate) {
					qPos.add(checkSitesDate);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBycheckSitesDate_First(String checkSitesDate,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBycheckSitesDate_First(checkSitesDate,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkSitesDate=");
		msg.append(checkSitesDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBycheckSitesDate_First(String checkSitesDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBycheckSitesDate(checkSitesDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBycheckSitesDate_Last(String checkSitesDate,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBycheckSitesDate_Last(checkSitesDate,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkSitesDate=");
		msg.append(checkSitesDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBycheckSitesDate_Last(String checkSitesDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBycheckSitesDate(checkSitesDate);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBycheckSitesDate(checkSitesDate, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where checkSitesDate = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param checkSitesDate the check sites date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBycheckSitesDate_PrevAndNext(long inqueryId,
		String checkSitesDate, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBycheckSitesDate_PrevAndNext(session, inquery,
					checkSitesDate, orderByComparator, true);

			array[1] = inquery;

			array[2] = getBycheckSitesDate_PrevAndNext(session, inquery,
					checkSitesDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBycheckSitesDate_PrevAndNext(Session session,
		Inquery inquery, String checkSitesDate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindCheckSitesDate = false;

		if (checkSitesDate == null) {
			query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_1);
		}
		else if (checkSitesDate.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_3);
		}
		else {
			bindCheckSitesDate = true;

			query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindCheckSitesDate) {
			qPos.add(checkSitesDate);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where checkSitesDate = &#63; from the database.
	 *
	 * @param checkSitesDate the check sites date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBycheckSitesDate(String checkSitesDate)
		throws SystemException {
		for (Inquery inquery : findBycheckSitesDate(checkSitesDate,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where checkSitesDate = &#63;.
	 *
	 * @param checkSitesDate the check sites date
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBycheckSitesDate(String checkSitesDate)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKSITESDATE;

		Object[] finderArgs = new Object[] { checkSitesDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindCheckSitesDate = false;

			if (checkSitesDate == null) {
				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_1);
			}
			else if (checkSitesDate.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_3);
			}
			else {
				bindCheckSitesDate = true;

				query.append(_FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindCheckSitesDate) {
					qPos.add(checkSitesDate);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_1 = "inquery.checkSitesDate IS NULL";
	private static final String _FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_2 = "inquery.checkSitesDate = ?";
	private static final String _FINDER_COLUMN_CHECKSITESDATE_CHECKSITESDATE_3 = "(inquery.checkSitesDate IS NULL OR inquery.checkSitesDate = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_REFERENCEEFFECTIVE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByreferenceEffective",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByreferenceEffective",
			new String[] { String.class.getName() },
			InqueryModelImpl.REFERENCEEFFECTIVE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByreferenceEffective", new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByreferenceEffective(String referenceEffective)
		throws SystemException {
		return findByreferenceEffective(referenceEffective, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where referenceEffective = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param referenceEffective the reference effective
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByreferenceEffective(String referenceEffective,
		int start, int end) throws SystemException {
		return findByreferenceEffective(referenceEffective, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where referenceEffective = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param referenceEffective the reference effective
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByreferenceEffective(String referenceEffective,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE;
			finderArgs = new Object[] { referenceEffective };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_REFERENCEEFFECTIVE;
			finderArgs = new Object[] {
					referenceEffective,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(referenceEffective,
							inquery.getReferenceEffective())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByreferenceEffective_First(String referenceEffective,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByreferenceEffective_First(referenceEffective,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("referenceEffective=");
		msg.append(referenceEffective);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByreferenceEffective_First(String referenceEffective,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findByreferenceEffective(referenceEffective, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByreferenceEffective_Last(String referenceEffective,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByreferenceEffective_Last(referenceEffective,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("referenceEffective=");
		msg.append(referenceEffective);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByreferenceEffective_Last(String referenceEffective,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByreferenceEffective(referenceEffective);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findByreferenceEffective(referenceEffective,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where referenceEffective = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param referenceEffective the reference effective
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findByreferenceEffective_PrevAndNext(long inqueryId,
		String referenceEffective, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getByreferenceEffective_PrevAndNext(session, inquery,
					referenceEffective, orderByComparator, true);

			array[1] = inquery;

			array[2] = getByreferenceEffective_PrevAndNext(session, inquery,
					referenceEffective, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getByreferenceEffective_PrevAndNext(Session session,
		Inquery inquery, String referenceEffective,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindReferenceEffective = false;

		if (referenceEffective == null) {
			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
		}
		else if (referenceEffective.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
		}
		else {
			bindReferenceEffective = true;

			query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindReferenceEffective) {
			qPos.add(referenceEffective);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where referenceEffective = &#63; from the database.
	 *
	 * @param referenceEffective the reference effective
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByreferenceEffective(String referenceEffective)
		throws SystemException {
		for (Inquery inquery : findByreferenceEffective(referenceEffective,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where referenceEffective = &#63;.
	 *
	 * @param referenceEffective the reference effective
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByreferenceEffective(String referenceEffective)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE;

		Object[] finderArgs = new Object[] { referenceEffective };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindReferenceEffective = false;

			if (referenceEffective == null) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1);
			}
			else if (referenceEffective.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3);
			}
			else {
				bindReferenceEffective = true;

				query.append(_FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindReferenceEffective) {
					qPos.add(referenceEffective);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_1 =
		"inquery.referenceEffective IS NULL";
	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_2 =
		"inquery.referenceEffective = ?";
	private static final String _FINDER_COLUMN_REFERENCEEFFECTIVE_REFERENCEEFFECTIVE_3 =
		"(inquery.referenceEffective IS NULL OR inquery.referenceEffective = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_SOURCE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBysource",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBysource",
			new String[] { String.class.getName() },
			InqueryModelImpl.SOURCE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_SOURCE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBysource",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where source = &#63;.
	 *
	 * @param source the source
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBysource(String source) throws SystemException {
		return findBysource(source, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where source = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBysource(String source, int start, int end)
		throws SystemException {
		return findBysource(source, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where source = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param source the source
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBysource(String source, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE;
			finderArgs = new Object[] { source };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_SOURCE;
			finderArgs = new Object[] { source, start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(source, inquery.getSource())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBysource_First(String source,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBysource_First(source, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBysource_First(String source,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBysource(source, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBysource_Last(String source,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBysource_Last(source, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("source=");
		msg.append(source);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where source = &#63;.
	 *
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBysource_Last(String source,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBysource(source);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBysource(source, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where source = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param source the source
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBysource_PrevAndNext(long inqueryId, String source,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBysource_PrevAndNext(session, inquery, source,
					orderByComparator, true);

			array[1] = inquery;

			array[2] = getBysource_PrevAndNext(session, inquery, source,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBysource_PrevAndNext(Session session, Inquery inquery,
		String source, OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindSource = false;

		if (source == null) {
			query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
		}
		else if (source.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
		}
		else {
			bindSource = true;

			query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindSource) {
			qPos.add(source);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where source = &#63; from the database.
	 *
	 * @param source the source
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBysource(String source) throws SystemException {
		for (Inquery inquery : findBysource(source, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where source = &#63;.
	 *
	 * @param source the source
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBysource(String source) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_SOURCE;

		Object[] finderArgs = new Object[] { source };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindSource = false;

			if (source == null) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_1);
			}
			else if (source.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_SOURCE_SOURCE_3);
			}
			else {
				bindSource = true;

				query.append(_FINDER_COLUMN_SOURCE_SOURCE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindSource) {
					qPos.add(source);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SOURCE_SOURCE_1 = "inquery.source IS NULL";
	private static final String _FINDER_COLUMN_SOURCE_SOURCE_2 = "inquery.source = ?";
	private static final String _FINDER_COLUMN_SOURCE_SOURCE_3 = "(inquery.source IS NULL OR inquery.source = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_NAMEOFOWNER =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBynameofowner",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOWNER =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBynameofowner",
			new String[] { String.class.getName() },
			InqueryModelImpl.NAMEOFOWNER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_NAMEOFOWNER = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBynameofowner",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameofowner(String nameofowner)
		throws SystemException {
		return findBynameofowner(nameofowner, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where nameofowner = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param nameofowner the nameofowner
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameofowner(String nameofowner, int start,
		int end) throws SystemException {
		return findBynameofowner(nameofowner, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where nameofowner = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param nameofowner the nameofowner
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameofowner(String nameofowner, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOWNER;
			finderArgs = new Object[] { nameofowner };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_NAMEOFOWNER;
			finderArgs = new Object[] { nameofowner, start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(nameofowner, inquery.getNameofowner())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindNameofowner = false;

			if (nameofowner == null) {
				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_1);
			}
			else if (nameofowner.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_3);
			}
			else {
				bindNameofowner = true;

				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindNameofowner) {
					qPos.add(nameofowner);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBynameofowner_First(String nameofowner,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBynameofowner_First(nameofowner,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("nameofowner=");
		msg.append(nameofowner);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBynameofowner_First(String nameofowner,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBynameofowner(nameofowner, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBynameofowner_Last(String nameofowner,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBynameofowner_Last(nameofowner, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("nameofowner=");
		msg.append(nameofowner);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBynameofowner_Last(String nameofowner,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBynameofowner(nameofowner);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBynameofowner(nameofowner, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where nameofowner = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param nameofowner the nameofowner
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBynameofowner_PrevAndNext(long inqueryId,
		String nameofowner, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBynameofowner_PrevAndNext(session, inquery,
					nameofowner, orderByComparator, true);

			array[1] = inquery;

			array[2] = getBynameofowner_PrevAndNext(session, inquery,
					nameofowner, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBynameofowner_PrevAndNext(Session session,
		Inquery inquery, String nameofowner,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindNameofowner = false;

		if (nameofowner == null) {
			query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_1);
		}
		else if (nameofowner.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_3);
		}
		else {
			bindNameofowner = true;

			query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindNameofowner) {
			qPos.add(nameofowner);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where nameofowner = &#63; from the database.
	 *
	 * @param nameofowner the nameofowner
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBynameofowner(String nameofowner)
		throws SystemException {
		for (Inquery inquery : findBynameofowner(nameofowner,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where nameofowner = &#63;.
	 *
	 * @param nameofowner the nameofowner
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBynameofowner(String nameofowner) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_NAMEOFOWNER;

		Object[] finderArgs = new Object[] { nameofowner };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindNameofowner = false;

			if (nameofowner == null) {
				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_1);
			}
			else if (nameofowner.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_3);
			}
			else {
				bindNameofowner = true;

				query.append(_FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindNameofowner) {
					qPos.add(nameofowner);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_1 = "inquery.nameofowner IS NULL";
	private static final String _FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_2 = "inquery.nameofowner = ?";
	private static final String _FINDER_COLUMN_NAMEOFOWNER_NAMEOFOWNER_3 = "(inquery.nameofowner IS NULL OR inquery.nameofowner = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICLEREGISTRATION =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByvehicleRegistration",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATION =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByvehicleRegistration",
			new String[] { String.class.getName() },
			InqueryModelImpl.VEHICLEREGISTRATION_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_VEHICLEREGISTRATION = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByvehicleRegistration",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByvehicleRegistration(String vehicleRegistration)
		throws SystemException {
		return findByvehicleRegistration(vehicleRegistration,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where vehicleRegistration = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByvehicleRegistration(String vehicleRegistration,
		int start, int end) throws SystemException {
		return findByvehicleRegistration(vehicleRegistration, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where vehicleRegistration = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByvehicleRegistration(String vehicleRegistration,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATION;
			finderArgs = new Object[] { vehicleRegistration };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICLEREGISTRATION;
			finderArgs = new Object[] {
					vehicleRegistration,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(vehicleRegistration,
							inquery.getVehicleRegistration())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindVehicleRegistration = false;

			if (vehicleRegistration == null) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_1);
			}
			else if (vehicleRegistration.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_3);
			}
			else {
				bindVehicleRegistration = true;

				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVehicleRegistration) {
					qPos.add(vehicleRegistration);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByvehicleRegistration_First(String vehicleRegistration,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByvehicleRegistration_First(vehicleRegistration,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vehicleRegistration=");
		msg.append(vehicleRegistration);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByvehicleRegistration_First(
		String vehicleRegistration, OrderByComparator orderByComparator)
		throws SystemException {
		List<Inquery> list = findByvehicleRegistration(vehicleRegistration, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByvehicleRegistration_Last(String vehicleRegistration,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByvehicleRegistration_Last(vehicleRegistration,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("vehicleRegistration=");
		msg.append(vehicleRegistration);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByvehicleRegistration_Last(String vehicleRegistration,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByvehicleRegistration(vehicleRegistration);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findByvehicleRegistration(vehicleRegistration,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where vehicleRegistration = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param vehicleRegistration the vehicle registration
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findByvehicleRegistration_PrevAndNext(long inqueryId,
		String vehicleRegistration, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getByvehicleRegistration_PrevAndNext(session, inquery,
					vehicleRegistration, orderByComparator, true);

			array[1] = inquery;

			array[2] = getByvehicleRegistration_PrevAndNext(session, inquery,
					vehicleRegistration, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getByvehicleRegistration_PrevAndNext(Session session,
		Inquery inquery, String vehicleRegistration,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindVehicleRegistration = false;

		if (vehicleRegistration == null) {
			query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_1);
		}
		else if (vehicleRegistration.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_3);
		}
		else {
			bindVehicleRegistration = true;

			query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindVehicleRegistration) {
			qPos.add(vehicleRegistration);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where vehicleRegistration = &#63; from the database.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByvehicleRegistration(String vehicleRegistration)
		throws SystemException {
		for (Inquery inquery : findByvehicleRegistration(vehicleRegistration,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where vehicleRegistration = &#63;.
	 *
	 * @param vehicleRegistration the vehicle registration
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByvehicleRegistration(String vehicleRegistration)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_VEHICLEREGISTRATION;

		Object[] finderArgs = new Object[] { vehicleRegistration };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindVehicleRegistration = false;

			if (vehicleRegistration == null) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_1);
			}
			else if (vehicleRegistration.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_3);
			}
			else {
				bindVehicleRegistration = true;

				query.append(_FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindVehicleRegistration) {
					qPos.add(vehicleRegistration);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_1 =
		"inquery.vehicleRegistration IS NULL";
	private static final String _FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_2 =
		"inquery.vehicleRegistration = ?";
	private static final String _FINDER_COLUMN_VEHICLEREGISTRATION_VEHICLEREGISTRATION_3 =
		"(inquery.vehicleRegistration IS NULL OR inquery.vehicleRegistration = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TERRITORY =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByterritory",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByterritory",
			new String[] { String.class.getName() },
			InqueryModelImpl.TERRITORY_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TERRITORY = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByterritory",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where territory = &#63;.
	 *
	 * @param territory the territory
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByterritory(String territory)
		throws SystemException {
		return findByterritory(territory, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the inqueries where territory = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param territory the territory
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByterritory(String territory, int start, int end)
		throws SystemException {
		return findByterritory(territory, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where territory = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param territory the territory
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByterritory(String territory, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY;
			finderArgs = new Object[] { territory };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TERRITORY;
			finderArgs = new Object[] { territory, start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(territory, inquery.getTerritory())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTerritory) {
					qPos.add(territory);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByterritory_First(String territory,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByterritory_First(territory, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("territory=");
		msg.append(territory);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByterritory_First(String territory,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findByterritory(territory, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByterritory_Last(String territory,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByterritory_Last(territory, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("territory=");
		msg.append(territory);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where territory = &#63;.
	 *
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByterritory_Last(String territory,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByterritory(territory);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findByterritory(territory, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where territory = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param territory the territory
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findByterritory_PrevAndNext(long inqueryId,
		String territory, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getByterritory_PrevAndNext(session, inquery, territory,
					orderByComparator, true);

			array[1] = inquery;

			array[2] = getByterritory_PrevAndNext(session, inquery, territory,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getByterritory_PrevAndNext(Session session,
		Inquery inquery, String territory, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindTerritory = false;

		if (territory == null) {
			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
		}
		else if (territory.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
		}
		else {
			bindTerritory = true;

			query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTerritory) {
			qPos.add(territory);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where territory = &#63; from the database.
	 *
	 * @param territory the territory
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByterritory(String territory) throws SystemException {
		for (Inquery inquery : findByterritory(territory, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where territory = &#63;.
	 *
	 * @param territory the territory
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByterritory(String territory) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TERRITORY;

		Object[] finderArgs = new Object[] { territory };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindTerritory = false;

			if (territory == null) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_1);
			}
			else if (territory.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_3);
			}
			else {
				bindTerritory = true;

				query.append(_FINDER_COLUMN_TERRITORY_TERRITORY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTerritory) {
					qPos.add(territory);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_1 = "inquery.territory IS NULL";
	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_2 = "inquery.territory = ?";
	private static final String _FINDER_COLUMN_TERRITORY_TERRITORY_3 = "(inquery.territory IS NULL OR inquery.territory = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STATE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBystate",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBystate",
			new String[] { String.class.getName() },
			InqueryModelImpl.STATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STATE = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBystate",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where state = &#63;.
	 *
	 * @param state the state
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBystate(String state) throws SystemException {
		return findBystate(state, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBystate(String state, int start, int end)
		throws SystemException {
		return findBystate(state, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBystate(String state, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE;
			finderArgs = new Object[] { state };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STATE;
			finderArgs = new Object[] { state, start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(state, inquery.getState())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_STATE_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindState) {
					qPos.add(state);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBystate_First(String state,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBystate_First(state, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("state=");
		msg.append(state);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBystate_First(String state,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBystate(state, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBystate_Last(String state,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBystate_Last(state, orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("state=");
		msg.append(state);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBystate_Last(String state,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBystate(state);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBystate(state, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where state = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBystate_PrevAndNext(long inqueryId, String state,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBystate_PrevAndNext(session, inquery, state,
					orderByComparator, true);

			array[1] = inquery;

			array[2] = getBystate_PrevAndNext(session, inquery, state,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBystate_PrevAndNext(Session session, Inquery inquery,
		String state, OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindState = false;

		if (state == null) {
			query.append(_FINDER_COLUMN_STATE_STATE_1);
		}
		else if (state.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_STATE_STATE_3);
		}
		else {
			bindState = true;

			query.append(_FINDER_COLUMN_STATE_STATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindState) {
			qPos.add(state);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where state = &#63; from the database.
	 *
	 * @param state the state
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBystate(String state) throws SystemException {
		for (Inquery inquery : findBystate(state, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where state = &#63;.
	 *
	 * @param state the state
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBystate(String state) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STATE;

		Object[] finderArgs = new Object[] { state };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindState = false;

			if (state == null) {
				query.append(_FINDER_COLUMN_STATE_STATE_1);
			}
			else if (state.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				query.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindState) {
					qPos.add(state);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATE_STATE_1 = "inquery.state IS NULL";
	private static final String _FINDER_COLUMN_STATE_STATE_2 = "inquery.state = ?";
	private static final String _FINDER_COLUMN_STATE_STATE_3 = "(inquery.state IS NULL OR inquery.state = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_LOCATIONCAGESITA =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBylocationCageSita",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findBylocationCageSita", new String[] { String.class.getName() },
			InqueryModelImpl.LOCATIONCAGESITA_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_LOCATIONCAGESITA = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countBylocationCageSita", new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBylocationCageSita(String locationCageSita)
		throws SystemException {
		return findBylocationCageSita(locationCageSita, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where locationCageSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param locationCageSita the location cage sita
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBylocationCageSita(String locationCageSita,
		int start, int end) throws SystemException {
		return findBylocationCageSita(locationCageSita, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where locationCageSita = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param locationCageSita the location cage sita
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBylocationCageSita(String locationCageSita,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA;
			finderArgs = new Object[] { locationCageSita };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_LOCATIONCAGESITA;
			finderArgs = new Object[] {
					locationCageSita,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(locationCageSita,
							inquery.getLocationCageSita())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBylocationCageSita_First(String locationCageSita,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBylocationCageSita_First(locationCageSita,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("locationCageSita=");
		msg.append(locationCageSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBylocationCageSita_First(String locationCageSita,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBylocationCageSita(locationCageSita, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBylocationCageSita_Last(String locationCageSita,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBylocationCageSita_Last(locationCageSita,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("locationCageSita=");
		msg.append(locationCageSita);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBylocationCageSita_Last(String locationCageSita,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBylocationCageSita(locationCageSita);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBylocationCageSita(locationCageSita,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where locationCageSita = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param locationCageSita the location cage sita
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBylocationCageSita_PrevAndNext(long inqueryId,
		String locationCageSita, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBylocationCageSita_PrevAndNext(session, inquery,
					locationCageSita, orderByComparator, true);

			array[1] = inquery;

			array[2] = getBylocationCageSita_PrevAndNext(session, inquery,
					locationCageSita, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBylocationCageSita_PrevAndNext(Session session,
		Inquery inquery, String locationCageSita,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindLocationCageSita = false;

		if (locationCageSita == null) {
			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
		}
		else if (locationCageSita.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
		}
		else {
			bindLocationCageSita = true;

			query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindLocationCageSita) {
			qPos.add(locationCageSita);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where locationCageSita = &#63; from the database.
	 *
	 * @param locationCageSita the location cage sita
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBylocationCageSita(String locationCageSita)
		throws SystemException {
		for (Inquery inquery : findBylocationCageSita(locationCageSita,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where locationCageSita = &#63;.
	 *
	 * @param locationCageSita the location cage sita
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBylocationCageSita(String locationCageSita)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_LOCATIONCAGESITA;

		Object[] finderArgs = new Object[] { locationCageSita };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindLocationCageSita = false;

			if (locationCageSita == null) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1);
			}
			else if (locationCageSita.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3);
			}
			else {
				bindLocationCageSita = true;

				query.append(_FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindLocationCageSita) {
					qPos.add(locationCageSita);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_1 =
		"inquery.locationCageSita IS NULL";
	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_2 =
		"inquery.locationCageSita = ?";
	private static final String _FINDER_COLUMN_LOCATIONCAGESITA_LOCATIONCAGESITA_3 =
		"(inquery.locationCageSita IS NULL OR inquery.locationCageSita = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_FORECLOSURESTATUS =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByforeclosureStatus",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByforeclosureStatus", new String[] { String.class.getName() },
			InqueryModelImpl.FORECLOSURESTATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_FORECLOSURESTATUS = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByforeclosureStatus", new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		return findByforeclosureStatus(foreclosureStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where foreclosureStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByforeclosureStatus(String foreclosureStatus,
		int start, int end) throws SystemException {
		return findByforeclosureStatus(foreclosureStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where foreclosureStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findByforeclosureStatus(String foreclosureStatus,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS;
			finderArgs = new Object[] { foreclosureStatus };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_FORECLOSURESTATUS;
			finderArgs = new Object[] {
					foreclosureStatus,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(foreclosureStatus,
							inquery.getForeclosureStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByforeclosureStatus_First(String foreclosureStatus,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByforeclosureStatus_First(foreclosureStatus,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByforeclosureStatus_First(String foreclosureStatus,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findByforeclosureStatus(foreclosureStatus, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByforeclosureStatus_Last(String foreclosureStatus,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByforeclosureStatus_Last(foreclosureStatus,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("foreclosureStatus=");
		msg.append(foreclosureStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByforeclosureStatus_Last(String foreclosureStatus,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByforeclosureStatus(foreclosureStatus);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findByforeclosureStatus(foreclosureStatus,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where foreclosureStatus = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param foreclosureStatus the foreclosure status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findByforeclosureStatus_PrevAndNext(long inqueryId,
		String foreclosureStatus, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getByforeclosureStatus_PrevAndNext(session, inquery,
					foreclosureStatus, orderByComparator, true);

			array[1] = inquery;

			array[2] = getByforeclosureStatus_PrevAndNext(session, inquery,
					foreclosureStatus, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getByforeclosureStatus_PrevAndNext(Session session,
		Inquery inquery, String foreclosureStatus,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindForeclosureStatus = false;

		if (foreclosureStatus == null) {
			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
		}
		else if (foreclosureStatus.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
		}
		else {
			bindForeclosureStatus = true;

			query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindForeclosureStatus) {
			qPos.add(foreclosureStatus);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where foreclosureStatus = &#63; from the database.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		for (Inquery inquery : findByforeclosureStatus(foreclosureStatus,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where foreclosureStatus = &#63;.
	 *
	 * @param foreclosureStatus the foreclosure status
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByforeclosureStatus(String foreclosureStatus)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_FORECLOSURESTATUS;

		Object[] finderArgs = new Object[] { foreclosureStatus };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindForeclosureStatus = false;

			if (foreclosureStatus == null) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1);
			}
			else if (foreclosureStatus.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3);
			}
			else {
				bindForeclosureStatus = true;

				query.append(_FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindForeclosureStatus) {
					qPos.add(foreclosureStatus);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_1 =
		"inquery.foreclosureStatus IS NULL";
	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_2 =
		"inquery.foreclosureStatus = ?";
	private static final String _FINDER_COLUMN_FORECLOSURESTATUS_FORECLOSURESTATUS_3 =
		"(inquery.foreclosureStatus IS NULL OR inquery.foreclosureStatus = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_NAMEOFOFFICER =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBynameOfofficer",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOFFICER =
		new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, InqueryImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBynameOfofficer",
			new String[] { String.class.getName() },
			InqueryModelImpl.NAMEOFOFFICER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_NAMEOFOFFICER = new FinderPath(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBynameOfofficer",
			new String[] { String.class.getName() });

	/**
	 * Returns all the inqueries where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @return the matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameOfofficer(String nameOfofficer)
		throws SystemException {
		return findBynameOfofficer(nameOfofficer, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries where nameOfofficer = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameOfofficer(String nameOfofficer, int start,
		int end) throws SystemException {
		return findBynameOfofficer(nameOfofficer, start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries where nameOfofficer = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findBynameOfofficer(String nameOfofficer, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOFFICER;
			finderArgs = new Object[] { nameOfofficer };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_NAMEOFOFFICER;
			finderArgs = new Object[] {
					nameOfofficer,
					
					start, end, orderByComparator
				};
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Inquery inquery : list) {
				if (!Validator.equals(nameOfofficer, inquery.getNameOfofficer())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_INQUERY_WHERE);

			boolean bindNameOfofficer = false;

			if (nameOfofficer == null) {
				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_1);
			}
			else if (nameOfofficer.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_3);
			}
			else {
				bindNameOfofficer = true;

				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(InqueryModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindNameOfofficer) {
					qPos.add(nameOfofficer);
				}

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first inquery in the ordered set where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBynameOfofficer_First(String nameOfofficer,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBynameOfofficer_First(nameOfofficer,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("nameOfofficer=");
		msg.append(nameOfofficer);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the first inquery in the ordered set where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBynameOfofficer_First(String nameOfofficer,
		OrderByComparator orderByComparator) throws SystemException {
		List<Inquery> list = findBynameOfofficer(nameOfofficer, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last inquery in the ordered set where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findBynameOfofficer_Last(String nameOfofficer,
		OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchBynameOfofficer_Last(nameOfofficer,
				orderByComparator);

		if (inquery != null) {
			return inquery;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("nameOfofficer=");
		msg.append(nameOfofficer);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchInqueryException(msg.toString());
	}

	/**
	 * Returns the last inquery in the ordered set where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching inquery, or <code>null</code> if a matching inquery could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchBynameOfofficer_Last(String nameOfofficer,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBynameOfofficer(nameOfofficer);

		if (count == 0) {
			return null;
		}

		List<Inquery> list = findBynameOfofficer(nameOfofficer, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the inqueries before and after the current inquery in the ordered set where nameOfofficer = &#63;.
	 *
	 * @param inqueryId the primary key of the current inquery
	 * @param nameOfofficer the name ofofficer
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery[] findBynameOfofficer_PrevAndNext(long inqueryId,
		String nameOfofficer, OrderByComparator orderByComparator)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = findByPrimaryKey(inqueryId);

		Session session = null;

		try {
			session = openSession();

			Inquery[] array = new InqueryImpl[3];

			array[0] = getBynameOfofficer_PrevAndNext(session, inquery,
					nameOfofficer, orderByComparator, true);

			array[1] = inquery;

			array[2] = getBynameOfofficer_PrevAndNext(session, inquery,
					nameOfofficer, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Inquery getBynameOfofficer_PrevAndNext(Session session,
		Inquery inquery, String nameOfofficer,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_INQUERY_WHERE);

		boolean bindNameOfofficer = false;

		if (nameOfofficer == null) {
			query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_1);
		}
		else if (nameOfofficer.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_3);
		}
		else {
			bindNameOfofficer = true;

			query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(InqueryModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindNameOfofficer) {
			qPos.add(nameOfofficer);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(inquery);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Inquery> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the inqueries where nameOfofficer = &#63; from the database.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBynameOfofficer(String nameOfofficer)
		throws SystemException {
		for (Inquery inquery : findBynameOfofficer(nameOfofficer,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries where nameOfofficer = &#63;.
	 *
	 * @param nameOfofficer the name ofofficer
	 * @return the number of matching inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBynameOfofficer(String nameOfofficer)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_NAMEOFOFFICER;

		Object[] finderArgs = new Object[] { nameOfofficer };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_INQUERY_WHERE);

			boolean bindNameOfofficer = false;

			if (nameOfofficer == null) {
				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_1);
			}
			else if (nameOfofficer.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_3);
			}
			else {
				bindNameOfofficer = true;

				query.append(_FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindNameOfofficer) {
					qPos.add(nameOfofficer);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_1 = "inquery.nameOfofficer IS NULL";
	private static final String _FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_2 = "inquery.nameOfofficer = ?";
	private static final String _FINDER_COLUMN_NAMEOFOFFICER_NAMEOFOFFICER_3 = "(inquery.nameOfofficer IS NULL OR inquery.nameOfofficer = '')";

	public InqueryPersistenceImpl() {
		setModelClass(Inquery.class);
	}

	/**
	 * Caches the inquery in the entity cache if it is enabled.
	 *
	 * @param inquery the inquery
	 */
	@Override
	public void cacheResult(Inquery inquery) {
		EntityCacheUtil.putResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryImpl.class, inquery.getPrimaryKey(), inquery);

		inquery.resetOriginalValues();
	}

	/**
	 * Caches the inqueries in the entity cache if it is enabled.
	 *
	 * @param inqueries the inqueries
	 */
	@Override
	public void cacheResult(List<Inquery> inqueries) {
		for (Inquery inquery : inqueries) {
			if (EntityCacheUtil.getResult(
						InqueryModelImpl.ENTITY_CACHE_ENABLED,
						InqueryImpl.class, inquery.getPrimaryKey()) == null) {
				cacheResult(inquery);
			}
			else {
				inquery.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all inqueries.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(InqueryImpl.class.getName());
		}

		EntityCacheUtil.clearCache(InqueryImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the inquery.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Inquery inquery) {
		EntityCacheUtil.removeResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryImpl.class, inquery.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Inquery> inqueries) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Inquery inquery : inqueries) {
			EntityCacheUtil.removeResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
				InqueryImpl.class, inquery.getPrimaryKey());
		}
	}

	/**
	 * Creates a new inquery with the primary key. Does not add the inquery to the database.
	 *
	 * @param inqueryId the primary key for the new inquery
	 * @return the new inquery
	 */
	@Override
	public Inquery create(long inqueryId) {
		Inquery inquery = new InqueryImpl();

		inquery.setNew(true);
		inquery.setPrimaryKey(inqueryId);

		return inquery;
	}

	/**
	 * Removes the inquery with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param inqueryId the primary key of the inquery
	 * @return the inquery that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery remove(long inqueryId)
		throws NoSuchInqueryException, SystemException {
		return remove((Serializable)inqueryId);
	}

	/**
	 * Removes the inquery with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the inquery
	 * @return the inquery that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery remove(Serializable primaryKey)
		throws NoSuchInqueryException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Inquery inquery = (Inquery)session.get(InqueryImpl.class, primaryKey);

			if (inquery == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchInqueryException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(inquery);
		}
		catch (NoSuchInqueryException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Inquery removeImpl(Inquery inquery) throws SystemException {
		inquery = toUnwrappedModel(inquery);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(inquery)) {
				inquery = (Inquery)session.get(InqueryImpl.class,
						inquery.getPrimaryKeyObj());
			}

			if (inquery != null) {
				session.delete(inquery);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (inquery != null) {
			clearCache(inquery);
		}

		return inquery;
	}

	@Override
	public Inquery updateImpl(com.org.skali.sitanAdmin.model.Inquery inquery)
		throws SystemException {
		inquery = toUnwrappedModel(inquery);

		boolean isNew = inquery.isNew();

		InqueryModelImpl inqueryModelImpl = (InqueryModelImpl)inquery;

		Session session = null;

		try {
			session = openSession();

			if (inquery.isNew()) {
				session.save(inquery);

				inquery.setNew(false);
			}
			else {
				session.merge(inquery);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !InqueryModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESIZE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalDatesize()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATESIZE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESIZE,
					args);

				args = new Object[] { inqueryModelImpl.getDatesize() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATESIZE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATESIZE,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalCheckSitesDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKSITESDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESDATE,
					args);

				args = new Object[] { inqueryModelImpl.getCheckSitesDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKSITESDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKSITESDATE,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalReferenceEffective()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE,
					args);

				args = new Object[] { inqueryModelImpl.getReferenceEffective() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_REFERENCEEFFECTIVE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_REFERENCEEFFECTIVE,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalSource()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SOURCE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE,
					args);

				args = new Object[] { inqueryModelImpl.getSource() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_SOURCE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_SOURCE,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOWNER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalNameofowner()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_NAMEOFOWNER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOWNER,
					args);

				args = new Object[] { inqueryModelImpl.getNameofowner() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_NAMEOFOWNER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOWNER,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATION.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalVehicleRegistration()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICLEREGISTRATION,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATION,
					args);

				args = new Object[] { inqueryModelImpl.getVehicleRegistration() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICLEREGISTRATION,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICLEREGISTRATION,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalTerritory()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TERRITORY,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY,
					args);

				args = new Object[] { inqueryModelImpl.getTerritory() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TERRITORY,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TERRITORY,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { inqueryModelImpl.getOriginalState() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE,
					args);

				args = new Object[] { inqueryModelImpl.getState() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATE,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalLocationCageSita()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_LOCATIONCAGESITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA,
					args);

				args = new Object[] { inqueryModelImpl.getLocationCageSita() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_LOCATIONCAGESITA,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_LOCATIONCAGESITA,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalForeclosureStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORECLOSURESTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS,
					args);

				args = new Object[] { inqueryModelImpl.getForeclosureStatus() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORECLOSURESTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORECLOSURESTATUS,
					args);
			}

			if ((inqueryModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOFFICER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						inqueryModelImpl.getOriginalNameOfofficer()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_NAMEOFOFFICER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOFFICER,
					args);

				args = new Object[] { inqueryModelImpl.getNameOfofficer() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_NAMEOFOFFICER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_NAMEOFOFFICER,
					args);
			}
		}

		EntityCacheUtil.putResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
			InqueryImpl.class, inquery.getPrimaryKey(), inquery);

		return inquery;
	}

	protected Inquery toUnwrappedModel(Inquery inquery) {
		if (inquery instanceof InqueryImpl) {
			return inquery;
		}

		InqueryImpl inqueryImpl = new InqueryImpl();

		inqueryImpl.setNew(inquery.isNew());
		inqueryImpl.setPrimaryKey(inquery.getPrimaryKey());

		inqueryImpl.setInqueryId(inquery.getInqueryId());
		inqueryImpl.setDatesize(inquery.getDatesize());
		inqueryImpl.setCheckSitesDate(inquery.getCheckSitesDate());
		inqueryImpl.setReferenceEffective(inquery.getReferenceEffective());
		inqueryImpl.setSource(inquery.getSource());
		inqueryImpl.setNameofowner(inquery.getNameofowner());
		inqueryImpl.setVehicleRegistration(inquery.getVehicleRegistration());
		inqueryImpl.setTerritory(inquery.getTerritory());
		inqueryImpl.setState(inquery.getState());
		inqueryImpl.setLocationCageSita(inquery.getLocationCageSita());
		inqueryImpl.setForeclosureStatus(inquery.getForeclosureStatus());
		inqueryImpl.setNameOfofficer(inquery.getNameOfofficer());

		return inqueryImpl;
	}

	/**
	 * Returns the inquery with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the inquery
	 * @return the inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByPrimaryKey(Serializable primaryKey)
		throws NoSuchInqueryException, SystemException {
		Inquery inquery = fetchByPrimaryKey(primaryKey);

		if (inquery == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchInqueryException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return inquery;
	}

	/**
	 * Returns the inquery with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchInqueryException} if it could not be found.
	 *
	 * @param inqueryId the primary key of the inquery
	 * @return the inquery
	 * @throws com.org.skali.sitanAdmin.NoSuchInqueryException if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery findByPrimaryKey(long inqueryId)
		throws NoSuchInqueryException, SystemException {
		return findByPrimaryKey((Serializable)inqueryId);
	}

	/**
	 * Returns the inquery with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the inquery
	 * @return the inquery, or <code>null</code> if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Inquery inquery = (Inquery)EntityCacheUtil.getResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
				InqueryImpl.class, primaryKey);

		if (inquery == _nullInquery) {
			return null;
		}

		if (inquery == null) {
			Session session = null;

			try {
				session = openSession();

				inquery = (Inquery)session.get(InqueryImpl.class, primaryKey);

				if (inquery != null) {
					cacheResult(inquery);
				}
				else {
					EntityCacheUtil.putResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
						InqueryImpl.class, primaryKey, _nullInquery);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(InqueryModelImpl.ENTITY_CACHE_ENABLED,
					InqueryImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return inquery;
	}

	/**
	 * Returns the inquery with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param inqueryId the primary key of the inquery
	 * @return the inquery, or <code>null</code> if a inquery with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Inquery fetchByPrimaryKey(long inqueryId) throws SystemException {
		return fetchByPrimaryKey((Serializable)inqueryId);
	}

	/**
	 * Returns all the inqueries.
	 *
	 * @return the inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the inqueries.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @return the range of inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findAll(int start, int end) throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the inqueries.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.InqueryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of inqueries
	 * @param end the upper bound of the range of inqueries (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Inquery> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Inquery> list = (List<Inquery>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_INQUERY);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_INQUERY;

				if (pagination) {
					sql = sql.concat(InqueryModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Inquery>(list);
				}
				else {
					list = (List<Inquery>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the inqueries from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Inquery inquery : findAll()) {
			remove(inquery);
		}
	}

	/**
	 * Returns the number of inqueries.
	 *
	 * @return the number of inqueries
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_INQUERY);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the inquery persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.Inquery")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Inquery>> listenersList = new ArrayList<ModelListener<Inquery>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Inquery>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(InqueryImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_INQUERY = "SELECT inquery FROM Inquery inquery";
	private static final String _SQL_SELECT_INQUERY_WHERE = "SELECT inquery FROM Inquery inquery WHERE ";
	private static final String _SQL_COUNT_INQUERY = "SELECT COUNT(inquery) FROM Inquery inquery";
	private static final String _SQL_COUNT_INQUERY_WHERE = "SELECT COUNT(inquery) FROM Inquery inquery WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "inquery.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Inquery exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Inquery exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(InqueryPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"state"
			});
	private static Inquery _nullInquery = new InqueryImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Inquery> toCacheModel() {
				return _nullInqueryCacheModel;
			}
		};

	private static CacheModel<Inquery> _nullInqueryCacheModel = new CacheModel<Inquery>() {
			@Override
			public Inquery toEntityModel() {
				return _nullInquery;
			}
		};
}