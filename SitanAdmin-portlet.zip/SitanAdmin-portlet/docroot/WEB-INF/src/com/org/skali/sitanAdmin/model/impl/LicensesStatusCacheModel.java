/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.LicensesStatus;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing LicensesStatus in entity cache.
 *
 * @author reeshu
 * @see LicensesStatus
 * @generated
 */
public class LicensesStatusCacheModel implements CacheModel<LicensesStatus>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{licensesstatusid=");
		sb.append(licensesstatusid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", active=");
		sb.append(active);
		sb.append(", noActive=");
		sb.append(noActive);
		sb.append(", moreoverHadAge=");
		sb.append(moreoverHadAge);
		sb.append(", finishedWithin=");
		sb.append(finishedWithin);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public LicensesStatus toEntityModel() {
		LicensesStatusImpl licensesStatusImpl = new LicensesStatusImpl();

		licensesStatusImpl.setLicensesstatusid(licensesstatusid);
		licensesStatusImpl.setBilId(bilId);

		if (active == null) {
			licensesStatusImpl.setActive(StringPool.BLANK);
		}
		else {
			licensesStatusImpl.setActive(active);
		}

		if (noActive == null) {
			licensesStatusImpl.setNoActive(StringPool.BLANK);
		}
		else {
			licensesStatusImpl.setNoActive(noActive);
		}

		if (moreoverHadAge == null) {
			licensesStatusImpl.setMoreoverHadAge(StringPool.BLANK);
		}
		else {
			licensesStatusImpl.setMoreoverHadAge(moreoverHadAge);
		}

		if (finishedWithin == null) {
			licensesStatusImpl.setFinishedWithin(StringPool.BLANK);
		}
		else {
			licensesStatusImpl.setFinishedWithin(finishedWithin);
		}

		licensesStatusImpl.resetOriginalValues();

		return licensesStatusImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		licensesstatusid = objectInput.readLong();
		bilId = objectInput.readLong();
		active = objectInput.readUTF();
		noActive = objectInput.readUTF();
		moreoverHadAge = objectInput.readUTF();
		finishedWithin = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(licensesstatusid);
		objectOutput.writeLong(bilId);

		if (active == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(active);
		}

		if (noActive == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(noActive);
		}

		if (moreoverHadAge == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(moreoverHadAge);
		}

		if (finishedWithin == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(finishedWithin);
		}
	}

	public long licensesstatusid;
	public long bilId;
	public String active;
	public String noActive;
	public String moreoverHadAge;
	public String finishedWithin;
}