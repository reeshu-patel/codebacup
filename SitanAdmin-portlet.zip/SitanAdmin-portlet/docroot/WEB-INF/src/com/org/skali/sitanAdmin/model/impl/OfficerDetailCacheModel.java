/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.OfficerDetail;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing OfficerDetail in entity cache.
 *
 * @author reeshu
 * @see OfficerDetail
 * @generated
 */
public class OfficerDetailCacheModel implements CacheModel<OfficerDetail>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{officerid=");
		sb.append(officerid);
		sb.append(", officername=");
		sb.append(officername);
		sb.append(", officertype=");
		sb.append(officertype);
		sb.append(", office=");
		sb.append(office);
		sb.append(", Officerpower=");
		sb.append(Officerpower);
		sb.append(", Date=");
		sb.append(Date);
		sb.append(", officerphone=");
		sb.append(officerphone);
		sb.append(", officerEmail=");
		sb.append(officerEmail);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public OfficerDetail toEntityModel() {
		OfficerDetailImpl officerDetailImpl = new OfficerDetailImpl();

		officerDetailImpl.setOfficerid(officerid);

		if (officername == null) {
			officerDetailImpl.setOfficername(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setOfficername(officername);
		}

		if (officertype == null) {
			officerDetailImpl.setOfficertype(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setOfficertype(officertype);
		}

		if (office == null) {
			officerDetailImpl.setOffice(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setOffice(office);
		}

		if (Officerpower == null) {
			officerDetailImpl.setOfficerpower(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setOfficerpower(Officerpower);
		}

		if (Date == null) {
			officerDetailImpl.setDate(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setDate(Date);
		}

		officerDetailImpl.setOfficerphone(officerphone);

		if (officerEmail == null) {
			officerDetailImpl.setOfficerEmail(StringPool.BLANK);
		}
		else {
			officerDetailImpl.setOfficerEmail(officerEmail);
		}

		officerDetailImpl.resetOriginalValues();

		return officerDetailImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		officerid = objectInput.readLong();
		officername = objectInput.readUTF();
		officertype = objectInput.readUTF();
		office = objectInput.readUTF();
		Officerpower = objectInput.readUTF();
		Date = objectInput.readUTF();
		officerphone = objectInput.readLong();
		officerEmail = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(officerid);

		if (officername == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(officername);
		}

		if (officertype == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(officertype);
		}

		if (office == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(office);
		}

		if (Officerpower == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(Officerpower);
		}

		if (Date == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(Date);
		}

		objectOutput.writeLong(officerphone);

		if (officerEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(officerEmail);
		}
	}

	public long officerid;
	public String officername;
	public String officertype;
	public String office;
	public String Officerpower;
	public String Date;
	public long officerphone;
	public String officerEmail;
}