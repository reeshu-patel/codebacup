/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.jsonwebservice.JSONWebService;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.security.ac.AccessControlled;
import com.org.skali.sitanAdmin.model.Inquery;
import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.InqueryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.base.InqueryServiceBaseImpl;

/**
 * The implementation of the inquery remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.org.skali.sitanAdmin.service.InqueryService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.base.InqueryServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.InqueryServiceUtil
 */
public class InqueryServiceImpl extends InqueryServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.org.skali.sitanAdmin.service.InqueryServiceUtil} to access the inquery remote service.
	 */
	
	//@JSONWebService(value = "InqueryData", method = "GET")
	
	@JSONWebService(value ="Inquery_Data_Search", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject getInqueryData(String datesize, String checkSitesDate, String referenceEffective, String source,String nameofowner,String vehicleRegistration,String territory,String state,String locationCageSita,String foreclosureStatus,String nameOfofficer) throws ParseException
	{
	JSONObject inqueryReturn = JSONFactoryUtil.createJSONObject();
	JSONArray inqueryArray = JSONFactoryUtil.createJSONArray();

	
	List<Inquery> listReturn = new ArrayList<Inquery>();
	
	List<Inquery> list = new ArrayList<Inquery>();
	List<Inquery> inquery = null;
	try {
		inquery = InqueryLocalServiceUtil.getInqueries(0, InqueryLocalServiceUtil.getInqueriesCount());
	} catch (SystemException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	DynamicQuery dynamicQuery =null;
	boolean setFlag = true;
	boolean setFlagand = true;
	try{
	ClassLoader loader=(ClassLoader)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),"portletClassLoader");
	dynamicQuery = DynamicQueryFactoryUtil.forClass(Inquery.class, loader);
	
	Criterion criterion = null;
	
	if(!datesize.equals(StringPool.BLANK)){
		Date dt = new SimpleDateFormat("dd/MM/yyyy").parse(datesize);
		String createDate = new SimpleDateFormat("dd/MM/yyyy").format(dt);	
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("datesize", createDate);
		setFlag = false;
		}
		 criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("datesize",createDate));
		 setFlagand = false;
	}
	
	if(!checkSitesDate.equals(StringPool.BLANK)){
		Date dt1 = new SimpleDateFormat("dd/MM/yyyy").parse(checkSitesDate);
		String createDate1 = new SimpleDateFormat("dd/MM/yyyy").format(dt1);	
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("checkSitesDate", createDate1);
		setFlag = false;
		}
		criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("checkSitesDate",createDate1));
		setFlagand = false;
	}
	
	if(!referenceEffective.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("referenceEffective", referenceEffective);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("referenceEffective",referenceEffective));
		   setFlagand = false;
	}
	
	if(!source.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("source", source);
		setFlag = false;
		}
		criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("source",source));
		setFlagand = false;
	}
	
	if(!nameofowner.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("nameofowner", StringPool.PERCENT+nameofowner+StringPool.PERCENT);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("nameofowner",StringPool.PERCENT+nameofowner+StringPool.PERCENT));
		   setFlagand = false;
	}
	
	if(!vehicleRegistration.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("vehicleRegistration", vehicleRegistration);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("vehicleRegistration",vehicleRegistration));
		   setFlagand = false;
	}
	
	if(!territory.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("territory", territory);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("territory",territory));
		   setFlagand = false;
	}
	
	if(!state.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("state", state);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("state",state));
		   setFlagand = false;
	}
	
	if(!locationCageSita.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("locationCageSita", locationCageSita);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("locationCageSita",locationCageSita));
		   setFlagand = false;
	}
	
	if(!foreclosureStatus.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("foreclosureStatus", foreclosureStatus);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("foreclosureStatus",foreclosureStatus));
		   setFlagand = false;
	}
	if(!nameOfofficer.equals(StringPool.BLANK)){
		if(setFlag){
		criterion = RestrictionsFactoryUtil.like("nameOfofficer", StringPool.PERCENT+nameOfofficer+StringPool.PERCENT);
		setFlag = false;
		}
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("nameOfofficer",StringPool.PERCENT+nameOfofficer+StringPool.PERCENT));
		   setFlagand = false;
		
	}
	dynamicQuery.add(criterion);
	
	List<Inquery> gallryIds;
	try {
		gallryIds = InqueryLocalServiceUtil.dynamicQuery(dynamicQuery);
		for(Inquery gall:gallryIds ){
			list.add(gall);
		}
	} catch (SystemException e) {
		e.printStackTrace();
	}
	
	}catch(Exception e){}
	
	if(Validator.isNotNull(list) && list.size() > 0 )
	{
		for(Inquery inq:list){
			JSONObject noofinquery = JSONFactoryUtil.createJSONObject();
			noofinquery.put("inqueryId", inq.getInqueryId());
			noofinquery.put("datesize", inq.getDatesize());
			noofinquery.put("checkSitesDate", inq.getCheckSitesDate());
			noofinquery.put("referenceEffective", inq.getReferenceEffective());
			noofinquery.put("Source", inq.getSource());
			noofinquery.put("nameofowner", inq.getNameOfofficer());
			noofinquery.put("vehicleRegistration", inq.getVehicleRegistration());
			noofinquery.put("territory", inq.getTerritory());
			noofinquery.put("state", inq.getState());
			noofinquery.put("locationCageSita", inq.getLocationCageSita());
			noofinquery.put("foreclosureStatus", inq.getForeclosureStatus());
			noofinquery.put("nameOfofficer", inq.getNameOfofficer());
			inqueryArray.put(noofinquery);
		}
		
	}else if(setFlag == true && setFlagand == true){
		for(Inquery inq12:inquery){
			JSONObject noofinquery12 = JSONFactoryUtil.createJSONObject();	
			noofinquery12.put("inqueryId", inq12.getInqueryId());
			noofinquery12.put("datesize", inq12.getDatesize());
			noofinquery12.put("checkSitesDate", inq12.getCheckSitesDate());
			noofinquery12.put("referenceEffective", inq12.getReferenceEffective());
			noofinquery12.put("Source", inq12.getSource());
			noofinquery12.put("nameofowner", inq12.getNameOfofficer());
			noofinquery12.put("vehicleRegistration", inq12.getVehicleRegistration());
			noofinquery12.put("territory", inq12.getTerritory());
			noofinquery12.put("state", inq12.getState());
			noofinquery12.put("locationCageSita", inq12.getLocationCageSita());
			noofinquery12.put("foreclosureStatus", inq12.getForeclosureStatus());
			noofinquery12.put("nameOfofficer", inq12.getNameOfofficer());

			inqueryArray.put(noofinquery12);
		}
	}
	
	
	inqueryReturn.put("Inquery", inqueryArray);	 
	
	return inqueryReturn;
		
	}
}