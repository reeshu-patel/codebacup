/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException;
import com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail;
import com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailImpl;
import com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the acceptance vehicle detail service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see AcceptanceVehicleDetailPersistence
 * @see AcceptanceVehicleDetailUtil
 * @generated
 */
public class AcceptanceVehicleDetailPersistenceImpl extends BasePersistenceImpl<AcceptanceVehicleDetail>
	implements AcceptanceVehicleDetailPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link AcceptanceVehicleDetailUtil} to access the acceptance vehicle detail persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = AcceptanceVehicleDetailImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			AcceptanceVehicleDetailModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the acceptance vehicle details where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findBybilId(long bilId)
		throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the acceptance vehicle details where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @return the range of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findBybilId(long bilId, int start,
		int end) throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the acceptance vehicle details where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findBybilId(long bilId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<AcceptanceVehicleDetail> list = (List<AcceptanceVehicleDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (AcceptanceVehicleDetail acceptanceVehicleDetail : list) {
				if ((bilId != acceptanceVehicleDetail.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_ACCEPTANCEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(AcceptanceVehicleDetailModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<AcceptanceVehicleDetail>(list);
				}
				else {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first acceptance vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = fetchBybilId_First(bilId,
				orderByComparator);

		if (acceptanceVehicleDetail != null) {
			return acceptanceVehicleDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchAcceptanceVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the first acceptance vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching acceptance vehicle detail, or <code>null</code> if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<AcceptanceVehicleDetail> list = findBybilId(bilId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last acceptance vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = fetchBybilId_Last(bilId,
				orderByComparator);

		if (acceptanceVehicleDetail != null) {
			return acceptanceVehicleDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchAcceptanceVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the last acceptance vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching acceptance vehicle detail, or <code>null</code> if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<AcceptanceVehicleDetail> list = findBybilId(bilId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the acceptance vehicle details before and after the current acceptance vehicle detail in the ordered set where bilId = &#63;.
	 *
	 * @param vehicalid the primary key of the current acceptance vehicle detail
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail[] findBybilId_PrevAndNext(long vehicalid,
		long bilId, OrderByComparator orderByComparator)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = findByPrimaryKey(vehicalid);

		Session session = null;

		try {
			session = openSession();

			AcceptanceVehicleDetail[] array = new AcceptanceVehicleDetailImpl[3];

			array[0] = getBybilId_PrevAndNext(session, acceptanceVehicleDetail,
					bilId, orderByComparator, true);

			array[1] = acceptanceVehicleDetail;

			array[2] = getBybilId_PrevAndNext(session, acceptanceVehicleDetail,
					bilId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected AcceptanceVehicleDetail getBybilId_PrevAndNext(Session session,
		AcceptanceVehicleDetail acceptanceVehicleDetail, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_ACCEPTANCEVEHICLEDETAIL_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(AcceptanceVehicleDetailModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(acceptanceVehicleDetail);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<AcceptanceVehicleDetail> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the acceptance vehicle details where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (AcceptanceVehicleDetail acceptanceVehicleDetail : findBybilId(
				bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(acceptanceVehicleDetail);
		}
	}

	/**
	 * Returns the number of acceptance vehicle details where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_ACCEPTANCEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "acceptanceVehicleDetail.bilId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICALIDBILLID =
		new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByvehicalidBillId",
			new String[] {
				Long.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICALIDBILLID =
		new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByvehicalidBillId",
			new String[] { Long.class.getName(), Long.class.getName() },
			AcceptanceVehicleDetailModelImpl.BILID_COLUMN_BITMASK |
			AcceptanceVehicleDetailModelImpl.VEHICALID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_VEHICALIDBILLID = new FinderPath(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByvehicalidBillId",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns all the acceptance vehicle details where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @return the matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findByvehicalidBillId(long bilId,
		long vehicalid) throws SystemException {
		return findByvehicalidBillId(bilId, vehicalid, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the acceptance vehicle details where bilId = &#63; and vehicalid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @return the range of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findByvehicalidBillId(long bilId,
		long vehicalid, int start, int end) throws SystemException {
		return findByvehicalidBillId(bilId, vehicalid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the acceptance vehicle details where bilId = &#63; and vehicalid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findByvehicalidBillId(long bilId,
		long vehicalid, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICALIDBILLID;
			finderArgs = new Object[] { bilId, vehicalid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_VEHICALIDBILLID;
			finderArgs = new Object[] {
					bilId, vehicalid,
					
					start, end, orderByComparator
				};
		}

		List<AcceptanceVehicleDetail> list = (List<AcceptanceVehicleDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (AcceptanceVehicleDetail acceptanceVehicleDetail : list) {
				if ((bilId != acceptanceVehicleDetail.getBilId()) ||
						(vehicalid != acceptanceVehicleDetail.getVehicalid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_ACCEPTANCEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_VEHICALIDBILLID_BILID_2);

			query.append(_FINDER_COLUMN_VEHICALIDBILLID_VEHICALID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(AcceptanceVehicleDetailModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				qPos.add(vehicalid);

				if (!pagination) {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<AcceptanceVehicleDetail>(list);
				}
				else {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first acceptance vehicle detail in the ordered set where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findByvehicalidBillId_First(long bilId,
		long vehicalid, OrderByComparator orderByComparator)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = fetchByvehicalidBillId_First(bilId,
				vehicalid, orderByComparator);

		if (acceptanceVehicleDetail != null) {
			return acceptanceVehicleDetail;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(", vehicalid=");
		msg.append(vehicalid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchAcceptanceVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the first acceptance vehicle detail in the ordered set where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching acceptance vehicle detail, or <code>null</code> if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchByvehicalidBillId_First(long bilId,
		long vehicalid, OrderByComparator orderByComparator)
		throws SystemException {
		List<AcceptanceVehicleDetail> list = findByvehicalidBillId(bilId,
				vehicalid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last acceptance vehicle detail in the ordered set where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findByvehicalidBillId_Last(long bilId,
		long vehicalid, OrderByComparator orderByComparator)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = fetchByvehicalidBillId_Last(bilId,
				vehicalid, orderByComparator);

		if (acceptanceVehicleDetail != null) {
			return acceptanceVehicleDetail;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(", vehicalid=");
		msg.append(vehicalid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchAcceptanceVehicleDetailException(msg.toString());
	}

	/**
	 * Returns the last acceptance vehicle detail in the ordered set where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching acceptance vehicle detail, or <code>null</code> if a matching acceptance vehicle detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchByvehicalidBillId_Last(long bilId,
		long vehicalid, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByvehicalidBillId(bilId, vehicalid);

		if (count == 0) {
			return null;
		}

		List<AcceptanceVehicleDetail> list = findByvehicalidBillId(bilId,
				vehicalid, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the acceptance vehicle details where bilId = &#63; and vehicalid = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByvehicalidBillId(long bilId, long vehicalid)
		throws SystemException {
		for (AcceptanceVehicleDetail acceptanceVehicleDetail : findByvehicalidBillId(
				bilId, vehicalid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(acceptanceVehicleDetail);
		}
	}

	/**
	 * Returns the number of acceptance vehicle details where bilId = &#63; and vehicalid = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param vehicalid the vehicalid
	 * @return the number of matching acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByvehicalidBillId(long bilId, long vehicalid)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_VEHICALIDBILLID;

		Object[] finderArgs = new Object[] { bilId, vehicalid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_ACCEPTANCEVEHICLEDETAIL_WHERE);

			query.append(_FINDER_COLUMN_VEHICALIDBILLID_BILID_2);

			query.append(_FINDER_COLUMN_VEHICALIDBILLID_VEHICALID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				qPos.add(vehicalid);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_VEHICALIDBILLID_BILID_2 = "acceptanceVehicleDetail.bilId = ? AND ";
	private static final String _FINDER_COLUMN_VEHICALIDBILLID_VEHICALID_2 = "acceptanceVehicleDetail.vehicalid = ?";

	public AcceptanceVehicleDetailPersistenceImpl() {
		setModelClass(AcceptanceVehicleDetail.class);
	}

	/**
	 * Caches the acceptance vehicle detail in the entity cache if it is enabled.
	 *
	 * @param acceptanceVehicleDetail the acceptance vehicle detail
	 */
	@Override
	public void cacheResult(AcceptanceVehicleDetail acceptanceVehicleDetail) {
		EntityCacheUtil.putResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			acceptanceVehicleDetail.getPrimaryKey(), acceptanceVehicleDetail);

		acceptanceVehicleDetail.resetOriginalValues();
	}

	/**
	 * Caches the acceptance vehicle details in the entity cache if it is enabled.
	 *
	 * @param acceptanceVehicleDetails the acceptance vehicle details
	 */
	@Override
	public void cacheResult(
		List<AcceptanceVehicleDetail> acceptanceVehicleDetails) {
		for (AcceptanceVehicleDetail acceptanceVehicleDetail : acceptanceVehicleDetails) {
			if (EntityCacheUtil.getResult(
						AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
						AcceptanceVehicleDetailImpl.class,
						acceptanceVehicleDetail.getPrimaryKey()) == null) {
				cacheResult(acceptanceVehicleDetail);
			}
			else {
				acceptanceVehicleDetail.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all acceptance vehicle details.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(AcceptanceVehicleDetailImpl.class.getName());
		}

		EntityCacheUtil.clearCache(AcceptanceVehicleDetailImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the acceptance vehicle detail.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(AcceptanceVehicleDetail acceptanceVehicleDetail) {
		EntityCacheUtil.removeResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			acceptanceVehicleDetail.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(
		List<AcceptanceVehicleDetail> acceptanceVehicleDetails) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (AcceptanceVehicleDetail acceptanceVehicleDetail : acceptanceVehicleDetails) {
			EntityCacheUtil.removeResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
				AcceptanceVehicleDetailImpl.class,
				acceptanceVehicleDetail.getPrimaryKey());
		}
	}

	/**
	 * Creates a new acceptance vehicle detail with the primary key. Does not add the acceptance vehicle detail to the database.
	 *
	 * @param vehicalid the primary key for the new acceptance vehicle detail
	 * @return the new acceptance vehicle detail
	 */
	@Override
	public AcceptanceVehicleDetail create(long vehicalid) {
		AcceptanceVehicleDetail acceptanceVehicleDetail = new AcceptanceVehicleDetailImpl();

		acceptanceVehicleDetail.setNew(true);
		acceptanceVehicleDetail.setPrimaryKey(vehicalid);

		return acceptanceVehicleDetail;
	}

	/**
	 * Removes the acceptance vehicle detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param vehicalid the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail remove(long vehicalid)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		return remove((Serializable)vehicalid);
	}

	/**
	 * Removes the acceptance vehicle detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail remove(Serializable primaryKey)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		Session session = null;

		try {
			session = openSession();

			AcceptanceVehicleDetail acceptanceVehicleDetail = (AcceptanceVehicleDetail)session.get(AcceptanceVehicleDetailImpl.class,
					primaryKey);

			if (acceptanceVehicleDetail == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchAcceptanceVehicleDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(acceptanceVehicleDetail);
		}
		catch (NoSuchAcceptanceVehicleDetailException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected AcceptanceVehicleDetail removeImpl(
		AcceptanceVehicleDetail acceptanceVehicleDetail)
		throws SystemException {
		acceptanceVehicleDetail = toUnwrappedModel(acceptanceVehicleDetail);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(acceptanceVehicleDetail)) {
				acceptanceVehicleDetail = (AcceptanceVehicleDetail)session.get(AcceptanceVehicleDetailImpl.class,
						acceptanceVehicleDetail.getPrimaryKeyObj());
			}

			if (acceptanceVehicleDetail != null) {
				session.delete(acceptanceVehicleDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (acceptanceVehicleDetail != null) {
			clearCache(acceptanceVehicleDetail);
		}

		return acceptanceVehicleDetail;
	}

	@Override
	public AcceptanceVehicleDetail updateImpl(
		com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail acceptanceVehicleDetail)
		throws SystemException {
		acceptanceVehicleDetail = toUnwrappedModel(acceptanceVehicleDetail);

		boolean isNew = acceptanceVehicleDetail.isNew();

		AcceptanceVehicleDetailModelImpl acceptanceVehicleDetailModelImpl = (AcceptanceVehicleDetailModelImpl)acceptanceVehicleDetail;

		Session session = null;

		try {
			session = openSession();

			if (acceptanceVehicleDetail.isNew()) {
				session.save(acceptanceVehicleDetail);

				acceptanceVehicleDetail.setNew(false);
			}
			else {
				session.merge(acceptanceVehicleDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !AcceptanceVehicleDetailModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((acceptanceVehicleDetailModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						acceptanceVehicleDetailModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { acceptanceVehicleDetailModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}

			if ((acceptanceVehicleDetailModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICALIDBILLID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						acceptanceVehicleDetailModelImpl.getOriginalBilId(),
						acceptanceVehicleDetailModelImpl.getOriginalVehicalid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICALIDBILLID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICALIDBILLID,
					args);

				args = new Object[] {
						acceptanceVehicleDetailModelImpl.getBilId(),
						acceptanceVehicleDetailModelImpl.getVehicalid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_VEHICALIDBILLID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_VEHICALIDBILLID,
					args);
			}
		}

		EntityCacheUtil.putResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
			AcceptanceVehicleDetailImpl.class,
			acceptanceVehicleDetail.getPrimaryKey(), acceptanceVehicleDetail);

		return acceptanceVehicleDetail;
	}

	protected AcceptanceVehicleDetail toUnwrappedModel(
		AcceptanceVehicleDetail acceptanceVehicleDetail) {
		if (acceptanceVehicleDetail instanceof AcceptanceVehicleDetailImpl) {
			return acceptanceVehicleDetail;
		}

		AcceptanceVehicleDetailImpl acceptanceVehicleDetailImpl = new AcceptanceVehicleDetailImpl();

		acceptanceVehicleDetailImpl.setNew(acceptanceVehicleDetail.isNew());
		acceptanceVehicleDetailImpl.setPrimaryKey(acceptanceVehicleDetail.getPrimaryKey());

		acceptanceVehicleDetailImpl.setVehicalid(acceptanceVehicleDetail.getVehicalid());
		acceptanceVehicleDetailImpl.setBilId(acceptanceVehicleDetail.getBilId());
		acceptanceVehicleDetailImpl.setVehiNumberPlate(acceptanceVehicleDetail.getVehiNumberPlate());
		acceptanceVehicleDetailImpl.setOwnerName(acceptanceVehicleDetail.getOwnerName());
		acceptanceVehicleDetailImpl.setCompanyRepresentative(acceptanceVehicleDetail.getCompanyRepresentative());
		acceptanceVehicleDetailImpl.setKpNo(acceptanceVehicleDetail.getKpNo());
		acceptanceVehicleDetailImpl.setChronicle(acceptanceVehicleDetail.getChronicle());
		acceptanceVehicleDetailImpl.setSignature(acceptanceVehicleDetail.getSignature());
		acceptanceVehicleDetailImpl.setAccodocument(acceptanceVehicleDetail.getAccodocument());
		acceptanceVehicleDetailImpl.setCardIdentity(acceptanceVehicleDetail.getCardIdentity());
		acceptanceVehicleDetailImpl.setDrivingLicense(acceptanceVehicleDetail.getDrivingLicense());
		acceptanceVehicleDetailImpl.setGrantVehicle(acceptanceVehicleDetail.getGrantVehicle());
		acceptanceVehicleDetailImpl.setAttorney(acceptanceVehicleDetail.getAttorney());
		acceptanceVehicleDetailImpl.setNumberPlateDetail(acceptanceVehicleDetail.getNumberPlateDetail());

		return acceptanceVehicleDetailImpl;
	}

	/**
	 * Returns the acceptance vehicle detail with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findByPrimaryKey(Serializable primaryKey)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = fetchByPrimaryKey(primaryKey);

		if (acceptanceVehicleDetail == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchAcceptanceVehicleDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return acceptanceVehicleDetail;
	}

	/**
	 * Returns the acceptance vehicle detail with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException} if it could not be found.
	 *
	 * @param vehicalid the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail
	 * @throws com.org.skali.sitanAdmin.NoSuchAcceptanceVehicleDetailException if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail findByPrimaryKey(long vehicalid)
		throws NoSuchAcceptanceVehicleDetailException, SystemException {
		return findByPrimaryKey((Serializable)vehicalid);
	}

	/**
	 * Returns the acceptance vehicle detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail, or <code>null</code> if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		AcceptanceVehicleDetail acceptanceVehicleDetail = (AcceptanceVehicleDetail)EntityCacheUtil.getResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
				AcceptanceVehicleDetailImpl.class, primaryKey);

		if (acceptanceVehicleDetail == _nullAcceptanceVehicleDetail) {
			return null;
		}

		if (acceptanceVehicleDetail == null) {
			Session session = null;

			try {
				session = openSession();

				acceptanceVehicleDetail = (AcceptanceVehicleDetail)session.get(AcceptanceVehicleDetailImpl.class,
						primaryKey);

				if (acceptanceVehicleDetail != null) {
					cacheResult(acceptanceVehicleDetail);
				}
				else {
					EntityCacheUtil.putResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
						AcceptanceVehicleDetailImpl.class, primaryKey,
						_nullAcceptanceVehicleDetail);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(AcceptanceVehicleDetailModelImpl.ENTITY_CACHE_ENABLED,
					AcceptanceVehicleDetailImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return acceptanceVehicleDetail;
	}

	/**
	 * Returns the acceptance vehicle detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param vehicalid the primary key of the acceptance vehicle detail
	 * @return the acceptance vehicle detail, or <code>null</code> if a acceptance vehicle detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public AcceptanceVehicleDetail fetchByPrimaryKey(long vehicalid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)vehicalid);
	}

	/**
	 * Returns all the acceptance vehicle details.
	 *
	 * @return the acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the acceptance vehicle details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @return the range of acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the acceptance vehicle details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of acceptance vehicle details
	 * @param end the upper bound of the range of acceptance vehicle details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<AcceptanceVehicleDetail> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<AcceptanceVehicleDetail> list = (List<AcceptanceVehicleDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_ACCEPTANCEVEHICLEDETAIL);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_ACCEPTANCEVEHICLEDETAIL;

				if (pagination) {
					sql = sql.concat(AcceptanceVehicleDetailModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<AcceptanceVehicleDetail>(list);
				}
				else {
					list = (List<AcceptanceVehicleDetail>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the acceptance vehicle details from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (AcceptanceVehicleDetail acceptanceVehicleDetail : findAll()) {
			remove(acceptanceVehicleDetail);
		}
	}

	/**
	 * Returns the number of acceptance vehicle details.
	 *
	 * @return the number of acceptance vehicle details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_ACCEPTANCEVEHICLEDETAIL);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the acceptance vehicle detail persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<AcceptanceVehicleDetail>> listenersList = new ArrayList<ModelListener<AcceptanceVehicleDetail>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<AcceptanceVehicleDetail>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(AcceptanceVehicleDetailImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_ACCEPTANCEVEHICLEDETAIL = "SELECT acceptanceVehicleDetail FROM AcceptanceVehicleDetail acceptanceVehicleDetail";
	private static final String _SQL_SELECT_ACCEPTANCEVEHICLEDETAIL_WHERE = "SELECT acceptanceVehicleDetail FROM AcceptanceVehicleDetail acceptanceVehicleDetail WHERE ";
	private static final String _SQL_COUNT_ACCEPTANCEVEHICLEDETAIL = "SELECT COUNT(acceptanceVehicleDetail) FROM AcceptanceVehicleDetail acceptanceVehicleDetail";
	private static final String _SQL_COUNT_ACCEPTANCEVEHICLEDETAIL_WHERE = "SELECT COUNT(acceptanceVehicleDetail) FROM AcceptanceVehicleDetail acceptanceVehicleDetail WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "acceptanceVehicleDetail.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No AcceptanceVehicleDetail exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No AcceptanceVehicleDetail exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(AcceptanceVehicleDetailPersistenceImpl.class);
	private static AcceptanceVehicleDetail _nullAcceptanceVehicleDetail = new AcceptanceVehicleDetailImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<AcceptanceVehicleDetail> toCacheModel() {
				return _nullAcceptanceVehicleDetailCacheModel;
			}
		};

	private static CacheModel<AcceptanceVehicleDetail> _nullAcceptanceVehicleDetailCacheModel =
		new CacheModel<AcceptanceVehicleDetail>() {
			@Override
			public AcceptanceVehicleDetail toEntityModel() {
				return _nullAcceptanceVehicleDetail;
			}
		};
}