/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.BoardDirector;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing BoardDirector in entity cache.
 *
 * @author reeshu
 * @see BoardDirector
 * @generated
 */
public class BoardDirectorCacheModel implements CacheModel<BoardDirector>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{boarddirectorid=");
		sb.append(boarddirectorid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", wealp=");
		sb.append(wealp);
		sb.append(", kplama=");
		sb.append(kplama);
		sb.append(", newKp=");
		sb.append(newKp);
		sb.append(", position=");
		sb.append(position);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public BoardDirector toEntityModel() {
		BoardDirectorImpl boardDirectorImpl = new BoardDirectorImpl();

		boardDirectorImpl.setBoarddirectorid(boarddirectorid);
		boardDirectorImpl.setBilId(bilId);

		if (wealp == null) {
			boardDirectorImpl.setWealp(StringPool.BLANK);
		}
		else {
			boardDirectorImpl.setWealp(wealp);
		}

		if (kplama == null) {
			boardDirectorImpl.setKplama(StringPool.BLANK);
		}
		else {
			boardDirectorImpl.setKplama(kplama);
		}

		if (newKp == null) {
			boardDirectorImpl.setNewKp(StringPool.BLANK);
		}
		else {
			boardDirectorImpl.setNewKp(newKp);
		}

		if (position == null) {
			boardDirectorImpl.setPosition(StringPool.BLANK);
		}
		else {
			boardDirectorImpl.setPosition(position);
		}

		boardDirectorImpl.resetOriginalValues();

		return boardDirectorImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		boarddirectorid = objectInput.readLong();
		bilId = objectInput.readLong();
		wealp = objectInput.readUTF();
		kplama = objectInput.readUTF();
		newKp = objectInput.readUTF();
		position = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(boarddirectorid);
		objectOutput.writeLong(bilId);

		if (wealp == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(wealp);
		}

		if (kplama == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(kplama);
		}

		if (newKp == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(newKp);
		}

		if (position == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(position);
		}
	}

	public long boarddirectorid;
	public long bilId;
	public String wealp;
	public String kplama;
	public String newKp;
	public String position;
}