/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchDocumentTreeException;
import com.org.skali.sitanAdmin.model.DocumentTree;
import com.org.skali.sitanAdmin.model.impl.DocumentTreeImpl;
import com.org.skali.sitanAdmin.model.impl.DocumentTreeModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the document tree service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see DocumentTreePersistence
 * @see DocumentTreeUtil
 * @generated
 */
public class DocumentTreePersistenceImpl extends BasePersistenceImpl<DocumentTree>
	implements DocumentTreePersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DocumentTreeUtil} to access the document tree persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DocumentTreeImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, DocumentTreeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, DocumentTreeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, DocumentTreeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, DocumentTreeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			DocumentTreeModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the document trees where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findBybilId(long bilId) throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the document trees where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.DocumentTreeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of document trees
	 * @param end the upper bound of the range of document trees (not inclusive)
	 * @return the range of matching document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the document trees where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.DocumentTreeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of document trees
	 * @param end the upper bound of the range of document trees (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findBybilId(long bilId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<DocumentTree> list = (List<DocumentTree>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DocumentTree documentTree : list) {
				if ((bilId != documentTree.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DOCUMENTTREE_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DocumentTreeModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<DocumentTree>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DocumentTree>(list);
				}
				else {
					list = (List<DocumentTree>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first document tree in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document tree
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a matching document tree could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchDocumentTreeException, SystemException {
		DocumentTree documentTree = fetchBybilId_First(bilId, orderByComparator);

		if (documentTree != null) {
			return documentTree;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDocumentTreeException(msg.toString());
	}

	/**
	 * Returns the first document tree in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching document tree, or <code>null</code> if a matching document tree could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DocumentTree> list = findBybilId(bilId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last document tree in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document tree
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a matching document tree could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchDocumentTreeException, SystemException {
		DocumentTree documentTree = fetchBybilId_Last(bilId, orderByComparator);

		if (documentTree != null) {
			return documentTree;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDocumentTreeException(msg.toString());
	}

	/**
	 * Returns the last document tree in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching document tree, or <code>null</code> if a matching document tree could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<DocumentTree> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the document trees before and after the current document tree in the ordered set where bilId = &#63;.
	 *
	 * @param documenttreeid the primary key of the current document tree
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next document tree
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree[] findBybilId_PrevAndNext(long documenttreeid,
		long bilId, OrderByComparator orderByComparator)
		throws NoSuchDocumentTreeException, SystemException {
		DocumentTree documentTree = findByPrimaryKey(documenttreeid);

		Session session = null;

		try {
			session = openSession();

			DocumentTree[] array = new DocumentTreeImpl[3];

			array[0] = getBybilId_PrevAndNext(session, documentTree, bilId,
					orderByComparator, true);

			array[1] = documentTree;

			array[2] = getBybilId_PrevAndNext(session, documentTree, bilId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DocumentTree getBybilId_PrevAndNext(Session session,
		DocumentTree documentTree, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DOCUMENTTREE_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DocumentTreeModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(documentTree);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DocumentTree> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the document trees where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (DocumentTree documentTree : findBybilId(bilId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(documentTree);
		}
	}

	/**
	 * Returns the number of document trees where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DOCUMENTTREE_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "documentTree.bilId = ?";

	public DocumentTreePersistenceImpl() {
		setModelClass(DocumentTree.class);
	}

	/**
	 * Caches the document tree in the entity cache if it is enabled.
	 *
	 * @param documentTree the document tree
	 */
	@Override
	public void cacheResult(DocumentTree documentTree) {
		EntityCacheUtil.putResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeImpl.class, documentTree.getPrimaryKey(), documentTree);

		documentTree.resetOriginalValues();
	}

	/**
	 * Caches the document trees in the entity cache if it is enabled.
	 *
	 * @param documentTrees the document trees
	 */
	@Override
	public void cacheResult(List<DocumentTree> documentTrees) {
		for (DocumentTree documentTree : documentTrees) {
			if (EntityCacheUtil.getResult(
						DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
						DocumentTreeImpl.class, documentTree.getPrimaryKey()) == null) {
				cacheResult(documentTree);
			}
			else {
				documentTree.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all document trees.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DocumentTreeImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DocumentTreeImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the document tree.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DocumentTree documentTree) {
		EntityCacheUtil.removeResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeImpl.class, documentTree.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<DocumentTree> documentTrees) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DocumentTree documentTree : documentTrees) {
			EntityCacheUtil.removeResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
				DocumentTreeImpl.class, documentTree.getPrimaryKey());
		}
	}

	/**
	 * Creates a new document tree with the primary key. Does not add the document tree to the database.
	 *
	 * @param documenttreeid the primary key for the new document tree
	 * @return the new document tree
	 */
	@Override
	public DocumentTree create(long documenttreeid) {
		DocumentTree documentTree = new DocumentTreeImpl();

		documentTree.setNew(true);
		documentTree.setPrimaryKey(documenttreeid);

		return documentTree;
	}

	/**
	 * Removes the document tree with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param documenttreeid the primary key of the document tree
	 * @return the document tree that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree remove(long documenttreeid)
		throws NoSuchDocumentTreeException, SystemException {
		return remove((Serializable)documenttreeid);
	}

	/**
	 * Removes the document tree with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the document tree
	 * @return the document tree that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree remove(Serializable primaryKey)
		throws NoSuchDocumentTreeException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DocumentTree documentTree = (DocumentTree)session.get(DocumentTreeImpl.class,
					primaryKey);

			if (documentTree == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDocumentTreeException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(documentTree);
		}
		catch (NoSuchDocumentTreeException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DocumentTree removeImpl(DocumentTree documentTree)
		throws SystemException {
		documentTree = toUnwrappedModel(documentTree);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(documentTree)) {
				documentTree = (DocumentTree)session.get(DocumentTreeImpl.class,
						documentTree.getPrimaryKeyObj());
			}

			if (documentTree != null) {
				session.delete(documentTree);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (documentTree != null) {
			clearCache(documentTree);
		}

		return documentTree;
	}

	@Override
	public DocumentTree updateImpl(
		com.org.skali.sitanAdmin.model.DocumentTree documentTree)
		throws SystemException {
		documentTree = toUnwrappedModel(documentTree);

		boolean isNew = documentTree.isNew();

		DocumentTreeModelImpl documentTreeModelImpl = (DocumentTreeModelImpl)documentTree;

		Session session = null;

		try {
			session = openSession();

			if (documentTree.isNew()) {
				session.save(documentTree);

				documentTree.setNew(false);
			}
			else {
				session.merge(documentTree);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !DocumentTreeModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((documentTreeModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						documentTreeModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { documentTreeModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}
		}

		EntityCacheUtil.putResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
			DocumentTreeImpl.class, documentTree.getPrimaryKey(), documentTree);

		return documentTree;
	}

	protected DocumentTree toUnwrappedModel(DocumentTree documentTree) {
		if (documentTree instanceof DocumentTreeImpl) {
			return documentTree;
		}

		DocumentTreeImpl documentTreeImpl = new DocumentTreeImpl();

		documentTreeImpl.setNew(documentTree.isNew());
		documentTreeImpl.setPrimaryKey(documentTree.getPrimaryKey());

		documentTreeImpl.setDocumenttreeid(documentTree.getDocumenttreeid());
		documentTreeImpl.setBilId(documentTree.getBilId());
		documentTreeImpl.setFileentryid(documentTree.getFileentryid());
		documentTreeImpl.setFolderid(documentTree.getFolderid());
		documentTreeImpl.setFoldername(documentTree.getFoldername());
		documentTreeImpl.setTitle(documentTree.getTitle());
		documentTreeImpl.setDescription(documentTree.getDescription());
		documentTreeImpl.setLeaf(documentTree.getLeaf());
		documentTreeImpl.setType(documentTree.getType());

		return documentTreeImpl;
	}

	/**
	 * Returns the document tree with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the document tree
	 * @return the document tree
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDocumentTreeException, SystemException {
		DocumentTree documentTree = fetchByPrimaryKey(primaryKey);

		if (documentTree == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDocumentTreeException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return documentTree;
	}

	/**
	 * Returns the document tree with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchDocumentTreeException} if it could not be found.
	 *
	 * @param documenttreeid the primary key of the document tree
	 * @return the document tree
	 * @throws com.org.skali.sitanAdmin.NoSuchDocumentTreeException if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree findByPrimaryKey(long documenttreeid)
		throws NoSuchDocumentTreeException, SystemException {
		return findByPrimaryKey((Serializable)documenttreeid);
	}

	/**
	 * Returns the document tree with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the document tree
	 * @return the document tree, or <code>null</code> if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DocumentTree documentTree = (DocumentTree)EntityCacheUtil.getResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
				DocumentTreeImpl.class, primaryKey);

		if (documentTree == _nullDocumentTree) {
			return null;
		}

		if (documentTree == null) {
			Session session = null;

			try {
				session = openSession();

				documentTree = (DocumentTree)session.get(DocumentTreeImpl.class,
						primaryKey);

				if (documentTree != null) {
					cacheResult(documentTree);
				}
				else {
					EntityCacheUtil.putResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
						DocumentTreeImpl.class, primaryKey, _nullDocumentTree);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DocumentTreeModelImpl.ENTITY_CACHE_ENABLED,
					DocumentTreeImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return documentTree;
	}

	/**
	 * Returns the document tree with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param documenttreeid the primary key of the document tree
	 * @return the document tree, or <code>null</code> if a document tree with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DocumentTree fetchByPrimaryKey(long documenttreeid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)documenttreeid);
	}

	/**
	 * Returns all the document trees.
	 *
	 * @return the document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the document trees.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.DocumentTreeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of document trees
	 * @param end the upper bound of the range of document trees (not inclusive)
	 * @return the range of document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the document trees.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.DocumentTreeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of document trees
	 * @param end the upper bound of the range of document trees (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DocumentTree> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DocumentTree> list = (List<DocumentTree>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DOCUMENTTREE);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DOCUMENTTREE;

				if (pagination) {
					sql = sql.concat(DocumentTreeModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DocumentTree>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DocumentTree>(list);
				}
				else {
					list = (List<DocumentTree>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the document trees from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DocumentTree documentTree : findAll()) {
			remove(documentTree);
		}
	}

	/**
	 * Returns the number of document trees.
	 *
	 * @return the number of document trees
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DOCUMENTTREE);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the document tree persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.DocumentTree")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DocumentTree>> listenersList = new ArrayList<ModelListener<DocumentTree>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DocumentTree>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DocumentTreeImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DOCUMENTTREE = "SELECT documentTree FROM DocumentTree documentTree";
	private static final String _SQL_SELECT_DOCUMENTTREE_WHERE = "SELECT documentTree FROM DocumentTree documentTree WHERE ";
	private static final String _SQL_COUNT_DOCUMENTTREE = "SELECT COUNT(documentTree) FROM DocumentTree documentTree";
	private static final String _SQL_COUNT_DOCUMENTTREE_WHERE = "SELECT COUNT(documentTree) FROM DocumentTree documentTree WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "documentTree.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DocumentTree exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No DocumentTree exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DocumentTreePersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"type"
			});
	private static DocumentTree _nullDocumentTree = new DocumentTreeImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DocumentTree> toCacheModel() {
				return _nullDocumentTreeCacheModel;
			}
		};

	private static CacheModel<DocumentTree> _nullDocumentTreeCacheModel = new CacheModel<DocumentTree>() {
			@Override
			public DocumentTree toEntityModel() {
				return _nullDocumentTree;
			}
		};
}