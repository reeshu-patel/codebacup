/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchvisualchecklistException;
import com.org.skali.sitanAdmin.model.impl.visualchecklistImpl;
import com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl;
import com.org.skali.sitanAdmin.model.visualchecklist;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the visualchecklist service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see visualchecklistPersistence
 * @see visualchecklistUtil
 * @generated
 */
public class visualchecklistPersistenceImpl extends BasePersistenceImpl<visualchecklist>
	implements visualchecklistPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link visualchecklistUtil} to access the visualchecklist persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = visualchecklistImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKID = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBycheckId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKID =
		new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycheckId",
			new String[] { Long.class.getName() },
			visualchecklistModelImpl.CHECKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CHECKID = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycheckId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the visualchecklists where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @return the matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBycheckId(long checkId)
		throws SystemException {
		return findBycheckId(checkId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the visualchecklists where checkId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkId the check ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @return the range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBycheckId(long checkId, int start, int end)
		throws SystemException {
		return findBycheckId(checkId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the visualchecklists where checkId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param checkId the check ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBycheckId(long checkId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKID;
			finderArgs = new Object[] { checkId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKID;
			finderArgs = new Object[] { checkId, start, end, orderByComparator };
		}

		List<visualchecklist> list = (List<visualchecklist>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (visualchecklist visualchecklist : list) {
				if ((checkId != visualchecklist.getCheckId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_CHECKID_CHECKID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(visualchecklistModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(checkId);

				if (!pagination) {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<visualchecklist>(list);
				}
				else {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first visualchecklist in the ordered set where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findBycheckId_First(long checkId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchBycheckId_First(checkId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkId=");
		msg.append(checkId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the first visualchecklist in the ordered set where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchBycheckId_First(long checkId,
		OrderByComparator orderByComparator) throws SystemException {
		List<visualchecklist> list = findBycheckId(checkId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last visualchecklist in the ordered set where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findBycheckId_Last(long checkId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchBycheckId_Last(checkId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("checkId=");
		msg.append(checkId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the last visualchecklist in the ordered set where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchBycheckId_Last(long checkId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBycheckId(checkId);

		if (count == 0) {
			return null;
		}

		List<visualchecklist> list = findBycheckId(checkId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the visualchecklists where checkId = &#63; from the database.
	 *
	 * @param checkId the check ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBycheckId(long checkId) throws SystemException {
		for (visualchecklist visualchecklist : findBycheckId(checkId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(visualchecklist);
		}
	}

	/**
	 * Returns the number of visualchecklists where checkId = &#63;.
	 *
	 * @param checkId the check ID
	 * @return the number of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBycheckId(long checkId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKID;

		Object[] finderArgs = new Object[] { checkId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_CHECKID_CHECKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(checkId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CHECKID_CHECKID_2 = "visualchecklist.checkId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBybilId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBybilId",
			new String[] { Long.class.getName() },
			visualchecklistModelImpl.BILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILID = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBybilId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the visualchecklists where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBybilId(long bilId)
		throws SystemException {
		return findBybilId(bilId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the visualchecklists where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @return the range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBybilId(long bilId, int start, int end)
		throws SystemException {
		return findBybilId(bilId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the visualchecklists where bilId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findBybilId(long bilId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILID;
			finderArgs = new Object[] { bilId, start, end, orderByComparator };
		}

		List<visualchecklist> list = (List<visualchecklist>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (visualchecklist visualchecklist : list) {
				if ((bilId != visualchecklist.getBilId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(visualchecklistModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				if (!pagination) {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<visualchecklist>(list);
				}
				else {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first visualchecklist in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findBybilId_First(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchBybilId_First(bilId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the first visualchecklist in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchBybilId_First(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		List<visualchecklist> list = findBybilId(bilId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last visualchecklist in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findBybilId_Last(long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchBybilId_Last(bilId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the last visualchecklist in the ordered set where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchBybilId_Last(long bilId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBybilId(bilId);

		if (count == 0) {
			return null;
		}

		List<visualchecklist> list = findBybilId(bilId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the visualchecklists before and after the current visualchecklist in the ordered set where bilId = &#63;.
	 *
	 * @param checkId the primary key of the current visualchecklist
	 * @param bilId the bil ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist[] findBybilId_PrevAndNext(long checkId, long bilId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = findByPrimaryKey(checkId);

		Session session = null;

		try {
			session = openSession();

			visualchecklist[] array = new visualchecklistImpl[3];

			array[0] = getBybilId_PrevAndNext(session, visualchecklist, bilId,
					orderByComparator, true);

			array[1] = visualchecklist;

			array[2] = getBybilId_PrevAndNext(session, visualchecklist, bilId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected visualchecklist getBybilId_PrevAndNext(Session session,
		visualchecklist visualchecklist, long bilId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_VISUALCHECKLIST_WHERE);

		query.append(_FINDER_COLUMN_BILID_BILID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(visualchecklistModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(bilId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(visualchecklist);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<visualchecklist> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the visualchecklists where bilId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBybilId(long bilId) throws SystemException {
		for (visualchecklist visualchecklist : findBybilId(bilId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(visualchecklist);
		}
	}

	/**
	 * Returns the number of visualchecklists where bilId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @return the number of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBybilId(long bilId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILID;

		Object[] finderArgs = new Object[] { bilId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_BILID_BILID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILID_BILID_2 = "visualchecklist.bilId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_BILLCHEK = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByBillChek",
			new String[] {
				Long.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILLCHEK =
		new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED,
			visualchecklistImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByBillChek",
			new String[] { Long.class.getName(), Long.class.getName() },
			visualchecklistModelImpl.BILID_COLUMN_BITMASK |
			visualchecklistModelImpl.CHECKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_BILLCHEK = new FinderPath(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByBillChek",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns all the visualchecklists where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @return the matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findByBillChek(long bilId, long checkId)
		throws SystemException {
		return findByBillChek(bilId, checkId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the visualchecklists where bilId = &#63; and checkId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @return the range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findByBillChek(long bilId, long checkId,
		int start, int end) throws SystemException {
		return findByBillChek(bilId, checkId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the visualchecklists where bilId = &#63; and checkId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findByBillChek(long bilId, long checkId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILLCHEK;
			finderArgs = new Object[] { bilId, checkId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_BILLCHEK;
			finderArgs = new Object[] {
					bilId, checkId,
					
					start, end, orderByComparator
				};
		}

		List<visualchecklist> list = (List<visualchecklist>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (visualchecklist visualchecklist : list) {
				if ((bilId != visualchecklist.getBilId()) ||
						(checkId != visualchecklist.getCheckId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_BILLCHEK_BILID_2);

			query.append(_FINDER_COLUMN_BILLCHEK_CHECKID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(visualchecklistModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				qPos.add(checkId);

				if (!pagination) {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<visualchecklist>(list);
				}
				else {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findByBillChek_First(long bilId, long checkId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchByBillChek_First(bilId, checkId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(", checkId=");
		msg.append(checkId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the first visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchByBillChek_First(long bilId, long checkId,
		OrderByComparator orderByComparator) throws SystemException {
		List<visualchecklist> list = findByBillChek(bilId, checkId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findByBillChek_Last(long bilId, long checkId,
		OrderByComparator orderByComparator)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchByBillChek_Last(bilId, checkId,
				orderByComparator);

		if (visualchecklist != null) {
			return visualchecklist;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("bilId=");
		msg.append(bilId);

		msg.append(", checkId=");
		msg.append(checkId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchvisualchecklistException(msg.toString());
	}

	/**
	 * Returns the last visualchecklist in the ordered set where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching visualchecklist, or <code>null</code> if a matching visualchecklist could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchByBillChek_Last(long bilId, long checkId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByBillChek(bilId, checkId);

		if (count == 0) {
			return null;
		}

		List<visualchecklist> list = findByBillChek(bilId, checkId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the visualchecklists where bilId = &#63; and checkId = &#63; from the database.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByBillChek(long bilId, long checkId)
		throws SystemException {
		for (visualchecklist visualchecklist : findByBillChek(bilId, checkId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(visualchecklist);
		}
	}

	/**
	 * Returns the number of visualchecklists where bilId = &#63; and checkId = &#63;.
	 *
	 * @param bilId the bil ID
	 * @param checkId the check ID
	 * @return the number of matching visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByBillChek(long bilId, long checkId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_BILLCHEK;

		Object[] finderArgs = new Object[] { bilId, checkId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_VISUALCHECKLIST_WHERE);

			query.append(_FINDER_COLUMN_BILLCHEK_BILID_2);

			query.append(_FINDER_COLUMN_BILLCHEK_CHECKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(bilId);

				qPos.add(checkId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BILLCHEK_BILID_2 = "visualchecklist.bilId = ? AND ";
	private static final String _FINDER_COLUMN_BILLCHEK_CHECKID_2 = "visualchecklist.checkId = ?";

	public visualchecklistPersistenceImpl() {
		setModelClass(visualchecklist.class);
	}

	/**
	 * Caches the visualchecklist in the entity cache if it is enabled.
	 *
	 * @param visualchecklist the visualchecklist
	 */
	@Override
	public void cacheResult(visualchecklist visualchecklist) {
		EntityCacheUtil.putResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistImpl.class, visualchecklist.getPrimaryKey(),
			visualchecklist);

		visualchecklist.resetOriginalValues();
	}

	/**
	 * Caches the visualchecklists in the entity cache if it is enabled.
	 *
	 * @param visualchecklists the visualchecklists
	 */
	@Override
	public void cacheResult(List<visualchecklist> visualchecklists) {
		for (visualchecklist visualchecklist : visualchecklists) {
			if (EntityCacheUtil.getResult(
						visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
						visualchecklistImpl.class,
						visualchecklist.getPrimaryKey()) == null) {
				cacheResult(visualchecklist);
			}
			else {
				visualchecklist.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all visualchecklists.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(visualchecklistImpl.class.getName());
		}

		EntityCacheUtil.clearCache(visualchecklistImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the visualchecklist.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(visualchecklist visualchecklist) {
		EntityCacheUtil.removeResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistImpl.class, visualchecklist.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<visualchecklist> visualchecklists) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (visualchecklist visualchecklist : visualchecklists) {
			EntityCacheUtil.removeResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
				visualchecklistImpl.class, visualchecklist.getPrimaryKey());
		}
	}

	/**
	 * Creates a new visualchecklist with the primary key. Does not add the visualchecklist to the database.
	 *
	 * @param checkId the primary key for the new visualchecklist
	 * @return the new visualchecklist
	 */
	@Override
	public visualchecklist create(long checkId) {
		visualchecklist visualchecklist = new visualchecklistImpl();

		visualchecklist.setNew(true);
		visualchecklist.setPrimaryKey(checkId);

		return visualchecklist;
	}

	/**
	 * Removes the visualchecklist with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param checkId the primary key of the visualchecklist
	 * @return the visualchecklist that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist remove(long checkId)
		throws NoSuchvisualchecklistException, SystemException {
		return remove((Serializable)checkId);
	}

	/**
	 * Removes the visualchecklist with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the visualchecklist
	 * @return the visualchecklist that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist remove(Serializable primaryKey)
		throws NoSuchvisualchecklistException, SystemException {
		Session session = null;

		try {
			session = openSession();

			visualchecklist visualchecklist = (visualchecklist)session.get(visualchecklistImpl.class,
					primaryKey);

			if (visualchecklist == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchvisualchecklistException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(visualchecklist);
		}
		catch (NoSuchvisualchecklistException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected visualchecklist removeImpl(visualchecklist visualchecklist)
		throws SystemException {
		visualchecklist = toUnwrappedModel(visualchecklist);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(visualchecklist)) {
				visualchecklist = (visualchecklist)session.get(visualchecklistImpl.class,
						visualchecklist.getPrimaryKeyObj());
			}

			if (visualchecklist != null) {
				session.delete(visualchecklist);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (visualchecklist != null) {
			clearCache(visualchecklist);
		}

		return visualchecklist;
	}

	@Override
	public visualchecklist updateImpl(
		com.org.skali.sitanAdmin.model.visualchecklist visualchecklist)
		throws SystemException {
		visualchecklist = toUnwrappedModel(visualchecklist);

		boolean isNew = visualchecklist.isNew();

		visualchecklistModelImpl visualchecklistModelImpl = (visualchecklistModelImpl)visualchecklist;

		Session session = null;

		try {
			session = openSession();

			if (visualchecklist.isNew()) {
				session.save(visualchecklist);

				visualchecklist.setNew(false);
			}
			else {
				session.merge(visualchecklist);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !visualchecklistModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((visualchecklistModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						visualchecklistModelImpl.getOriginalCheckId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKID,
					args);

				args = new Object[] { visualchecklistModelImpl.getCheckId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKID,
					args);
			}

			if ((visualchecklistModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						visualchecklistModelImpl.getOriginalBilId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);

				args = new Object[] { visualchecklistModelImpl.getBilId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILID,
					args);
			}

			if ((visualchecklistModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILLCHEK.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						visualchecklistModelImpl.getOriginalBilId(),
						visualchecklistModelImpl.getOriginalCheckId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILLCHEK, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILLCHEK,
					args);

				args = new Object[] {
						visualchecklistModelImpl.getBilId(),
						visualchecklistModelImpl.getCheckId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_BILLCHEK, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_BILLCHEK,
					args);
			}
		}

		EntityCacheUtil.putResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
			visualchecklistImpl.class, visualchecklist.getPrimaryKey(),
			visualchecklist);

		return visualchecklist;
	}

	protected visualchecklist toUnwrappedModel(visualchecklist visualchecklist) {
		if (visualchecklist instanceof visualchecklistImpl) {
			return visualchecklist;
		}

		visualchecklistImpl visualchecklistImpl = new visualchecklistImpl();

		visualchecklistImpl.setNew(visualchecklist.isNew());
		visualchecklistImpl.setPrimaryKey(visualchecklist.getPrimaryKey());

		visualchecklistImpl.setCheckId(visualchecklist.getCheckId());
		visualchecklistImpl.setBilId(visualchecklist.getBilId());
		visualchecklistImpl.setNumberplates(visualchecklist.getNumberplates());
		visualchecklistImpl.setNumberplatesNote(visualchecklist.getNumberplatesNote());
		visualchecklistImpl.setForwardlighting(visualchecklist.getForwardlighting());
		visualchecklistImpl.setForwardlightingNote(visualchecklist.getForwardlightingNote());
		visualchecklistImpl.setBacklight(visualchecklist.getBacklight());
		visualchecklistImpl.setBacklightNote(visualchecklist.getBacklightNote());
		visualchecklistImpl.setTrafficLight(visualchecklist.getTrafficLight());
		visualchecklistImpl.setTrafficLightNote(visualchecklist.getTrafficLightNote());
		visualchecklistImpl.setSignallight(visualchecklist.getSignallight());
		visualchecklistImpl.setSignallightNote(visualchecklist.getSignallightNote());
		visualchecklistImpl.setVehiclebody(visualchecklist.getVehiclebody());
		visualchecklistImpl.setVehiclebodyNote(visualchecklist.getVehiclebodyNote());
		visualchecklistImpl.setVehicleAccessories(visualchecklist.getVehicleAccessories());
		visualchecklistImpl.setVehicleAccessoriesNote(visualchecklist.getVehicleAccessoriesNote());
		visualchecklistImpl.setWindscreen(visualchecklist.getWindscreen());
		visualchecklistImpl.setWindscreenNote(visualchecklist.getWindscreenNote());
		visualchecklistImpl.setRearMirror(visualchecklist.getRearMirror());
		visualchecklistImpl.setRearMirrorNote(visualchecklist.getRearMirrorNote());
		visualchecklistImpl.setDoormirror(visualchecklist.getDoormirror());
		visualchecklistImpl.setDoormirrorNote(visualchecklist.getDoormirrorNote());
		visualchecklistImpl.setVehicletires(visualchecklist.getVehicletires());
		visualchecklistImpl.setVehicletiresNote(visualchecklist.getVehicletiresNote());
		visualchecklistImpl.setFrontbumper(visualchecklist.getFrontbumper());
		visualchecklistImpl.setFrontbumperNote(visualchecklist.getFrontbumperNote());
		visualchecklistImpl.setRearbumper(visualchecklist.getRearbumper());
		visualchecklistImpl.setRearbumperNote(visualchecklist.getRearbumperNote());
		visualchecklistImpl.setFrontseat(visualchecklist.getFrontseat());
		visualchecklistImpl.setFrontseatNote(visualchecklist.getFrontseatNote());
		visualchecklistImpl.setRearseats(visualchecklist.getRearseats());
		visualchecklistImpl.setRearseatsNote(visualchecklist.getRearseatsNote());
		visualchecklistImpl.setNote(visualchecklist.getNote());
		visualchecklistImpl.setVehicleRegistrationNo(visualchecklist.getVehicleRegistrationNo());
		visualchecklistImpl.setModel(visualchecklist.getModel());
		visualchecklistImpl.setColor(visualchecklist.getColor());
		visualchecklistImpl.setDateofVehicles(visualchecklist.getDateofVehicles());
		visualchecklistImpl.setInvestigatorname(visualchecklist.getInvestigatorname());
		visualchecklistImpl.setInvestigatorphone(visualchecklist.getInvestigatorphone());
		visualchecklistImpl.setInvestigatorEmail(visualchecklist.getInvestigatorEmail());

		return visualchecklistImpl;
	}

	/**
	 * Returns the visualchecklist with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the visualchecklist
	 * @return the visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findByPrimaryKey(Serializable primaryKey)
		throws NoSuchvisualchecklistException, SystemException {
		visualchecklist visualchecklist = fetchByPrimaryKey(primaryKey);

		if (visualchecklist == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchvisualchecklistException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return visualchecklist;
	}

	/**
	 * Returns the visualchecklist with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchvisualchecklistException} if it could not be found.
	 *
	 * @param checkId the primary key of the visualchecklist
	 * @return the visualchecklist
	 * @throws com.org.skali.sitanAdmin.NoSuchvisualchecklistException if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist findByPrimaryKey(long checkId)
		throws NoSuchvisualchecklistException, SystemException {
		return findByPrimaryKey((Serializable)checkId);
	}

	/**
	 * Returns the visualchecklist with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the visualchecklist
	 * @return the visualchecklist, or <code>null</code> if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		visualchecklist visualchecklist = (visualchecklist)EntityCacheUtil.getResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
				visualchecklistImpl.class, primaryKey);

		if (visualchecklist == _nullvisualchecklist) {
			return null;
		}

		if (visualchecklist == null) {
			Session session = null;

			try {
				session = openSession();

				visualchecklist = (visualchecklist)session.get(visualchecklistImpl.class,
						primaryKey);

				if (visualchecklist != null) {
					cacheResult(visualchecklist);
				}
				else {
					EntityCacheUtil.putResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
						visualchecklistImpl.class, primaryKey,
						_nullvisualchecklist);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(visualchecklistModelImpl.ENTITY_CACHE_ENABLED,
					visualchecklistImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return visualchecklist;
	}

	/**
	 * Returns the visualchecklist with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param checkId the primary key of the visualchecklist
	 * @return the visualchecklist, or <code>null</code> if a visualchecklist with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public visualchecklist fetchByPrimaryKey(long checkId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)checkId);
	}

	/**
	 * Returns all the visualchecklists.
	 *
	 * @return the visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the visualchecklists.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @return the range of visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the visualchecklists.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.visualchecklistModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of visualchecklists
	 * @param end the upper bound of the range of visualchecklists (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<visualchecklist> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<visualchecklist> list = (List<visualchecklist>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_VISUALCHECKLIST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_VISUALCHECKLIST;

				if (pagination) {
					sql = sql.concat(visualchecklistModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<visualchecklist>(list);
				}
				else {
					list = (List<visualchecklist>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the visualchecklists from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (visualchecklist visualchecklist : findAll()) {
			remove(visualchecklist);
		}
	}

	/**
	 * Returns the number of visualchecklists.
	 *
	 * @return the number of visualchecklists
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_VISUALCHECKLIST);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the visualchecklist persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.visualchecklist")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<visualchecklist>> listenersList = new ArrayList<ModelListener<visualchecklist>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<visualchecklist>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(visualchecklistImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_VISUALCHECKLIST = "SELECT visualchecklist FROM visualchecklist visualchecklist";
	private static final String _SQL_SELECT_VISUALCHECKLIST_WHERE = "SELECT visualchecklist FROM visualchecklist visualchecklist WHERE ";
	private static final String _SQL_COUNT_VISUALCHECKLIST = "SELECT COUNT(visualchecklist) FROM visualchecklist visualchecklist";
	private static final String _SQL_COUNT_VISUALCHECKLIST_WHERE = "SELECT COUNT(visualchecklist) FROM visualchecklist visualchecklist WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "visualchecklist.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No visualchecklist exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No visualchecklist exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(visualchecklistPersistenceImpl.class);
	private static visualchecklist _nullvisualchecklist = new visualchecklistImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<visualchecklist> toCacheModel() {
				return _nullvisualchecklistCacheModel;
			}
		};

	private static CacheModel<visualchecklist> _nullvisualchecklistCacheModel = new CacheModel<visualchecklist>() {
			@Override
			public visualchecklist toEntityModel() {
				return _nullvisualchecklist;
			}
		};
}