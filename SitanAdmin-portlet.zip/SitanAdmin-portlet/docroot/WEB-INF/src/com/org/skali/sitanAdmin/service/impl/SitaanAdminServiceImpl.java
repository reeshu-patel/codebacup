/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.org.skali.sitanAdmin.service.impl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.jsonwebservice.JSONWebService;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.PrefsPropsUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.GroupConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.security.ac.AccessControlled;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.bookmarks.NoSuchFolderException;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFileEntryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderLocalServiceUtil;
import com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail;
import com.org.skali.sitanAdmin.model.ActionSummery;
import com.org.skali.sitanAdmin.model.ActiveVehicleDetail;
import com.org.skali.sitanAdmin.model.BillInquery;
import com.org.skali.sitanAdmin.model.BoardDirector;
import com.org.skali.sitanAdmin.model.DocumentTree;
import com.org.skali.sitanAdmin.model.EquityHolders;
import com.org.skali.sitanAdmin.model.LicensesStatus;
import com.org.skali.sitanAdmin.model.OfficerDetail;
import com.org.skali.sitanAdmin.model.RecoredComunication;
import com.org.skali.sitanAdmin.model.SitaanAdmin;
import com.org.skali.sitanAdmin.model.SourceTypes;
import com.org.skali.sitanAdmin.model.complainUserinfo;
import com.org.skali.sitanAdmin.model.detailoksboyds;
import com.org.skali.sitanAdmin.model.vehicalInfo;
import com.org.skali.sitanAdmin.model.visualchecklist;
import com.org.skali.sitanAdmin.model.impl.AcceptanceVehicleDetailImpl;
import com.org.skali.sitanAdmin.model.impl.visualchecklistImpl;
import com.org.skali.sitanAdmin.service.AcceptanceVehicleDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ActionSummeryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ActiveVehicleDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.BillInqueryLocalServiceUtil;
import com.org.skali.sitanAdmin.service.BoardDirectorLocalServiceUtil;
import com.org.skali.sitanAdmin.service.ClpSerializer;
import com.org.skali.sitanAdmin.service.DocumentTreeLocalServiceUtil;
import com.org.skali.sitanAdmin.service.EquityHoldersLocalServiceUtil;
import com.org.skali.sitanAdmin.service.LicensesStatusLocalServiceUtil;
import com.org.skali.sitanAdmin.service.OfficerDetailLocalServiceUtil;
import com.org.skali.sitanAdmin.service.RecoredComunicationLocalServiceUtil;
import com.org.skali.sitanAdmin.service.SitaanAdminLocalServiceUtil;
import com.org.skali.sitanAdmin.service.SourceTypesLocalServiceUtil;
import com.org.skali.sitanAdmin.service.complainUserinfoLocalServiceUtil;
import com.org.skali.sitanAdmin.service.detailoksboydsLocalServiceUtil;
import com.org.skali.sitanAdmin.service.vehicalInfoLocalServiceUtil;
import com.org.skali.sitanAdmin.service.visualchecklistLocalServiceUtil;
import com.org.skali.sitanAdmin.service.base.SitaanAdminServiceBaseImpl;

/**
 * The implementation of the sitaan admin remote service.
 *<p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.org.skali.sitanAdmin.service.SitaanAdminService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author reeshu
 * @see com.org.skali.sitanAdmin.service.base.SitaanAdminServiceBaseImpl
 * @see com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil
 */

public class SitaanAdminServiceImpl extends SitaanAdminServiceBaseImpl {
	
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil} to access the sitaan admin remote service.
	 */
	//@Context private HttpServletRequest renderRequest;
	
	@JSONWebService(value = "SitaAdmin_DashBoard_Search", method = "POST")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject FinedByColumn(String dateSeized,String checkSitesSita,String source,String ownerName,String territory,String state,String vehicleRegistrationNo,String referenceEffective,String confiscatedPeriod,String locationCageSita,String foreclosureStatus,String resultsforeclosure,String officerName,String action,String paymentStatus) throws SystemException, PortalException 
	{
		
	   List<SitaanAdmin> list = new ArrayList<SitaanAdmin>();
	   List<SitaanAdmin> sitaanAdmin = null;
	   
	  try {
			sitaanAdmin = SitaanAdminLocalServiceUtil.getSitaanAdmins(-1, -1);
		} catch (SystemException e1) {
			//TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		DynamicQuery dynamicQuery =null;
		boolean setFlag = true;
		boolean setFlagand = true;
		
		try{
		ClassLoader loader=(ClassLoader)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),"portletClassLoader");
		dynamicQuery = DynamicQueryFactoryUtil.forClass(SitaanAdmin.class, loader);
		
		Criterion criterion = null;
		if(!dateSeized.equals(StringPool.BLANK)){
		
		//System.out.println("Hello I am here");
		//System.out.println("Hello I am here dateSeized"+dateSeized);

		Date dt = new SimpleDateFormat("dd/MM/yyyy").parse(dateSeized);
		String createDate = new SimpleDateFormat("dd/MM/yyyy").format(dt);
		
		if(setFlag){
			criterion = RestrictionsFactoryUtil.eq("dateSeized", createDate);
			setFlag = false;
			}	
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("dateSeized",createDate));
			setFlagand = false;
		}
		
		if(!checkSitesSita.equals(StringPool.BLANK)){
			Date dt1 = new SimpleDateFormat("dd/MM/yyyy").parse(checkSitesSita);
			String createDate1 = new SimpleDateFormat("dd/MM/yyyy").format(dt1);	
			if(setFlag){
			criterion = RestrictionsFactoryUtil.eq("checkSitesSita", createDate1);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("checkSitesSita",createDate1));
			setFlagand = false;
		}
		
		if(!source.equals(StringPool.BLANK)){
			if(setFlag){
				criterion = RestrictionsFactoryUtil.like("source", source);
				setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("source",source));
			setFlagand = false;
		}
		if(!ownerName.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("ownerName", StringPool.PERCENT+ownerName+StringPool.PERCENT);
			setFlag = false;
			}
			
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("ownerName",StringPool.PERCENT+ownerName+StringPool.PERCENT));
			setFlagand = false;
		}
		
		if(!territory.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("territory", territory);
			setFlag = false;
			}
			
		 criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("territory",territory));
		 setFlagand = false;	
		}
		
	 if(!state.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("state", state);
			setFlag = false;
			}else{
			
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("state",state));
		   setFlagand = false;
		 }
	 }
	  if(!referenceEffective.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("referenceEffective", referenceEffective);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("referenceEffective",referenceEffective));
			setFlagand = false;
		}
		if(!vehicleRegistrationNo.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("vehicleRegistrationNo", vehicleRegistrationNo);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("vehicleRegistrationNo",vehicleRegistrationNo));
			setFlagand = false;
		}
		
		if(!confiscatedPeriod.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("confiscatedPeriod", confiscatedPeriod);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("confiscatedPeriod",confiscatedPeriod));
			setFlagand = false;
		}
		
		if(!locationCageSita.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("locationCageSita", locationCageSita);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("locationCageSita",locationCageSita));
			setFlagand = false;
		}
		
		if(!foreclosureStatus.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("foreclosureStatus", foreclosureStatus);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("foreclosureStatus",foreclosureStatus));
			setFlagand = false;
		}

		if(!resultsforeclosure.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("resultsforeclosure", resultsforeclosure);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("resultsforeclosure",resultsforeclosure));
			setFlagand = false;
		}
		if(!officerName.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("officerName", StringPool.PERCENT+officerName+StringPool.PERCENT);
			setFlag = false;
			}else{
		
		   criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.like("officerName",StringPool.PERCENT+officerName+StringPool.PERCENT));
		   setFlagand = false;
			}
		}
		
		if(!action.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("action", action);
			setFlag = false;
			}
			criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("action",action));
			setFlagand = false;
		}
		
		if(!paymentStatus.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("paymentStatus", paymentStatus);
			setFlag = false;
			}
		criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("paymentStatus",paymentStatus));
		setFlagand = false;
		}
		if(!paymentStatus.equals(StringPool.BLANK)){
			if(setFlag){
			criterion = RestrictionsFactoryUtil.like("confiscatedPeriod", confiscatedPeriod);
			setFlag = false;
			}
		 criterion=RestrictionsFactoryUtil.and(criterion,RestrictionsFactoryUtil.eq("confiscatedPeriod",confiscatedPeriod));
		 setFlagand = false;
		}
		dynamicQuery.add(criterion);

		//System.out.println("dynamicQuery===================>"+dynamicQuery);
		
		List<SitaanAdmin> gallryIds =null;
		try {
			gallryIds = SitaanAdminLocalServiceUtil.dynamicQuery(dynamicQuery);
			for(SitaanAdmin gall:gallryIds ){
				list.add(gall);

			}
			
		} catch (SystemException e) {
			e.printStackTrace();
		}
	 
	
	 }catch(Exception e){}
		
	JSONObject resultReturn = JSONFactoryUtil.createJSONObject();
		    
	JSONArray CaseNumberArray = JSONFactoryUtil.createJSONArray();
	
	//System.out.println("list===================>"+list.size());

	//System.out.println("setFlag========>"+setFlag+"setFlagand"+setFlagand);

 if(Validator.isNotNull(list) && list.size() > 0 ){
		for(SitaanAdmin sit :list){
	 			  
					JSONObject noOfCase = JSONFactoryUtil.createJSONObject();	
	 				noOfCase.put("bilId", sit.getBilId());
	 				noOfCase.put("dateSeized", sit.getDateSeized());
	 				
					noOfCase.put("checkSitesSita", sit.getCheckSitesSita());
	 				noOfCase.put("referenceEffective", sit.getReferenceEffective());
	 				noOfCase.put("confiscatedPeriod", sit.getConfiscatedPeriod());
	 				noOfCase.put("source", sit.getSource());
	 				noOfCase.put("ownerName", sit.getOwnerName());
	 				noOfCase.put("vehicleRegistrationNo", sit.getVehicleRegistrationNo());
	 				
	 				noOfCase.put("territory", sit.getTerritory());
	 				noOfCase.put("state", sit.getState());
	 				noOfCase.put("locationCageSita", sit.getLocationCageSita());
	 				noOfCase.put("foreclosureStatus", sit.getForeclosureStatus());
	 				noOfCase.put("resultsforeclosure", sit.getResultsforeclosure());
	 				noOfCase.put("officerName", sit.getOfficerName());
	 				noOfCase.put("action", sit.getAction());
	 				
	 				noOfCase.put("rightsReleased", sit.getRightsReleased());
	 				noOfCase.put("acceptancedate", sit.getAcceptancedate());
	 				noOfCase.put("paymentStatus", sit.getPaymentStatus());
	 				noOfCase.put("caseStatus", sit.getCaseStatus());
	 				noOfCase.put("foreclosureStatusType", sit.getForeclosureStatusType());
	 			    
	 				CaseNumberArray.put(noOfCase);
	 			
	 		}
		
	 		
		}else if(setFlag == true && setFlagand == true)
		    {	 
			for(SitaanAdmin inq12:sitaanAdmin){	
				JSONObject noofinquery12 = JSONFactoryUtil.createJSONObject();
				noofinquery12.put("bilId", inq12.getBilId());
				noofinquery12.put("dateSeized", inq12.getDateSeized());
 				
				noofinquery12.put("checkSitesSita", inq12.getCheckSitesSita());
				noofinquery12.put("referenceEffective", inq12.getReferenceEffective());
				noofinquery12.put("confiscatedPeriod", inq12.getConfiscatedPeriod());
				noofinquery12.put("source", inq12.getSource());
				noofinquery12.put("ownerName", inq12.getOwnerName());
				noofinquery12.put("vehicleRegistrationNo", inq12.getVehicleRegistrationNo());
 				
				noofinquery12.put("territory", inq12.getTerritory());
				noofinquery12.put("state", inq12.getState());
				noofinquery12.put("locationCageSita", inq12.getLocationCageSita());
				noofinquery12.put("foreclosureStatus", inq12.getForeclosureStatus());
				noofinquery12.put("resultsforeclosure", inq12.getResultsforeclosure());
				noofinquery12.put("officerName", inq12.getOfficerName());
				noofinquery12.put("action", inq12.getAction());
 				
				noofinquery12.put("rightsReleased", inq12.getRightsReleased());
				noofinquery12.put("acceptancedate", inq12.getAcceptancedate());
				noofinquery12.put("paymentStatus", inq12.getPaymentStatus());
				noofinquery12.put("caseStatus", inq12.getCaseStatus());
				noofinquery12.put("foreclosureStatusType", inq12.getForeclosureStatusType());

 				CaseNumberArray.put(noofinquery12);
			}
		 }
	
	 		resultReturn.put("SitanAdmin_Main", CaseNumberArray);	 
	 	
	 		
			return resultReturn;
		}
	
	@JSONWebService(value = "New_Case_Information_BillId", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject FinedByBillId(long bilId) throws PortalException, SystemException{
		
		
		JSONObject resultReturncase = JSONFactoryUtil.createJSONObject();
		JSONArray CaseArray = JSONFactoryUtil.createJSONArray();
	   // JSONArray InformationArray = JSONFactoryUtil.createJSONArray();
		JSONArray InformationArraymain = JSONFactoryUtil.createJSONArray();
		
		JSONArray ipdetailArray = JSONFactoryUtil.createJSONArray();
		JSONArray actionSummeryArray = JSONFactoryUtil.createJSONArray();
		
		List<SitaanAdmin> sitaanAdmins = SitaanAdminLocalServiceUtil.getsByBilId(bilId);
		JSONObject complainDetail = JSONFactoryUtil.createJSONObject();
		JSONObject driverInformation = JSONFactoryUtil.createJSONObject();
		JSONObject detailoksboys = JSONFactoryUtil.createJSONObject();
		JSONObject vehicalInformation = JSONFactoryUtil.createJSONObject();
		for(SitaanAdmin sitan :sitaanAdmins){
			long billid = sitan.getBilId();
			List<complainUserinfo> complain = complainUserinfoLocalServiceUtil.getsByBillId(billid);
			
 			JSONObject CaseNo = JSONFactoryUtil.createJSONObject();	
 			JSONObject Informationtab = JSONFactoryUtil.createJSONObject();
 			JSONObject Information = JSONFactoryUtil.createJSONObject();
 			
 			JSONObject iistmainobject = JSONFactoryUtil.createJSONObject();
 			JSONObject iist = JSONFactoryUtil.createJSONObject();
 			
 			JSONObject VISUALmainobject = JSONFactoryUtil.createJSONObject();
 			JSONObject VISUAL = JSONFactoryUtil.createJSONObject();
 			
 			JSONObject ipdetail = JSONFactoryUtil.createJSONObject();
 			
 			CaseNo.put("bilId", sitan.getBilId());
 			CaseNo.put("No_Reference_Effective", sitan.getReferenceEffective());

 			CaseNo.put("Date_Event", sitan.getDateofincident());
 			CaseNo.put("Time_Event", sitan.getTimeEvent());
 				
 			CaseNo.put("Location_of_incident", sitan.getLocationofincident());
 			
 			for(complainUserinfo conplaininfo:complain){
 				CaseNo.put("Driver_Name", conplaininfo.getDName());
 	 			CaseNo.put("Driver_License_expiry_Date", "");

				
			}
 			CaseNo.put("vehicleRegistrationNo", sitan.getVehicleRegistrationNo());
 			CaseNo.put("caseStatus", sitan.getCaseStatus());
 			
 			CaseNo.put("Vehicle_status", "be confiscated");
 				
 			CaseNo.put("Status_Document", "be confiscated");
 			CaseNo.put("state", sitan.getState());
 			
 			CaseNo.put("territory", sitan.getTerritory());
 			
 			CaseNo.put("Complaints", "2");
 			CaseNo.put("catch", "3");
 			CaseNo.put("Administrative_actions", "1");
 			CaseNo.put("action", sitan.getAction());
 				
 			
 			CaseArray.put(CaseNo);
 			
 			Information.put("Submitter_name", sitan.getSubmittername());
 			Information.put("Passport", sitan.getPassportNo());
 			Information.put("power", sitan.getPower());
 			Information.put("Office", sitan.getOffice());
 			Information.put("chronicle", sitan.getChronicle());
 			//InformationArray.put(Information);
 			Informationtab.put("HANDOVER_INFORMATION", Information);
 			InformationArraymain.put(Informationtab);
 			
 			iist.put("Types_of_goods", sitan.getTypeofgoods());
 			iist.put("quantity", sitan.getQuantity());
 			iist.put("record", sitan.getRecord());
 			//iistArray.put(iist);
 			iistmainobject.put("lIST_SITAAN", iist);
 			InformationArraymain.put(iistmainobject);
 			
 			
 			VISUAL.put("Inspectors_name", sitan.getInspectorsName());
 			//VISUALArray.put(iist);
 			VISUALmainobject.put("VISUAL_INSPECTION", VISUAL);
 			InformationArraymain.put(VISUALmainobject);
 			
 			ipdetail.put("Number_of_Document", "1");
 			//ipdetailArray.put(ipdetail);
 			
 			//complain Detail
 			
 			complainDetail.put("bilId", sitan.getBilId());
 			complainDetail.put("category", sitan.getCategory());
 				
 			complainDetail.put("typeofComplaint", sitan.getTypeofComplaint());
 			complainDetail.put("referenceEffective", sitan.getReferenceEffective());
 			complainDetail.put("classLicense", sitan.getClassLicense());
 			complainDetail.put("particle", sitan.getParticle());
 			complainDetail.put("dateofincident", sitan.getDateofincident());
 			complainDetail.put("timeEvent", sitan.getTimeEvent());
 				
 			complainDetail.put("locationofincident", sitan.getLocationofincident());
 			complainDetail.put("terminal", sitan.getTerminal());
 			complainDetail.put("bookie", sitan.getBookie());
 			complainDetail.put("Landmark", sitan.getLandmark());
 			
 			complainDetail.put("territory", sitan.getTerritory());
 			complainDetail.put("internalStakeholder", sitan.getInternalStakeholder());
 			complainDetail.put("externalStakeholder", sitan.getExternalStakeholder());
 			
 			List<complainUserinfo> complainUserinfos  = complainUserinfoLocalServiceUtil.getsByBillId(bilId);
 			for(complainUserinfo compl:complainUserinfos){
 				
 				complainDetail.put("bilId", compl.getBilId());
 	 			complainDetail.put("prefix", compl.getPrefix());
 	 			complainDetail.put("Name", compl.getName());
 	 			complainDetail.put("identificationnumber", compl.getIdentificationnumber());
 	 			complainDetail.put("passport", compl.getPassport());
 	 			complainDetail.put("citizen", compl.getCitizen());
 	 			complainDetail.put("Nation", compl.getNation());
 	 			complainDetail.put("gender", compl.getGender());
 	 			complainDetail.put("Age", compl.getAge());
 	 			complainDetail.put("phoneNo", compl.getPhoneNo());
 	 			complainDetail.put("cellPhones", compl.getCellPhones());
 	 			complainDetail.put("Address", compl.getAddress());
 	 			complainDetail.put("Email", compl.getEmail());
 	 			
 	 			//complainDetailArray.put(complainDetail);

 	 			// 	DRIVER INFORMATION	
 	 			
 	 			driverInformation.put("dName", compl.getDName());
 	 				
 	 			driverInformation.put("didentificationnumber", compl.getDidentificationnumber());
 	 			driverInformation.put("dateofbirth", compl.getDateofbirth());
 	 			driverInformation.put("dcitizen", compl.getDcitizen());
 	 			driverInformation.put("driverNation", compl.getDriverNation());
 	 			driverInformation.put("drivergender", compl.getDrivergender());
 	 			driverInformation.put("driverAge", compl.getDriverAge());
 	 				
 	 			driverInformation.put("retirees", compl.getRetirees());
 	 			driverInformation.put("PSVLicenseStatu", compl.getStatusReadPSV());
 	 			driverInformation.put("driverLicenseStatus", compl.getDriverLicense());
 	 			driverInformation.put("dphone", compl.getDphone());
 	 			driverInformation.put("dphoneTwo", compl.getDphoneTwo());
 	 			driverInformation.put("daddress", compl.getDaddress());
 	 			
 			}

 			
 			//driverInformationArray.put(driverInformation);	
 			//complainDetailArray.put(complainDetail);
 			//DETAILS OKS /OYDS
 			
 			List<detailoksboyds> detailoksboyds = detailoksboydsLocalServiceUtil.getsByDetailBillId(bilId);
 			for(detailoksboyds detail:detailoksboyds){
 				
 				detailoksboys.put("bilId", detail.getBilId());
 	 			detailoksboys.put("companyName", detail.getCompanyName());
 	 				
 	 			detailoksboys.put("classOperatorLicense", detail.getClassOperatorLicense());
 	 			detailoksboys.put("listofCompanies", detail.getListofCompanies());
 	 			detailoksboys.put("reRegistration", detail.getReRegistration());
 	 			detailoksboys.put("email", detail.getEmail());
 	 			detailoksboys.put("noReferenceFile", detail.getNoReferenceFile());
 	 				
 	 			detailoksboys.put("addressList", detail.getAddressList());
 	 			detailoksboys.put("addressListRegistation", detail.getAddressListRegistation());
 	 			detailoksboys.put("authorisedCapital", detail.getAuthorisedCapital());
 	 			detailoksboys.put("accruedCapital", detail.getAccruedCapital());
 	 			detailoksboys.put("capitalPaid", detail.getCapitalPaid());
 	 			detailoksboys.put("ComRegNo", detail.getComRegNo());
 	 			detailoksboys.put("nationOwner", detail.getNationOwner());
 	 				
 	 			detailoksboys.put("dateListofCompanies", detail.getDateListofCompanies());
 	 			detailoksboys.put("activity", detail.getActivity());
 	 			detailoksboys.put("phoneNo", detail.getPhoneNo());
 	 			detailoksboys.put("faxNo", detail.getFaxNo());
 	 			detailoksboys.put("lastUpdateDate", detail.getLastUpdateDate());
 	 			
 			}
 			List<BoardDirector> boardDirectors = BoardDirectorLocalServiceUtil.getsByBilId(billid);
 			JSONArray boarddirArray = JSONFactoryUtil.createJSONArray();
 			for(BoardDirector bosrd:boardDirectors){
 				JSONObject boardDirector = JSONFactoryUtil.createJSONObject();
 				boardDirector.put("boarddirectorid", bosrd.getBoarddirectorid());
 				boardDirector.put("wealp", bosrd.getWealp());
 				boardDirector.put("kplama", bosrd.getKplama());
 				boardDirector.put("newKp", bosrd.getNewKp());
 				boardDirector.put("position", bosrd.getPosition());
 				boarddirArray.put(boardDirector);
 			}
 			detailoksboys.put("BoardDirector", boarddirArray);
 			
 			JSONArray equityHolArray = JSONFactoryUtil.createJSONArray();
 			List<EquityHolders> equityHolders = EquityHoldersLocalServiceUtil.getsByBilId(billid);
 			for(EquityHolders equity:equityHolders){
 				
 				JSONObject equityHolder = JSONFactoryUtil.createJSONObject();
 				equityHolder.put("equityholders", equity.getEquityholdersid());
 				equityHolder.put("name", equity.getName());
 				equityHolder.put("kpLama", equity.getKpLama());
 				equityHolder.put("newKp", equity.getNewKp());
 				equityHolder.put("value", equity.getValue());
 				equityHolder.put("percent", equity.getPercent());
 				equityHolder.put("gender", equity.getGender());
 				equityHolder.put("nation", equity.getNation());
 				equityHolArray.put(equityHolder);
 				
 			}
 			detailoksboys.put("equityHolder", equityHolArray);
 			
 			List<LicensesStatus> licensesStatus = LicensesStatusLocalServiceUtil.getsByBilId(billid);
 			JSONArray licenseArray = JSONFactoryUtil.createJSONArray();
 			for(LicensesStatus bosrd:licensesStatus){
 				JSONObject lisenceStatus = JSONFactoryUtil.createJSONObject();
 				lisenceStatus.put("licensesstatusid", bosrd.getLicensesstatusid());
 				lisenceStatus.put("active", bosrd.getActive());
 				lisenceStatus.put("Noactive", bosrd.getNoActive());
 				lisenceStatus.put("moreoverHadAge", bosrd.getMoreoverHadAge());
 				lisenceStatus.put("finishedWithin", bosrd.getFinishedWithin());
 				
 				licenseArray.put(lisenceStatus);
 			}
 			detailoksboys.put("LicensesStatus", licenseArray);
 			
 			List<ActiveVehicleDetail> activeVehicleDetails = ActiveVehicleDetailLocalServiceUtil.getsByBilId(billid);
 			JSONArray ActivevehicalArray = JSONFactoryUtil.createJSONArray();
 			for(ActiveVehicleDetail bosrd:activeVehicleDetails){
 				JSONObject vehicalStatus = JSONFactoryUtil.createJSONObject();
 				vehicalStatus.put("vehicalid", bosrd.getVehicalid());
 				vehicalStatus.put("classcode", bosrd.getClasscode());
 				vehicalStatus.put("byVehicle", bosrd.getByVehicle());
 				vehicalStatus.put("withoutMotor", bosrd.getWithoutMotor());
 				vehicalStatus.put("commencement", bosrd.getCommencement());
 				vehicalStatus.put("ageLimit", bosrd.getAgeLimit());
 				ActivevehicalArray.put(vehicalStatus);
 			}
 			detailoksboys.put("ComparedActiveVehicleClass", ActivevehicalArray);
 			
 			
 	 // VEHICLE INFORMATION		
 			List<vehicalInfo> veInfos = vehicalInfoLocalServiceUtil.getsByVehicalBillId(bilId);
 			for(vehicalInfo vehic:veInfos){
 				
 				vehicalInformation.put("bilId", vehic.getBilId());
 	 			vehicalInformation.put("brands", vehic.getBrands());
 	 				
 	 			vehicalInformation.put("Model", vehic.getModel());
 	 			vehicalInformation.put("noEnjin", vehic.getNoEnjin());
 	 			vehicalInformation.put("noCasis", vehic.getNoCasis());
 	 			vehicalInformation.put("bodytype", vehic.getBodytype());
 	 			vehicalInformation.put("color", vehic.getColor());
 	 			vehicalInformation.put("yearbuilt", vehic.getYearbuilt());
 	 				
 	 			vehicalInformation.put("dateofVehicles", vehic.getDateofVehicles());
 	 			vehicalInformation.put("temporaryLicenses", vehic.getTemporaryLicenses());
 	 			vehicalInformation.put("numberofPassengers", vehic.getNumberofPassengers());
 	 			vehicalInformation.put("seatingNumber", vehic.getSeatingNumber());
 	 			vehicalInformation.put("operatingArea", vehic.getOperatingArea());
 	 			vehicalInformation.put("typeofservice", vehic.getTypeofservice());
 	 			vehicalInformation.put("readStatus", vehic.getReadStatus());
 	 				
 	 			vehicalInformation.put("bdm", vehic.getBdm());
 	 			vehicalInformation.put("btm", vehic.getBtm());
 	 			vehicalInformation.put("bt1", vehic.getBt1());
 	 			//vehicalInformationArray.put(vehicalInformation);
 			}
 			
 		}
		
		//SUMMARY OF ACTION
		
		List<ActionSummery>  actionSummeries = ActionSummeryLocalServiceUtil.getsByBilId(bilId);
		for(ActionSummery action:actionSummeries){
			
			JSONObject actionSummery = JSONFactoryUtil.createJSONObject();
			actionSummery.put("bilId", action.getBilId());
 			actionSummery.put("dateSeized", action.getDateTime());
 			actionSummery.put("Status", action.getStatus());
 			actionSummery.put("Action", action.getAction());
 			actionSummery.put("ActionBy", action.getActionBy());
 			actionSummeryArray.put(actionSummery);
		}
		
		//Error Inquery		
		
		JSONObject dataObject = JSONFactoryUtil.createJSONObject();
		JSONArray errorinquiryArray = JSONFactoryUtil.createJSONArray();
		JSONArray errorTypearray= JSONFactoryUtil.createJSONArray();
		JSONArray sourceTypeArray= JSONFactoryUtil.createJSONArray();
		List<SourceTypes> sourceTypes = SourceTypesLocalServiceUtil.getSourceTypeses(-1, -1);
		for(SourceTypes source:sourceTypes){
			
			JSONObject errorType = JSONFactoryUtil.createJSONObject();
			JSONObject sourceType = JSONFactoryUtil.createJSONObject();
			errorType.put("id", source.getSourcetypeid());
			errorType.put("value", source.getErrortypes());
			errorTypearray.put(errorType);
			sourceType.put("id", source.getSourcetypeid());
			sourceType.put("value", source.getSourcetypes());
			sourceTypeArray.put(sourceType);
		}
		List<BillInquery> billInqueries = BillInqueryLocalServiceUtil.getsByBilId(bilId);
		for(BillInquery sitan:billInqueries){
			JSONObject errorinquiry = JSONFactoryUtil.createJSONObject();
			errorinquiry.put("billinquery", sitan.getBillinquery());
			errorinquiry.put("bilId", sitan.getBilId());
			errorinquiry.put("complaintDate", sitan.getComplaintDate());
			errorinquiry.put("referenceEffective", sitan.getReferenceEffective());
			errorinquiry.put("vehiclesNo", sitan.getVehiclesNo());
			errorinquiry.put("companyName", sitan.getCompanyName());
			errorinquiry.put("source", sitan.getSource());
			errorinquiry.put("offense", sitan.getOffense());
			errorinquiry.put("virtue", sitan.getVirtue());
				
			errorinquiry.put("filerating", sitan.getFilerating());
			errorinquiry.put("caseStatus", sitan.getCaseStatus());
			errorinquiry.put("nameofofficer", sitan.getNameofofficer());
			errorinquiry.put("error", sitan.getError());
			errorinquiry.put("errorType", sitan.getErrorType());
			errorinquiryArray.put(errorinquiry);
			}
		dataObject.put("ErrorTypes", errorTypearray);
		dataObject.put("Source", sourceTypeArray);
		dataObject.put("Error_Inquery_Data", errorinquiryArray);
		
		
		resultReturncase.put("CASE_INFORMATION", CaseArray);
		resultReturncase.put("INFORMATION_SITAN", InformationArraymain);
		resultReturncase.put("IP_DETAILS", ipdetailArray);
		resultReturncase.put("COMPLAINT_DETAILS", complainDetail);
		resultReturncase.put("DETAILS_OKS_OYDS", detailoksboys);
		resultReturncase.put("DRIVER_INFORMATION", driverInformation);
		resultReturncase.put("VEHICLE_INFORMATION", vehicalInformation);
		resultReturncase.put("ACTION_SUMMERY", actionSummeryArray);
		resultReturncase.put("ERROR_INQUERY", dataObject);
		
		

		return resultReturncase;
	 }
	
	@JSONWebService(value = "Cmd_User_List", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public  List<User> geCMDUsers()
			throws com.liferay.portal.kernel.exception.PortalException,
				com.liferay.portal.kernel.exception.SystemException {
			return UserLocalServiceUtil.getUsers(-1, -1);
		}
	
	
	@JSONWebService(value = "End_Action_Case_Informarmation_BillId", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject ActionCaseByBillId(long bilId) throws PortalException, SystemException{
		
		
		JSONObject resultReturncase = JSONFactoryUtil.createJSONObject();
		JSONArray CaseArray = JSONFactoryUtil.createJSONArray();
	    //JSONArray InformationArray = JSONFactoryUtil.createJSONArray();
		JSONArray InformationArraymain = JSONFactoryUtil.createJSONArray();
		JSONArray ipdetailArray = JSONFactoryUtil.createJSONArray();
		JSONArray complainDetailArray = JSONFactoryUtil.createJSONArray();
		JSONArray detailoksboysArray = JSONFactoryUtil.createJSONArray();
		JSONArray driverInformationArray = JSONFactoryUtil.createJSONArray();
		JSONArray vehicalInformationArray = JSONFactoryUtil.createJSONArray();
		
		JSONArray actionSummeryArray = JSONFactoryUtil.createJSONArray();
		
		
		List<SitaanAdmin> sitaanAdmins = SitaanAdminLocalServiceUtil.getsByBilId(bilId);
		

		for(SitaanAdmin sitan :sitaanAdmins){
 			JSONObject CaseNo = JSONFactoryUtil.createJSONObject();	
 			JSONObject Informationtab = JSONFactoryUtil.createJSONObject();
 			JSONObject Information = JSONFactoryUtil.createJSONObject();
 			
 			//JSONArray iistArray = JSONFactoryUtil.createJSONArray();
 			JSONObject iistmainobject = JSONFactoryUtil.createJSONObject();
 			JSONObject iist = JSONFactoryUtil.createJSONObject();
 			
 			//JSONArray VISUALArray = JSONFactoryUtil.createJSONArray();
 			JSONObject VISUALmainobject = JSONFactoryUtil.createJSONObject();
 			JSONObject VISUAL = JSONFactoryUtil.createJSONObject();
 			
 			
 			JSONObject ipdetail = JSONFactoryUtil.createJSONObject();
 			JSONObject complainDetail = JSONFactoryUtil.createJSONObject();
 			JSONObject detailoksboys = JSONFactoryUtil.createJSONObject();
 			JSONObject driverInformation = JSONFactoryUtil.createJSONObject();
 			JSONObject vehicalInformation = JSONFactoryUtil.createJSONObject();
 			
 			//JSONObject errorinquiry = JSONFactoryUtil.createJSONObject();
 			//JSONObject actionSummery = JSONFactoryUtil.createJSONObject();
 		
 			
 			CaseNo.put("bilId", sitan.getBilId());
 			CaseNo.put("dateSeized", sitan.getDateSeized());
 				
 			CaseNo.put("checkSitesSita", sitan.getCheckSitesSita());
 			CaseNo.put("referenceEffective", sitan.getReferenceEffective());
 			CaseNo.put("confiscatedPeriod", sitan.getConfiscatedPeriod());
 			CaseNo.put("source", sitan.getSource());
 			CaseNo.put("ownerName", sitan.getOwnerName());
 			CaseNo.put("vehicleRegistrationNo", sitan.getVehicleRegistrationNo());
 				
 			CaseNo.put("territory", sitan.getTerritory());
 			CaseNo.put("state", sitan.getState());
 			CaseNo.put("locationCageSita", sitan.getLocationCageSita());
 			CaseNo.put("foreclosureStatus", sitan.getForeclosureStatus());
 			CaseNo.put("resultsforeclosure", sitan.getResultsforeclosure());
 			CaseNo.put("officerName", sitan.getOfficerName());
 			CaseNo.put("action", sitan.getAction());
 				
 			CaseNo.put("rightsReleased", sitan.getRightsReleased());
 			CaseNo.put("acceptancedate", sitan.getAcceptancedate());
 			CaseNo.put("paymentStatus", sitan.getPaymentStatus());
 			CaseNo.put("caseStatus", sitan.getCaseStatus());
 			CaseArray.put(CaseNo);
 			
 			Information.put("Submitter_name", sitan.getSubmittername());
 			Information.put("Passport", sitan.getPassportNo());
 			Information.put("power", sitan.getPower());
 			Information.put("Office", sitan.getOffice());
 			Information.put("chronicle", sitan.getChronicle());
 			//InformationArray.put(Information);
 			Informationtab.put("HANDOVER_INFORMATION", Information);
 			InformationArraymain.put(Informationtab);
 			
 			iist.put("Perintah_Perlepasan", "Bahagian Penguatkuasaan / Bahagian Perundangan");
 			iist.put("Status_OKT", "Tidak Bersalah / Bersalah / Bersalah dan Didenda");
 			//iistArray.put(iist);
 			iistmainobject.put("CASE_SUMMARY_RESULTS", iist);
 			InformationArraymain.put(iistmainobject);
 			
 			List<RecoredComunication> recoredComun  = RecoredComunicationLocalServiceUtil.getsByBillId(bilId);
 			for(RecoredComunication compl:recoredComun){
 			VISUAL.put("Date_and_Time", compl.getDateTime());
 			VISUAL.put("Contact",compl.getContact());
 			VISUAL.put("Communication_method", compl.getCommunicationMethod());
 			VISUAL.put("No_Telefon_Faks_Surat", compl.getTelefon());
 			VISUAL.put("particle", compl.getParticle());
 			
 			//VISUALArray.put(iist);
 			VISUALmainobject.put("RECORD_OF_COMMUNICATION", VISUAL);
 			InformationArraymain.put(VISUALmainobject);
 			
 			JSONArray paymentArray = JSONFactoryUtil.createJSONArray();
 			JSONObject paymentobject = JSONFactoryUtil.createJSONObject();
 			JSONObject payment = JSONFactoryUtil.createJSONObject();
 			
 			payment.put("Payment_amount", compl.getPaymentAmount());
 			payment.put("Payment_method", compl.getPaymentMethod());
 			payment.put("Communication_method", compl.getCommunicationMethod());
 			payment.put("Payment_Date", compl.getPaymentDate());
 			payment.put("No_Referral_Payment", compl.getReferralPayment());
 			
 			paymentArray.put(payment);
 			paymentobject.put("PAYMENT_DETAILS", paymentArray);
 			InformationArraymain.put(paymentobject);
 			
 			}
 			ipdetail.put("Number_of_Document", "1");
 			ipdetailArray.put(ipdetail);
 			
 			// complain Detail	
 			
 			complainDetail.put("bilId", sitan.getBilId());
 			complainDetail.put("category", sitan.getCategory());
 				
 			complainDetail.put("typeofComplaint", sitan.getTypeofComplaint());
 			complainDetail.put("referenceEffective", sitan.getReferenceEffective());
 			complainDetail.put("classLicense", sitan.getClassLicense());
 			complainDetail.put("particle", sitan.getParticle());
 			complainDetail.put("dateofincident", sitan.getDateofincident());
 			complainDetail.put("timeEvent", sitan.getTimeEvent());
 				
 			complainDetail.put("locationofincident", sitan.getLocationofincident());
 			complainDetail.put("terminal", sitan.getTerminal());
 			complainDetail.put("bookie", sitan.getBookie());
 			complainDetail.put("Landmark", sitan.getLandmark());
 			
 			complainDetail.put("territory", sitan.getTerritory());
 			complainDetail.put("internalStakeholder", sitan.getInternalStakeholder());
 			complainDetail.put("externalStakeholder", sitan.getExternalStakeholder());
 			
 			List<complainUserinfo> complainUserinfos  = complainUserinfoLocalServiceUtil.getsByBillId(bilId);
 			for(complainUserinfo compl:complainUserinfos){
 				
 				complainDetail.put("bilId", compl.getBilId());
 	 			complainDetail.put("prefix", compl.getPrefix());
 	 			complainDetail.put("Name", compl.getName());
 	 			complainDetail.put("identificationnumber", compl.getIdentificationnumber());
 	 			complainDetail.put("passport", compl.getPassport());
 	 			complainDetail.put("citizen", compl.getCitizen());
 	 			complainDetail.put("Nation", compl.getNation());
 	 			complainDetail.put("gender", compl.getGender());
 	 			complainDetail.put("Age", compl.getAge());
 	 			complainDetail.put("phoneNo", compl.getPhoneNo());
 	 			complainDetail.put("cellPhones", compl.getCellPhones());
 	 			complainDetail.put("Address", compl.getAddress());
 	 			complainDetail.put("Email", compl.getEmail());
 	 			complainDetail.put("State", compl.getState());
 	 			
 	 			//DRIVER INFORMATION	
 	 			
 	 			driverInformation.put("dName", compl.getDName());
 	 			driverInformation.put("didentificationnumber", compl.getDidentificationnumber());
 	 			driverInformation.put("dateofbirth", compl.getDateofbirth());
 	 			driverInformation.put("dcitizen", compl.getDcitizen());
 	 			driverInformation.put("driverNation", compl.getDriverNation());
 	 			driverInformation.put("drivergender", compl.getDrivergender());
 	 			driverInformation.put("driverAge", compl.getDriverAge());
 	 				
 	 			driverInformation.put("retirees", compl.getRetirees());
 	 			driverInformation.put("statusReadPSV", compl.getStatusReadPSV());
 	 			driverInformation.put("driverLicense", compl.getDriverLicense());
 	 			driverInformation.put("dphone", compl.getDphone());
 	 			driverInformation.put("daddress", compl.getDaddress());
 	 				
 			}
 			
 			complainDetailArray.put(complainDetail);
 			driverInformationArray.put(driverInformation);
 			complainDetailArray.put(complainDetail);
 			
 		   //DETAILS OKS / Boyds
 			
 			List<detailoksboyds> detailoksboyds = detailoksboydsLocalServiceUtil.getsByDetailBillId(bilId);
 			for(detailoksboyds detail:detailoksboyds){
 				
 				detailoksboys.put("bilId", detail.getBilId());
 	 			detailoksboys.put("companyName", detail.getCompanyName());
 	 				
 	 			detailoksboys.put("classOperatorLicense", detail.getClassOperatorLicense());
 	 			detailoksboys.put("listofCompanies", detail.getListofCompanies());
 	 			detailoksboys.put("reRegistration", detail.getReRegistration());
 	 			detailoksboys.put("email", detail.getEmail());
 	 			detailoksboys.put("noReferenceFile", detail.getNoReferenceFile());
 	 				
 	 			detailoksboys.put("addressList", detail.getAddressList());
 	 			detailoksboys.put("addressListRegistation", detail.getAddressListRegistation());
 	 			detailoksboys.put("authorisedCapital", detail.getAuthorisedCapital());
 	 			detailoksboys.put("accruedCapital", detail.getAccruedCapital());
 	 			detailoksboys.put("capitalPaid", detail.getCapitalPaid());
 	 			detailoksboys.put("ComRegNo", detail.getComRegNo());
 	 			detailoksboys.put("nationOwner", detail.getNationOwner());
 	 				
 	 			detailoksboys.put("dateListofCompanies", detail.getDateListofCompanies());
 	 			detailoksboys.put("activity", detail.getActivity());
 	 			detailoksboys.put("phoneNo", detail.getPhoneNo());
 	 			detailoksboys.put("faxNo", detail.getFaxNo());
 	 			detailoksboys.put("lastUpdateDate", detail.getLastUpdateDate());
 	 			detailoksboysArray.put(detailoksboys);	
 				

 			}
 			
 			List<BoardDirector> boardDirectors = BoardDirectorLocalServiceUtil.getsByBilId(bilId);
 			JSONArray boarddirArray = JSONFactoryUtil.createJSONArray();
 			for(BoardDirector bosrd:boardDirectors){
 				JSONObject boardDirector = JSONFactoryUtil.createJSONObject();
 				boardDirector.put("boarddirectorid", bosrd.getBoarddirectorid());
 				boardDirector.put("wealp", bosrd.getWealp());
 				boardDirector.put("kplama", bosrd.getKplama());
 				boardDirector.put("newKp", bosrd.getNewKp());
 				boardDirector.put("position", bosrd.getPosition());
 				boarddirArray.put(boardDirector);
 			}
 			detailoksboys.put("BoardDirector", boarddirArray);
 			
 			JSONArray equityHolArray = JSONFactoryUtil.createJSONArray();
 			List<EquityHolders> equityHolders = EquityHoldersLocalServiceUtil.getsByBilId(bilId);
 			for(EquityHolders equity:equityHolders){
 				
 				JSONObject equityHolder = JSONFactoryUtil.createJSONObject();
 				equityHolder.put("equityholders", equity.getEquityholdersid());
 				equityHolder.put("name", equity.getName());
 				equityHolder.put("kpLama", equity.getKpLama());
 				equityHolder.put("newKp", equity.getNewKp());
 				equityHolder.put("value", equity.getValue());
 				equityHolder.put("percent", equity.getPercent());
 				equityHolder.put("gender", equity.getGender());
 				equityHolder.put("nation", equity.getNation());
 				equityHolArray.put(equityHolder);
 				
 			}
 			detailoksboys.put("equityHolder", equityHolArray);
 			
 			
 			List<LicensesStatus> licensesStatus = LicensesStatusLocalServiceUtil.getsByBilId(bilId);
 			JSONArray licenseArray = JSONFactoryUtil.createJSONArray();
 			for(LicensesStatus bosrd:licensesStatus){
 				JSONObject lisenceStatus = JSONFactoryUtil.createJSONObject();
 				lisenceStatus.put("licensesstatusid", bosrd.getLicensesstatusid());
 				lisenceStatus.put("active", bosrd.getActive());
 				lisenceStatus.put("Noactive", bosrd.getNoActive());
 				lisenceStatus.put("moreoverHadAge", bosrd.getMoreoverHadAge());
 				lisenceStatus.put("finishedWithin", bosrd.getFinishedWithin());
 				
 				licenseArray.put(lisenceStatus);
 			}
 			detailoksboys.put("Licenses Status", licenseArray);
 			
 			List<ActiveVehicleDetail> activeVehicleDetails = ActiveVehicleDetailLocalServiceUtil.getsByBilId(bilId);
 			JSONArray ActivevehicalArray = JSONFactoryUtil.createJSONArray();
 			for(ActiveVehicleDetail bosrd:activeVehicleDetails){
 				JSONObject vehicalStatus = JSONFactoryUtil.createJSONObject();
 				vehicalStatus.put("vehicalid", bosrd.getVehicalid());
 				vehicalStatus.put("classcode", bosrd.getClasscode());
 				vehicalStatus.put("byVehicle", bosrd.getByVehicle());
 				vehicalStatus.put("withoutMotor", bosrd.getWithoutMotor());
 				vehicalStatus.put("commencement", bosrd.getCommencement());
 				vehicalStatus.put("ageLimit", bosrd.getAgeLimit());
 				ActivevehicalArray.put(vehicalStatus);
 			}
 			detailoksboys.put("ComparedActiveVehicleClass", ActivevehicalArray);
 			
 			//VEHICLE INFORMATION		
 			List<vehicalInfo> veInfos = vehicalInfoLocalServiceUtil.getsByVehicalBillId(bilId);
 			for(vehicalInfo vehic:veInfos){
 				
 				vehicalInformation.put("bilId", vehic.getBilId());
 	 			vehicalInformation.put("brands", vehic.getBrands());
 	 				
 	 			vehicalInformation.put("Model", vehic.getModel());
 	 			vehicalInformation.put("noEnjin", vehic.getNoEnjin());
 	 			vehicalInformation.put("noCasis", vehic.getNoCasis());
 	 			vehicalInformation.put("bodytype", vehic.getBodytype());
 	 			vehicalInformation.put("color", vehic.getColor());
 	 			vehicalInformation.put("yearbuilt", vehic.getYearbuilt());
 	 				
 	 			vehicalInformation.put("dateofVehicles", vehic.getDateofVehicles());
 	 			vehicalInformation.put("temporaryLicenses", vehic.getTemporaryLicenses());
 	 			vehicalInformation.put("numberofPassengers", vehic.getNumberofPassengers());
 	 			vehicalInformation.put("seatingNumber", vehic.getSeatingNumber());
 	 			vehicalInformation.put("operatingArea", vehic.getOperatingArea());
 	 			vehicalInformation.put("typeofservice", vehic.getTypeofservice());
 	 			vehicalInformation.put("readStatus", vehic.getReadStatus());
 	 				
 	 			vehicalInformation.put("bdm", vehic.getBdm());
 	 			vehicalInformation.put("btm", vehic.getBtm());
 	 			vehicalInformation.put("bt1", vehic.getBt1());
 	 			vehicalInformationArray.put(vehicalInformation);
 			}
 			
 				
      }
		
	   //SUMMARY OF ACTION
		List<ActionSummery>  actionSummeries = ActionSummeryLocalServiceUtil.getsByBilId(bilId);
			for(ActionSummery action:actionSummeries){
				JSONObject actionSummery = JSONFactoryUtil.createJSONObject();
				actionSummery.put("bilId", action.getBilId());
		 		actionSummery.put("dateSeized", action.getDateTime());
		 		actionSummery.put("Status", action.getStatus());
		 		actionSummery.put("Action", action.getAction());
		 		actionSummery.put("ActionBy", action.getActionBy());
		 		actionSummeryArray.put(actionSummery);
			}
		
		
		// ERROR inquiry		
		JSONObject dataObject = JSONFactoryUtil.createJSONObject();
		JSONArray errorinquiryArray = JSONFactoryUtil.createJSONArray();
		JSONArray errorTypearray= JSONFactoryUtil.createJSONArray();
		JSONArray sourceTypeArray= JSONFactoryUtil.createJSONArray();
		List<SourceTypes> sourceTypes = SourceTypesLocalServiceUtil.getSourceTypeses(-1, -1);
		for(SourceTypes source:sourceTypes){
			
			JSONObject errorType = JSONFactoryUtil.createJSONObject();
			JSONObject sourceType = JSONFactoryUtil.createJSONObject();
			errorType.put("id", source.getSourcetypeid());
			errorType.put("value", source.getErrortypes());
			errorTypearray.put(errorType);
			sourceType.put("id", source.getSourcetypeid());
			sourceType.put("value", source.getSourcetypes());
			sourceTypeArray.put(sourceType);
		}
		List<BillInquery> billInqueries = BillInqueryLocalServiceUtil.getsByBilId(bilId);
		for(BillInquery sitan:billInqueries){
			JSONObject errorinquiry = JSONFactoryUtil.createJSONObject();
			errorinquiry.put("billinquery", sitan.getBillinquery());
			errorinquiry.put("bilId", sitan.getBilId());
			errorinquiry.put("complaintDate", sitan.getComplaintDate());
			errorinquiry.put("referenceEffective", sitan.getReferenceEffective());
			errorinquiry.put("vehiclesNo", sitan.getVehiclesNo());
			errorinquiry.put("companyName", sitan.getCompanyName());
			errorinquiry.put("source", sitan.getSource());
			errorinquiry.put("offense", sitan.getOffense());
			errorinquiry.put("virtue", sitan.getVirtue());
				
			errorinquiry.put("filerating", sitan.getFilerating());
			errorinquiry.put("caseStatus", sitan.getCaseStatus());
			errorinquiry.put("nameofofficer", sitan.getNameofofficer());
			errorinquiry.put("error", sitan.getError());
			errorinquiryArray.put(errorinquiry);
			}
		dataObject.put("ErrorTypes", errorTypearray);
		dataObject.put("Source", sourceTypeArray);
		dataObject.put("Error_Inquery_Data", errorinquiryArray);
		
		resultReturncase.put("CASE_INFORMATION", CaseArray);
		resultReturncase.put("INFORMATION_SITAN", InformationArraymain);
		resultReturncase.put("IP_DETAILS", ipdetailArray);
		resultReturncase.put("COMPLAINT_DETAILS", complainDetailArray);
		resultReturncase.put("DETAILS_OKS_OYDS", detailoksboysArray);
		resultReturncase.put("DRIVER_INFORMATION", driverInformationArray);
		resultReturncase.put("VEHICLE_INFORMATION", vehicalInformationArray);
		resultReturncase.put("ERROR_INQUERY", dataObject);
		resultReturncase.put("ACTION_SUMMERY", actionSummeryArray);
		
		return resultReturncase;
	 }
	
	@JSONWebService(value = "Upload_Document_Search", method = "PUT")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject UploadDocumentSearch(String title) throws SystemException, PortalException {
	
		JSONObject galleryyReturn = JSONFactoryUtil.createJSONObject();
		JSONArray galleryArray = JSONFactoryUtil.createJSONArray();
		
		DynamicQuery dynamicQuery =null;
		
		try{
			
		ClassLoader loader=(ClassLoader)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),"portletClassLoader");
		dynamicQuery = DynamicQueryFactoryUtil.forClass(DLFileEntry.class, loader);
		
		Criterion criterion = null;
		boolean setFlag = true;
		
		if(!title.equals(StringPool.BLANK)){
			criterion = RestrictionsFactoryUtil.like("title", StringPool.PERCENT+title+StringPool.PERCENT);
			setFlag = false;
		}
		dynamicQuery.add(criterion);
		}catch(Exception e){}

		
		List<DLFileEntry> gallryIds =null;
		try{
		gallryIds = DLFileEntryLocalServiceUtil.dynamicQuery(dynamicQuery);

		}catch(Exception e){}
		for(DLFileEntry dlgall:gallryIds){
			
			JSONObject noofdlentry = JSONFactoryUtil.createJSONObject();
			String filePath="";
			noofdlentry.put("FileName", dlgall.getTitle());
			noofdlentry.put("Size", dlgall.getSize());
			long fileentryid = dlgall.getFileEntryId();
			DLFileEntry dl=DLFileEntryLocalServiceUtil.getDLFileEntry(fileentryid);
			filePath="/documents/"+dl.getGroupId()+"/"+dl.getFolderId()+"/"+dl.getTitle()+"/"+dl.getUuid();
			noofdlentry.put("Filepath", filePath);
			galleryArray.put(noofdlentry);
		}
		galleryyReturn.put("Upload_File_Detail", galleryArray);
		return galleryyReturn;
	 }
	
	@JSONWebService(value = "Upload_Document", method = "POST")
	@AccessControlled(guestAccessEnabled = true)
	public void Upload_Document(File file,String fileName) throws PortalException, SystemException, IOException
	 {
	
	/*try{
		String SelectfilePath
		PortletRequest portletRequest = (PortletRequest) renderRequest.getAttribute("javax.portlet.request");
		ThemeDisplay themedisplay= (ThemeDisplay)portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long userid =   themedisplay.getUserId();
		System.out.println("hello user Id ====================>"+userid);

		}catch(Exception e){
			
			System.out.println("hello user Id ====================>Unable to call");
		}*/
		
		String groupName = GroupConstants.GUEST;
		long companyId = PortalUtil.getDefaultCompanyId();
		long groupId = GroupLocalServiceUtil.getGroup(companyId, groupName).getGroupId(); 
		
		long userId = UserLocalServiceUtil.getDefaultUserId(companyId);
		    
	   // File uploadedFile = new File(SelectfilePath);
		
	 //System.out.println("File"+file.getAbsolutePath());
		
	 String uploadedFile = file.getAbsolutePath();
		
	  if(uploadedFile != null)
		{
		ServiceContext serviceContext = new ServiceContext();
		serviceContext.setScopeGroupId(serviceContext.getScopeGroupId());
							
		String mimeType = MimeTypesUtil.getContentType(uploadedFile);
			long folderId = 0l;
			long parentFolderId = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
			long size = uploadedFile.length();
			//String filename =file.getName();
			
		if(userId != 0l)
			{
			//System.out.println("My Size" +size + "Total Size" + PrefsPropsUtil.getLong(PropsKeys.UPLOAD_SERVLET_REQUEST_IMPL_MAX_SIZE));
			if(size <= PrefsPropsUtil.getLong(PropsKeys.UPLOAD_SERVLET_REQUEST_IMPL_MAX_SIZE) )
			{
		  try
			 {
			     DLFolder folder = DLFolderLocalServiceUtil.getFolder(groupId, parentFolderId, "SPAD");
			    // System.out.println("Try Folder Exception");
			     folderId = folder.getFolderId(); 
			     
			 } 
			 
		 catch (NoSuchFolderException e) 
			{
			 
				 DLFolder folder = DLFolderLocalServiceUtil.addFolder(userId, groupId, groupId, false, 0, fileName, "", false, serviceContext);
			    //DLFolder folder = DLFolderLocalServiceUtil.addFolder(userId,groupId, groupId, false, 0, "Home","", serviceContext);
			    //System.out.println("Catch Folder");
				 
				 folderId = folder.getFolderId();
			      
			 }
			 
			FileEntry fileEntry = DLAppLocalServiceUtil.addFileEntry(userId, groupId, folderId, fileName, mimeType,
			fileName, fileName, "", FileUtil.getBytes(file), serviceContext);
			
			//System.out.println("File Upload Succesfully");
			
			}
			else
			{
			// System.out.println("File Size is TOO LARGE");
				
			}
		 }
	}
	   
  }
	
	@JSONWebService(value = "Document_Binding_Tree", method = "PUT")
	@AccessControlled(guestAccessEnabled = true)
	public JSONArray Document_Binding_Tree()  throws PortalException, SystemException, IOException
	 {
		
		//JSONObject documentReturn = JSONFactoryUtil.createJSONObject();
		JSONArray documentArray = JSONFactoryUtil.createJSONArray();
		
		List<DocumentTree> documentTrees = DocumentTreeLocalServiceUtil.getDocumentTrees(-1, -1);
		
		for(DocumentTree doctree:documentTrees){
			
			long fileentryid = doctree.getFileentryid();
			
			//DLFileEntry fileentry = DLFileEntryLocalServiceUtil.getDLFileEntry(fileentryid);
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			
			String filePath="";
			doc.put("DocumentId", doctree.getDocumenttreeid());
			doc.put("Billid", doctree.getBilId());
			doc.put("FileEntryId", doctree.getFileentryid());
			doc.put("FolderId", doctree.getFolderid());
			doc.put("label", doctree.getTitle());
			doc.put("FolderName", doctree.getFoldername());
			doc.put("leaf", doctree.getLeaf());
			doc.put("type", doctree.getType());
			
			DLFileEntry dl=DLFileEntryLocalServiceUtil.getDLFileEntry(fileentryid);
			filePath="/documents/"+dl.getGroupId()+"/"+dl.getFolderId()+"/"+dl.getTitle()+"/"+dl.getUuid();
			doc.put("Filepath", filePath);
			documentArray.put(doc);
		}
		
		//documentReturn.put("Document_detail", documentArray);
		
		return documentArray;
		
		
	 }
	
	@JSONWebService(value = "Officer_List", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject Officer_List()  throws PortalException, SystemException, IOException
	 {
		
		JSONObject officerReturn = JSONFactoryUtil.createJSONObject();
		JSONArray officerArray = JSONFactoryUtil.createJSONArray();
		
		List<OfficerDetail> officerDetails = OfficerDetailLocalServiceUtil.getOfficerDetails(-1, -1);
		
		for(OfficerDetail officer:officerDetails){
			
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			doc.put("officerid", officer.getOfficerid());
			doc.put("officername", officer.getOfficername());
			doc.put("officertype", officer.getOfficertype());
			doc.put("office", officer.getOffice());
			doc.put("Officerpower", officer.getOfficerpower());
			doc.put("Date", officer.getDate());
			doc.put("Email", officer.getOfficerEmail());
			
			officerArray.put(doc);
		}
		
		officerReturn.put("Officer_List", officerArray);
		return officerReturn;
		
		
	 }
	
	@JSONWebService(value = "Visual_Inspection_Get", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject VisualInspection(long bilId)  throws PortalException, SystemException, IOException
	 {
		
		JSONObject VisualReturn = JSONFactoryUtil.createJSONObject();
		JSONArray VisualArray = JSONFactoryUtil.createJSONArray();
		
		List<vehicalInfo> vehicalInfos = vehicalInfoLocalServiceUtil.getsByVehicalBillId(bilId);
		
		for(vehicalInfo vehical:vehicalInfos){
			
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			doc.put("billId", vehical.getBilId());
			doc.put("vehicleRegistrationNo", vehical.getVehicleRegistrationNo());
			doc.put("model", vehical.getModel());
			doc.put("color", vehical.getColor());
			doc.put("dateofVehicles", vehical.getDateofVehicles());
			
			doc.put("investigatorname", vehical.getInvestigatorname());
			doc.put("investigatorphone", vehical.getInvestigatorphone());
			doc.put("investigatorEmail", vehical.getInvestigatorEmail());
			
			VisualArray.put(doc);
		}
		
		VisualReturn.put("Visual_Inspection", VisualArray);
		return VisualReturn;
		
		
	 }
	@JSONWebService(value ="Visual_Inspection_POST", method = "POST")
	@AccessControlled(guestAccessEnabled = true)
	public visualchecklist VisualInspectionPost(long checkId,long bilId,String numberplates,String numberplatesNote,String forwardlighting,String forwardlightingNote,String backlight,String backlightNote,String trafficLight,String trafficLightNote,String signallight,
			String signallightNote,String vehiclebody,String vehiclebodyNote,String vehicleAccessories,String vehicleAccessoriesNote,String windscreen,String windscreenNote,String rearMirror,String rearMirrorNote,
			String doormirror,String doormirrorNote,String vehicletires,String vehicletiresNote,String frontbumper,String frontbumperNote,
			String rearbumper,String rearbumperNote,String frontseat,String frontseatNote,String rearseats,String rearseatsNote,String note
			,String investigatorname,String investigatorEmail,String investigatorphone)  throws PortalException, SystemException, IOException
	 {
		
		//St checkidS = String.valueOf(checkId);
		
		if(checkId != 0 ){
			
			//System.out.println(checkId);
			visualchecklist visual = visualchecklistLocalServiceUtil.getvisualchecklist(checkId);
			visual.setCheckId(checkId);
			visual.setBilId(bilId);
			visual.setNumberplates(numberplates);
			visual.setNumberplatesNote(numberplatesNote);
			visual.setForwardlighting(forwardlighting);
			visual.setForwardlightingNote(forwardlightingNote);
			visual.setBacklight(backlight);
			visual.setBacklightNote(backlightNote);
			visual.setTrafficLight(trafficLight);
			visual.setTrafficLightNote(trafficLightNote);
			visual.setSignallight(signallight);
			visual.setSignallightNote(signallightNote);
			visual.setVehicleAccessories(vehicleAccessories);
			visual.setVehicleAccessoriesNote(vehicleAccessoriesNote);
			visual.setVehiclebody(vehiclebody);
			visual.setVehiclebodyNote(vehiclebodyNote);
			visual.setWindscreen(windscreen);
			visual.setWindscreenNote(windscreenNote);
			visual.setRearbumper(rearbumper);
			visual.setRearbumperNote(rearbumperNote);
			visual.setRearMirror(rearMirror);
			visual.setRearMirrorNote(rearMirrorNote);
			visual.setDoormirror(doormirror);
			visual.setDoormirrorNote(doormirrorNote);
			visual.setVehicletires(vehicletires);
			visual.setVehicletiresNote(vehicletiresNote);
			visual.setFrontbumper(frontbumper);
			visual.setFrontbumperNote(frontbumperNote);
			visual.setRearbumper(rearbumper);
			visual.setRearbumperNote(rearbumperNote);
			visual.setFrontseat(frontseat);
			visual.setFrontseatNote(frontseatNote);
			visual.setRearseats(rearseats);
			visual.setRearseatsNote(rearseatsNote);
			visual.setNote(note);
			/*visual.setVehicleRegistrationNo(vehicleRegistrationNo);
			visual.setModel(model);
			visual.setColor(color);
			visual.setDateofVehicles(dateofVehicles);*/
			visual.setInvestigatorname(investigatorname);
			visual.setInvestigatorEmail(investigatorEmail);
			visual.setInvestigatorphone(investigatorphone);
			
			 
			return visualchecklistLocalServiceUtil.updatevisualchecklist(visual);
			
		}else{
			
			//System.out.println("I am here");
		    long checkmailId = CounterLocalServiceUtil.increment(visualchecklistServiceImpl.class.getName());
			
			visualchecklist visual=null;
			visual = new visualchecklistImpl();
			//visual = visualchecklistLocalServiceUtil.createvisualchecklist(checkId);
			visual.setCheckId(checkmailId);
			visual.setBilId(bilId);
			visual.setNumberplates(numberplates);
			visual.setNumberplatesNote(numberplatesNote);
			visual.setForwardlighting(forwardlighting);
			visual.setForwardlightingNote(forwardlightingNote);
			visual.setBacklight(backlight);
			visual.setBacklightNote(backlightNote);
			visual.setTrafficLight(trafficLight);
			visual.setTrafficLightNote(trafficLightNote);
			visual.setSignallight(signallight);
			visual.setSignallightNote(signallightNote);
			visual.setVehicleAccessories(vehicleAccessories);
			visual.setVehicleAccessoriesNote(vehicleAccessoriesNote);
			visual.setVehiclebody(vehiclebody);
			visual.setVehiclebodyNote(vehiclebodyNote);
			visual.setWindscreen(windscreen);
			visual.setWindscreenNote(windscreenNote);
			visual.setRearbumper(rearbumper);
			visual.setRearbumperNote(rearbumperNote);
			visual.setRearMirror(rearMirror);
			visual.setRearMirrorNote(rearMirrorNote);
			visual.setDoormirror(doormirror);
			visual.setDoormirrorNote(doormirrorNote);
			visual.setVehicletires(vehicletires);
			visual.setVehicletiresNote(vehicletiresNote);
			visual.setFrontbumper(frontbumper);
			visual.setFrontbumperNote(frontbumperNote);
			visual.setRearbumper(rearbumper);
			visual.setRearbumperNote(rearbumperNote);
			visual.setFrontseat(frontseat);
			visual.setFrontseatNote(frontseatNote);
			visual.setRearseats(rearseats);
			visual.setRearseatsNote(rearseatsNote);
			visual.setNote(note);
			/*visual.setVehicleRegistrationNo(vehicleRegistrationNo);
			visual.setModel(model);
			visual.setColor(color);
			visual.setDateofVehicles(dateofVehicles);*/
			visual.setInvestigatorname(investigatorname);
			visual.setInvestigatorEmail(investigatorEmail);
			visual.setInvestigatorphone(investigatorphone);
				
			return visualchecklistLocalServiceUtil.addvisualchecklist(visual);

			
			}
	 }
	
	@JSONWebService(value = "File_Visual_Inspection_Get", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject SaveVisualInspection(long bilId,long checkId)  throws PortalException, SystemException, IOException
	 {
		
		JSONObject VisualInspectionReturn = JSONFactoryUtil.createJSONObject();
		JSONObject VisualMainReturn = JSONFactoryUtil.createJSONObject();
		
		//JSONObject VehicalDetailM = JSONFactoryUtil.createJSONObject();
		List<vehicalInfo> vehicalInfos = vehicalInfoLocalServiceUtil.getsByVehicalBillId(bilId);
		for(vehicalInfo visual:vehicalInfos){
		JSONObject VehicalDetail = JSONFactoryUtil.createJSONObject();
		VehicalDetail.put("billId", visual.getBilId());
		VehicalDetail.put("vehicleRegistrationNo", visual.getVehicleRegistrationNo());
		VehicalDetail.put("dateofVehicles", visual.getDateofVehicles());
		VehicalDetail.put("model", visual.getModel());
		VehicalDetail.put("color", visual.getColor());
		VisualInspectionReturn.put("VehicalDetail", VehicalDetail);
		}
		if(bilId !=0 && checkId !=0 ){
		List<visualchecklist> visualchecklists = visualchecklistLocalServiceUtil.getsByBillChek(bilId, checkId);
		for(visualchecklist visual:visualchecklists){
			
			
			JSONObject VisualInspecterdoc = JSONFactoryUtil.createJSONObject();
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			
			
			VisualInspecterdoc.put("checkId", visual.getCheckId());
			VisualInspecterdoc.put("billId", visual.getBilId());
			VisualInspecterdoc.put("investigatorName", visual.getInvestigatorname());
			VisualInspecterdoc.put("investigatorPhone", visual.getInvestigatorphone());
			VisualInspecterdoc.put("investigatorEmail", visual.getInvestigatorEmail());
			
			VisualInspectionReturn.put("investigatorDetail", VisualInspecterdoc);
			
			doc.put("checkId", visual.getCheckId());
			doc.put("bilId",visual.getBilId());
			doc.put("numberplates", visual.getNumberplates());
			doc.put("numberplatesNote", visual.getNumberplatesNote());
			doc.put("forwardlighting", visual.getForwardlighting());
			doc.put("forwardlightingNote", visual.getForwardlightingNote());
			doc.put("backlight", visual.getBacklight());               
			doc.put("backlightNote", visual.getBacklightNote());        
			doc.put("trafficLight", visual.getTrafficLight());              
			doc.put("trafficLightNote", visual.getTrafficLightNote());         
			doc.put("signallight", visual.getSignallight());                   
			doc.put("signallightNote", visual.getSignallightNote());           
			doc.put("vehicleAccessories", visual.getVehicleAccessories());         
			doc.put("vehicleAccessoriesNote", visual.getVehicleAccessoriesNote()); 
			doc.put("vehiclebody", visual.getVehiclebody());                        
			doc.put("vehiclebodyNote", visual.getVehiclebodyNote());               
			doc.put("windscreen",visual.getWindscreen());
			doc.put("windscreenNote",visual.getWindscreenNote());
			doc.put("rearbumper",visual.getRearbumper());
			doc.put("rearbumperNote",visual.getRearbumperNote());
			doc.put("rearMirror",visual.getRearMirror());
			doc.put("rearMirrorNote",visual.getRearMirrorNote());
			doc.put("doormirror",visual.getDoormirror());
			doc.put("doormirrorNote",visual.getDoormirrorNote());
			doc.put("vehicletires",visual.getVehicletires());
			doc.put("vehicletiresNote",visual.getVehicletiresNote());
			doc.put("frontbumper",visual.getFrontbumper());
			doc.put("frontbumperNote",visual.getFrontbumperNote());
			doc.put("rearbumper",visual.getRearbumper());
			doc.put("rearbumperNote",visual.getRearbumperNote());
			doc.put("frontseat",visual.getFrontseat());
			doc.put("frontseatNote",visual.getFrontseatNote());
			doc.put("rearseats",visual.getRearseats());
			doc.put("rearseatsNote",visual.getRearseatsNote());
			doc.put("note",visual.getNote());
			
			VisualInspectionReturn.put("visualInspectionRadio", doc);
			
		}
	   VisualMainReturn.put("visualInspection", VisualInspectionReturn);
	}else if(bilId !=0 && checkId ==0 ){
		
		List<visualchecklist> visualchecklists = visualchecklistLocalServiceUtil.getsByBilId(bilId);
		JSONArray InvestigatorArray= JSONFactoryUtil.createJSONArray();
		JSONArray VisualInspecteArray= JSONFactoryUtil.createJSONArray();
		for(visualchecklist visual:visualchecklists){
			
			//System.out.println("checkid"+visual.getCheckId());
			JSONObject VisualInspecterdoc = JSONFactoryUtil.createJSONObject();
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			
			VisualInspecterdoc.put("checkId", visual.getCheckId());
			VisualInspecterdoc.put("billId", visual.getBilId());
			
			VisualInspecterdoc.put("investigatorName", visual.getInvestigatorname());
			VisualInspecterdoc.put("investigatorPhone", visual.getInvestigatorphone());
			VisualInspecterdoc.put("investigatorEmail", visual.getInvestigatorEmail());
			VisualInspecteArray.put(VisualInspecterdoc);
			
			doc.put("checkId", visual.getCheckId());
			doc.put("bilId",visual.getBilId());
			doc.put("numberplates", visual.getNumberplates());
			doc.put("numberplatesNote", visual.getNumberplatesNote());
			doc.put("forwardlighting", visual.getForwardlighting());
			doc.put("forwardlightingNote", visual.getForwardlightingNote());
			doc.put("backlight", visual.getBacklight());               
			doc.put("backlightNote", visual.getBacklightNote());        
			doc.put("trafficLight", visual.getTrafficLight());              
			doc.put("trafficLightNote", visual.getTrafficLightNote());         
			doc.put("signallight", visual.getSignallight());                   
			doc.put("signallightNote", visual.getSignallightNote());           
			doc.put("vehicleAccessories", visual.getVehicleAccessories());         
			doc.put("vehicleAccessoriesNote", visual.getVehicleAccessoriesNote()); 
			doc.put("vehiclebody", visual.getVehiclebody());                        
			doc.put("vehiclebodyNote", visual.getVehiclebodyNote());               
			doc.put("windscreen",visual.getWindscreen());
			doc.put("windscreenNote",visual.getWindscreenNote());
			doc.put("rearbumper",visual.getRearbumper());
			doc.put("rearbumperNote",visual.getRearbumperNote());
			doc.put("rearMirror",visual.getRearMirror());
			doc.put("rearMirrorNote",visual.getRearMirrorNote());
			doc.put("doormirror",visual.getDoormirror());
			doc.put("doormirrorNote",visual.getDoormirrorNote());
			doc.put("vehicletires",visual.getVehicletires());
			doc.put("vehicletiresNote",visual.getVehicletiresNote());
			doc.put("frontbumper",visual.getFrontbumper());
			doc.put("frontbumperNote",visual.getFrontbumperNote());
			doc.put("rearbumper",visual.getRearbumper());
			doc.put("rearbumperNote",visual.getRearbumperNote());
			doc.put("frontseat",visual.getFrontseat());
			doc.put("frontseatNote",visual.getFrontseatNote());
			doc.put("rearseats",visual.getRearseats());
			doc.put("rearseatsNote",visual.getRearseatsNote());
			doc.put("note",visual.getNote());
			//VisualArray.put(doc);
			InvestigatorArray.put(doc);
		}
		VisualInspectionReturn.put("investigatorDetail", VisualInspecteArray);
		VisualInspectionReturn.put("visualInspectionRadio", InvestigatorArray);
		
	    VisualMainReturn.put("visualInspection", VisualInspectionReturn);
	}
	
	
		return VisualMainReturn;
	 }
	
	@JSONWebService(value = "Multiple_Upload_Document", method = "POST")
	@AccessControlled(guestAccessEnabled = true)
	public void Multiple_Upload_Document(File file[]) throws PortalException, SystemException, IOException
	 {
		 
		//System.out.println("Files Length  -------------"+file.length);
		//System.out.println("filename inSide file[]=========="+file);
		
		//String uploadedFile = file.length;
		//String fileNames[] = uploadPortletRequest.getFileNames("fourmfile");
		
		String groupName = GroupConstants.GUEST;
		long companyId = PortalUtil.getDefaultCompanyId();
		long groupId = GroupLocalServiceUtil.getGroup(companyId, groupName).getGroupId(); 
		long userId = UserLocalServiceUtil.getDefaultUserId(companyId);
		
		//File uploadedFile = new File(SelectfilePath);
		//System.out.println("File"+file.getAbsolutePath());,String fileName[]
		//String uploadedFile = file.getAbsolutePath();if(file.length == fileName.length)
		//{
	
	 for(int j=0; j < file.length; j++)
	  {
		
		//String filepath = 	
		File uploadedFile = file[j];	
		String filename = uploadedFile.getName();
		//System.out.println("filename inSide=========="+filename);
	
	 if(uploadedFile != null)
		{
		ServiceContext serviceContext = new ServiceContext();
		serviceContext.setScopeGroupId(serviceContext.getScopeGroupId());
							
		String mimeType = MimeTypesUtil.getContentType(uploadedFile);
			long folderId = 0l;
			long parentFolderId = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
			long size = uploadedFile.length();
			//String filename =file.getName();
			
		if(userId != 0l)
			{
			//System.out.println("My Size" +size + "Total Size" + PrefsPropsUtil.getLong(PropsKeys.UPLOAD_SERVLET_REQUEST_IMPL_MAX_SIZE));
			if(size <= PrefsPropsUtil.getLong(PropsKeys.UPLOAD_SERVLET_REQUEST_IMPL_MAX_SIZE))
			{
		  try
			 {
			     DLFolder folder = DLFolderLocalServiceUtil.getFolder(groupId, parentFolderId, "SPAD");
			    // System.out.println("Try Folder Exception");
			     folderId = folder.getFolderId(); 
			     
			 } 
			 
		 catch (NoSuchFolderException e) 
			{
			 
				 DLFolder folder = DLFolderLocalServiceUtil.addFolder(userId, groupId, groupId, false, 0, uploadedFile.getName(), "", false, serviceContext);
			    //DLFolder folder = DLFolderLocalServiceUtil.addFolder(userId,groupId, groupId, false, 0, "Home","", serviceContext);
			    //System.out.println("Catch Folder");
				 
				 folderId = folder.getFolderId();
			      
			 }
			 
			FileEntry fileEntry = DLAppLocalServiceUtil.addFileEntry(userId, groupId, folderId, uploadedFile.getName(), mimeType,
			uploadedFile.getName(), uploadedFile.getName(), "", FileUtil.getBytes(uploadedFile), serviceContext);
			//System.out.println("File Upload Succesfully");
			
			}
			else
			{
			// System.out.println("File Size is TOO LARGE");
				 }
				}
			}
		}
	
	}
	
	
	@JSONWebService(value ="Acceptanece_Vehical_Detail_POST", method = "POST")
	@AccessControlled(guestAccessEnabled = true)
	public AcceptanceVehicleDetail AcceptaneceVehicalDetail(long vehicalid,long bilId,String vehiNumberPlate,String ownerName,String companyRepresentative,
			String kpNo,String chronicle,String Signature,String accodocument,String cardIdentity,String drivingLicense,
			String grantVehicle,String attorney,String numberPlateDetail)  throws PortalException, SystemException, IOException
	 {
		
		if(vehicalid != 0 ){
			
			//System.out.println(vehicalid);
			AcceptanceVehicleDetail visual = AcceptanceVehicleDetailLocalServiceUtil.getAcceptanceVehicleDetail(vehicalid);
			visual.setVehicalid(vehicalid);
			visual.setBilId(bilId);
			visual.setVehiNumberPlate(vehiNumberPlate);
			visual.setOwnerName(ownerName);
			visual.setCompanyRepresentative(companyRepresentative);
			visual.setKpNo(kpNo);
			visual.setChronicle(chronicle);
			visual.setSignature(Signature);
			visual.setAccodocument(accodocument);
			visual.setCardIdentity(cardIdentity);
			visual.setDrivingLicense(drivingLicense);
			visual.setGrantVehicle(grantVehicle);
			visual.setAttorney(attorney);
			visual.setNumberPlateDetail(numberPlateDetail);
			 
			return AcceptanceVehicleDetailLocalServiceUtil.updateAcceptanceVehicleDetail(visual);
			
		}else{
			
			long checkmailId = CounterLocalServiceUtil.increment(AcceptanceVehicleDetailImpl.class.getName());
			
			AcceptanceVehicleDetail visual=null;
			visual = new AcceptanceVehicleDetailImpl();
			//visual = visualchecklistLocalServiceUtil.createvisualchecklist(checkId);
			visual.setVehicalid(checkmailId);
			visual.setBilId(bilId);
			visual.setVehiNumberPlate(vehiNumberPlate);
			visual.setOwnerName(ownerName);
			visual.setCompanyRepresentative(companyRepresentative);
			visual.setKpNo(kpNo);
			visual.setChronicle(chronicle);
			visual.setSignature(Signature);
			visual.setAccodocument(accodocument);
			visual.setCardIdentity(cardIdentity);
			visual.setDrivingLicense(drivingLicense);
			visual.setGrantVehicle(grantVehicle);
			visual.setAttorney(attorney);
			visual.setNumberPlateDetail(numberPlateDetail);
				
			return AcceptanceVehicleDetailLocalServiceUtil.addAcceptanceVehicleDetail(visual);

			}
	
	 }
	
	
	@JSONWebService(value = "File_Acceptanece_Vehical_Detail_Get", method = "GET")
	@AccessControlled(guestAccessEnabled = true)
	public JSONObject FileAcceptaneceVehicalDetail(long vehicalid,long bilId)  throws PortalException, SystemException, IOException
	 {
		
		JSONObject VisualInspectionReturn = JSONFactoryUtil.createJSONObject();
		JSONObject VisualMainReturn = JSONFactoryUtil.createJSONObject();
		if(bilId !=0 && vehicalid !=0 ){
		List<AcceptanceVehicleDetail> visualchecklists = AcceptanceVehicleDetailLocalServiceUtil.getsByVehicalAndBillId(bilId, vehicalid);
		for(AcceptanceVehicleDetail visual:visualchecklists){
			
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			
			doc.put("vehicalid", visual.getVehicalid());
			doc.put("bilId",visual.getBilId());
			doc.put("vehiNumberPlate", visual.getVehiNumberPlate());
			doc.put("ownerName", visual.getOwnerName());
			doc.put("companyRepresentative", visual.getCompanyRepresentative());
			doc.put("kpNo", visual.getKpNo());               
			doc.put("chronicle", visual.getChronicle());        
			doc.put("Signature", visual.getSignature());              
			doc.put("accodocument", visual.getAccodocument());         
			doc.put("cardIdentity", visual.getCardIdentity());           
			doc.put("drivingLicense", visual.getDrivingLicense());         
			doc.put("grantVehicle", visual.getGrantVehicle()); 
			doc.put("attorney", visual.getAttorney());                        
			doc.put("numberPlateDetail", visual.getNumberPlateDetail());               
			
			VisualInspectionReturn.put("Acceptanece_Vehical_Detail", doc);
		}
	   VisualMainReturn.put("AcceptaneceVehicalDetail", VisualInspectionReturn);
	   
	}else if(bilId !=0 && vehicalid ==0 ){
		
		List<AcceptanceVehicleDetail> visualchecklists = AcceptanceVehicleDetailLocalServiceUtil.getsByBilId(bilId);
		JSONArray InvestigatorArray= JSONFactoryUtil.createJSONArray();
		for(AcceptanceVehicleDetail visual:visualchecklists){
			
			JSONObject doc = JSONFactoryUtil.createJSONObject();
			doc.put("vehicalid", visual.getVehicalid());
			doc.put("bilId",visual.getBilId());
			doc.put("vehiNumberPlate", visual.getVehiNumberPlate());
			doc.put("ownerName", visual.getOwnerName());
			doc.put("companyRepresentative", visual.getCompanyRepresentative());
			doc.put("kpNo", visual.getKpNo());               
			doc.put("chronicle", visual.getChronicle());        
			doc.put("Signature", visual.getSignature());              
			doc.put("accodocument", visual.getAccodocument());         
			doc.put("cardIdentity", visual.getCardIdentity());           
			doc.put("drivingLicense", visual.getDrivingLicense());         
			doc.put("grantVehicle", visual.getGrantVehicle()); 
			doc.put("attorney", visual.getAttorney());                        
			doc.put("numberPlateDetail", visual.getNumberPlateDetail());               
			InvestigatorArray.put(doc);
			
		}
	   VisualInspectionReturn.put("Acceptanece_Vehical_Detail", InvestigatorArray);
	   VisualMainReturn.put("AcceptaneceVehicalDetail", VisualInspectionReturn);
	}
		
	
		return VisualMainReturn;
	 }
	
}
	    