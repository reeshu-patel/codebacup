/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.EquityHolders;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing EquityHolders in entity cache.
 *
 * @author reeshu
 * @see EquityHolders
 * @generated
 */
public class EquityHoldersCacheModel implements CacheModel<EquityHolders>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{equityholdersid=");
		sb.append(equityholdersid);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", name=");
		sb.append(name);
		sb.append(", kpLama=");
		sb.append(kpLama);
		sb.append(", newKp=");
		sb.append(newKp);
		sb.append(", value=");
		sb.append(value);
		sb.append(", percent=");
		sb.append(percent);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", nation=");
		sb.append(nation);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EquityHolders toEntityModel() {
		EquityHoldersImpl equityHoldersImpl = new EquityHoldersImpl();

		equityHoldersImpl.setEquityholdersid(equityholdersid);
		equityHoldersImpl.setBilId(bilId);

		if (name == null) {
			equityHoldersImpl.setName(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setName(name);
		}

		if (kpLama == null) {
			equityHoldersImpl.setKpLama(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setKpLama(kpLama);
		}

		if (newKp == null) {
			equityHoldersImpl.setNewKp(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setNewKp(newKp);
		}

		if (value == null) {
			equityHoldersImpl.setValue(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setValue(value);
		}

		if (percent == null) {
			equityHoldersImpl.setPercent(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setPercent(percent);
		}

		if (gender == null) {
			equityHoldersImpl.setGender(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setGender(gender);
		}

		if (nation == null) {
			equityHoldersImpl.setNation(StringPool.BLANK);
		}
		else {
			equityHoldersImpl.setNation(nation);
		}

		equityHoldersImpl.resetOriginalValues();

		return equityHoldersImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		equityholdersid = objectInput.readLong();
		bilId = objectInput.readLong();
		name = objectInput.readUTF();
		kpLama = objectInput.readUTF();
		newKp = objectInput.readUTF();
		value = objectInput.readUTF();
		percent = objectInput.readUTF();
		gender = objectInput.readUTF();
		nation = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(equityholdersid);
		objectOutput.writeLong(bilId);

		if (name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (kpLama == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(kpLama);
		}

		if (newKp == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(newKp);
		}

		if (value == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(value);
		}

		if (percent == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(percent);
		}

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (nation == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nation);
		}
	}

	public long equityholdersid;
	public long bilId;
	public String name;
	public String kpLama;
	public String newKp;
	public String value;
	public String percent;
	public String gender;
	public String nation;
}