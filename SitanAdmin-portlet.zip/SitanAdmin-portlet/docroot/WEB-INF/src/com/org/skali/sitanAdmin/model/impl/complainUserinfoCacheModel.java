/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.complainUserinfo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing complainUserinfo in entity cache.
 *
 * @author reeshu
 * @see complainUserinfo
 * @generated
 */
public class complainUserinfoCacheModel implements CacheModel<complainUserinfo>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(57);

		sb.append("{complainUserId=");
		sb.append(complainUserId);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", prefix=");
		sb.append(prefix);
		sb.append(", name=");
		sb.append(name);
		sb.append(", identificationnumber=");
		sb.append(identificationnumber);
		sb.append(", passport=");
		sb.append(passport);
		sb.append(", citizen=");
		sb.append(citizen);
		sb.append(", nation=");
		sb.append(nation);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", age=");
		sb.append(age);
		sb.append(", phoneNo=");
		sb.append(phoneNo);
		sb.append(", cellPhones=");
		sb.append(cellPhones);
		sb.append(", address=");
		sb.append(address);
		sb.append(", email=");
		sb.append(email);
		sb.append(", state=");
		sb.append(state);
		sb.append(", dName=");
		sb.append(dName);
		sb.append(", didentificationnumber=");
		sb.append(didentificationnumber);
		sb.append(", dateofbirth=");
		sb.append(dateofbirth);
		sb.append(", dcitizen=");
		sb.append(dcitizen);
		sb.append(", driverNation=");
		sb.append(driverNation);
		sb.append(", drivergender=");
		sb.append(drivergender);
		sb.append(", driverAge=");
		sb.append(driverAge);
		sb.append(", retirees=");
		sb.append(retirees);
		sb.append(", statusReadPSV=");
		sb.append(statusReadPSV);
		sb.append(", driverLicense=");
		sb.append(driverLicense);
		sb.append(", dphone=");
		sb.append(dphone);
		sb.append(", dphoneTwo=");
		sb.append(dphoneTwo);
		sb.append(", daddress=");
		sb.append(daddress);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public complainUserinfo toEntityModel() {
		complainUserinfoImpl complainUserinfoImpl = new complainUserinfoImpl();

		complainUserinfoImpl.setComplainUserId(complainUserId);
		complainUserinfoImpl.setBilId(bilId);

		if (prefix == null) {
			complainUserinfoImpl.setPrefix(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setPrefix(prefix);
		}

		if (name == null) {
			complainUserinfoImpl.setName(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setName(name);
		}

		if (identificationnumber == null) {
			complainUserinfoImpl.setIdentificationnumber(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setIdentificationnumber(identificationnumber);
		}

		if (passport == null) {
			complainUserinfoImpl.setPassport(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setPassport(passport);
		}

		if (citizen == null) {
			complainUserinfoImpl.setCitizen(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setCitizen(citizen);
		}

		if (nation == null) {
			complainUserinfoImpl.setNation(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setNation(nation);
		}

		if (gender == null) {
			complainUserinfoImpl.setGender(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setGender(gender);
		}

		complainUserinfoImpl.setAge(age);

		if (phoneNo == null) {
			complainUserinfoImpl.setPhoneNo(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setPhoneNo(phoneNo);
		}

		if (cellPhones == null) {
			complainUserinfoImpl.setCellPhones(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setCellPhones(cellPhones);
		}

		if (address == null) {
			complainUserinfoImpl.setAddress(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setAddress(address);
		}

		if (email == null) {
			complainUserinfoImpl.setEmail(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setEmail(email);
		}

		if (state == null) {
			complainUserinfoImpl.setState(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setState(state);
		}

		if (dName == null) {
			complainUserinfoImpl.setDName(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDName(dName);
		}

		if (didentificationnumber == null) {
			complainUserinfoImpl.setDidentificationnumber(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDidentificationnumber(didentificationnumber);
		}

		if (dateofbirth == null) {
			complainUserinfoImpl.setDateofbirth(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDateofbirth(dateofbirth);
		}

		if (dcitizen == null) {
			complainUserinfoImpl.setDcitizen(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDcitizen(dcitizen);
		}

		if (driverNation == null) {
			complainUserinfoImpl.setDriverNation(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDriverNation(driverNation);
		}

		if (drivergender == null) {
			complainUserinfoImpl.setDrivergender(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDrivergender(drivergender);
		}

		complainUserinfoImpl.setDriverAge(driverAge);

		if (retirees == null) {
			complainUserinfoImpl.setRetirees(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setRetirees(retirees);
		}

		complainUserinfoImpl.setStatusReadPSV(statusReadPSV);

		if (driverLicense == null) {
			complainUserinfoImpl.setDriverLicense(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDriverLicense(driverLicense);
		}

		if (dphone == null) {
			complainUserinfoImpl.setDphone(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDphone(dphone);
		}

		if (dphoneTwo == null) {
			complainUserinfoImpl.setDphoneTwo(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDphoneTwo(dphoneTwo);
		}

		if (daddress == null) {
			complainUserinfoImpl.setDaddress(StringPool.BLANK);
		}
		else {
			complainUserinfoImpl.setDaddress(daddress);
		}

		complainUserinfoImpl.resetOriginalValues();

		return complainUserinfoImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		complainUserId = objectInput.readLong();
		bilId = objectInput.readLong();
		prefix = objectInput.readUTF();
		name = objectInput.readUTF();
		identificationnumber = objectInput.readUTF();
		passport = objectInput.readUTF();
		citizen = objectInput.readUTF();
		nation = objectInput.readUTF();
		gender = objectInput.readUTF();
		age = objectInput.readLong();
		phoneNo = objectInput.readUTF();
		cellPhones = objectInput.readUTF();
		address = objectInput.readUTF();
		email = objectInput.readUTF();
		state = objectInput.readUTF();
		dName = objectInput.readUTF();
		didentificationnumber = objectInput.readUTF();
		dateofbirth = objectInput.readUTF();
		dcitizen = objectInput.readUTF();
		driverNation = objectInput.readUTF();
		drivergender = objectInput.readUTF();
		driverAge = objectInput.readLong();
		retirees = objectInput.readUTF();
		statusReadPSV = objectInput.readLong();
		driverLicense = objectInput.readUTF();
		dphone = objectInput.readUTF();
		dphoneTwo = objectInput.readUTF();
		daddress = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(complainUserId);
		objectOutput.writeLong(bilId);

		if (prefix == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(prefix);
		}

		if (name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (identificationnumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(identificationnumber);
		}

		if (passport == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(passport);
		}

		if (citizen == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(citizen);
		}

		if (nation == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nation);
		}

		if (gender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(gender);
		}

		objectOutput.writeLong(age);

		if (phoneNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(phoneNo);
		}

		if (cellPhones == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(cellPhones);
		}

		if (address == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (state == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (dName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dName);
		}

		if (didentificationnumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(didentificationnumber);
		}

		if (dateofbirth == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofbirth);
		}

		if (dcitizen == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dcitizen);
		}

		if (driverNation == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(driverNation);
		}

		if (drivergender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(drivergender);
		}

		objectOutput.writeLong(driverAge);

		if (retirees == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(retirees);
		}

		objectOutput.writeLong(statusReadPSV);

		if (driverLicense == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(driverLicense);
		}

		if (dphone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dphone);
		}

		if (dphoneTwo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dphoneTwo);
		}

		if (daddress == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(daddress);
		}
	}

	public long complainUserId;
	public long bilId;
	public String prefix;
	public String name;
	public String identificationnumber;
	public String passport;
	public String citizen;
	public String nation;
	public String gender;
	public long age;
	public String phoneNo;
	public String cellPhones;
	public String address;
	public String email;
	public String state;
	public String dName;
	public String didentificationnumber;
	public String dateofbirth;
	public String dcitizen;
	public String driverNation;
	public String drivergender;
	public long driverAge;
	public String retirees;
	public long statusReadPSV;
	public String driverLicense;
	public String dphone;
	public String dphoneTwo;
	public String daddress;
}