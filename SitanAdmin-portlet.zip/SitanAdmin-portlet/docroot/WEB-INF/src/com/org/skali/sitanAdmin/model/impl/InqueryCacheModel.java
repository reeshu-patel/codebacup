/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.Inquery;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Inquery in entity cache.
 *
 * @author reeshu
 * @see Inquery
 * @generated
 */
public class InqueryCacheModel implements CacheModel<Inquery>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{inqueryId=");
		sb.append(inqueryId);
		sb.append(", datesize=");
		sb.append(datesize);
		sb.append(", checkSitesDate=");
		sb.append(checkSitesDate);
		sb.append(", referenceEffective=");
		sb.append(referenceEffective);
		sb.append(", source=");
		sb.append(source);
		sb.append(", nameofowner=");
		sb.append(nameofowner);
		sb.append(", vehicleRegistration=");
		sb.append(vehicleRegistration);
		sb.append(", territory=");
		sb.append(territory);
		sb.append(", state=");
		sb.append(state);
		sb.append(", locationCageSita=");
		sb.append(locationCageSita);
		sb.append(", foreclosureStatus=");
		sb.append(foreclosureStatus);
		sb.append(", nameOfofficer=");
		sb.append(nameOfofficer);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Inquery toEntityModel() {
		InqueryImpl inqueryImpl = new InqueryImpl();

		inqueryImpl.setInqueryId(inqueryId);

		if (datesize == null) {
			inqueryImpl.setDatesize(StringPool.BLANK);
		}
		else {
			inqueryImpl.setDatesize(datesize);
		}

		if (checkSitesDate == null) {
			inqueryImpl.setCheckSitesDate(StringPool.BLANK);
		}
		else {
			inqueryImpl.setCheckSitesDate(checkSitesDate);
		}

		if (referenceEffective == null) {
			inqueryImpl.setReferenceEffective(StringPool.BLANK);
		}
		else {
			inqueryImpl.setReferenceEffective(referenceEffective);
		}

		if (source == null) {
			inqueryImpl.setSource(StringPool.BLANK);
		}
		else {
			inqueryImpl.setSource(source);
		}

		if (nameofowner == null) {
			inqueryImpl.setNameofowner(StringPool.BLANK);
		}
		else {
			inqueryImpl.setNameofowner(nameofowner);
		}

		if (vehicleRegistration == null) {
			inqueryImpl.setVehicleRegistration(StringPool.BLANK);
		}
		else {
			inqueryImpl.setVehicleRegistration(vehicleRegistration);
		}

		if (territory == null) {
			inqueryImpl.setTerritory(StringPool.BLANK);
		}
		else {
			inqueryImpl.setTerritory(territory);
		}

		if (state == null) {
			inqueryImpl.setState(StringPool.BLANK);
		}
		else {
			inqueryImpl.setState(state);
		}

		if (locationCageSita == null) {
			inqueryImpl.setLocationCageSita(StringPool.BLANK);
		}
		else {
			inqueryImpl.setLocationCageSita(locationCageSita);
		}

		if (foreclosureStatus == null) {
			inqueryImpl.setForeclosureStatus(StringPool.BLANK);
		}
		else {
			inqueryImpl.setForeclosureStatus(foreclosureStatus);
		}

		if (nameOfofficer == null) {
			inqueryImpl.setNameOfofficer(StringPool.BLANK);
		}
		else {
			inqueryImpl.setNameOfofficer(nameOfofficer);
		}

		inqueryImpl.resetOriginalValues();

		return inqueryImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		inqueryId = objectInput.readLong();
		datesize = objectInput.readUTF();
		checkSitesDate = objectInput.readUTF();
		referenceEffective = objectInput.readUTF();
		source = objectInput.readUTF();
		nameofowner = objectInput.readUTF();
		vehicleRegistration = objectInput.readUTF();
		territory = objectInput.readUTF();
		state = objectInput.readUTF();
		locationCageSita = objectInput.readUTF();
		foreclosureStatus = objectInput.readUTF();
		nameOfofficer = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(inqueryId);

		if (datesize == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(datesize);
		}

		if (checkSitesDate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(checkSitesDate);
		}

		if (referenceEffective == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(referenceEffective);
		}

		if (source == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(source);
		}

		if (nameofowner == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameofowner);
		}

		if (vehicleRegistration == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleRegistration);
		}

		if (territory == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(territory);
		}

		if (state == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (locationCageSita == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(locationCageSita);
		}

		if (foreclosureStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(foreclosureStatus);
		}

		if (nameOfofficer == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameOfofficer);
		}
	}

	public long inqueryId;
	public String datesize;
	public String checkSitesDate;
	public String referenceEffective;
	public String source;
	public String nameofowner;
	public String vehicleRegistration;
	public String territory;
	public String state;
	public String locationCageSita;
	public String foreclosureStatus;
	public String nameOfofficer;
}