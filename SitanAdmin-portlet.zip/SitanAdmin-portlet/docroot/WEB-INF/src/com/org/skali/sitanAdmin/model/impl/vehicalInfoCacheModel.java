/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.vehicalInfo;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing vehicalInfo in entity cache.
 *
 * @author reeshu
 * @see vehicalInfo
 * @generated
 */
public class vehicalInfoCacheModel implements CacheModel<vehicalInfo>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(47);

		sb.append("{vehicalId=");
		sb.append(vehicalId);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", brands=");
		sb.append(brands);
		sb.append(", model=");
		sb.append(model);
		sb.append(", noEnjin=");
		sb.append(noEnjin);
		sb.append(", noCasis=");
		sb.append(noCasis);
		sb.append(", bodytype=");
		sb.append(bodytype);
		sb.append(", color=");
		sb.append(color);
		sb.append(", vehicleRegistrationNo=");
		sb.append(vehicleRegistrationNo);
		sb.append(", yearbuilt=");
		sb.append(yearbuilt);
		sb.append(", dateofVehicles=");
		sb.append(dateofVehicles);
		sb.append(", temporaryLicenses=");
		sb.append(temporaryLicenses);
		sb.append(", numberofPassengers=");
		sb.append(numberofPassengers);
		sb.append(", seatingNumber=");
		sb.append(seatingNumber);
		sb.append(", operatingArea=");
		sb.append(operatingArea);
		sb.append(", typeofservice=");
		sb.append(typeofservice);
		sb.append(", readStatus=");
		sb.append(readStatus);
		sb.append(", bdm=");
		sb.append(bdm);
		sb.append(", btm=");
		sb.append(btm);
		sb.append(", bt1=");
		sb.append(bt1);
		sb.append(", investigatorname=");
		sb.append(investigatorname);
		sb.append(", investigatorphone=");
		sb.append(investigatorphone);
		sb.append(", investigatorEmail=");
		sb.append(investigatorEmail);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public vehicalInfo toEntityModel() {
		vehicalInfoImpl vehicalInfoImpl = new vehicalInfoImpl();

		vehicalInfoImpl.setVehicalId(vehicalId);
		vehicalInfoImpl.setBilId(bilId);

		if (brands == null) {
			vehicalInfoImpl.setBrands(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setBrands(brands);
		}

		if (model == null) {
			vehicalInfoImpl.setModel(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setModel(model);
		}

		vehicalInfoImpl.setNoEnjin(noEnjin);
		vehicalInfoImpl.setNoCasis(noCasis);

		if (bodytype == null) {
			vehicalInfoImpl.setBodytype(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setBodytype(bodytype);
		}

		if (color == null) {
			vehicalInfoImpl.setColor(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setColor(color);
		}

		if (vehicleRegistrationNo == null) {
			vehicalInfoImpl.setVehicleRegistrationNo(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setVehicleRegistrationNo(vehicleRegistrationNo);
		}

		if (yearbuilt == null) {
			vehicalInfoImpl.setYearbuilt(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setYearbuilt(yearbuilt);
		}

		if (dateofVehicles == null) {
			vehicalInfoImpl.setDateofVehicles(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setDateofVehicles(dateofVehicles);
		}

		if (temporaryLicenses == null) {
			vehicalInfoImpl.setTemporaryLicenses(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setTemporaryLicenses(temporaryLicenses);
		}

		vehicalInfoImpl.setNumberofPassengers(numberofPassengers);

		if (seatingNumber == null) {
			vehicalInfoImpl.setSeatingNumber(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setSeatingNumber(seatingNumber);
		}

		if (operatingArea == null) {
			vehicalInfoImpl.setOperatingArea(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setOperatingArea(operatingArea);
		}

		if (typeofservice == null) {
			vehicalInfoImpl.setTypeofservice(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setTypeofservice(typeofservice);
		}

		if (readStatus == null) {
			vehicalInfoImpl.setReadStatus(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setReadStatus(readStatus);
		}

		if (bdm == null) {
			vehicalInfoImpl.setBdm(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setBdm(bdm);
		}

		if (btm == null) {
			vehicalInfoImpl.setBtm(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setBtm(btm);
		}

		if (bt1 == null) {
			vehicalInfoImpl.setBt1(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setBt1(bt1);
		}

		if (investigatorname == null) {
			vehicalInfoImpl.setInvestigatorname(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setInvestigatorname(investigatorname);
		}

		if (investigatorphone == null) {
			vehicalInfoImpl.setInvestigatorphone(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setInvestigatorphone(investigatorphone);
		}

		if (investigatorEmail == null) {
			vehicalInfoImpl.setInvestigatorEmail(StringPool.BLANK);
		}
		else {
			vehicalInfoImpl.setInvestigatorEmail(investigatorEmail);
		}

		vehicalInfoImpl.resetOriginalValues();

		return vehicalInfoImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		vehicalId = objectInput.readLong();
		bilId = objectInput.readLong();
		brands = objectInput.readUTF();
		model = objectInput.readUTF();
		noEnjin = objectInput.readLong();
		noCasis = objectInput.readLong();
		bodytype = objectInput.readUTF();
		color = objectInput.readUTF();
		vehicleRegistrationNo = objectInput.readUTF();
		yearbuilt = objectInput.readUTF();
		dateofVehicles = objectInput.readUTF();
		temporaryLicenses = objectInput.readUTF();
		numberofPassengers = objectInput.readLong();
		seatingNumber = objectInput.readUTF();
		operatingArea = objectInput.readUTF();
		typeofservice = objectInput.readUTF();
		readStatus = objectInput.readUTF();
		bdm = objectInput.readUTF();
		btm = objectInput.readUTF();
		bt1 = objectInput.readUTF();
		investigatorname = objectInput.readUTF();
		investigatorphone = objectInput.readUTF();
		investigatorEmail = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(vehicalId);
		objectOutput.writeLong(bilId);

		if (brands == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(brands);
		}

		if (model == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(model);
		}

		objectOutput.writeLong(noEnjin);
		objectOutput.writeLong(noCasis);

		if (bodytype == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bodytype);
		}

		if (color == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(color);
		}

		if (vehicleRegistrationNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(vehicleRegistrationNo);
		}

		if (yearbuilt == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(yearbuilt);
		}

		if (dateofVehicles == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateofVehicles);
		}

		if (temporaryLicenses == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(temporaryLicenses);
		}

		objectOutput.writeLong(numberofPassengers);

		if (seatingNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(seatingNumber);
		}

		if (operatingArea == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(operatingArea);
		}

		if (typeofservice == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(typeofservice);
		}

		if (readStatus == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(readStatus);
		}

		if (bdm == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bdm);
		}

		if (btm == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(btm);
		}

		if (bt1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(bt1);
		}

		if (investigatorname == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorname);
		}

		if (investigatorphone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorphone);
		}

		if (investigatorEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(investigatorEmail);
		}
	}

	public long vehicalId;
	public long bilId;
	public String brands;
	public String model;
	public long noEnjin;
	public long noCasis;
	public String bodytype;
	public String color;
	public String vehicleRegistrationNo;
	public String yearbuilt;
	public String dateofVehicles;
	public String temporaryLicenses;
	public long numberofPassengers;
	public String seatingNumber;
	public String operatingArea;
	public String typeofservice;
	public String readStatus;
	public String bdm;
	public String btm;
	public String bt1;
	public String investigatorname;
	public String investigatorphone;
	public String investigatorEmail;
}