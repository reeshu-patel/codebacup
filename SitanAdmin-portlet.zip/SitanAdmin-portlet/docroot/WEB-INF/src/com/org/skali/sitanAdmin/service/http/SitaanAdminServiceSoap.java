/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.http;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil;

import java.rmi.RemoteException;

/**
 * Provides the SOAP utility for the
 * {@link com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil} service utility. The
 * static methods of this class calls the same methods of the service utility.
 * However, the signatures are different because it is difficult for SOAP to
 * support certain types.
 *
 * <p>
 * ServiceBuilder follows certain rules in translating the methods. For example,
 * if the method in the service utility returns a {@link java.util.List}, that
 * is translated to an array of {@link com.org.skali.sitanAdmin.model.SitaanAdminSoap}.
 * If the method in the service utility returns a
 * {@link com.org.skali.sitanAdmin.model.SitaanAdmin}, that is translated to a
 * {@link com.org.skali.sitanAdmin.model.SitaanAdminSoap}. Methods that SOAP cannot
 * safely wire are skipped.
 * </p>
 *
 * <p>
 * The benefits of using the SOAP utility is that it is cross platform
 * compatible. SOAP allows different languages like Java, .NET, C++, PHP, and
 * even Perl, to call the generated services. One drawback of SOAP is that it is
 * slow because it needs to serialize all calls into a text format (XML).
 * </p>
 *
 * <p>
 * You can see a list of services at http://localhost:8080/api/axis. Set the
 * property <b>axis.servlet.hosts.allowed</b> in portal.properties to configure
 * security.
 * </p>
 *
 * <p>
 * The SOAP utility is only generated for remote services.
 * </p>
 *
 * @author reeshu
 * @see SitaanAdminServiceHttp
 * @see com.org.skali.sitanAdmin.model.SitaanAdminSoap
 * @see com.org.skali.sitanAdmin.service.SitaanAdminServiceUtil
 * @generated
 */
public class SitaanAdminServiceSoap {
	public static java.lang.String FinedByColumn(java.lang.String dateSeized,
		java.lang.String checkSitesSita, java.lang.String source,
		java.lang.String ownerName, java.lang.String territory,
		java.lang.String state, java.lang.String vehicleRegistrationNo,
		java.lang.String referenceEffective,
		java.lang.String confiscatedPeriod, java.lang.String locationCageSita,
		java.lang.String foreclosureStatus,
		java.lang.String resultsforeclosure, java.lang.String officerName,
		java.lang.String action, java.lang.String paymentStatus)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.FinedByColumn(dateSeized,
					checkSitesSita, source, ownerName, territory, state,
					vehicleRegistrationNo, referenceEffective,
					confiscatedPeriod, locationCageSita, foreclosureStatus,
					resultsforeclosure, officerName, action, paymentStatus);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String FinedByBillId(long bilId)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.FinedByBillId(bilId);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static com.liferay.portal.model.UserSoap[] geCMDUsers()
		throws RemoteException {
		try {
			java.util.List<com.liferay.portal.model.User> returnValue = SitaanAdminServiceUtil.geCMDUsers();

			return com.liferay.portal.model.UserSoap.toSoapModels(returnValue);
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String ActionCaseByBillId(long bilId)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.ActionCaseByBillId(bilId);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String UploadDocumentSearch(java.lang.String title)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.UploadDocumentSearch(title);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String Document_Binding_Tree()
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONArray returnValue = SitaanAdminServiceUtil.Document_Binding_Tree();

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String Officer_List() throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.Officer_List();

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String VisualInspection(long bilId)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.VisualInspection(bilId);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static com.org.skali.sitanAdmin.model.visualchecklistSoap VisualInspectionPost(
		long checkId, long bilId, java.lang.String numberplates,
		java.lang.String numberplatesNote, java.lang.String forwardlighting,
		java.lang.String forwardlightingNote, java.lang.String backlight,
		java.lang.String backlightNote, java.lang.String trafficLight,
		java.lang.String trafficLightNote, java.lang.String signallight,
		java.lang.String signallightNote, java.lang.String vehiclebody,
		java.lang.String vehiclebodyNote, java.lang.String vehicleAccessories,
		java.lang.String vehicleAccessoriesNote, java.lang.String windscreen,
		java.lang.String windscreenNote, java.lang.String rearMirror,
		java.lang.String rearMirrorNote, java.lang.String doormirror,
		java.lang.String doormirrorNote, java.lang.String vehicletires,
		java.lang.String vehicletiresNote, java.lang.String frontbumper,
		java.lang.String frontbumperNote, java.lang.String rearbumper,
		java.lang.String rearbumperNote, java.lang.String frontseat,
		java.lang.String frontseatNote, java.lang.String rearseats,
		java.lang.String rearseatsNote, java.lang.String note,
		java.lang.String investigatorname, java.lang.String investigatorEmail,
		java.lang.String investigatorphone) throws RemoteException {
		try {
			com.org.skali.sitanAdmin.model.visualchecklist returnValue = SitaanAdminServiceUtil.VisualInspectionPost(checkId,
					bilId, numberplates, numberplatesNote, forwardlighting,
					forwardlightingNote, backlight, backlightNote,
					trafficLight, trafficLightNote, signallight,
					signallightNote, vehiclebody, vehiclebodyNote,
					vehicleAccessories, vehicleAccessoriesNote, windscreen,
					windscreenNote, rearMirror, rearMirrorNote, doormirror,
					doormirrorNote, vehicletires, vehicletiresNote,
					frontbumper, frontbumperNote, rearbumper, rearbumperNote,
					frontseat, frontseatNote, rearseats, rearseatsNote, note,
					investigatorname, investigatorEmail, investigatorphone);

			return com.org.skali.sitanAdmin.model.visualchecklistSoap.toSoapModel(returnValue);
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String SaveVisualInspection(long bilId, long checkId)
		throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.SaveVisualInspection(bilId,
					checkId);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static com.org.skali.sitanAdmin.model.AcceptanceVehicleDetailSoap AcceptaneceVehicalDetail(
		long vehicalid, long bilId, java.lang.String vehiNumberPlate,
		java.lang.String ownerName, java.lang.String companyRepresentative,
		java.lang.String kpNo, java.lang.String chronicle,
		java.lang.String Signature, java.lang.String accodocument,
		java.lang.String cardIdentity, java.lang.String drivingLicense,
		java.lang.String grantVehicle, java.lang.String attorney,
		java.lang.String numberPlateDetail) throws RemoteException {
		try {
			com.org.skali.sitanAdmin.model.AcceptanceVehicleDetail returnValue = SitaanAdminServiceUtil.AcceptaneceVehicalDetail(vehicalid,
					bilId, vehiNumberPlate, ownerName, companyRepresentative,
					kpNo, chronicle, Signature, accodocument, cardIdentity,
					drivingLicense, grantVehicle, attorney, numberPlateDetail);

			return com.org.skali.sitanAdmin.model.AcceptanceVehicleDetailSoap.toSoapModel(returnValue);
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	public static java.lang.String FileAcceptaneceVehicalDetail(
		long vehicalid, long bilId) throws RemoteException {
		try {
			com.liferay.portal.kernel.json.JSONObject returnValue = SitaanAdminServiceUtil.FileAcceptaneceVehicalDetail(vehicalid,
					bilId);

			return returnValue.toString();
		}
		catch (Exception e) {
			_log.error(e, e);

			throw new RemoteException(e.getMessage());
		}
	}

	private static Log _log = LogFactoryUtil.getLog(SitaanAdminServiceSoap.class);
}