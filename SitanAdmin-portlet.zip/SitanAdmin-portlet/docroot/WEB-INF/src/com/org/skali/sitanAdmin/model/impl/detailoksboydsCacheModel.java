/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.org.skali.sitanAdmin.model.detailoksboyds;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing detailoksboyds in entity cache.
 *
 * @author reeshu
 * @see detailoksboyds
 * @generated
 */
public class detailoksboydsCacheModel implements CacheModel<detailoksboyds>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(41);

		sb.append("{boydssId=");
		sb.append(boydssId);
		sb.append(", bilId=");
		sb.append(bilId);
		sb.append(", companyName=");
		sb.append(companyName);
		sb.append(", classOperatorLicense=");
		sb.append(classOperatorLicense);
		sb.append(", listofCompanies=");
		sb.append(listofCompanies);
		sb.append(", reRegistration=");
		sb.append(reRegistration);
		sb.append(", email=");
		sb.append(email);
		sb.append(", noReferenceFile=");
		sb.append(noReferenceFile);
		sb.append(", addressList=");
		sb.append(addressList);
		sb.append(", addressListRegistation=");
		sb.append(addressListRegistation);
		sb.append(", authorisedCapital=");
		sb.append(authorisedCapital);
		sb.append(", accruedCapital=");
		sb.append(accruedCapital);
		sb.append(", capitalPaid=");
		sb.append(capitalPaid);
		sb.append(", ComRegNo=");
		sb.append(ComRegNo);
		sb.append(", nationOwner=");
		sb.append(nationOwner);
		sb.append(", dateListofCompanies=");
		sb.append(dateListofCompanies);
		sb.append(", activity=");
		sb.append(activity);
		sb.append(", phoneNo=");
		sb.append(phoneNo);
		sb.append(", faxNo=");
		sb.append(faxNo);
		sb.append(", lastUpdateDate=");
		sb.append(lastUpdateDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public detailoksboyds toEntityModel() {
		detailoksboydsImpl detailoksboydsImpl = new detailoksboydsImpl();

		detailoksboydsImpl.setBoydssId(boydssId);
		detailoksboydsImpl.setBilId(bilId);

		if (companyName == null) {
			detailoksboydsImpl.setCompanyName(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setCompanyName(companyName);
		}

		if (classOperatorLicense == null) {
			detailoksboydsImpl.setClassOperatorLicense(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setClassOperatorLicense(classOperatorLicense);
		}

		if (listofCompanies == null) {
			detailoksboydsImpl.setListofCompanies(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setListofCompanies(listofCompanies);
		}

		if (reRegistration == null) {
			detailoksboydsImpl.setReRegistration(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setReRegistration(reRegistration);
		}

		if (email == null) {
			detailoksboydsImpl.setEmail(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setEmail(email);
		}

		if (noReferenceFile == null) {
			detailoksboydsImpl.setNoReferenceFile(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setNoReferenceFile(noReferenceFile);
		}

		if (addressList == null) {
			detailoksboydsImpl.setAddressList(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setAddressList(addressList);
		}

		if (addressListRegistation == null) {
			detailoksboydsImpl.setAddressListRegistation(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setAddressListRegistation(addressListRegistation);
		}

		if (authorisedCapital == null) {
			detailoksboydsImpl.setAuthorisedCapital(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setAuthorisedCapital(authorisedCapital);
		}

		detailoksboydsImpl.setAccruedCapital(accruedCapital);

		if (capitalPaid == null) {
			detailoksboydsImpl.setCapitalPaid(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setCapitalPaid(capitalPaid);
		}

		detailoksboydsImpl.setComRegNo(ComRegNo);

		if (nationOwner == null) {
			detailoksboydsImpl.setNationOwner(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setNationOwner(nationOwner);
		}

		if (dateListofCompanies == null) {
			detailoksboydsImpl.setDateListofCompanies(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setDateListofCompanies(dateListofCompanies);
		}

		if (activity == null) {
			detailoksboydsImpl.setActivity(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setActivity(activity);
		}

		if (phoneNo == null) {
			detailoksboydsImpl.setPhoneNo(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setPhoneNo(phoneNo);
		}

		if (faxNo == null) {
			detailoksboydsImpl.setFaxNo(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setFaxNo(faxNo);
		}

		if (lastUpdateDate == null) {
			detailoksboydsImpl.setLastUpdateDate(StringPool.BLANK);
		}
		else {
			detailoksboydsImpl.setLastUpdateDate(lastUpdateDate);
		}

		detailoksboydsImpl.resetOriginalValues();

		return detailoksboydsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		boydssId = objectInput.readLong();
		bilId = objectInput.readLong();
		companyName = objectInput.readUTF();
		classOperatorLicense = objectInput.readUTF();
		listofCompanies = objectInput.readUTF();
		reRegistration = objectInput.readUTF();
		email = objectInput.readUTF();
		noReferenceFile = objectInput.readUTF();
		addressList = objectInput.readUTF();
		addressListRegistation = objectInput.readUTF();
		authorisedCapital = objectInput.readUTF();
		accruedCapital = objectInput.readLong();
		capitalPaid = objectInput.readUTF();
		ComRegNo = objectInput.readLong();
		nationOwner = objectInput.readUTF();
		dateListofCompanies = objectInput.readUTF();
		activity = objectInput.readUTF();
		phoneNo = objectInput.readUTF();
		faxNo = objectInput.readUTF();
		lastUpdateDate = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(boydssId);
		objectOutput.writeLong(bilId);

		if (companyName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(companyName);
		}

		if (classOperatorLicense == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(classOperatorLicense);
		}

		if (listofCompanies == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(listofCompanies);
		}

		if (reRegistration == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(reRegistration);
		}

		if (email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (noReferenceFile == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(noReferenceFile);
		}

		if (addressList == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(addressList);
		}

		if (addressListRegistation == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(addressListRegistation);
		}

		if (authorisedCapital == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(authorisedCapital);
		}

		objectOutput.writeLong(accruedCapital);

		if (capitalPaid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(capitalPaid);
		}

		objectOutput.writeLong(ComRegNo);

		if (nationOwner == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nationOwner);
		}

		if (dateListofCompanies == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(dateListofCompanies);
		}

		if (activity == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(activity);
		}

		if (phoneNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(phoneNo);
		}

		if (faxNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(faxNo);
		}

		if (lastUpdateDate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(lastUpdateDate);
		}
	}

	public long boydssId;
	public long bilId;
	public String companyName;
	public String classOperatorLicense;
	public String listofCompanies;
	public String reRegistration;
	public String email;
	public String noReferenceFile;
	public String addressList;
	public String addressListRegistation;
	public String authorisedCapital;
	public long accruedCapital;
	public String capitalPaid;
	public long ComRegNo;
	public String nationOwner;
	public String dateListofCompanies;
	public String activity;
	public String phoneNo;
	public String faxNo;
	public String lastUpdateDate;
}