/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of the Liferay Enterprise
 * Subscription License ("License"). You may not use this file except in
 * compliance with the License. You can obtain a copy of the License by
 * contacting Liferay, Inc. See the License for the specific language governing
 * permissions and limitations under the License, including but not limited to
 * distribution rights of the Software.
 *
 *
 *
 */

package com.org.skali.sitanAdmin.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.org.skali.sitanAdmin.NoSuchOfficerDetailException;
import com.org.skali.sitanAdmin.model.OfficerDetail;
import com.org.skali.sitanAdmin.model.impl.OfficerDetailImpl;
import com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the officer detail service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author reeshu
 * @see OfficerDetailPersistence
 * @see OfficerDetailUtil
 * @generated
 */
public class OfficerDetailPersistenceImpl extends BasePersistenceImpl<OfficerDetail>
	implements OfficerDetailPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link OfficerDetailUtil} to access the officer detail persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = OfficerDetailImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED,
			OfficerDetailImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED,
			OfficerDetailImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_OFFICERID =
		new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED,
			OfficerDetailImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByofficerid",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERID =
		new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED,
			OfficerDetailImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByofficerid", new String[] { Long.class.getName() },
			OfficerDetailModelImpl.OFFICERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_OFFICERID = new FinderPath(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByofficerid",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the officer details where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @return the matching officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findByofficerid(long officerid)
		throws SystemException {
		return findByofficerid(officerid, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the officer details where officerid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param officerid the officerid
	 * @param start the lower bound of the range of officer details
	 * @param end the upper bound of the range of officer details (not inclusive)
	 * @return the range of matching officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findByofficerid(long officerid, int start,
		int end) throws SystemException {
		return findByofficerid(officerid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the officer details where officerid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param officerid the officerid
	 * @param start the lower bound of the range of officer details
	 * @param end the upper bound of the range of officer details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findByofficerid(long officerid, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERID;
			finderArgs = new Object[] { officerid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_OFFICERID;
			finderArgs = new Object[] { officerid, start, end, orderByComparator };
		}

		List<OfficerDetail> list = (List<OfficerDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (OfficerDetail officerDetail : list) {
				if ((officerid != officerDetail.getOfficerid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_OFFICERDETAIL_WHERE);

			query.append(_FINDER_COLUMN_OFFICERID_OFFICERID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(OfficerDetailModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(officerid);

				if (!pagination) {
					list = (List<OfficerDetail>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<OfficerDetail>(list);
				}
				else {
					list = (List<OfficerDetail>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first officer detail in the ordered set where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching officer detail
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail findByofficerid_First(long officerid,
		OrderByComparator orderByComparator)
		throws NoSuchOfficerDetailException, SystemException {
		OfficerDetail officerDetail = fetchByofficerid_First(officerid,
				orderByComparator);

		if (officerDetail != null) {
			return officerDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("officerid=");
		msg.append(officerid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchOfficerDetailException(msg.toString());
	}

	/**
	 * Returns the first officer detail in the ordered set where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching officer detail, or <code>null</code> if a matching officer detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail fetchByofficerid_First(long officerid,
		OrderByComparator orderByComparator) throws SystemException {
		List<OfficerDetail> list = findByofficerid(officerid, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last officer detail in the ordered set where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching officer detail
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a matching officer detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail findByofficerid_Last(long officerid,
		OrderByComparator orderByComparator)
		throws NoSuchOfficerDetailException, SystemException {
		OfficerDetail officerDetail = fetchByofficerid_Last(officerid,
				orderByComparator);

		if (officerDetail != null) {
			return officerDetail;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("officerid=");
		msg.append(officerid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchOfficerDetailException(msg.toString());
	}

	/**
	 * Returns the last officer detail in the ordered set where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching officer detail, or <code>null</code> if a matching officer detail could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail fetchByofficerid_Last(long officerid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByofficerid(officerid);

		if (count == 0) {
			return null;
		}

		List<OfficerDetail> list = findByofficerid(officerid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the officer details where officerid = &#63; from the database.
	 *
	 * @param officerid the officerid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByofficerid(long officerid) throws SystemException {
		for (OfficerDetail officerDetail : findByofficerid(officerid,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(officerDetail);
		}
	}

	/**
	 * Returns the number of officer details where officerid = &#63;.
	 *
	 * @param officerid the officerid
	 * @return the number of matching officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByofficerid(long officerid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_OFFICERID;

		Object[] finderArgs = new Object[] { officerid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_OFFICERDETAIL_WHERE);

			query.append(_FINDER_COLUMN_OFFICERID_OFFICERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(officerid);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_OFFICERID_OFFICERID_2 = "officerDetail.officerid = ?";

	public OfficerDetailPersistenceImpl() {
		setModelClass(OfficerDetail.class);
	}

	/**
	 * Caches the officer detail in the entity cache if it is enabled.
	 *
	 * @param officerDetail the officer detail
	 */
	@Override
	public void cacheResult(OfficerDetail officerDetail) {
		EntityCacheUtil.putResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailImpl.class, officerDetail.getPrimaryKey(),
			officerDetail);

		officerDetail.resetOriginalValues();
	}

	/**
	 * Caches the officer details in the entity cache if it is enabled.
	 *
	 * @param officerDetails the officer details
	 */
	@Override
	public void cacheResult(List<OfficerDetail> officerDetails) {
		for (OfficerDetail officerDetail : officerDetails) {
			if (EntityCacheUtil.getResult(
						OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
						OfficerDetailImpl.class, officerDetail.getPrimaryKey()) == null) {
				cacheResult(officerDetail);
			}
			else {
				officerDetail.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all officer details.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(OfficerDetailImpl.class.getName());
		}

		EntityCacheUtil.clearCache(OfficerDetailImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the officer detail.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(OfficerDetail officerDetail) {
		EntityCacheUtil.removeResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailImpl.class, officerDetail.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<OfficerDetail> officerDetails) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (OfficerDetail officerDetail : officerDetails) {
			EntityCacheUtil.removeResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
				OfficerDetailImpl.class, officerDetail.getPrimaryKey());
		}
	}

	/**
	 * Creates a new officer detail with the primary key. Does not add the officer detail to the database.
	 *
	 * @param officerid the primary key for the new officer detail
	 * @return the new officer detail
	 */
	@Override
	public OfficerDetail create(long officerid) {
		OfficerDetail officerDetail = new OfficerDetailImpl();

		officerDetail.setNew(true);
		officerDetail.setPrimaryKey(officerid);

		return officerDetail;
	}

	/**
	 * Removes the officer detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param officerid the primary key of the officer detail
	 * @return the officer detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail remove(long officerid)
		throws NoSuchOfficerDetailException, SystemException {
		return remove((Serializable)officerid);
	}

	/**
	 * Removes the officer detail with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the officer detail
	 * @return the officer detail that was removed
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail remove(Serializable primaryKey)
		throws NoSuchOfficerDetailException, SystemException {
		Session session = null;

		try {
			session = openSession();

			OfficerDetail officerDetail = (OfficerDetail)session.get(OfficerDetailImpl.class,
					primaryKey);

			if (officerDetail == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchOfficerDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(officerDetail);
		}
		catch (NoSuchOfficerDetailException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected OfficerDetail removeImpl(OfficerDetail officerDetail)
		throws SystemException {
		officerDetail = toUnwrappedModel(officerDetail);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(officerDetail)) {
				officerDetail = (OfficerDetail)session.get(OfficerDetailImpl.class,
						officerDetail.getPrimaryKeyObj());
			}

			if (officerDetail != null) {
				session.delete(officerDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (officerDetail != null) {
			clearCache(officerDetail);
		}

		return officerDetail;
	}

	@Override
	public OfficerDetail updateImpl(
		com.org.skali.sitanAdmin.model.OfficerDetail officerDetail)
		throws SystemException {
		officerDetail = toUnwrappedModel(officerDetail);

		boolean isNew = officerDetail.isNew();

		OfficerDetailModelImpl officerDetailModelImpl = (OfficerDetailModelImpl)officerDetail;

		Session session = null;

		try {
			session = openSession();

			if (officerDetail.isNew()) {
				session.save(officerDetail);

				officerDetail.setNew(false);
			}
			else {
				session.merge(officerDetail);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !OfficerDetailModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((officerDetailModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						officerDetailModelImpl.getOriginalOfficerid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OFFICERID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERID,
					args);

				args = new Object[] { officerDetailModelImpl.getOfficerid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_OFFICERID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_OFFICERID,
					args);
			}
		}

		EntityCacheUtil.putResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
			OfficerDetailImpl.class, officerDetail.getPrimaryKey(),
			officerDetail);

		return officerDetail;
	}

	protected OfficerDetail toUnwrappedModel(OfficerDetail officerDetail) {
		if (officerDetail instanceof OfficerDetailImpl) {
			return officerDetail;
		}

		OfficerDetailImpl officerDetailImpl = new OfficerDetailImpl();

		officerDetailImpl.setNew(officerDetail.isNew());
		officerDetailImpl.setPrimaryKey(officerDetail.getPrimaryKey());

		officerDetailImpl.setOfficerid(officerDetail.getOfficerid());
		officerDetailImpl.setOfficername(officerDetail.getOfficername());
		officerDetailImpl.setOfficertype(officerDetail.getOfficertype());
		officerDetailImpl.setOffice(officerDetail.getOffice());
		officerDetailImpl.setOfficerpower(officerDetail.getOfficerpower());
		officerDetailImpl.setDate(officerDetail.getDate());
		officerDetailImpl.setOfficerphone(officerDetail.getOfficerphone());
		officerDetailImpl.setOfficerEmail(officerDetail.getOfficerEmail());

		return officerDetailImpl;
	}

	/**
	 * Returns the officer detail with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the officer detail
	 * @return the officer detail
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail findByPrimaryKey(Serializable primaryKey)
		throws NoSuchOfficerDetailException, SystemException {
		OfficerDetail officerDetail = fetchByPrimaryKey(primaryKey);

		if (officerDetail == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchOfficerDetailException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return officerDetail;
	}

	/**
	 * Returns the officer detail with the primary key or throws a {@link com.org.skali.sitanAdmin.NoSuchOfficerDetailException} if it could not be found.
	 *
	 * @param officerid the primary key of the officer detail
	 * @return the officer detail
	 * @throws com.org.skali.sitanAdmin.NoSuchOfficerDetailException if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail findByPrimaryKey(long officerid)
		throws NoSuchOfficerDetailException, SystemException {
		return findByPrimaryKey((Serializable)officerid);
	}

	/**
	 * Returns the officer detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the officer detail
	 * @return the officer detail, or <code>null</code> if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		OfficerDetail officerDetail = (OfficerDetail)EntityCacheUtil.getResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
				OfficerDetailImpl.class, primaryKey);

		if (officerDetail == _nullOfficerDetail) {
			return null;
		}

		if (officerDetail == null) {
			Session session = null;

			try {
				session = openSession();

				officerDetail = (OfficerDetail)session.get(OfficerDetailImpl.class,
						primaryKey);

				if (officerDetail != null) {
					cacheResult(officerDetail);
				}
				else {
					EntityCacheUtil.putResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
						OfficerDetailImpl.class, primaryKey, _nullOfficerDetail);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(OfficerDetailModelImpl.ENTITY_CACHE_ENABLED,
					OfficerDetailImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return officerDetail;
	}

	/**
	 * Returns the officer detail with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param officerid the primary key of the officer detail
	 * @return the officer detail, or <code>null</code> if a officer detail with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OfficerDetail fetchByPrimaryKey(long officerid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)officerid);
	}

	/**
	 * Returns all the officer details.
	 *
	 * @return the officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the officer details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of officer details
	 * @param end the upper bound of the range of officer details (not inclusive)
	 * @return the range of officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the officer details.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.org.skali.sitanAdmin.model.impl.OfficerDetailModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of officer details
	 * @param end the upper bound of the range of officer details (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OfficerDetail> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<OfficerDetail> list = (List<OfficerDetail>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_OFFICERDETAIL);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_OFFICERDETAIL;

				if (pagination) {
					sql = sql.concat(OfficerDetailModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<OfficerDetail>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<OfficerDetail>(list);
				}
				else {
					list = (List<OfficerDetail>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the officer details from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (OfficerDetail officerDetail : findAll()) {
			remove(officerDetail);
		}
	}

	/**
	 * Returns the number of officer details.
	 *
	 * @return the number of officer details
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_OFFICERDETAIL);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the officer detail persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.org.skali.sitanAdmin.model.OfficerDetail")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<OfficerDetail>> listenersList = new ArrayList<ModelListener<OfficerDetail>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<OfficerDetail>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(OfficerDetailImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_OFFICERDETAIL = "SELECT officerDetail FROM OfficerDetail officerDetail";
	private static final String _SQL_SELECT_OFFICERDETAIL_WHERE = "SELECT officerDetail FROM OfficerDetail officerDetail WHERE ";
	private static final String _SQL_COUNT_OFFICERDETAIL = "SELECT COUNT(officerDetail) FROM OfficerDetail officerDetail";
	private static final String _SQL_COUNT_OFFICERDETAIL_WHERE = "SELECT COUNT(officerDetail) FROM OfficerDetail officerDetail WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "officerDetail.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No OfficerDetail exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No OfficerDetail exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(OfficerDetailPersistenceImpl.class);
	private static OfficerDetail _nullOfficerDetail = new OfficerDetailImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<OfficerDetail> toCacheModel() {
				return _nullOfficerDetailCacheModel;
			}
		};

	private static CacheModel<OfficerDetail> _nullOfficerDetailCacheModel = new CacheModel<OfficerDetail>() {
			@Override
			public OfficerDetail toEntityModel() {
				return _nullOfficerDetail;
			}
		};
}